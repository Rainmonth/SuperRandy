package com.hhdd.kada.module.story;

public class StoryCollectionModel implements StoryCollectionContract.Model {
    @Override
    public void getCollectionDetail(long collectionId) {

    }

    @Override
    public void getHistoryResumePlayData(long collectionId) {

    }
}
