package com.hhdd.kada.module.story;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.hhdd.kada.R;
import com.hhdd.kada.app.fragment.FragmentFlipper;
import com.hhdd.kada.base.BaseFragmentActivity;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.logger.LogHelper;

/**
 * created by zhc on 2018/11/12
 */
public class NewStoryCollectionActivity extends BaseFragmentActivity {
    private static final String TAG = "StoryCollection";

    public static final String FRAGMENT_STORY_COLLECTION = "storyCollectionFragment";

    public static final String COLLECTION_ID = "collectionId";
    public static final String COLLECTION_MODEL = "collectionModel";

    public static void start(Context ctx, long collectionId) {
        if (ctx == null) {
            return;
        }
        try {
            Intent intent = new Intent(ctx, NewStoryCollectionActivity.class);
            intent.putExtra(COLLECTION_ID, collectionId);
            ctx.startActivity(intent);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
    }

    /**
     * 兼容老的传值方式
     */
    @Deprecated
    public static void start(Context ctx, BaseCollectionFragment.CollectionModel collectionModel) {
        if (ctx == null) {
            return;
        }
        try {
            Intent intent = new Intent(ctx, NewStoryCollectionActivity.class);
            intent.putExtra(COLLECTION_MODEL, collectionModel);
            ctx.startActivity(intent);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_story_collection_new;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (intent != null) {
            // 获取传递过来的数据
            long mCollectionId = intent.getLongExtra(COLLECTION_ID, 0);
            if (mCollectionId == 0) { // 说明采用的不是传递collectionId方式进入的
                BaseCollectionFragment.CollectionModel mCollectionModel = (BaseCollectionFragment.CollectionModel)
                        intent.getSerializableExtra(COLLECTION_MODEL);
                if (mCollectionModel != null) {
                    mCollectionId = mCollectionModel.getCollectId();
                }
                if (mCollectionId == 0) {
                    LogHelper.e(TAG, "Enter StoryCollection with wrong collectionId!!!");
                    return;
                }
            }
            LogHelper.d(TAG, "Enter StoryCollection with collectionId:" + mCollectionId);
            // 将传递过来的数据设置到Fragment中
            StoryCollectionFragment mStoryCollectionFragment = new StoryCollectionFragment();
            // 统一传递collectionId到相应的Fragment中
            mStoryCollectionFragment.onEnter(mCollectionId);

            // 添加Fragment
            FragmentFlipper mFragmentFlipper = new FragmentFlipper(getSupportFragmentManager());
            mFragmentFlipper.addFragment(R.id.container, FRAGMENT_STORY_COLLECTION, mStoryCollectionFragment);
            mFragmentFlipper.showFragment(FRAGMENT_STORY_COLLECTION);
        }
    }

    @Override
    protected int getFragmentContainerId() {
        return R.id.container;
    }
}
