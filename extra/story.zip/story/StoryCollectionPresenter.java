package com.hhdd.kada.module.story;

import android.os.Looper;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.db.main.entities.ListenHistory;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.model.StoryHistoryInfo;
import com.hhdd.kada.main.utils.SafeHandler;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

public class StoryCollectionPresenter {
    private static final int HISTORY_DATA_NONE = -1001;

    private SafeHandler mHistoryHandler;
    private SafeHandler mHandler;
    private StrongReference<DefaultCallback> storyCollectionStrongReference;
    private StoryCollectionContract.View mView;

    public StoryCollectionPresenter(StoryCollectionContract.View mView) {
        this.mView = mView;
        storyCollectionStrongReference = new StrongReference<>();
        mHistoryHandler = (SafeHandler) KaDaApplication.mainLooperHandler();
        mHandler = new SafeHandler(Looper.getMainLooper());
    }

    // ------以下方法用于获取数据------
    public void getStoryCollectionInfo(final long collectionId) {
        clearStoryCollectionReference();
        storyCollectionStrongReference = new StrongReference<>();
        DefaultCallback storyCollectionCallback = new DefaultCallback<StoryCollectionDetail>() {

            @Override
            public void onLoadFromCache(final StoryCollectionDetail cachedData) {
                if (cachedData != null && cachedData.getItems() != null && cachedData.getItems().size() > 0) {
                    // 重要：处理remainTime
                    if (cachedData.getRemainingTime() > 0) {
                        long remainTime = cachedData.getRemainingTime() * 1000
                                + System.currentTimeMillis();
                        cachedData.setRemainingTime(remainTime);
                    }

                    loadResumeData(collectionId, cachedData);
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            // 处理背景的展示
                            mView.updateBackground();
                            // 进行恢复播放数据的处理
                            loadResumeData(collectionId, cachedData);
                        }
                    });
                }
            }

            @Override
            public void onDataReceived(final StoryCollectionDetail responseData) {
                if (responseData != null && responseData.getItems() != null
                        && responseData.getItems().size() > 0) {
                    // 重要：处理remainTime
                    if (responseData.getRemainingTime() > 0) {
                        long remainTime = responseData.getRemainingTime() * 1000
                                + System.currentTimeMillis();
                        responseData.setRemainingTime(remainTime);
                    }
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            // 处理背景的展示
                            mView.updateBackground();
                            // 进行恢复播放数据的处理
                            loadResumeData(collectionId, responseData);
                        }
                    });
                } else {
                    //  错误处理，显示错误弹框
                    mHandler.post(new Runnable() {
                        @Override
                        public void run() {
                            mView.showContentDialog(2, 1, collectionId);
                            mView.handleErrorOccurred(true, 0, "加载数据为空");
                        }
                    });
                }
            }

            @Override
            public void onException(int code, String reason) {
                // 处理异常数据，异常时如果之前的合集数据不为空，则用之前的数据完成展示
                mView.handleException(code, reason);
            }
        };
        storyCollectionStrongReference.set(storyCollectionCallback);
        StoryAPI.storyAPI_collectItemList(collectionId, false, storyCollectionStrongReference);


    }

    private static class LoadHistoryInfoFlowableOnSubscribe implements FlowableOnSubscribe<StoryHistoryInfo> {

        private long mCollectId;

        public LoadHistoryInfoFlowableOnSubscribe(long collectId) {
            mCollectId = collectId;
        }

        @Override
        public void subscribe(FlowableEmitter<StoryHistoryInfo> e) {
            ListenHistory listenHistory = DatabaseManager.getInstance()
                    .listenHistoryDB().queryCollectHistory(mCollectId);
            StoryHistoryInfo storyHistoryInfo = new StoryHistoryInfo();
            if (listenHistory != null) {
                storyHistoryInfo = StoryHistoryInfo.createByHistory(listenHistory);
            } else {
                storyHistoryInfo.setIndex(HISTORY_DATA_NONE);
            }
            e.onNext(storyHistoryInfo);
            e.onComplete();
        }
    }

    public void loadResumeData(long collectionId, final StoryCollectionDetail storyCollectionDetail) {
        mHistoryHandler.removeCallbacksAndMessages(null);
        if (storyCollectionDetail != null && storyCollectionDetail.getSubscribe() == 1) {
            Flowable.create(new LoadHistoryInfoFlowableOnSubscribe(collectionId), BackpressureStrategy.BUFFER)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<StoryHistoryInfo>() {
                        @Override
                        public void accept(final StoryHistoryInfo storyHistoryInfo) {
                            if (storyHistoryInfo != null) {
                                mHistoryHandler.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (storyHistoryInfo.getIndex() == HISTORY_DATA_NONE) {
//                                            mStoryHistoryInfo = null;
                                            // 置空操作
                                            reassembledData(storyCollectionDetail, null);
                                        }
                                        reassembledData(storyCollectionDetail, storyHistoryInfo);
                                    }
                                });
                            }
                        }
                    });
        } else {
            reassembledData(storyCollectionDetail, null);
        }
    }

    private void reassembledData(final StoryCollectionDetail storyCollectionDetail,
                                 final StoryHistoryInfo storyHistoryInfo) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                if (mView != null) {
                    mView.updateSubscribeView(storyCollectionDetail);
                    mView.reassembledData(storyCollectionDetail, storyHistoryInfo);
                }
            }
        });
    }

    public void onDestroy() {
        if (mHandler != null) {
            mHandler.removeCallbacksAndMessages(null);
            mHandler = null;
        }
        if (mHistoryHandler != null) {
            mHistoryHandler.removeCallbacksAndMessages(null);
            mHistoryHandler = null;
        }
        clearStoryCollectionReference();
    }

    private void clearStoryCollectionReference() {
        if (storyCollectionStrongReference != null) {
            storyCollectionStrongReference.clear();
            storyCollectionStrongReference = null;
        }
    }
}
