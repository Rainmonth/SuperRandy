package com.hhdd.kada.module.story;

import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.model.StoryHistoryInfo;

import java.util.List;

public interface StoryCollectionContract {
    interface View {
        void reassembledData(StoryCollectionDetail storyCollectionDetail,
                      StoryHistoryInfo storyHistoryInfo);

        void updateBackground();

        void showContentDialog(int kind, int type, long collectionId);

        void handleErrorOccurred(boolean isFirstPage, int errorCode, String msg);

        void handleException(int code, String reason);

        void showAllDownloadProgress(boolean isShowAllDownloadProgress);

        void updateSubscribeView(StoryCollectionDetail storyCollectionDetail);

        void showHistoryResumePlay(StoryCollectionDetail storyCollectionDetail,
                                   StoryHistoryInfo storyHistoryInfo,
                                   List<BaseModel> models);

        void onDestroy();
    }

    interface Model {
        // 获取合集数据
        void getCollectionDetail(long collectionId);

        // 在获取合集数据成功之后才判断是否需要显示继续播放
        void getHistoryResumePlayData(long collectionId);
    }
}
