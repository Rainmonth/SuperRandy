package com.hhdd.kada.main.model;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/13
 * @describe : com.hhdd.kada.main.model
 */
public class AccountUnifyContentInfo extends BaseModel {

    private int type; // 属性类型
    private String typeName; // 属性名称
    private String value; //属性值
    private int isMerge; // 0 不可合并  1 可以合并  2 存在冲突，不可合并

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getIsMerge() {
        return isMerge;
    }

    public void setIsMerge(int isMerge) {
        this.isMerge = isMerge;
    }
}
