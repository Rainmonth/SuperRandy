package com.hhdd.kada.main.model;

/**
 * Created by sxh on 2017/8/14.
 */

public class SearchBookResultInfo extends BaseModel {

    /**
     * sourceId : 3693
     * name : 不能给陌生人开门
     * coverUrl : http://story.hhdd.com/story/cover/3693/c6569e4c-c9fb-4d0a-bf92-b2666598e567.jpg
     * downloadUrl : null
     * minAge : 4
     * maxAge : 6
     * author :
     * subscription : false
     * category : 2
     * version : 0
     */

    private int sourceId;
    private String name;
    private String coverUrl;
    private Object downloadUrl;
    private int minAge;
    private int maxAge;
    private String author;
    private boolean subscription;
    private int category;
    private int version;

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public Object getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(Object downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public int getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(int maxAge) {
        this.maxAge = maxAge;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public boolean isSubscription() {
        return subscription;
    }

    public void setSubscription(boolean subscription) {
        this.subscription = subscription;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

}
