package com.hhdd.kada.main.model;

/**
 * Created by lj on 16/9/21.
 */
public class AlbumBanner extends BaseModel {

    String bannerUrl;

    public AlbumBanner(String bannerUrl) {
        this.bannerUrl = bannerUrl;
    }

    public String getBannerUrl() {
        return bannerUrl;
    }

    public void setBannerUrl(String bannerUrl) {
        this.bannerUrl = bannerUrl;
    }
}
