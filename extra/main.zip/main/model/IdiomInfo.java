package com.hhdd.kada.main.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by mcx on 2017/7/25.
 */

public class IdiomInfo implements Serializable{

    private List<DataBean> data;

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean implements Serializable{
        /**
         * textList : ["爱","不","释","手"]
         * idiom : 爱不释手
         */

        private String idiom;
        private List<String> textList;

        public String getIdiom() {
            return idiom;
        }

        public void setIdiom(String idiom) {
            this.idiom = idiom;
        }

        public List<String> getTextList() {
            return textList;
        }

        public void setTextList(List<String> textList) {
            this.textList = textList;
        }
    }
}
