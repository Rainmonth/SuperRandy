package com.hhdd.kada.main.model;

import java.io.Serializable;

/**
 * Created by mcx on 2018/4/9.
 */

public class UserRegisterModel implements Serializable {
    public boolean toast;
    public int comple;
}
