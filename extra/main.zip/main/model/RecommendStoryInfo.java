package com.hhdd.kada.main.model;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/23
 * @describe : com.hhdd.kada.main.model
 */
public class RecommendStoryInfo extends StoryCollectionInfo {

    private String image;
    private int charge; // 1免费 2收费
    private boolean isCheck;

    public boolean isCheck() {
        return isCheck;
    }

    public void setCheck(boolean check) {
        isCheck = check;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getCharge() {
        return charge;
    }

    public void setCharge(int charge) {
        this.charge = charge;
    }

    @Override
    public String getCoverUrl() {
        return image;
    }

    @Override
    public int getExtFlag() {
        return charge == 2 ? 56 : 0;
    }

    @Override
    public String getRecommend() {
        return name;
    }
}
