package com.hhdd.kada.main.model;

import com.google.gson.Gson;

import java.util.List;

/**
 * Created by sxh on 2017/8/3.
 * 绘本合辑详情
 */

public class BookCollectionDetailInfo extends BaseModel {
    private int categoryId;
    private String name;
    private String coverUrl;
    private int extFlag;
    private int collectId;
    private int count;
    private String bannerUrl;
    private int type;
    private String introduction;
    private int clickCount;
    private int subscribeCount;
    private double price;
    private String serialize;
    private String recommend;
    private String imageUrl;
    private String backImage;
    private String explainAudio;
    private int subscribe;     //是否订阅 0:未订阅，1:已订阅，2:已取消订阅, 3:假订阅
    private List<BookInfo> items;
    private double originalPrice;

    private boolean isCommonStyle;

    private int status;
    private List<Integer> dimensionIdList;
    private String smallAppSquare;// 微信小程序封面图

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public BookCollectionDetailInfo() {
    }

    public String getExplainAudio() {
        return explainAudio;
    }

    public void setExplainAudio(String explainAudio) {
        this.explainAudio = explainAudio;
    }

    public String getBackImage() {
        return backImage;
    }

    public void setBackImage(String backImage) {
        this.backImage = backImage;
    }

//    public boolean isCommonStyle() {
//        return isCommonStyle;
//    }
//
//    public void setCommonStyle(boolean commonStyle) {
//        isCommonStyle = commonStyle;
//    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public int getExtFlag() {
        return extFlag;
    }

    public void setExtFlag(int extFlag) {
        this.extFlag = extFlag;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public String getBannerUrl() {
        return bannerUrl;
    }

    public void setBannerUrl(String bannerUrl) {
        this.bannerUrl = bannerUrl;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
    }

    public int getSubscribeCount() {
        return subscribeCount;
    }

    public void setSubscribeCount(int subscribeCount) {
        this.subscribeCount = subscribeCount;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getSerialize() {
        return serialize;
    }

    public void setSerialize(String serialize) {
        this.serialize = serialize;
    }

    public String getRecommend() {
        return recommend;
    }

    public void setRecommend(String recommend) {
        this.recommend = recommend;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(int subscribe) {
        this.subscribe = subscribe;
    }

    public List<BookInfo> getItems() {
        return items;
    }

    public void setItems(List<BookInfo> items) {
        this.items = items;
    }

    public double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public List<Integer> getDimensionIdList() {
        return dimensionIdList;
    }

    public void setDimensionIdList(List<Integer> dimensionIdList) {
        this.dimensionIdList = dimensionIdList;
    }

    public String getSmallAppSquare() {
        return smallAppSquare;
    }

    public void setSmallAppSquare(String smallAppSquare) {
        this.smallAppSquare = smallAppSquare;
    }

    @Override
    public String toString() {
        Gson gson = new Gson();
        String json = gson.toJson(this);
        return json;
    }
}
