package com.hhdd.kada.main.model;

import com.hhdd.kada.module.talentplan.model.TalentPlanWeekInfo;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/12
 * @describe : com.hhdd.kada.main.model
 */
public class TalentPlanWeekInfos extends BaseModel {

    private int issue; //当前期次(周数)  -1表示未开通优才计划
    private List<TalentPlanWeekInfo> planUserIssueVOList; //53周内容(含试读)
    private int subscribeCount; //优才计划开通人数
    private boolean subscribePlan;// 是否开通优才计划
    private String planDate; //优才计划日期

    public int getIssue() {
        return issue;
    }

    public void setIssue(int issue) {
        this.issue = issue;
    }

    public List<TalentPlanWeekInfo> getPlanUserIssueVOList() {
        return planUserIssueVOList;
    }

    public void setPlanUserIssueVOList(List<TalentPlanWeekInfo> planUserIssueVOList) {
        this.planUserIssueVOList = planUserIssueVOList;
    }

    public int getSubscribeCount() {
        return subscribeCount;
    }

    public void setSubscribeCount(int subscribeCount) {
        this.subscribeCount = subscribeCount;
    }

    public boolean isSubscribePlan() {
        return subscribePlan;
    }

    public void setSubscribePlan(boolean subscribePlan) {
        this.subscribePlan = subscribePlan;
    }

    public String getPlanDate() {
        return planDate;
    }

    public void setPlanDate(String planDate) {
        this.planDate = planDate;
    }
}
