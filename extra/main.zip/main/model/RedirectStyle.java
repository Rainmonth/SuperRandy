package com.hhdd.kada.main.model;

import com.google.gson.Gson;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.logger.LogHelper;

/**
 * Created by simon on 05/01/2017.
 */

//样式
public class RedirectStyle extends BaseModel {
    int corner;
    String icon;
    int circle;

    public int getCorner() {
        return corner;
    }

    public void setCorner(int corner) {
        this.corner = corner;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public int getCircle() {
        return circle;
    }

    public void setCircle(int circle) {
        this.circle = circle;
    }

    public static RedirectStyle parse(String jsonString) {
        if (jsonString!=null&&jsonString.length()>0) {
            try {
                Gson gson = new Gson();
                return gson.fromJson(jsonString,RedirectStyle.class);
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        }
        return null;
    }
}
