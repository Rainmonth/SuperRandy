package com.hhdd.kada.main.model;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/8/2
 * @describe : com.hhdd.kada.main.model
 */
public class AliPayInfo extends BaseModel {

    private String outTradeNo;
    private String alipayJson;

    public String getOutTradeNo() {
        return outTradeNo;
    }

    public void setOutTradeNo(String outTradeNo) {
        this.outTradeNo = outTradeNo;
    }

    public String getAlipayJson() {
        return alipayJson;
    }

    public void setAlipayJson(String alipayJson) {
        this.alipayJson = alipayJson;
    }
}
