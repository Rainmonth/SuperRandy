package com.hhdd.kada.main.model;

import android.support.annotation.NonNull;

import com.hhdd.kada.main.vo.BaseVO;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/9/12
 * @describe : com.hhdd.kada.main.model
 */
public class DialogConfigInfo extends BaseVO implements Comparable<DialogConfigInfo> {
    private String imageUrl;
    private String soundUrl;
    private String content;
    private String redirectUri;
    private String timeBegin;
    private String timeEnd;
    private int haveFlash;//是否显示动画，显示动画则动画收缩到咔哒币
    private int redirectId;
    private int priority;//优先级（0....N)，值越大优先级越高

    public int getRedirectId() {
        return redirectId;
    }

    public void setRedirectId(int redirectId) {
        this.redirectId = redirectId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getSoundUrl() {
        return soundUrl;
    }

    public void setSoundUrl(String soundUrl) {
        this.soundUrl = soundUrl;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getRedirectUri() {
        return redirectUri;
    }

    public void setRedirectUri(String redirectUri) {
        this.redirectUri = redirectUri;
    }

    public String getTimeBegin() {
        return timeBegin;
    }

    public void setTimeBegin(String timeBegin) {
        this.timeBegin = timeBegin;
    }

    public String getTimeEnd() {
        return timeEnd;
    }

    public void setTimeEnd(String timeEnd) {
        this.timeEnd = timeEnd;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getHaveFlash() {
        return haveFlash;
    }

    public void setHaveFlash(int haveFlash) {
        this.haveFlash = haveFlash;
    }

    @Override
    public int compareTo(@NonNull DialogConfigInfo o) {
        return o.getPriority() - priority;
    }
}
