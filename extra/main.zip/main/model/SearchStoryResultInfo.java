package com.hhdd.kada.main.model;

/**
 * Created by sxh on 2017/5/18.
 * 听书搜索结果model
 */

public class SearchStoryResultInfo extends BaseModel {

    /**
     * sourceId : 4740
     * name : 熙儿妈桃子
     * coverUrl : http://image.hhdd.com/story/cover/4740/d09e13e1-c6e7-435e-8fd0-3495a236c8bd.jpg
     * minAge : 4
     * maxAge : 9
     * author :
     * downloadUrl : null
     * subscription : false
     * version : 0
     * category : 1
     */

    private String time;
    private int sourceId;
    private String name;
    private String coverUrl;
    private int minAge;
    private int maxAge;
    private String author;
    private boolean subscription;
    private String downloadUrl;
    private int version;
    private int category;    //  1代表单本 , 2代表合辑

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public int getCategory() {
        return category;
    }

    public void setCategory(int category) {
        this.category = category;
    }

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public int getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(int maxAge) {
        this.maxAge = maxAge;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public boolean isSubscription() {
        return subscription;
    }

    public void setSubscription(boolean subscription) {
        this.subscription = subscription;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
