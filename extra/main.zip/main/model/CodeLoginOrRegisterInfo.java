package com.hhdd.kada.main.model;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/11
 * @describe : com.hhdd.kada.main.model
 */
public class CodeLoginOrRegisterInfo extends BaseModel {

    private int isReg; //是否注册  0 用户登录返回   1 用户注册返回
    private long userId;
    private int comple; // 是否完善资料  0未完善  1已完善
    private boolean toast;  // 是否推荐过内容  true 推荐过   false 未推荐过

    //用户登录名(手机为手机号，微信为unionId，但接口下发字段为openId，实际为unionId) 或合并后手机主帐号 用于获取本地对应正确的数据库
    private String loginName;

    public int getIsReg() {
        return isReg;
    }

    public void setIsReg(int isReg) {
        this.isReg = isReg;
    }

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getComple() {
        return comple;
    }

    public void setComple(int comple) {
        this.comple = comple;
    }

    public boolean isToast() {
        return toast;
    }

    public void setToast(boolean toast) {
        this.toast = toast;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
}
