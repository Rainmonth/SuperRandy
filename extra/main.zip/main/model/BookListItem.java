package com.hhdd.kada.main.model;

import com.hhdd.kada.download.DownloadStatusVO;
import com.hhdd.kada.main.ui.book.BookItemView;

/**
 * Created by lj on 16/11/25.
 */

public class BookListItem extends BaseModel {

    public static final int TYPE_BOOK = 1;
    public static final int TYPE_BOOK_COLLECTION=2;
    //优才计划绘本
    public static final int TYPE_TALENT_BOOK = 3;

    //用于下载
    private BookItemView itemView;  //下载进度view
    private DownloadStatusVO downloadStatusVO;  //下载状态


    private int subscribeStatus;

    public int getSubscribeStatus() {
        return subscribeStatus;
    }

    public void setSubscribeStatus(int subscribeStatus) {
        this.subscribeStatus = subscribeStatus;
    }

    public BookItemView getItemView() {
        return itemView;
    }

    public void setItemView(BookItemView itemView) {
        this.itemView = itemView;
    }

    public DownloadStatusVO getDownloadStatusVO() {
        return downloadStatusVO;
    }

    public void setDownloadStatusVO(DownloadStatusVO downloadStatusVO) {
        this.downloadStatusVO = downloadStatusVO;
    }

    public BookListItem() {

    }

    public BookListItem(int type, BaseModel data) {
        this.type=type;
        this.data=data;
    }

    int type;
    BaseModel data;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public BaseModel getData() {
        return data;
    }

    public void setData(BaseModel data) {
        this.data = data;
    }
}
