package com.hhdd.kada.main.model;

/**
 * Created by lj on 17/3/13.
 */

public class TaskShareResult extends BaseModel{

//    "code": 2006,
//            "msg": "任务完成",
//            "coin": 5

    int code;
    String msg;
    int coin;


    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public int getCoin() {
        return coin;
    }

    public void setCoin(int coin) {
        this.coin = coin;
    }
}
