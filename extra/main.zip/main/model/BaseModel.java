package com.hhdd.kada.main.model;

import java.io.Serializable;

/**
 * Created by simon on 5/31/16.
 */
public class BaseModel implements Serializable {

    private Object modelStatus;    //用于业务上特殊需求的数据传递

    public Object getModelStatus() {
        return modelStatus;
    }

    public void setModelStatus(Object modelStatus) {
        this.modelStatus = modelStatus;
    }

    //列表中的位置
    private int index = -1;

    public BaseModel() {
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }
}
