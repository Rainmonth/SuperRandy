package com.hhdd.kada.main.model;

import android.view.View;

import com.hhdd.core.model.StoryInfo;
import com.hhdd.kada.download.DownloadStatusVO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by simon on 9/20/16.
 */
public class StoryListItem extends BaseModel {

    public static final int TYPE_STORY = 1;
    public static final int TYPE_STORY_COLLECTION_OLD = 2; //老合集
    public static final int TYPE_STORY_COLLECTION_SITCOM = 3; //老连续剧
    public static final int TYPE_STORY_COLLECTION_NEW = 4; //新合集

    public static final int STATUS_FREE = 0;//免费
    public static final int STATUS_CHARGE = 1;//收费
    public static final int STATUS_LATELY_UPDATE = 2;//最近更新

    public boolean delete = false;//是否标记为删除。用于“我的书架”界面用户批量删除->提交。之所以不通过list移除的形式，是因为用户可能取消操作。取消时，list的操作会乱序
    public boolean charge = false;//是否是收费合辑。仅用于“我的书架”里面。

    public int unsubscribeFlag;//0不可退订，1可退订

    public StoryListItem() {

    }

    public StoryListItem(int type, BaseModel data) {
        this.type = type;
        this.data = data;
    }

    public StoryListItem(int type, BaseModel data, int collectStatus) {
        this.type = type;
        this.data = data;
        this.collectStatus = collectStatus;
    }

    int type;

//    public StoryListItem(int type, BaseModel data, int collectStatus, boolean isFromUser, int subscribeStatus) {
//        this.type = type;
//        this.data = data;
//        this.collectStatus = collectStatus;
//        this.isFromUser = isFromUser;
//        this.subscribeStatus = subscribeStatus;
//    }

    public StoryListItem(int type, BaseModel data, int collectStatus, int subscribeStatus) {
        this.type = type;
        this.data = data;
        this.collectStatus = collectStatus;
        this.subscribeStatus = subscribeStatus;
    }

//    public boolean isFromUser() {
//        return isFromUser;
//    }
//
//    public void setFromUser(boolean fromUser) {
//        isFromUser = fromUser;
//    }

    BaseModel data;
    int playMode; //显示动画属性
    int collectStatus;// 合集状态 0:免费 1：收费 2：最近更新
//    boolean isFromUser;
    int subscribeStatus;

    public int getSubscribeStatus() {
        return subscribeStatus;
    }

    public void setSubscribeStatus(int subscribeStatus) {
        this.subscribeStatus = subscribeStatus;
    }

    private DownloadStatusVO downloadStatusVO;
    View itemView;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public BaseModel getData() {
        return data;
    }

    public void setData(BaseModel data) {
        this.data = data;
    }

    public int getPlayMode() {
        return playMode;
    }

    public void setPlayMode(int playMode) {
        this.playMode = playMode;
    }

    public int getCollectStatus() {
        return collectStatus;
    }

    public void setCollectStatus(int collectStatus) {
        this.collectStatus = collectStatus;
    }

    public DownloadStatusVO getDownloadStatusVO() {
        return downloadStatusVO;
    }

    public void setDownloadStatusVO(DownloadStatusVO downloadStatusVO) {
        this.downloadStatusVO = downloadStatusVO;
    }

    public View getItemView() {
        return itemView;
    }

    public void setItemView(View itemView) {
        this.itemView = itemView;
    }

    public StoryInfo toOldStoryInfo() {
        StoryInfo info = StoryInfo.createInfoByNewStory(this);
        return info;
    }

    public static List<StoryInfo> toOldStoryInfoList(List<BaseModel> list) {
        List<StoryInfo> storyInfos = new ArrayList<StoryInfo>();
        for (int i = 0; i < list.size(); i++) {
            BaseModel model = list.get(i);
            model.setIndex(i);
            if (model instanceof StoryListItem) {
                storyInfos.add(((StoryListItem) model).toOldStoryInfo());
            } else if (model instanceof com.hhdd.kada.main.model.StoryInfo) {
                storyInfos.add(StoryInfo.createInfoByNewStory(model));
            }
        }
        return storyInfos;
    }

}
