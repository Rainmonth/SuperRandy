package com.hhdd.kada.main.model;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/27
 * @describe : com.hhdd.kada.main.model
 */
public class BaseBookStoryInfo extends BaseModel {

    protected int id;

    public int getId() {
        return id;
    }
}
