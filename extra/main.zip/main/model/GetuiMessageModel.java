package com.hhdd.kada.main.model;

import java.io.Serializable;

/**
 * Created by lj on 17/1/19.
 */

public class GetuiMessageModel implements Serializable{

    private String redirect_url;

    public String getRedirect_url() {
        return redirect_url;
    }

    public void setRedirect_url(String redirect_url) {
        this.redirect_url = redirect_url;
    }

    @Override
    public String toString() {
        return "GetuiMessageModel{" +
                "redirect_url='" + redirect_url + '\'' +
                '}';
    }
}
