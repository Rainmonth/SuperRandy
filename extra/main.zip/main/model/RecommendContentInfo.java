package com.hhdd.kada.main.model;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/8
 * @describe : com.hhdd.kada.main.model
 */
public class RecommendContentInfo extends BaseModel {

    private List<RecommendBookInfo> bookList;
    private List<RecommendStoryInfo> storyList;

    public List<RecommendBookInfo> getBookList() {
        return bookList;
    }

    public void setBookList(List<RecommendBookInfo> bookList) {
        this.bookList = bookList;
    }

    public List<RecommendStoryInfo> getStoryList() {
        return storyList;
    }

    public void setStoryList(List<RecommendStoryInfo> storyList) {
        this.storyList = storyList;
    }
}
