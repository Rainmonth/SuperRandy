package com.hhdd.kada.main.model;

import com.hhdd.kada.main.vo.BaseModelVO;

/**
 * Created by mcx on 2017/8/3.
 */

public class BookOtherCollectListModel extends BaseModelVO {
    //    "sourceId": 53651,
//    "type": 1, (1:单绘本，2：合辑）
//    "image": "http://image.hhdd.com/books2/53651/cover.jpg",
//    "extFlag": 5 （extflag=4096：热门经典合辑，8：小编推荐，4：新品推荐）
    int sourceId;
    int type;
    String image;
    int extFlag;
    int version;

    public int unsubscribeFlag;//0不可退订，1可退订

    public boolean delete = false;//是否标记为删除。用于“我的书架”界面用户批量删除->提交。之所以不通过list移除的形式，是因为用户可能取消操作。取消时，list的操作会乱序

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getExtFlag() {
        return extFlag;
    }

    public void setExtFlag(int extFlag) {
        this.extFlag = extFlag;
    }

    public static BookInfo creatBookInfo(BookOtherCollectListModel info) {
        BookInfo bookInfo = new BookInfo();
        bookInfo.setIndex(info.getIndex());
        bookInfo.setBookId(info.getSourceId());
        bookInfo.setCoverUrl(info.getImage());
        bookInfo.setExtFlag(info.getExtFlag());
        bookInfo.setVersion(info.getVersion());

        return bookInfo;
    }

    public static BookCollectionInfo creatBookCollectionInfo(BookOtherCollectListModel info) {
        BookCollectionInfo bookInfo = new BookCollectionInfo();
        bookInfo.setIndex(info.getIndex());
        bookInfo.setIndex(info.getIndex());
        bookInfo.setCollectId(info.getSourceId());
        bookInfo.setCoverUrl(info.getImage());
        bookInfo.setExtFlag(info.getExtFlag());

        return bookInfo;
    }
}
