package com.hhdd.kada.main.model;

/**
 * Created by simon on 9/20/16.
 */
public class StoryCollectionInfo extends BaseCollectionInfo {

    int sourceId;
    private String sourceKey; //打点统计相关 {name:"" content:""} =>json  妈妈页面
    int categoryId;
    int extFlag;
    int collectId;
    int type; //区分是普通合集 还是 连续剧
    String author;
    int minAge;
    int maxAge;
    int clickCount;
    String serialize;  //连载标志 "每周二、四 20:00"

    int onlineCount;  //更新到多少集

    boolean showNew; //显示合集有更新
    int currentCount;

    public StoryCollectionInfo() {
    }

    public StoryCollectionInfo(int categoryId, String name, String coverUrl, int extFlag, int collectId, int count, int type, int clickCount, int subscribeCount, double price, String serialize, String recommend, int subscribe, int currentCount) {
        this.categoryId = categoryId;
        this.name = name;
        this.coverUrl = coverUrl;
        this.extFlag = extFlag;
        this.collectId = collectId;
        this.count = count;
        this.type = type;
        this.clickCount = clickCount;
        this.subscribeCount = subscribeCount;
        this.price = price;
        this.serialize = serialize;
        this.recommend = recommend;
        this.subscribe = subscribe;
        this.currentCount = currentCount;
    }

    public int getOnlineCount() {
        return onlineCount;
    }

    public void setOnlineCount(int onlineCount) {
        this.onlineCount = onlineCount;
    }

    public int getCurrentCount(){
        return currentCount;
    }

    public void setCurrentCount(int currentCount){
        this.currentCount = currentCount;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public int getExtFlag() {
        return extFlag;
    }

    public void setExtFlag(int extFlag) {
        this.extFlag = extFlag;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public int getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(int maxAge) {
        this.maxAge = maxAge;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
    }

    public String getSerialize() {
        return serialize;
    }

    public void setSerialize(String serialize) {
        this.serialize = serialize;
    }

    public boolean isShowNew() {
        return showNew;
    }

    public void setShowNew(boolean showNew) {
        this.showNew = showNew;
    }

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceKey() {
        return sourceKey;
    }

    public void setSourceKey(String sourceKey) {
        this.sourceKey = sourceKey;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o != null &&o.getClass() == StoryCollectionInfo.class) {
            StoryCollectionInfo n = (StoryCollectionInfo) o;
            return n.getCollectId() == this.getCollectId();
        }
        return false;
    }

    @Override
    public int getId() {
        return collectId;
    }
}



//
//categoryId: 1031,
//        name: "瑞丁老爸——卡梅拉",
//        coverUrl: "http://image.hhdd.com/books/cover/6bb8c376-8fb3-4b71-ac75-6dd99adf1bd7.jpg",
//        extFlag: 0,
//        collectId: 3618,
//        count: 14,
//        type: 1,
//        minAge: 4,
//        maxAge: 6
//
