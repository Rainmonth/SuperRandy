package com.hhdd.kada.main.model;

import java.util.List;

/**
 * Created by sxh on 2017/8/2.
 * 听书订阅model(分为收费、免费)
 */

public class SubscribeStoryInfo  extends BaseModel{
    List<StoryListItem> chargeList;
    List<StoryListItem> freesList;

    public SubscribeStoryInfo() {
    }

    public SubscribeStoryInfo(List<StoryListItem> chargeList, List<StoryListItem> freesList) {
        this.chargeList = chargeList;
        this.freesList = freesList;
    }

    public List<StoryListItem> getChargeList() {
        return chargeList;
    }

    public void setChargeList(List<StoryListItem> chargeList) {
        this.chargeList = chargeList;
    }

    public List<StoryListItem> getFreesList() {
        return freesList;
    }

    public void setFreesList(List<StoryListItem> freesList) {
        this.freesList = freesList;
    }
}
