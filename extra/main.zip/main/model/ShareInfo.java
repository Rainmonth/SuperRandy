package com.hhdd.kada.main.model;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/8/7
 * @describe : com.hhdd.kada.main.model
 */
public class ShareInfo extends BaseModel {

    private String title; //分享标题
    private String content; //分享内容
    private String imageUrl; //分享封面图片地址
    private String targetUrl; //分享跳转链接
    private String wxMinPath; //分享微信小程序路径地址
    private String smallAppSquare; //分享微信小程序封面图

    public ShareInfo() {
    }

    public ShareInfo(String title, String content, String imageUrl, String targetUrl) {
        this.title = title;
        this.content = content;
        this.imageUrl = imageUrl;
        this.targetUrl = targetUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getTargetUrl() {
        return targetUrl;
    }

    public void setTargetUrl(String targetUrl) {
        this.targetUrl = targetUrl;
    }

    public String getWxMinPath() {
        return wxMinPath;
    }

    public void setWxMinPath(String wxMinPath) {
        this.wxMinPath = wxMinPath;
    }

    public String getSmallAppSquare() {
        return smallAppSquare;
    }

    public void setSmallAppSquare(String smallAppSquare) {
        this.smallAppSquare = smallAppSquare;
    }
}
