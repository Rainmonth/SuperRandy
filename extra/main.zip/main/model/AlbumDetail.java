package com.hhdd.kada.main.model;

/**
 * Created by lj on 16/9/21.
 */
public class AlbumDetail extends BaseModel {

    String orgName;
    String description;
    String introduction;
    String iconUrl;

    public AlbumDetail(String orgName, String description, String introduction, String iconUrl) {
        this.orgName = orgName;
        this.description = description;
        this.introduction = introduction;
        this.iconUrl = iconUrl;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }
}
