package com.hhdd.kada.main.model;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/27
 * @describe : com.hhdd.kada.main.model
 */
public class PhoneLoginInfo extends BaseModel {

    private String loginName; //用户登录名(手机为手机号，微信为unionId，但接口下发字段为openId，实际为unionId) 用于获取本地对应正确的数据库
    private String userId; //用户id

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
