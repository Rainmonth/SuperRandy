package com.hhdd.kada.main.model;

import android.graphics.Point;

public class DirectionPoint extends Point {
    public int direction;   //方向    1 左  2 上  3 右  4 下
}
