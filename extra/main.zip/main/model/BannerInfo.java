package com.hhdd.kada.main.model;

import com.hhdd.kada.main.vo.BaseVO;

/**
 * Created by lj on 16/12/13.
 */

public class BannerInfo extends BaseVO {

    int id;
    String content;
    String name;
    String bannerUrl;
    int type;
    String redirectUri;
    String coverUrl;
    int kind;

    public static final int BOOK_BANNER = 1;
    public static final int STORY_BANNER = 2;
    public void setKind(int kind) {
        this.kind = kind;
    }

    public int getKind() {
        return kind;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getBannerUrl() {
        return bannerUrl;
    }

    public void setBannerUrl(String bannerUrl) {
        this.bannerUrl = bannerUrl;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getRedirectUri() {
        return redirectUri;
    }

    public void setRedirectUri(String redirectUri) {
        this.redirectUri = redirectUri;
    }
}
