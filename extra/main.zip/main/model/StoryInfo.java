package com.hhdd.kada.main.model;

/**
 * Created by simon on 9/20/16.
 */
public class StoryInfo extends BaseBookStoryInfo {

    int collectId;
    int categoryId;
    String name;
    String coverUrl;
    int extFlag;
    //  本地添加，非接口返回，用来判断其所属合集的状态（如是否限免等）
    int collectExtFlag;
    int storyId;
    String downloadUrl;
    String time;
    String author;
    int minAge;
    int maxAge;
    int version;
    int clickCount;
    int ind;
    String itemName;    //名称为付费更多、免费更多两个标签单独处理

    boolean isPlaceholder;  //是否是占位的view
    int leftCount;  //还剩多少集未更新
    int status;
    String collectCover;   //所在合辑封面

    public String getCollectCover() {
        return collectCover;
    }

    public void setCollectCover(String collectCover) {
        this.collectCover = collectCover;
    }

    public StoryInfo(String itemName) {
        this.itemName = itemName;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    public int getLeftCount() {
        return leftCount;
    }

    public void setLeftCount(int leftCount) {
        this.leftCount = leftCount;
    }

    public boolean isPlaceholder() {
        return isPlaceholder;
    }

    public void setPlaceholder(boolean placeholder) {
        isPlaceholder = placeholder;
    }


    public StoryInfo() {
    }

    public StoryInfo(int storyId) {
        this.storyId = storyId;
    }

    public StoryInfo(int categoryId, String name, String coverUrl, int extFlag, int storyId, String downloadUrl, String time, String author, int minAge, int maxAge, int version, int clickCount) {
        this.categoryId = categoryId;
        this.name = name;
        this.coverUrl = coverUrl;
        this.extFlag = extFlag;
        this.storyId = storyId;
        this.downloadUrl = downloadUrl;
        this.time = time;
        this.author = author;
        this.minAge = minAge;
        this.maxAge = maxAge;
        this.version = version;
        this.clickCount = clickCount;
    }

    public StoryInfo(int categoryId, String name, String coverUrl, int extFlag, int storyId, String downloadUrl, String author, int minAge, int maxAge, int version) {
        this.categoryId = categoryId;
        this.name = name;
        this.coverUrl = coverUrl;
        this.extFlag = extFlag;
        this.storyId = storyId;
        this.downloadUrl = downloadUrl;
        this.author = author;
        this.minAge = minAge;
        this.maxAge = maxAge;
        this.version = version;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public int getExtFlag() {
        return extFlag;
    }

    public void setExtFlag(int extFlag) {
        this.extFlag = extFlag;
    }

    public int getCollectExtFlag() {
        return collectExtFlag;
    }

    public void setCollectExtFlag(int collectExtFlag) {
        this.collectExtFlag = collectExtFlag;
    }

    public int getStoryId() {
        return storyId;
    }

    public void setStoryId(int storyId) {
        this.storyId = storyId;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public int getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(int maxAge) {
        this.maxAge = maxAge;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
    }
    public int getInd() {
        return ind;
    }

    public void setInd(int ind) {
        this.ind = ind;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }




    public StoryInfo clone(){
        StoryInfo info = new StoryInfo();
        info.setAuthor(getAuthor());
        info.setCategoryId(getCategoryId());
        info.setClickCount(getClickCount());
        info.setCoverUrl(getCoverUrl());
        info.setDownloadUrl(getDownloadUrl());
        info.setExtFlag(getExtFlag());
        info.setMaxAge(getMaxAge());
        info.setMinAge(getMinAge());
        info.setName(getName());
        info.setStoryId(getStoryId());
        info.setVersion(getVersion());
        info.setClickCount(getClickCount());
        info.setTime(getTime());
        info.setStatus(getStatus());
        return info;
    }

    // 根据 first 判断两个 Name 是否相等
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o != null &&o.getClass() == StoryInfo.class) {
            StoryInfo n = (StoryInfo) o;
            return n.getStoryId() == this.getStoryId();
        }
        return false;
    }

    // 根据 first 计算 Name 对象的 hashCode() 返回值
    public int hashCode() {
        return (int) this.getStoryId();
    }

    @Override
    public int getId() {
        return storyId;
    }
}

//categoryId: 1028,
//        name: "《三字经》教读25",
//        coverUrl: "http://image.hhdd.com/books/cover/7936a991-c078-4d5f-b83e-193e350a38e8.jpg",
//        extFlag: 0,
//        storyId: 3611,
//        downloadUrl: "http://cdn.hhdd.com/books/en_media/5cb46bab-5801-458a-a9e4-c74963e21a25.mp3",
//        time: "131",
//        minAge: 0,
//        maxAge: 3,
//        version: 1
