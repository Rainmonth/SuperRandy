package com.hhdd.kada.main.model;

import android.text.TextUtils;

import com.hhdd.kada.Constants;
import com.hhdd.kada.db.main.entities.ListenHistory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lj on 16/12/13.
 */

public class StoryHistoryInfo extends BaseModel {

    private int collectId;
    private Integer storyId;
    private String coverUrl;
    private long lastReadTime;
    private Integer readCurrentTime;
    private Integer readTime;
    private Integer readCount;
    private Integer type;
    private Integer version;
    private Integer status;
    private Integer subscribe;
    private String downloadUrl;
    private double time;


    public StoryHistoryInfo() {
    }

    public StoryHistoryInfo(Integer storyId) {
        this.storyId = storyId;
    }

    public StoryHistoryInfo(int collectId, Integer storyId, String coverUrl, long lastReadTime, Integer readCurrentTime, Integer readTime, Integer readCount, Integer type, Integer version, Integer status, Integer subscribe, String downloadUrl, double time) {
        this.collectId = collectId;
        this.storyId = storyId;
        this.coverUrl = coverUrl;
        this.lastReadTime = lastReadTime;
        this.readCurrentTime = readCurrentTime;
        this.readTime = readTime;
        this.readCount = readCount;
        this.type = type;
        this.version = version;
        this.status = status;
        this.subscribe = subscribe;
        this.downloadUrl = downloadUrl;
        this.time = time;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    public Integer getStoryId() {
        return storyId;
    }

    public void setStoryId(Integer storyId) {
        this.storyId = storyId;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public long getLastReadTime() {
        return lastReadTime;
    }

    public void setLastReadTime(long lastReadTime) {
        this.lastReadTime = lastReadTime;
    }

    public Integer getReadCurrentTime() {
        return readCurrentTime;
    }

    public void setReadCurrentTime(Integer readCurrentTime) {
        this.readCurrentTime = readCurrentTime;
    }

    public Integer getReadTime() {
        return readTime;
    }

    public void setReadTime(Integer readTime) {
        this.readTime = readTime;
    }

    public Integer getReadCount() {
        return readCount;
    }

    public void setReadCount(Integer readCount) {
        this.readCount = readCount;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(Integer subscribe) {
        this.subscribe = subscribe;
    }

    public String getDownloadUrl() {
        return downloadUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public ListenHistory toListenHistory() {
        ListenHistory listenHistory = new ListenHistory();
        listenHistory.setCollectId(getCollectId());
        listenHistory.setStoryId(getStoryId());
        listenHistory.setCoverUrl(getCoverUrl());
        listenHistory.setLastReadTime(getLastReadTime());
        listenHistory.setReadCount(getReadCount());
        listenHistory.setReadCurrentTime(getReadCurrentTime());
        listenHistory.setReadTime(getReadTime());
        listenHistory.setStatus(getStatus());
        listenHistory.setSubscribe(getSubscribe());
        listenHistory.setType(getType());
        listenHistory.setVersion(getVersion());
        listenHistory.setDownloadUrl(getDownloadUrl());
        listenHistory.setTime(getTime());
        return listenHistory;
    }

    public static ListenHistory createHistoryByStoryInfo(com.hhdd.core.model.StoryInfo storyInfo,
                                                         int readCurrentTime,
                                                         int readTime,
                                                         int type) {
        ListenHistory listenHistory = new ListenHistory();
        listenHistory.setCollectId((int) storyInfo.getCollectionId());
        listenHistory.setStoryId((int) storyInfo.getId());
        listenHistory.setReadCount(1);
        if (TextUtils.isEmpty(storyInfo.getCollectCoverUrl())){
            listenHistory.setCoverUrl(storyInfo.getCoverUrl());
        }else {
            listenHistory.setCoverUrl(storyInfo.getCollectCoverUrl());
        }
        listenHistory.setDownloadUrl(storyInfo.getSoundUrl());
        listenHistory.setLastReadTime(System.currentTimeMillis());
        listenHistory.setReadCurrentTime(readCurrentTime);
        listenHistory.setStatus(1);
        listenHistory.setTime(storyInfo.getTime()/1000d);
        listenHistory.setSubscribe(storyInfo.getSubscribe());
        listenHistory.setReadTime(readTime);
        listenHistory.setType(type);
        return listenHistory;
    }

    public static List<StoryHistoryInfo> createByHistory(List<ListenHistory> list) {
        if (list != null && list.size() > 0) {
            List<StoryHistoryInfo> listenHistoryInfos = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                ListenHistory history = list.get(i);
                //等于0的也是单本
                int type = history.getType() == 0 ? Constants.TYPE_STORY_SINGLE : history.getType();
                StoryHistoryInfo info = new StoryHistoryInfo(history.getCollectId(), history.getStoryId(), history.getCoverUrl(), history.getLastReadTime(), history.getReadCurrentTime(), history.getReadTime(),
                        history.getReadCount(), type, history.getVersion(), history.getStatus(), history.getSubscribe(), history.getDownloadUrl(), history.getTime());
                listenHistoryInfos.add(info);
            }
            return listenHistoryInfos;
        }
        return null;
    }

    public static StoryHistoryInfo createByHistory(ListenHistory history){
        if(history != null){
            StoryHistoryInfo info = new StoryHistoryInfo(history.getCollectId(), history.getStoryId(), history.getCoverUrl(), history.getLastReadTime(), history.getReadCurrentTime(), history.getReadTime(),
                    history.getReadCount(), history.getType(), history.getVersion(), history.getStatus(), history.getSubscribe(), history.getDownloadUrl(), history.getTime());
            return info;
        }
        return null;
    }

}
