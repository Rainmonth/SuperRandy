package com.hhdd.kada.main.model;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/13
 * @describe : com.hhdd.kada.main.model
 */
public class AccountUnifyInfo extends BaseModel {

    private long userId;
    private int type; // 1 当前登录用户  2  被绑定用户
    private int accountType; // 1 手机帐号  2 微信帐号 3 华为帐号
    private int isRecommend; // 是否为推荐帐号  0 不推荐  1 推荐
    private List<AccountUnifyContentInfo> accountList; // 帐号数据list
    private List<AccountUnifyContentInfo> unifyList; // 模拟合并后数据list

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getAccountType() {
        return accountType;
    }

    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }

    public int getIsRecommend() {
        return isRecommend;
    }

    public void setIsRecommend(int isRecommend) {
        this.isRecommend = isRecommend;
    }

    public List<AccountUnifyContentInfo> getAccountList() {
        return accountList;
    }

    public void setAccountList(List<AccountUnifyContentInfo> accountList) {
        this.accountList = accountList;
    }

    public List<AccountUnifyContentInfo> getUnifyList() {
        return unifyList;
    }

    public void setUnifyList(List<AccountUnifyContentInfo> unifyList) {
        this.unifyList = unifyList;
    }
}
