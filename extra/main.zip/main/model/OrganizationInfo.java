package com.hhdd.kada.main.model;

/**
 * Created by simon on 9/19/16.
 */
public class OrganizationInfo extends BaseModel {

    int orgId;
    String orgName;
    String iconUrl;
    int orgType;
    int count;
    int ind;
    String bannerUrl;
    String introduction;
    int clickCount;
    String soundUrl;
    String bgimageUrl;
    String description;

    public String clickCountString() {
        String countString = "0";
        if (clickCount>=10000) {
            float f=clickCount/10000;
            countString = String.valueOf((float)(Math.round(f*10)/10))+"万次";
        } else if (clickCount<1000){
            countString = "<1000";
        }else {
            countString = String.valueOf(clickCount);
        }
        return countString;
    }

    public int getOrgId() {
        return orgId;
    }

    public void setOrgId(int orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getIconUrl() {
        return iconUrl;
    }

    public void setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getOrgType() {
        return orgType;
    }

    public void setOrgType(int orgType) {
        this.orgType = orgType;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getInd() {
        return ind;
    }

    public void setInd(int ind) {
        this.ind = ind;
    }

    public String getBannerUrl() {
        return bannerUrl;
    }

    public void setBannerUrl(String bannerUrl) {
        this.bannerUrl = bannerUrl;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
    }

    public String getSoundUrl() {
        return soundUrl;
    }

    public void setSoundUrl(String soundUrl) {
        this.soundUrl = soundUrl;
    }

    public String getBgimageUrl() {
        return bgimageUrl;
    }

    public void setBgimageUrl(String bgimageUrl) {
        this.bgimageUrl = bgimageUrl;
    }
}


//orgId: 1,
//        orgName: "咔哒故事",
//        iconUrl: "http://image.hhdd.com/books/cover/97193092-8d26-4b22-9651-69b9ed5c53aa.jpg",
//        description: "咔哒故事",
//        orgType: 1,
//        count: 1,
//        ind: 1,
//        bannerUrl: "http://image.hhdd.com/books/cover/97193092-8d26-4b22-9651-69b9ed5c53aa.jpg",
//        introduction: "咔哒故事",
//        clickCount: 10001
//


