package com.hhdd.kada.main.model;

import com.hhdd.kada.module.talentplan.model.TalentPlanRewardRecommendInfo;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/13
 * @describe : com.hhdd.kada.main.model
 */
public class TalentPlanCollectInfo extends BaseModel {

    /**
     * "collectId": 700001,
     * "name": "优才计划",
     * "subscribeCount": 14,
     * "subscribeInitCount": 22,
     * "price": 1,
     * "appleProId": "fdafdasfdsa",
     * "appleChProId": "fdasfdasfds",
     * "coverUrl": "http://www.baidu.com",
     * "recommend": "fdafdsafdsafdsa",
     * "applePrice": 1,
     * "collectType": 1
     */
    private int collectId; //优才计划合集id
    private String name;
    private int subscribeCount; //优才计划开通人数
    private int subscribeInitCount; //初始人数
    private int price; //优才计划价格 单位 分
    private String coverUrl;
    private String recommend;
    private int collectType;
    private String shareUrl; //分享跳转链接地址
    private String detailUrl; //优才计划介绍地址
    private double originalPrice; //优才计划原价
    private int extFlag;

    public TalentPlanCollectInfo() {
    }

    public TalentPlanCollectInfo(TalentPlanRewardRecommendInfo rewardRecommendInfo) {
        collectId = rewardRecommendInfo.collectId;
        name = rewardRecommendInfo.name;
        extFlag = rewardRecommendInfo.extFlag;
        originalPrice = rewardRecommendInfo.originalPrice;
        price = (int) rewardRecommendInfo.price;
        subscribeCount = rewardRecommendInfo.subscribeCount;
        coverUrl = rewardRecommendInfo.coverUrl;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getSubscribeCount() {
        return subscribeCount;
    }

    public void setSubscribeCount(int subscribeCount) {
        this.subscribeCount = subscribeCount;
    }

    public int getSubscribeInitCount() {
        return subscribeInitCount;
    }

    public void setSubscribeInitCount(int subscribeInitCount) {
        this.subscribeInitCount = subscribeInitCount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getRecommend() {
        return recommend;
    }

    public void setRecommend(String recommend) {
        this.recommend = recommend;
    }

    public int getCollectType() {
        return collectType;
    }

    public void setCollectType(int collectType) {
        this.collectType = collectType;
    }

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl;
    }

    public String getDetailUrl() {
        return detailUrl;
    }

    public void setDetailUrl(String detailUrl) {
        this.detailUrl = detailUrl;
    }

    public double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public int getExtFlag() {
        return extFlag;
    }

    public void setExtFlag(int extFlag) {
        this.extFlag = extFlag;
    }
}
