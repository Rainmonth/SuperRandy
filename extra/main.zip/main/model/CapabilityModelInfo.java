package com.hhdd.kada.main.model;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/13
 * @describe : com.hhdd.kada.main.model
 */
public class CapabilityModelInfo extends BaseModel {

    private int dimensionId; //维度ID
    private String dimensionName; //维度名称 如 科学认知
    private String dimensionDetail; //维度说明
    private int abilityId; //能力级别ID
    private String abilityName; //能力级别名称 如 LV1
    private int bookCount; //本维度的绘本数
    private int storyCount; //本维度的听书数
    private List<GeniusModelInfo> genius; //精灵信息数组，支持多个精灵

    public int getDimensionId() {
        return dimensionId;
    }

    public void setDimensionId(int dimensionId) {
        this.dimensionId = dimensionId;
    }

    public String getDimensionName() {
        return dimensionName;
    }

    public void setDimensionName(String dimensionName) {
        this.dimensionName = dimensionName;
    }

    public String getDimensionDetail() {
        return dimensionDetail;
    }

    public void setDimensionDetail(String dimensionDetail) {
        this.dimensionDetail = dimensionDetail;
    }

    public int getAbilityId() {
        return abilityId;
    }

    public void setAbilityId(int abilityId) {
        this.abilityId = abilityId;
    }

    public String getAbilityName() {
        return abilityName;
    }

    public void setAbilityName(String abilityName) {
        this.abilityName = abilityName;
    }

    public int getBookCount() {
        return bookCount;
    }

    public void setBookCount(int bookCount) {
        this.bookCount = bookCount;
    }

    public int getStoryCount() {
        return storyCount;
    }

    public void setStoryCount(int storyCount) {
        this.storyCount = storyCount;
    }

    public List<GeniusModelInfo> getGenius() {
        return genius;
    }

    public void setGenius(List<GeniusModelInfo> genius) {
        this.genius = genius;
    }
}
