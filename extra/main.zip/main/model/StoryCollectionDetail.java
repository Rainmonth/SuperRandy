package com.hhdd.kada.main.model;

import java.util.List;

/**
 * Created by lj on 17/4/24.
 */

public class StoryCollectionDetail extends BaseModel {
//         "clickCount": 2350,
//        "subscribeCount": 100,
//        "price": 188,
//        "serialize": "每周二、四 20:00",
//        "recommend": "好听的科普故事2",
//        "subscribe": 0,
    private int collectId;
    private int categoryId;
    private String name;
    private String bannerUrl;
    private String coverUrl;
    private String introduction;
    private int count;
    private int type;
    private int clickCount;
    private int subscribeCount;
    private double price;
    private int extFlag;
    private String serialize;
    private String recommend;
    private int subscribe; //  是否订阅 0:未订阅  1:已订阅  2:已取消订阅  3:假订阅
    private int status; //合辑状态 1：上线  3：下线  4：删除
    private double originalPrice;
    private long remainingTime; // 限免剩余时间 added from v3.8.0

    private boolean isShowResume; //是否显示续播，用于控制合集中螃蟹提示语贴着banner底部还是留点间距

    private List<StoryInfo> items;
    private List<Integer> dimensionIdList;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getBannerUrl() {
        return bannerUrl;
    }

    public void setBannerUrl(String bannerUrl) {
        this.bannerUrl = bannerUrl;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
    }

    public int getSubscribeCount() {
        return subscribeCount;
    }

    public void setSubscribeCount(int subscribeCount) {
        this.subscribeCount = subscribeCount;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getSerialize() {
        return serialize;
    }

    public void setSerialize(String serialize) {
        this.serialize = serialize;
    }

    public String getRecommend() {
        return recommend;
    }

    public void setRecommend(String recommend) {
        this.recommend = recommend;
    }

    public int getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(int subscribe) {
        this.subscribe = subscribe;
    }

    public int getExtFlag() {
        return extFlag;
    }

    public void setExtFlag(int extFlag) {
        this.extFlag = extFlag;
    }

    public List<StoryInfo> getItems() {
        return items;
    }

    public void setItems(List<StoryInfo> items) {
        this.items = items;
    }

    public double getOriginalPrice() {
        return originalPrice;
    }

    public void setOriginalPrice(double originalPrice) {
        this.originalPrice = originalPrice;
    }

    public long getRemainingTime() {
        return remainingTime;
    }

    public void setRemainingTime(long remainingTime) {
        this.remainingTime = remainingTime;
    }

    public boolean isShowResume() {
        return isShowResume;
    }

    public void setShowResume(boolean showResume) {
        isShowResume = showResume;
    }

    public List<Integer> getDimensionIdList() {
        return dimensionIdList;
    }

    public void setDimensionIdList(List<Integer> dimensionIdList) {
        this.dimensionIdList = dimensionIdList;
    }

    @Override
    public String toString() {
        return "StoryCollectionDetail{" +
                "collectId=" + collectId +
                ", categoryId=" + categoryId +
                ", name='" + name + '\'' +
                ", bannerUrl='" + bannerUrl + '\'' +
                ", coverUrl='" + coverUrl + '\'' +
                ", introduction='" + introduction + '\'' +
                ", count=" + count +
                ", type=" + type +
                ", clickCount=" + clickCount +
                ", subscribeCount=" + subscribeCount +
                ", price=" + price +
                ", extFlag=" + extFlag +
                ", serialize='" + serialize + '\'' +
                ", recommend='" + recommend + '\'' +
                ", subscribe=" + subscribe +
                ", status=" + status +
                ", items=" + items +
                '}';
    }
}
