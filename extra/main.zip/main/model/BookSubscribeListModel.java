package com.hhdd.kada.main.model;

import java.util.List;

/**
 * Created by mcx on 2017/8/3.
 */

public class BookSubscribeListModel extends BaseModel{
    private List<BookOtherCollectListModel> freeList;
    private List<BookOtherCollectListModel> chargeList;

    public List<BookOtherCollectListModel> getFreeList() {
        return freeList;
    }

    public void setFreeList(List<BookOtherCollectListModel> freeList) {
        this.freeList = freeList;
    }

    public List<BookOtherCollectListModel> getChargeList() {
        return chargeList;
    }

    public void setChargeList(List<BookOtherCollectListModel> chargeList) {
        this.chargeList = chargeList;
    }
}
