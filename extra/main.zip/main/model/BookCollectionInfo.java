package com.hhdd.kada.main.model;


/**
 * Created by lj on 16/11/25.
 */

public class BookCollectionInfo extends BaseCollectionInfo {

    private int sourceId;//妈妈-推荐付费列表 表示合集id
    private String sourceKey; //打点统计相关 {name:"" content:""} =>json  妈妈页面
    private int collectId;
    private int categoryId;
    private int extFlag;
    private int type;
    private String author;
    private int minAge;
    private int maxAge;
    private int clickCount;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getExtFlag() {
        return extFlag;
    }

    public void setExtFlag(int extFlag) {
        this.extFlag = extFlag;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public int getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(int maxAge) {
        this.maxAge = maxAge;
    }

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
    }

    @Override
    public int getId() {
        return collectId;
    }

    public int getSourceId() {
        return sourceId;
    }

    public void setSourceId(int sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceKey() {
        return sourceKey;
    }

    public void setSourceKey(String sourceKey) {
        this.sourceKey = sourceKey;
    }

    public static BookCollectionInfo createBySearchBookResultInfo(SearchBookResultInfo info){
        BookCollectionInfo bookCollectionInfo = new BookCollectionInfo();
        bookCollectionInfo.setCollectId(info.getSourceId());
        bookCollectionInfo.setCoverUrl(info.getCoverUrl());
        return bookCollectionInfo;
    }

    @Override
    public String toString() {
        return "BookCollectionInfo{" +
                "collectId=" + collectId +
                ", categoryId=" + categoryId +
                ", type=" + type +
                ", name='" + name + '\'' +
                '}';
    }
}
