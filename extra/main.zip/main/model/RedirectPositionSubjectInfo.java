package com.hhdd.kada.main.model;

/**
 * @autor lazys
 * @created 2018/5/25 09:41
 * @desc 新增精选主题样式，延用之前主题的数据结构，新增位置position属性 0 == 居中  1 == 左对齐
 */
public class RedirectPositionSubjectInfo extends RedirectInfo {
    int position = 0;//默认居中

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
