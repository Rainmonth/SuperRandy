package com.hhdd.kada.main.model;

/**
 * @autor lazys
 * @created 2018/5/25 09:41
 * @desc 新增精选主题样式，延用之前主题的数据结构，新增位置position属性 0 == 居中  1 == 左对齐
 */
public class RedirectPositionSubjectInfo extends RedirectInfo {
    int position = 0;//默认居中
    // 属于哪个，由于该ViewHolder被多个地方共用，需要为了展示不同样式，需增加该字段来予以区分
    int belongTo = 0; // 默认来自精选，0来自精选，1来自听书首页

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getBelongTo() {
        return belongTo;
    }

    public void setBelongTo(int belongTo) {
        this.belongTo = belongTo;
    }
}
