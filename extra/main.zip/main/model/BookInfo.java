package com.hhdd.kada.main.model;


import java.io.Serializable;

/**
 * Created by lj on 16/11/25.
 */

public class BookInfo extends BaseBookStoryInfo {

    private int collectId;   //为了方便处理，将合辑id赋予在bookinfo
    private boolean isFormUser;  //是否内置

    public boolean isFormUser() {
        return isFormUser;
    }

    public void setFormUser(boolean formUser) {
        isFormUser = formUser;
    }

    private int bookId;
    private String coverUrl;
    private int categoryId;
    private String name;
    private int direction;
    private int pageCount;
    private int type; // 1、中文绘本 2、英文绘本
    private int extFlag;
    private String uploadUser;
    private String author;
    private int minAge;
    private int maxAge;
    private String itemName;
    private String traceId;
    private int ind;    //合集内容顺序
    private int version;
    private int clickCount;
    private int hhcurrency; //需要多少咔哒币
    private boolean unLock;
    private String logo;//cp logo
    private int status;

    public BookInfo() {
    }

    public BookInfo(int bookId, String coverUrl, int categoryId, String name, int direction, int pageCount, int type, int extFlag, String uploadUser, String author, int minAge, int maxAge, String itemName, int version, int clickCount, int hhcurrency, boolean unLock, int status) {
        this.bookId = bookId;
        this.coverUrl = coverUrl;
        this.categoryId = categoryId;
        this.name = name;
        this.direction = direction;
        this.pageCount = pageCount;
        this.type = type;
        this.extFlag = extFlag;
        this.uploadUser = uploadUser;
        this.author = author;
        this.minAge = minAge;
        this.maxAge = maxAge;
        this.itemName = itemName;
        this.version = version;
        this.clickCount = clickCount;
        this.hhcurrency = hhcurrency;
        this.unLock = unLock;
        this.status = status;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getInd() {
        return ind;
    }

    public void setInd(int ind) {
        this.ind = ind;
    }

    public String getTraceId() {
        return traceId;
    }

    public void setTraceId(String traceId) {
        this.traceId = traceId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDirection() {
        return direction;
    }

    public void setDirection(int direction) {
        this.direction = direction;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getExtFlag() {
        return extFlag;
    }

    public void setExtFlag(int extFlag) {
        this.extFlag = extFlag;
    }

    public String getUploadUser() {
        return uploadUser;
    }

    public void setUploadUser(String uploadUser) {
        this.uploadUser = uploadUser;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getMinAge() {
        return minAge;
    }

    public void setMinAge(int minAge) {
        this.minAge = minAge;
    }

    public int getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(int maxAge) {
        this.maxAge = maxAge;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getClickCount() {
        return clickCount;
    }

    public void setClickCount(int clickCount) {
        this.clickCount = clickCount;
    }

    public int getHhcurrency() {
        return hhcurrency;
    }

    public void setHhcurrency(int hhcurrency) {
        this.hhcurrency = hhcurrency;
    }

    public boolean isUnLock() {
        return unLock;
    }

    public void setUnLock(boolean unLock) {
        this.unLock = unLock;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    // 根据 first 判断两个 id 是否相等
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }
        if (o.getClass() == BookInfo.class)
        {
            BookInfo n = (BookInfo)o;
            return n.getBookId() == this.getBookId();
        }
        return false;
    }

    // 根据 first 计算 Name 对象的 hashCode() 返回值
    public int hashCode()
    {
        return this.getBookId();
    }


    public BookInfo clone() {
        BookInfo bookInfo = new BookInfo();
        bookInfo.bookId=bookId;
        bookInfo.coverUrl=coverUrl;
        bookInfo.categoryId=categoryId;
        bookInfo.name=name;
        bookInfo.direction=direction;
        bookInfo.pageCount=pageCount;
        bookInfo.type=type;
        bookInfo.extFlag=extFlag;
        bookInfo.uploadUser=uploadUser;
        bookInfo.minAge=minAge;
        bookInfo.maxAge=maxAge;
        bookInfo.itemName=itemName;
        bookInfo.author=author;
        bookInfo.author=author;
        bookInfo.version=version;
        bookInfo.clickCount = clickCount;
        bookInfo.hhcurrency = hhcurrency;
        bookInfo.unLock = unLock;
        return bookInfo;
    }

    @Override
    public int getId() {
        return bookId;
    }

    public static BookInfo createBySearchBookResultInfo(SearchBookResultInfo info){
        BookInfo bookInfo = new BookInfo();
        bookInfo.setBookId(info.getSourceId());
        bookInfo.setCoverUrl(info.getCoverUrl());
        return bookInfo;
    }
}


