package com.hhdd.kada.main.model;

import java.io.Serializable;

/**
 * Created by lj on 17/3/7.
 */

public class WeixinPayModel implements Serializable {

    boolean fillPhone;
    String openID;
    boolean toast;
    int comple;
    boolean firstLogin; //是否微信第一次登录，若非第一次登录，不出完善资料页面
    private String loginName; //登录帐号(合并后主帐号)用户名，用于获取本地对应正确的数据库

    public boolean isFillPhone() {
        return fillPhone;
    }

    public void setFillPhone(boolean fillPhone) {
        this.fillPhone = fillPhone;
    }

    public String getOpenID() {
        return openID;
    }

    public void setOpenID(String openID) {
        this.openID = openID;
    }

    public boolean isToast() {
        return toast;
    }

    public void setToast(boolean toast) {
        this.toast = toast;
    }

    public int getComple() {
        return comple;
    }

    public void setComple(int comple) {
        this.comple = comple;
    }

    public boolean isFirstLogin() {
        return firstLogin;
    }

    public void setFirstLogin(boolean firstLogin) {
        this.firstLogin = firstLogin;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }
}
