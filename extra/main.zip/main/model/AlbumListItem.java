package com.hhdd.kada.main.model;

/**
 * Created by lj on 16/9/21.
 */
public class AlbumListItem extends BaseModel {

    public static final int TYPE_BANNER = 1;
    public static final int TYPE_DETAIL=2;

    public AlbumListItem() {

    }

    public AlbumListItem(int type, BaseModel data) {
        this.type=type;
        this.data=data;
    }

    int type;
    BaseModel data;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public BaseModel getData() {
        return data;
    }

    public void setData(BaseModel data) {
        this.data = data;
    }
}
