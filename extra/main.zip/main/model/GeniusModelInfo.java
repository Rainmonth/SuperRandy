package com.hhdd.kada.main.model;

import android.text.TextUtils;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/22
 * @describe : com.hhdd.kada.main.model
 */
public class GeniusModelInfo extends BaseModel {

    private int geniusId; // 精灵ID
    private String geniusName; // 精灵名称 科学火龙果
    private String geniusDetail; // 精灵说明
    private String geniusLevel; // 精灵级别 D->C->B->A
    private float geniusValue; // 本级别满级所需养料值
    private float consumeValue; // 消耗的养料值

    public int getGeniusId() {
        return geniusId;
    }

    public void setGeniusId(int geniusId) {
        this.geniusId = geniusId;
    }

    public String getGeniusName() {
        return geniusName;
    }

    public void setGeniusName(String geniusName) {
        this.geniusName = geniusName;
    }

    public String getGeniusDetail() {
        return geniusDetail;
    }

    public void setGeniusDetail(String geniusDetail) {
        this.geniusDetail = geniusDetail;
    }

    public String getGeniusLevel() {
        if(!TextUtils.isEmpty(geniusLevel)) {
            return geniusLevel.toUpperCase();
        }
        return geniusLevel;
    }

    public void setGeniusLevel(String geniusLevel) {
        this.geniusLevel = geniusLevel;
    }

    public float getGeniusValue() {
        return geniusValue;
    }

    public void setGeniusValue(float geniusValue) {
        this.geniusValue = geniusValue;
    }

    public float getConsumeValue() {
        return consumeValue;
    }

    public void setConsumeValue(float consumeValue) {
        this.consumeValue = consumeValue;
    }
}
