package com.hhdd.kada.main.model;

import java.util.List;

/**
 * Created by mcx on 2017/8/7.
 */

public class BookCollectionCategoryInfo extends BaseModel {
    private String type;
    private List<SubCategoryInfo> data;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<SubCategoryInfo> getData() {
        return data;
    }

    public void setData(List<SubCategoryInfo> data) {
        this.data = data;
    }

    public static class SubCategoryInfo extends BaseModel {
        private String title;
        private String redirectUri;
        private int count;
        private String iconUrl;
        private int ind;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getRedirectUri() {
            return redirectUri;
        }

        public void setRedirectUri(String redirectUri) {
            this.redirectUri = redirectUri;
        }

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public int getInd() {
            return ind;
        }

        public void setInd(int ind) {
            this.ind = ind;
        }
    }
}
