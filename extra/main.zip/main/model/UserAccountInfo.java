package com.hhdd.kada.main.model;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/12
 * @describe : com.hhdd.kada.main.model
 */
public class UserAccountInfo extends BaseModel {

    private int type; // 1 手机帐号信息  2 微信帐号信息  3 华为帐号信息
    /**
     * status目前1的情况仅为当前登录帐号，故当前是以1来判断是否为当前帐号，
     * 也就是仅状态为0的时候才显示立即绑定，其它情况均显示对应信息
     */
    private int status; // 0 帐号信息不存在  1 未合并  2 已合并
    private String nick; // 帐号用户昵称
    private String loginName; //帐号名称
    private String headUrl; //用户头像URL

    public static final int TYPE_PHONE = 1;
    public static final int TYPE_WEIXIN = TYPE_PHONE + 1;
    public static final int TYPE_HUAWEI = TYPE_WEIXIN + 1;
    public static final int STATUS_ACCOUNT_NONE = 0;
    public static final int STATUS_UN_BIND = STATUS_ACCOUNT_NONE + 1;
    public static final int STATUS_ALREADY_BIND = STATUS_UN_BIND + 1;

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getHeadUrl() {
        return headUrl;
    }

    public void setHeadUrl(String headUrl) {
        this.headUrl = headUrl;
    }
}
