package com.hhdd.kada.main.model;

import java.util.List;

/**
 * Created by simon on 18/11/2016.
 */

public class DataListItem extends BaseModel {

    //类型和数据
    String type;
    List<BaseModel> list;

    //style
    int sep; //1: 显示items分隔条，0不显示s
    int title; //1: 显示标题在底部

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<BaseModel> getList() {
        return list;
    }

    public void setList(List<BaseModel> list) {
        this.list = list;
    }

    public int getSep() {
        return sep;
    }

    public void setSep(int sep) {
        this.sep = sep;
    }

    public int getTitle() {
        return title;
    }

    public void setTitle(int title) {
        this.title = title;
    }
}
