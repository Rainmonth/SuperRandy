package com.hhdd.kada.main.model;

import java.util.List;

/**
 * Created by sxh on 2017/4/25.
 */

public class StoryCollectionCategoryInfo extends BaseModel {


    /**
     * type : 类型
     * data : [{"title":"新品","redirectUri":"kada://openstorycollectioncommon?extFlag=4","count":339,"iconUrl":"http: //cdn.hhdd.com/assets/img/1a0e4316-a06e-48b9-911f-b286a1fc09de.png","ind":1},{"title":"连载","redirectUri":"kada://openstorycollectioncommon?extFlag=16","count":339,"iconUrl":"http: //cdn.hhdd.com/assets/img/1a0e4316-a06e-48b9-911f-b286a1fc09de.png","ind":2}]
     */

    private String type;
    private List<SubCategoryInfo> data;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<SubCategoryInfo> getData() {
        return data;
    }

    public void setData(List<SubCategoryInfo> data) {
        this.data = data;
    }

    public static class SubCategoryInfo extends BaseModel{
        /**
         * title : 新品
         * redirectUri : kada://openstorycollectioncommon?extFlag=4
         * count : 339
         * iconUrl : http: //cdn.hhdd.com/assets/img/1a0e4316-a06e-48b9-911f-b286a1fc09de.png
         * ind : 1
         */

        private String title;
        private String redirectUri;
        private int count;
        private String iconUrl;
        private int ind;

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getRedirectUri() {
            return redirectUri;
        }

        public void setRedirectUri(String redirectUri) {
            this.redirectUri = redirectUri;
        }

        public int getCount() {
            return count;
        }

        public void setCount(int count) {
            this.count = count;
        }

        public String getIconUrl() {
            return iconUrl;
        }

        public void setIconUrl(String iconUrl) {
            this.iconUrl = iconUrl;
        }

        public int getInd() {
            return ind;
        }

        public void setInd(int ind) {
            this.ind = ind;
        }
    }
}