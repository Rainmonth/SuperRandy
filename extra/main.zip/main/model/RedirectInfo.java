package com.hhdd.kada.main.model;

import com.google.gson.Gson;
import com.hhdd.logger.LogHelper;

import java.io.Serializable;

/**
 * Created by simon on 6/8/16.
 */
public class RedirectInfo extends BaseModel {

    int redirectId;//如果不存数据库,可不要

    //标题
    String title;

    //子标题
    String subTitle;

    //图
    String imageUrl;

    //图片展示的宽,一般定义为0满屏
    float width;

    //高 0
    float height;

    //kada://videolist, kada://datalist?module=book_new&path=new_config.json&params=xxxx
    String redirectUri;

    //跳转协议兼容
    String html5;

    //打点统计相关
    String sourceKey; //{name:"" content:""} =>json

    public RedirectInfo() {
    }

    ///...
    public int getRedirectId() {
        return redirectId;
    }

    public void setRedirectId(int redirectId) {
        this.redirectId = redirectId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubTitle() {
        return subTitle;
    }

    public void setSubTitle(String subTitle) {
        this.subTitle = subTitle;
    }

    public String getImageUrl() {
        return imageUrl==null?"":imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public float getWidth() {
        return width;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public String getRedirectUri() {
        return redirectUri;
    }

    public void setRedirectUri(String redirectUri) {
        this.redirectUri = redirectUri;
    }

    public String getHtml5() {
        return html5;
    }

    public void setHtml5(String html5) {
        this.html5 = html5;
    }

    public String getSourceKey() {
        return sourceKey;
    }

    public void setSourceKey(String sourceKey) {
        this.sourceKey = sourceKey;
    }

    public static class SourceKeyStatInfo implements Serializable{
        String name;
        String content;

        public String getContent() {
            return content!=null?content:"";
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getName() {
            return name!=null?name:"";
        }

        public void setName(String name) {
            this.name = name;
        }

        public static SourceKeyStatInfo parse(String jsonString) {
            SourceKeyStatInfo statInfo=null;
            if (jsonString!=null&&jsonString.length()>0) {
                try {
                    Gson gson = new Gson();
                    statInfo = gson.fromJson(jsonString,SourceKeyStatInfo.class);
                } catch (Exception e) {
                    LogHelper.printStackTrace(e);
                }
            }
            return statInfo;
        }
    }
}
