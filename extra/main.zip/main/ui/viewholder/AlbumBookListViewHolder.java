package com.hhdd.kada.main.ui.viewholder;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;


import com.hhdd.core.model.BaseVO;
import com.hhdd.core.model.BookInfo;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;

import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.views.ScaleDraweeView;

import java.util.List;

/**
 * Created by lj on 16/3/16.
 */
public class AlbumBookListViewHolder extends BaseViewHolder {

    int mItemWidth;
    int mItemHeight;
    View view;
    ViewGroup container;


    public AlbumBookListViewHolder(Context context) {
        super(context);

        int itemMarginLeft = (int) mContext.getResources().getDimension(
                R.dimen.listen_grid_view_item_margin_right);
        int itemMarginRight = (int) mContext.getResources().getDimension(
                R.dimen.listen_grid_view_item_margin_right);


        int itemPaddingRight = (int) mContext.getResources().getDimension(R.dimen.listen_grid_view_item_padding_right);
        int itemPaddingLeft = (int) mContext.getResources().getDimension(R.dimen.listen_grid_view_item_padding_left);

        int itemSpacing = (int) mContext.getResources().getDimension(
                R.dimen.listen_grid_view_spacing);
        int screenWidth = ScreenUtil.getScreenSize(mContext).x;
        mItemWidth = (int) ((screenWidth - itemMarginLeft - itemMarginRight - itemPaddingRight - itemPaddingLeft - 2 * itemSpacing) / 3.0f);
        mItemHeight = (int) (mItemWidth * 32.0f / 25.0f);
    }

    @Override
    public void recycle() {
        super.recycle();
    }

    @Override
    public View initView() {
        view = View.inflate(mContext, R.layout.album_book_layout, null);
        container = (ViewGroup) getChildView(view, R.id.container);

        for (int index = 0; index < container.getChildCount(); index++) {

            final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(index));
            final ScaleDraweeView cover = (ScaleDraweeView) frameLayout.getChildAt(0);

//            ((FrameLayout)container.getChildAt(index)).getChildAt()
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) (frameLayout.getLayoutParams());
            FrameLayout.LayoutParams coverParams = (FrameLayout.LayoutParams) cover.getLayoutParams();

            params.width = mItemWidth;
            params.height = mItemHeight + (int) mContext.getResources().getDimension(R.dimen.listen_albumplaylistview_number_height);
            coverParams.width = mItemWidth - (int) mContext.getResources().getDimension(R.dimen.story_margin);
            coverParams.height = mItemHeight;

            if ((index + 1) % 3 == 0) {
                params.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;

            } else if ((index + 1) % 3 == 1) {
                params.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;

            } else {
                params.gravity = Gravity.CENTER;
            }
            cover.setLayoutParams(coverParams);
            frameLayout.setLayoutParams(params);

            cover.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(final View v) {

                    frameLayout.getChildAt(2).setVisibility(View.GONE);
                    final int[] location = new int[2];
                    cover.getLocationOnScreen(location);

                    Object object = cover.getTag(R.id.listen_list_book_info);
                    if (object != null && object instanceof BookInfo) {
                        final BookInfo info = (BookInfo) object;
                        if (info.getInfoType() == BookInfo.TYPE_BOOK) {

//                            KaDaApplication.getInstance().setBitmapList(null);
//                            final List<Bitmap> bitmapList = new ArrayList<Bitmap>();
//                            Bitmap bitmap = BitmapUtils.drawableToBitmap(cover.getDrawable(),cover.getWidth(),cover.getHeight());
//                            if (bitmap != null) {
//
//                                bitmapList.add(bitmap);
//                                KaDaApplication.getInstance().setBitmapList(bitmapList);
//                                BookService.saveBookInfoToLocal(info);
//
//                                PlaybackActivity.BookLocation bookLocation = new PlaybackActivity.BookLocation(location[0], location[1], cover.getWidth(), cover.getHeight());
//                                PlaybackActivity.startActivity(mContext, info.getBookId(), info.getExtFlag(), info.getVersion(), bookLocation);
//                            }else{
                            PlaybackActivity.startActivity(mContext, info.getBookId(), info.getExtFlag(), info.getVersion());
//                            }
                        }
                    }

                }
            });


        }
        return view;
    }

    @Override
    public void loadData(BaseVO vo) {
    }

    @Override
    public void loadData(List<BaseVO> list) {

        if (list != null && list.size() > 0) {
            int count = list.size() > 3 ? 3 : list.size();
            for (int i = 0; i < count; i++) {
                if (list.get(i) instanceof BookInfo) {
                    BookInfo info = (BookInfo) list.get(i);
                    FrameLayout layout = (FrameLayout) container.getChildAt(i);
                    layout.setVisibility(View.VISIBLE);
                    ScaleDraweeView cover = (ScaleDraweeView) layout.getChildAt(0);
                    ImageView flag = (ImageView) layout.getChildAt(2);
                    TextView clickCount = (TextView) layout.getChildAt(3);
                    clickCount.setText(StringUtil.formatClickCount(info.getClickCount()));

                    if ((info.getExtFlag() & Extflag.EXT_FLAG_256) == Extflag.EXT_FLAG_256) {
//                        if (((HistoryCache) ServiceProxyFactory.getProxy().getService(ServiceProxyName.HISTORY_CACHE)).isContainBookId(info.getBookId())) {
//                            flag.setVisibility(View.GONE);
//                        } else {
//                            flag.setVisibility(View.VISIBLE);
//                            flag.setImageResource(R.drawable.icon_hot_flag);
//                        }
                        flag.setVisibility(View.VISIBLE);
                        flag.setImageResource(R.drawable.icon_hot_flag);
                    } else {
                        if ((info.getExtFlag() & Extflag.EXT_FLAG_64) == Extflag.EXT_FLAG_64) {
//                            if (((HistoryCache) ServiceProxyFactory.getProxy().getService(ServiceProxyName.HISTORY_CACHE)).isContainBookId(info.getBookId())) {
//                                flag.setVisibility(View.GONE);
//                            } else {
//                                flag.setVisibility(View.VISIBLE);
//                                flag.setImageResource(R.drawable.icon_new_flag);
//                            }
                            flag.setVisibility(View.VISIBLE);
                            flag.setImageResource(R.drawable.icon_new_flag);
                        } else {
                            flag.setVisibility(View.GONE);
                        }
                    }

                    TextView number = (TextView) layout.getChildAt(1);
                    number.setText(info.getItemName());

                    String coverUrl = info.getCoverUrl();
                    boolean needResetImageUrl = true;
                    if (cover.getTag(R.id.list_item_image_url) != null) {
                        String url = (String) cover.getTag(R.id.list_item_image_url);
                        if (TextUtils.equals(url, coverUrl)) {
                            needResetImageUrl = false;
                        }
                    }
                    if (needResetImageUrl) {
                        cover.setTag(R.id.list_item_image_url, coverUrl);
                        FrescoUtils.showUrl(coverUrl, cover, mItemWidth, mItemHeight);
                    }

                    cover.setTag(R.id.listen_list_book_info, info);
                }
            }
            for (int i = count; i < container.getChildCount(); i++) {
                FrameLayout layout = (FrameLayout) container.getChildAt(i);
                ScaleDraweeView cover = (ScaleDraweeView) layout.getChildAt(0);
                layout.setVisibility(View.GONE);
                cover.setTag(R.id.listen_list_book_info, null);
            }
        }
    }

}