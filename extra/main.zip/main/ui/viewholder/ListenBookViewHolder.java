package com.hhdd.kada.main.ui.viewholder;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.net.Uri;
import android.view.View;
import android.view.animation.LinearInterpolator;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.core.model.BaseVO;
import com.hhdd.core.model.StoryInfo;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.views.ScaleDraweeView;

import java.util.List;

/**
 * Created by lj on 15/9/24.
 */
public class ListenBookViewHolder extends BaseViewHolder {

    private View coverBgLayout;
    private ScaleDraweeView cover;
    private SimpleDraweeView coverBgSdv;
//    private ImageView mPlayBtn;
    int coverLayoutSize, coverSize;

    public ListenBookViewHolder(Context context) {
        super(context);
    }

    @Override
    public View initView() {
        View layout = View.inflate(mContext, R.layout.listen_book_item, null);
        coverBgLayout = layout.findViewById(R.id.cover_bg_layout);
        cover = (ScaleDraweeView) layout.findViewById(R.id.listen_cover);
        coverBgSdv = (SimpleDraweeView) layout.findViewById(R.id.listen_cover_bg_sdv);

        coverLayoutSize = (int) (ScreenUtil.getScreenWidth(mContext) * 6 / 7.0f);
        coverSize = (int) (ScreenUtil.getScreenWidth(mContext) / 2.0f);

        coverBgLayout.getLayoutParams().width = coverLayoutSize;
        coverBgLayout.getLayoutParams().height = coverLayoutSize;

        cover.getLayoutParams().width = coverSize;
        cover.getLayoutParams().height = coverSize;
        return layout;
    }


    @Override
    public void loadData(BaseVO vo) {
        if (vo != null && vo instanceof StoryInfo) {
            final StoryInfo storyInfo = (StoryInfo) vo;
            if (storyInfo.getCoverUrl() != null) {
//                cover.setImageURI(Uri.parse(storyInfo.getCoverUrl()));
//                FrescoUtils.showUrl(storyInfo.getCoverUrl(),cover,coverSize,coverSize);

                String imgUrl = CdnUtils.getImgCdnUrl(storyInfo.getCoverUrl(), CdnUtils.getStoryCoverSize());
                FrescoUtils.showImg(cover, imgUrl, coverSize, coverSize);
            } else {
                cover.setImageURI(Uri.parse("res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.books_two));
            }
            cover.setVisibility(View.VISIBLE);
            cover.setTag(R.id.listen_list_book_info, storyInfo);
        }
    }

    @Override
    public void loadData(List<BaseVO> list) {

    }

    public void startAnim() {

        ValueAnimator rotate;
        Object o = cover.getTag(R.id.listen_book_index_anim_listener);
        if (o != null && o instanceof ValueAnimator) {
            rotate = (ValueAnimator) o;
        } else {
            rotate = ObjectAnimator.ofFloat(coverBgLayout, "rotation", 0, 360);
            rotate.setRepeatCount(-1);
            rotate.setDuration(10000);
            rotate.setInterpolator(new LinearInterpolator());
            coverBgLayout.setTag(R.id.listen_book_index_anim_listener, rotate);
        }

        if (!rotate.isRunning()) {
            rotate.start();
        }
    }

    public void stopAnim() {
        ValueAnimator rotate;
        Object o = cover.getTag(R.id.listen_book_index_anim_listener);
        if (o != null && o instanceof ValueAnimator) {
            rotate = (ValueAnimator) o;
//                        rotate = listener.getAnimator();
        } else {
            rotate = ObjectAnimator.ofFloat(coverBgLayout, "rotation", 0, 360);
            rotate.setRepeatCount(-1);
            rotate.setDuration(30000);
            rotate.setInterpolator(new LinearInterpolator());
//            if(listener != null){
//                rotate.addUpdateListener(listener);
//            }
            coverBgLayout.setTag(R.id.listen_book_index_anim_listener, rotate);
        }

        rotate.end();
    }

    public void setBackground(int imgResId) {
        FrescoUtils.showImg(coverBgSdv, imgResId, coverLayoutSize, coverLayoutSize);
    }

    @Override
    public void recycle() {
        super.recycle();
    }
}
