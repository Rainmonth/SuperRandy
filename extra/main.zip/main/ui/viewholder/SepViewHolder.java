package com.hhdd.kada.main.ui.viewholder;

import android.content.Context;
import android.view.View;

import com.hhdd.core.model.BaseVO;
import com.hhdd.kada.R;

import java.util.List;

/**
 * Created by simon on 6/8/15.
 */
public class SepViewHolder extends BaseViewHolder {
    public SepViewHolder(Context context) {
        super(context);
    }

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.seperator_layout, null);
        return view;
    }

    @Override
    public void loadData(BaseVO vo) {

    }

    @Override
    public void loadData(List<BaseVO> list) {

    }
}
