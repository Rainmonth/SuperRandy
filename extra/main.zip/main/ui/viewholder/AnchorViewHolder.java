package com.hhdd.kada.main.ui.viewholder;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.OrganizationInfo;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;


/**
 * Created by sxh on 2017/4/24.
 */

public class AnchorViewHolder extends BaseViewHolder<BaseModelVO> implements View.OnClickListener {

    public static final int TYPE_ANCHOR_ITEM_CLICKED = 100;

    private View view;
    private SimpleDraweeView cover;
    private TextView name;
    private TextView des;
    private TextView count;
    private View container;

    @Override
    public View createView(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_anchor_list, parent, false);
        container = view.findViewById(R.id.container_anchor);
        cover = (SimpleDraweeView) view.findViewById(R.id.cover);
        name = (TextView) view.findViewById(R.id.cartoon_name);
        des = (TextView) view.findViewById(R.id.anchor_des);
        count = (TextView) view.findViewById(R.id.listen_count);
        container.setOnClickListener(this);
        return view;
    }

    @Override
    public void showData(int position, BaseModelVO baseModelVO) {
        if (baseModelVO != null) {
            BaseModel baseModel = baseModelVO.getModel();
            if (baseModel != null && baseModel instanceof OrganizationInfo) {
                final OrganizationInfo organizationInfo = (OrganizationInfo) baseModel;
                name.setText(organizationInfo.getOrgName());
                des.setText(organizationInfo.getDescription());
                count.setText(organizationInfo.clickCountString());
                count.setVisibility(View.INVISIBLE);

                String iconUrl = CdnUtils.getImgCdnUrl(organizationInfo.getIconUrl(), true);
                FrescoUtils.showImg(cover, iconUrl);
                container.setTag(organizationInfo);
            }
        }
    }

    @Override
    public void onClick(View v) {
        if (mOnEventProcessor == null) {
            return;
        }

        mOnEventProcessor.process(TYPE_ANCHOR_ITEM_CLICKED, v.getTag());
    }
}
