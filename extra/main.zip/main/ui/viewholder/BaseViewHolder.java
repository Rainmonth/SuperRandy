package com.hhdd.kada.main.ui.viewholder;

import android.content.Context;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;

import com.hhdd.core.model.BaseVO;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;

import java.util.List;

import butterknife.ButterKnife;

/**
 * Created by simon on 10/6/15.
 */
public abstract class BaseViewHolder {
    protected Context mContext;

    protected View rootView;

    public BaseViewHolder(Context context) {
        this.mContext = context;
        if(getLayoutId() > 0) {
            rootView = LayoutInflater.from(KaDaApplication.applicationContext()).inflate(getLayoutId(), null);
            ButterKnife.bind(this, rootView);
        }
    }

    protected int getLayoutId(){
        return 0;
    }

    public abstract View initView();

    public abstract void loadData(BaseVO vo);

    public void loadData(List<BaseVO> list) { }

    public void recycle() {

    }

    public static <T extends View> T getChildView(View view, int id) {
        SparseArray<View> viewHolder = (SparseArray<View>) view.getTag(R.id.view_holder);
        if (viewHolder == null) {
            viewHolder = new SparseArray<View>();
            view.setTag(R.id.view_holder,viewHolder);
        }
        View childView = viewHolder.get(id);
        if (childView == null) {
            childView = view.findViewById(id);
            viewHolder.put(id, childView);
        }
        return (T) childView;
    }
}
