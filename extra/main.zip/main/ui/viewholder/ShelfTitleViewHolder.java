package com.hhdd.kada.main.ui.viewholder;

import android.graphics.Color;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.StyleVO;

/**
 * Created by lj on 17/4/21.
 *
 * Restructured by Xiaoyu on 2018/8/13 下午3:02
 */

public class ShelfTitleViewHolder extends BaseViewHolder<BaseModelVO> {

    public static final int TYPE_MANAGE_CLICKED = 100;

    SimpleDraweeView titleIcon;
    TextView titleTv;
    View manageView;

    @Override
    public View createView(ViewGroup parent) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_holder_story_title, parent, false);

        titleIcon = (SimpleDraweeView) view.findViewById(R.id.datalist_title_icon);
        titleTv = (TextView) view.findViewById(R.id.datalist_title_tv);
        manageView = view.findViewById(R.id.datalist_title_manage);

        return view;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        if (itemData.getModel() != null) {
            BaseModel baseModel = itemData.getModel();
            if (baseModel instanceof RedirectInfo) {
                RedirectInfo redirectInfo = (RedirectInfo) baseModel;
                final String uri = redirectInfo.getRedirectUri();
                if(TextUtils.isEmpty(uri)){
                    manageView.setVisibility(View.INVISIBLE);
                    manageView.setOnClickListener(null);
                }else {
                    manageView.setVisibility(View.VISIBLE);
                    manageView.setTag(redirectInfo);
                    manageView.setOnClickListener(mOnClickWithAnimListener);
                }

                String title = redirectInfo.getTitle();
                if (!StringUtil.isEmpty(title)) {
                    titleTv.setText(title);
                }

                StyleVO styleVO = itemData.getStyleVO();
                if (styleVO == null || TextUtils.isEmpty(styleVO.getTextColor())) {
                    titleTv.setTextColor(Color.WHITE);
                } else {
                    titleTv.setTextColor(Color.parseColor(styleVO.getTextColor()));
                }

                String imgUrl = redirectInfo.getImageUrl();
                if (!StringUtil.isEmpty(imgUrl)) {
                    FrescoUtils.showUrl(imgUrl, titleIcon);
                }
            }
        }
    }

    private KaDaApplication.OnClickWithAnimListener mOnClickWithAnimListener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            RedirectInfo redirectInfo = (RedirectInfo) v.getTag();
            if (redirectInfo == null) {
                return;
            }

            mOnEventProcessor.process(TYPE_MANAGE_CLICKED);
        }
    };
}
