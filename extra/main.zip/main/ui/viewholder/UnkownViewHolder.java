package com.hhdd.kada.main.ui.viewholder;

import android.content.Context;
import android.view.View;

import com.hhdd.core.model.BaseVO;

/**
 * Created by simon on 6/8/15.
 */
public class UnkownViewHolder extends BaseViewHolder {

    public UnkownViewHolder(Context context) {
        super(context);
    }

    @Override
    public View initView() {
        return null;
    }

    @Override
    public void loadData(BaseVO vo) {

    }


}
