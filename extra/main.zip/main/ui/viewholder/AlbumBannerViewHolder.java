package com.hhdd.kada.main.ui.viewholder;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hhdd.core.model.BaseVO;
import com.hhdd.core.model.RecommendVO;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.AutoScrollViewPager;
import com.hhdd.kada.main.views.RecyclingPagerAdapter;
import com.hhdd.kada.main.views.ScaleDraweeView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lj on 16/7/20.
 */
public class AlbumBannerViewHolder extends  BaseViewHolder {
    BannerAdapter mAdapter;
    AutoScrollViewPager mViewPager;
    FrameLayout layout;

    int bannerType;
    private int mWidth;
    private int mHeight;
    List<BaseVO> mRecommendList = new ArrayList<BaseVO>();

    public AlbumBannerViewHolder(Context context,int bannerType) {
        super(context);
        this.bannerType = bannerType;
    }



    public void onPause() {
        mViewPager.stopAutoScroll();
    }

    public void onResume() {
        mViewPager.startAutoScroll();
        mAdapter.notifyDataSetChanged();
        mViewPager.postInvalidate();
    }

    @Override
    public View initView() {
        View view = View.inflate(mContext, R.layout.banner, null);
        mViewPager = (AutoScrollViewPager)view.findViewById(R.id.banner_viewpager);
        layout = (FrameLayout) view.findViewById(R.id.banner_container);


        int width = mContext.getResources().getDisplayMetrics().widthPixels;
//        float i = 100/320f;
//        float height = width*i+240;
        int height = (int) mContext.getResources().getDimension(R.dimen.banner_height);
        mAdapter = new BannerAdapter(mContext);

        ViewGroup.LayoutParams params =  mViewPager.getLayoutParams();
        mWidth = params.width = width;
        mHeight = params.height = height;
        mViewPager.setLayoutParams(params);
        mViewPager.setAdapter(mAdapter);

        return view;
    }


    @Override
    public void loadData(BaseVO vo) {

    }

    @Override
    public void loadData(List<BaseVO> list) {
        if (list!=null && list.size()>0) {
            mRecommendList.clear();
            mRecommendList.addAll(list);
            mAdapter.setIsInfiniteLoop(true);
            mAdapter.notifyDataSetChanged();
            mViewPager.postInvalidate();
            mViewPager.setInterval(4000);
            mViewPager.startAutoScroll();
        }
    }


    class BannerAdapter extends RecyclingPagerAdapter {

        boolean isInfiniteLoop;
        public BannerAdapter(Context context){

        }
        @Override
        public View getView(int position, View view, ViewGroup container) {
            if (view==null) {
                view = View.inflate(mContext, R.layout.album_banner_layout, null);
            }
            if(mRecommendList != null && mRecommendList.size()>0){
                final ScaleDraweeView cover = (ScaleDraweeView) view.findViewById(R.id.cover);
                cover.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.MATCH_PARENT));
                final RelativeLayout introduction = (RelativeLayout) view.findViewById(R.id.introduction_container);
                introduction.setLayoutParams(new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.MATCH_PARENT));
                final TextView textView = (TextView) view.findViewById(R.id.introduction);
                final TextView name = (TextView) view.findViewById(R.id.name);
                final ScaleDraweeView smallCover = (ScaleDraweeView) view.findViewById(R.id.small_cover);
                BaseVO baseVO = mRecommendList.get(getPosition(position));
                if(baseVO instanceof RecommendVO){
                    RecommendVO vo = (RecommendVO) baseVO;
                    if(vo.getBannerUrl() != null && !vo.getBannerUrl().equals("")){
//                        DisplayImageOptions options = KaDaApplication.Options.getListOptions();
//                        ImageSize imageSize = new ImageSize(mWidth,mHeight);
//                        com.nostra13.universalimageloader.core.ImageLoader.getInstance().displayImage(vo.getBannerUrl(),
//                                new ImageViewAware(imageView),options,imageSize,null,null);
//                        imageView.setVisibility(View.VISIBLE);
                        cover.setVisibility(View.VISIBLE);
                        FrescoUtils.showUrl(vo.getBannerUrl(),cover,mWidth,mHeight);
                        introduction.setVisibility(View.GONE);
                    }else if(vo.getContent() != null && !vo.getCoverUrl().equals("")){
                        cover.setVisibility(View.GONE);
                        introduction.setVisibility(View.VISIBLE);
                        textView.setText(vo.getContent());
                        name.setText(vo.getName());
//                        smallCover.setImageUrl(vo.getCoverUrl());
                        int width;
                        int height;
                        if(bannerType == Constants.TYPE_BOOK){
                            width = mContext.getResources().getDimensionPixelOffset(R.dimen.album_banner_small_cover_width);
                            height = mContext.getResources().getDimensionPixelOffset(R.dimen.album_banner_small_cover_height);
                        }else{
                            width = mContext.getResources().getDimensionPixelOffset(R.dimen.album_banner_small_cover_width);
                            height = mContext.getResources().getDimensionPixelOffset(R.dimen.album_banner_small_cover_width);
                        }
                        smallCover.getLayoutParams().width = width;
                        smallCover.getLayoutParams().height = height;
                        FrescoUtils.showUrl(vo.getCoverUrl(),smallCover, width, height);
                    }
                }
            }

            return view;
        }

        @Override
        public int getCount() {
            return isInfiniteLoop?500:mRecommendList.size();
        }

        public int getPosition(int position) {
            if( mRecommendList.size() == 0){
                return position;
            }
            return position % mRecommendList.size();
        }

        public void setIsInfiniteLoop(boolean isInfiniteLoop) {
            this.isInfiniteLoop = isInfiniteLoop;
        }
    }
}
