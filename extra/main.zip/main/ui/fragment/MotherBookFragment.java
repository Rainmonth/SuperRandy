package com.hhdd.kada.main.ui.fragment;

import android.os.Bundle;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BannerAPI;
import com.hhdd.kada.api.ExcellentAPI;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.Book1x3ViewHolder;
import com.hhdd.kada.main.viewholders.Book2x2ViewHolder;
import com.hhdd.kada.main.viewholders.BookIPViewHolder;
import com.hhdd.kada.main.viewholders.MotherBookBannerViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorMiddleViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorViewHolder;
import com.hhdd.kada.main.viewholders.StoryCateViewHolder;
import com.hhdd.kada.main.viewholders.TitleViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.main.vo.ViewTypes;
import com.hhdd.kada.module.userhabit.StaPageName;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.ui.fragment
 */
public class MotherBookFragment extends RecyclerDataListFragment2 {//RecyclerDataListNoTitleFragment //by lazy for v3.7

    private List<BaseVO> bannerList = new ArrayList<>();
    private List<BaseModelListVO> configList = new ArrayList<>();

    private static final int View_Type_DataList_Old_Banner = 101;
    private static final int View_Type_Separator = View_Type_DataList_Old_Banner + 1;
    private StrongReference<DefaultCallback> configStrongReference;

    public MotherBookFragment() {
        super(LIST_MODE_PULL_DOWN_TO_REFRESH, "", null);
    }

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        useTitleBar("选绘本");//by lazy for v3.7 title字段可以通过咔哒协议传过来 在onEnter方法中获取

        setBackgroundColor(KaDaApplication.instance.getResources().getColor(R.color.white));
        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(ViewTypes.View_Type_Separator.getId(), SeparatorViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_BookCate.getId(), StoryCateViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_Title.getId(), TitleViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_BookCollect2X2.getId(), Book2x2ViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_BookCollect1X3.getId(), Book1x3ViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_OrgSlide.getId(), BookIPViewHolder.class);
        viewTypeMaps.put(View_Type_DataList_Old_Banner, MotherBookBannerViewHolder.class);
        viewTypeMaps.put(View_Type_Separator, SeparatorMiddleViewHolder.class);
        BaseViewHolderCreator viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        setViewHolderCreator(viewHolderCreator);

        showLoadingView();
        doRefresh();
    }

    @Override
    protected void doRefresh() {
        bannerList.clear();
        configList.clear();
        loadBannerData();
        if (configStrongReference==null){
            configStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<BaseModelListVO>> defaultCallback = new DefaultCallback<List<BaseModelListVO>>() {

            @Override
            public void onDataReceived(List<BaseModelListVO> data) {
                if (data != null && data.size() > 0) {
                    configList.addAll(data);
                }

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reLoadData();
                        handleLoadComplete(false);
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                handleErrorOccurred(true, 0, "加载失败");
            }
        };
        configStrongReference.set(defaultCallback);
        ExcellentAPI.getMotherBookConfig(configStrongReference);
    }

    /**
     * 获取banner数据
     */
    private void loadBannerData() {
        getBannerInfo();
    }

    /**
     * 获取banner数据
     */
    private void getBannerInfo() {
        BannerAPI.getMotherBookBanner(new API.ResponseHandler<List<BannerInfo>>() {
            @Override
            public void onSuccess(List<BannerInfo> responseData) {
                if (responseData != null && responseData.size() > 0) {
                    BaseModelListVO modelListVO = new BaseModelListVO();
                    modelListVO.setViewType(View_Type_DataList_Old_Banner);
                    modelListVO.getItemList().addAll(responseData);
                    bannerList.add(modelListVO);

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            updateBanner();
                        }
                    });
                }
            }

            @Override
            public void onFailure(int code, String message) {

            }
        });
    }

    private void updateBanner() {
        getDataListDisplayed().getDataList().clear();
        getDataListDisplayed().getDataList().addAll(bannerList);
        getDataListDisplayed().getDataList().addAll(configList);
        getDataListDisplayed().getDataList().add(getBaseV0());
        notifyDataSetChanged();
    }

    private void reLoadData() {
        List<BaseModel> modelListVOList = new ArrayList<>();
        modelListVOList.addAll(bannerList);
        modelListVOList.addAll(configList);
        modelListVOList.add(getBaseV0());
        reloadData(modelListVOList);
    }

    private BaseVO getBaseV0() {
        BaseVO baseVO = new BaseVO();
        baseVO.setViewType(View_Type_Separator);
        return baseVO;
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);

        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.mom_home_book_view, TimeUtil.currentTime()));
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (configStrongReference!=null){
            configStrongReference.clear();
            configStrongReference = null;
        }
    }
}
