package com.hhdd.kada.main.ui.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.coin.event.CoinUpdateEvent;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.event.WeiXinLoginEvent;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.manager.WChatManager;
import com.hhdd.kada.main.model.CodeLoginOrRegisterInfo;
import com.hhdd.kada.main.model.HWLoginInfo;
import com.hhdd.kada.main.model.PhoneLoginInfo;
import com.hhdd.kada.main.model.WeixinPayModel;
import com.hhdd.kada.main.ui.activity.WebViewActivity;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.utils.AESCoder;
import com.hhdd.kada.main.utils.HWSDKUtil;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.PatternUtil;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.kada.widget.LoginCodeInputView;
import com.hhdd.kada.widget.LoginPasswordInputView;
import com.hhdd.logger.LogHelper;
import com.tencent.mm.opensdk.modelmsg.SendAuth;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/5/28
 * @describe : com.hhdd.kada.main.ui.fragment
 */
public class NewLoginFragment extends BaseFragment {

    @BindView(R.id.titleBarView)
    TitleBar titleBar;
    @BindView(R.id.recommendLoginLayout)
    View recommendLoginLayout;
    @BindView(R.id.hwLoginLayout)
    View hwLoginLayout;
    @BindView(R.id.hwLoginImageView)
    ImageView hwLoginImageView;
    @BindView(R.id.wxLoginImageView)
    ImageView wxLoginImageView;
    @BindView(R.id.codeInputView)
    LoginCodeInputView codeInputView;
    @BindView(R.id.passwordInputView)
    LoginPasswordInputView passwordInputView;
    @BindView(R.id.switchLoginTypeLayout)
    View switchLoginTypeLayout;
    @BindView(R.id.switchLoginTypeTextView)
    TextView switchLoginTypeTextView;
    @BindView(R.id.lineView)
    TextView lineView;
    @BindView(R.id.loginTextView)
    TextView loginTextView;
    @BindView(R.id.protocolCheckImageView)
    View protocolCheckImageView;
    @BindView(R.id.protocolTextView)
    TextView protocolTextView;
    @BindView(R.id.layout)
    View layout;
    @BindView(R.id.resetPasswordTextView)
    View resetPasswordTextView;

    private LoginFragmentListener listener;
    private TranslateAnimation centerToLeftAnimation;
    private TranslateAnimation rightToCenterAnimation;
    private StrongReference<DefaultCallback> codeLoginOrRegisterStrongReference;
    private StrongReference<DefaultCallback> loginStrongReference;
    private StrongReference<DefaultCallback> weixinStrongReference;
    private PowerManager.WakeLock mWakeLock;
    private boolean isCodeLoginShow = true;//当前展示是否为验证码登录页面

    public void setListener(LoginFragmentListener listener) {
        this.listener = listener;
    }

    public static NewLoginFragment newInstance(Bundle bundle) {
        NewLoginFragment fragment = new NewLoginFragment();
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_login_new, container, false);
        ButterKnife.bind(this, rootView);
        EventBus.getDefault().register(this);
        initView();
        initData();
        initListener();
        return rootView;
    }

    /**
     * view初始化
     */
    private void initView() {
        titleBar.setTitle(KaDaApplication.instance.getResources().getString(R.string.login_text));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleBarLayoutParams = titleBar.getLayoutParams();
            if (titleBarLayoutParams==null){
                titleBarLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleBarLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height)+LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleBar.setLayoutParams(titleBarLayoutParams);
            titleBar.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }
        protocolCheckImageView.setSelected(true);
        Bundle bundle = getArguments();
        if (bundle != null && bundle.getInt(Constants.KEY_FROM_TYPE) > 0) {
            recommendLoginLayout.setVisibility(View.GONE);
        }
        hwLoginLayout.setVisibility(HWSDKUtil.isShowHuaWeiInfo() ? View.VISIBLE : View.GONE);
        PowerManager pm = (PowerManager) KaDaApplication.instance.getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());
        mWakeLock.acquire();
    }

    /**
     * 事件监听初始化
     */
    private void initListener() {
        titleBar.setLeftOnClickListener(
                new KaDaApplication.NoDoubleClickListener() {
                    @Override
                    public void onNoDoubleClick(View v) {
                        if (listener != null) {
                            listener.handleBackButtonClicked(NewLoginFragment.this);
                        } else {
                            mActivity.finish();
                        }
                    }
                }
        );
        codeInputView.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                switch (action) {
                    case LoginCodeInputView.ACTION_GET_CODE:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.login_page_apply_code, TimeUtil.currentTime()));
                        getLoginOrRegisterCode();
                        break;
                    case LoginCodeInputView.ACTION_DONE:
                        doLoginClick(true);
                        break;
                    case LoginCodeInputView.ACTION_TEXT_CHANGED_UN_ENABLE:
                        loginTextView.setEnabled(false);
                        break;
                    case LoginCodeInputView.ACTION_TEXT_CHANGED_ENABLE:
                        loginTextView.setEnabled(protocolCheckImageView.isSelected());
                        break;
                    default:
                        break;
                }
            }
        });
        passwordInputView.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                switch (action) {
                    case LoginPasswordInputView.ACTION_DONE:
                        doLoginClick(true);
                        break;
                    case LoginPasswordInputView.ACTION_TEXT_CHANGED_UN_ENABLE:
                        loginTextView.setEnabled(false);
                        break;
                    case LoginPasswordInputView.ACTION_TEXT_CHANGED_ENABLE:
                        loginTextView.setEnabled(protocolCheckImageView.isSelected());
                        break;
                    default:
                        break;
                }
            }
        });
        switchLoginTypeLayout.setOnClickListener(new KaDaApplication.NoDoubleClickListener(300) {
            @Override
            public void onNoDoubleClick(View v) {
                isCodeLoginShow = !isCodeLoginShow;
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(isCodeLoginShow ? "2" : "1",
                        StaCtrName.login_page_change_mode, TimeUtil.currentTime()));
                switchLoginType();
            }
        });
        protocolCheckImageView.setOnClickListener(new KaDaApplication.NoDoubleClickListener(0) {
            @Override
            public void onNoDoubleClick(View v) {
                protocolCheckImageView.setSelected(!protocolCheckImageView.isSelected());
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(protocolCheckImageView.isSelected() ? "1" : "0",
                        StaCtrName.login_page_privacy_checkbox_click, TimeUtil.currentTime()));
                updateLoginEnableState();
            }
        });
        protocolTextView.setText(getClickableSpan());
        protocolTextView.setMovementMethod(LinkMovementMethod.getInstance());
        KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                switch (v.getId()) {
                    case R.id.hwLoginImageView:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.login_page_thirdparty_huawei, TimeUtil.currentTime()));
                        doHWLogin();
                        break;
                    case R.id.wxLoginImageView:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.login_page_thirdparty_wechat, TimeUtil.currentTime()));
                        hideKeyBoard();
                        WChatManager wChatManager = ((WChatManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.W_CHAT_MANAGER));
                        wChatManager.setTag(NewLoginFragment.this.getClass().getSimpleName());
                        wChatManager.requestOauthCode(new WChatManager.IWXListener() {
                            @Override
                            public void wxUnInstall() {
                                ToastUtils.showToast(R.string.uninstall_wx);
                            }
                        }, Constants.LOGIN_WX_TRANSACTION);
                        break;
                    case R.id.loginTextView:
                        hideKeyBoard();
                        doLoginClick(false);
                        break;
                    case R.id.resetPasswordTextView:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.login_page_forget_click, TimeUtil.currentTime()));
                        hideKeyBoard();
                        passwordInputView.getPasswordEditTextView().setText("");
                        if (NewLoginFragment.this.listener != null) {
                            NewLoginFragment.this.listener.handleForgetButtonClicked(NewLoginFragment.this, passwordInputView.getPhoneEditTextView().getText().toString());
                        }
                        break;
                    default:
                        break;
                }
            }
        };
        loginTextView.setOnClickListener(listener);
        hwLoginImageView.setOnClickListener(listener);
        wxLoginImageView.setOnClickListener(listener);
        resetPasswordTextView.setOnClickListener(listener);
        layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyBoard();
            }
        });
    }

    /**
     * 华为登录
     */
    private void doHWLogin() {
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(mActivity, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                HWSDKUtil.clearLoginReference();
            }
        });
        HWSDKUtil.login(new HWSDKUtil.HWLoginHandler<HWLoginInfo>() {
            @Override
            public void onSuccess(final HWLoginInfo hwLoginInfo) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(mActivity);
                        PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                        prefsManager.putInt(Constants.LAST_LOGIN_WAY, InitFragment.LAST_LOGIN_WAY_IS_HW);

                        if (listener != null) {
                            listener.thirdLoginSuccess(LoginFragmentListener.TYPE_HW, hwLoginInfo.getLoginName(),
                                    hwLoginInfo.getComple() == 1, hwLoginInfo.isToast(), hwLoginInfo.isFirstLogin());
                        }
                    }
                });
            }

            @Override
            public void onFail(int errorCode, String message) {
                customDialogManager.dismissDialog(mActivity);
                String errorStr = KaDaApplication.applicationContext().getResources().getString(R.string.html_error);
                if(!TextUtils.isEmpty(message) && !message.contains(errorStr)) {
                    ToastUtils.showToast(message);
                }
            }
        });
    }

    /**
     * 验证码登录注册 获取验证码
     */
    private void getLoginOrRegisterCode() {
        String phoneStr = codeInputView.getPhoneEditTextView().getText().toString();
        UserAPI.getSmsCode(phoneStr, Constants.CODE_GET_TYPE_LOGINPHONE, new API.ResponseHandler<String>() {
            @Override
            public void onSuccess(String responseData) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        ToastUtils.showToast(R.string.message_send_success);
                    }
                });
            }

            @Override
            public void onFailure(int code, String message) {
            }
        });
    }

    /**
     * 点击登录或登录/注册按钮
     * @param isSoftKeyBoardLogin 是否为点击软键盘确定键登录/注册
     */
    private void doLoginClick(boolean isSoftKeyBoardLogin) {
        if (codeInputView.getVisibility() == View.VISIBLE) {
            doCodeLoginOrRegister(isSoftKeyBoardLogin);
        } else {
            doLogin(isSoftKeyBoardLogin);
        }
    }

    /**
     * 验证码登录或注册
     * @param isSoftKeyBoardLogin 是否为点击软键盘确定键登录/注册
     */
    private void doCodeLoginOrRegister(boolean isSoftKeyBoardLogin) {
        final String phoneNumberStr = codeInputView.getPhoneEditTextView().getText().toString();
        String codeStr = codeInputView.getCodeEditTextView().getText().toString();
        if (TextUtils.isEmpty(phoneNumberStr)) {
            ToastUtils.showToast(R.string.phone_not_null);
            return;
        }
        if (!PatternUtil.isMobile(phoneNumberStr)) {
            ToastUtils.showToast(R.string.phone_error);
            return;
        }
        if (TextUtils.isEmpty(codeStr)) {
            ToastUtils.showToast(R.string.code_not_null);
            return;
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                isSoftKeyBoardLogin ? StaCtrName.login_page_submit_click : StaCtrName.login_page_login_click, TimeUtil.currentTime()));
        if (listener != null) {
            listener.showLoading();
        }
        if (codeLoginOrRegisterStrongReference == null) {
            codeLoginOrRegisterStrongReference = new StrongReference<>();
        }
        DefaultCallback<CodeLoginOrRegisterInfo> loginCallback = new DefaultCallback<CodeLoginOrRegisterInfo>() {
            @Override
            public void onDataReceived(final CodeLoginOrRegisterInfo data) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1", StaCtrName.login_page_login_success, TimeUtil.currentTime()));
                        EventBus.getDefault().post(new CoinUpdateEvent());

                        if (data != null && !TextUtils.isEmpty(data.getLoginName())) {
                            PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                            prefsManager.putInt(Constants.LAST_LOGIN_WAY, InitFragment.LAST_LOGIN_WAY_IS_PHONE);

                            if (data.getIsReg() == 0) {
                                if (listener != null) {
                                    listener.userLogin(NewLoginFragment.class.getSimpleName(), data.getLoginName(), false, false);
                                }
                            } else {
                                if (listener != null) {
                                    listener.registerSuccess(data.getLoginName(), data.getComple() == 1, data.isToast());
                                }
                            }
                        } else {
                            ToastUtils.showToast(R.string.login_or_register_error);
                        }
                        if (listener != null) {
                            listener.hideLoading();
                        }
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1", StaCtrName.login_page_login_failure, TimeUtil.currentTime()));
                String errorStr = KaDaApplication.getInstance().getResources().getString(R.string.html_error);
                if (!TextUtils.isEmpty(reason) && !reason.contains(errorStr)) {
                    ToastUtils.showToast(reason);
                } else {
                    ToastUtils.showToast(R.string.login_or_register_error);
                }
                if (listener != null) {
                    listener.hideLoading();
                }
            }
        };
        codeLoginOrRegisterStrongReference.set(loginCallback);
        UserAPI.doCodeLoginOrRegister(phoneNumberStr, codeStr, codeLoginOrRegisterStrongReference);
    }

    /**
     * 通过密码进行登录
     * @param isSoftKeyBoardLogin 是否为点击软键盘确定键登录
     */
    private void doLogin(boolean isSoftKeyBoardLogin) {
        final String phoneNumberStr = passwordInputView.getPhoneEditTextView().getText().toString();
        final String passwordStr = passwordInputView.getPasswordEditTextView().getText().toString();
        if (TextUtils.isEmpty(phoneNumberStr)) {
            ToastUtils.showToast(R.string.phone_not_null);
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("0", StaCtrName.login_page_login_result, TimeUtil.currentTime()));
            return;
        }

        if (!PatternUtil.isMobile(phoneNumberStr)) {
            ToastUtils.showToast(R.string.phone_error);
            return;
        }

        if (TextUtils.isEmpty(passwordStr)) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("0", StaCtrName.login_page_login_result, TimeUtil.currentTime()));
            ToastUtils.showToast(R.string.password_not_null);
            return;
        }
        if (!NetworkUtils.isReachable()) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("0", StaCtrName.login_page_login_result, TimeUtil.currentTime()));
            ToastUtils.showToast(R.string.network_error);
            return;
        }

        String passwordAESCoder = null;
        try {
            passwordAESCoder = AESCoder.encrypt(passwordStr);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }

        if (TextUtils.isEmpty(passwordAESCoder)) {
            return;
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                isSoftKeyBoardLogin ? StaCtrName.login_page_submit_click : StaCtrName.login_page_login_click, TimeUtil.currentTime()));
        if (listener != null) {
            listener.showLoading();
        }
        if (loginStrongReference == null) {
            loginStrongReference = new StrongReference<>();
        }
        DefaultCallback<PhoneLoginInfo> loginCallback = new DefaultCallback<PhoneLoginInfo>() {
            @Override
            public void onDataReceived(final PhoneLoginInfo data) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1", StaCtrName.login_page_login_success, TimeUtil.currentTime()));

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        EventBus.getDefault().post(new CoinUpdateEvent());

                        if (data != null && !TextUtils.isEmpty(data.getLoginName())) {
                            PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                            prefsManager.putInt(Constants.LAST_LOGIN_WAY, InitFragment.LAST_LOGIN_WAY_IS_PHONE);

                            if (listener != null) {
                                listener.userLogin(NewLoginFragment.class.getSimpleName(), data.getLoginName(), false, false);
                            }
                        }
                        if (listener != null) {
                            listener.hideLoading();
                        }
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1", StaCtrName.login_page_login_failure, TimeUtil.currentTime()));
                if (TextUtils.isEmpty(passwordStr)) {
                    ToastUtils.showToast(R.string.password_error);
                } else {
                    String errorStr = KaDaApplication.getInstance().getResources().getString(R.string.html_error);
                    if (!TextUtils.isEmpty(reason) && !reason.contains(errorStr)) {
                        ToastUtils.showToast(reason);
                    } else {
                        ToastUtils.showToast(R.string.login_error);
                    }

                }
                if (listener != null) {
                    listener.hideLoading();
                }
            }
        };
        loginStrongReference.set(loginCallback);
        UserAPI.doLogin(phoneNumberStr, passwordAESCoder, loginStrongReference);
    }

    /**
     * 微信授权登录成功，调用服务端微信登录接口
     * @param event
     */
    public void onEvent(WeiXinLoginEvent event) {
        final SendAuth.Resp response = event.getResp();
        if (event.isSuccess() && response != null && TextUtils.equals(getClass().getSimpleName(), event.getTag())) {
            final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
            customDialogManager.showDialog(mActivity, new CustomProgressDialog.Listener() {
                @Override
                public void onClosed() {
                    clearApiReference(weixinStrongReference);
                }
            });
            if (weixinStrongReference == null) {
                weixinStrongReference = new StrongReference<>();
            }
            DefaultCallback weixinCallback = new DefaultCallback<WeixinPayModel>() {
                @Override
                public void onDataReceived(final WeixinPayModel data) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("2", StaCtrName.login_page_login_success, TimeUtil.currentTime()));
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            customDialogManager.dismissDialog(mActivity);
                            if (data != null && listener != null) {
                                PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                                prefsManager.putInt(Constants.LAST_LOGIN_WAY, InitFragment.LAST_LOGIN_WAY_IS_WX);

                                WeixinPayModel model = data;
                                final boolean isInfoCompleted = model.getComple() == 1;
                                final boolean isToast = model.isToast();
                                listener.thirdLoginSuccess(LoginFragmentListener.TYPE_WX, model.getLoginName(), isInfoCompleted, isToast, model.isFirstLogin());
                            }
                        }
                    });
                }

                @Override
                public void onException(int code, String reason) {
                    super.onException(reason);
                    customDialogManager.dismissDialog(mActivity);
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("2", StaCtrName.login_page_login_failure, TimeUtil.currentTime()));
                }
            };
            weixinStrongReference.set(weixinCallback);
            ((WChatManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.W_CHAT_MANAGER)).login(response.code, KaDaApplication.DEVICE_ID, weixinStrongReference);
        }
    }

    private SpannableString getClickableSpan() {
        View.OnClickListener listener = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (getContext() == null) {
                    return;
                }
                if (getContext() instanceof Activity) {
                    if (((Activity) getContext()).isFinishing()) {
                        return;
                    }
                }
                //点击之后重新设置协议spannableString，保证点击后"用户协议"背景色不会一直保持，而按下的时候却有背景色
                protocolTextView.setText(getClickableSpan());
                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", StaCtrName.login_user_protocol_click, TimeUtil.currentTime()));
                WebViewActivity.startActivity(getContext(), API.USER_PROTOCOL_URL);
            }
        };

        SpannableString spannableInfo = new SpannableString(KaDaApplication.instance.getResources().getString(R.string.protocol_text));
        int start = 7;
        spannableInfo.setSpan(new Clickable(listener), start, spannableInfo.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableInfo.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.color_ffe65e)), start, spannableInfo.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableInfo;
    }

    class Clickable extends ClickableSpan implements View.OnClickListener {
        private final View.OnClickListener mListener;

        public Clickable(View.OnClickListener l) {
            mListener = l;
        }

        @Override
        public void onClick(View v) {
            mListener.onClick(v);
        }

        @Override
        public void updateDrawState(TextPaint ds) {
            ds.setUnderlineText(false);
        }
    }

    /**
     * 数据初始化
     */
    private void initData() {
        releaseAnimation();
        centerToLeftAnimation = new TranslateAnimation(0, -LocalDisplay.SCREEN_WIDTH_PIXELS, 0, 0);
        centerToLeftAnimation.setDuration(200);
        rightToCenterAnimation = new TranslateAnimation(LocalDisplay.SCREEN_WIDTH_PIXELS, 0, 0, 0);
        rightToCenterAnimation.setDuration(200);
    }

    /**
     * 切换登录方式(手机验证码登录/密码登录)
     */
    private void switchLoginType() {
        hideKeyBoard();
        codeInputView.setVisibility(View.VISIBLE);
        passwordInputView.setVisibility(View.VISIBLE);
        centerToLeftAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (isCodeLoginShow) {
                    passwordInputView.setVisibility(View.GONE);
                    String passwordInputViewText = passwordInputView.getPhoneEditTextView().getText().toString().trim();
                    if (!TextUtils.isEmpty(passwordInputViewText)){
                        codeInputView.getPhoneEditTextView().setText(passwordInputViewText);
                        codeInputView.getPhoneEditTextView().setSelection(passwordInputViewText.length());
                    }
                } else {
                    codeInputView.setVisibility(View.GONE);
                    String codeInputViewText = codeInputView.getPhoneEditTextView().getText().toString().trim();
                    if (!TextUtils.isEmpty(codeInputViewText)){
                        passwordInputView.getPhoneEditTextView().setText(codeInputViewText);
                        passwordInputView.getPhoneEditTextView().setSelection(codeInputViewText.length());
                    }
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        codeInputView.startAnimation(isCodeLoginShow ? rightToCenterAnimation : centerToLeftAnimation);
        passwordInputView.startAnimation(isCodeLoginShow ? centerToLeftAnimation : rightToCenterAnimation);
        switchLoginTypeTextView.setText(isCodeLoginShow ? R.string.password_login_text : R.string.code_login_text);
        lineView.setText(isCodeLoginShow ? R.string.password_login_text : R.string.code_login_text);
        resetPasswordTextView.setVisibility(isCodeLoginShow ? View.GONE : View.VISIBLE);
        updateLoginEnableState();
        trackPageHabit();
    }

    /**
     * 更新登录/注册按钮enable状态
     */
    private void updateLoginEnableState() {
        boolean isInputAllHaveData;
        if (isCodeLoginShow) {
            isInputAllHaveData = !TextUtils.isEmpty(codeInputView.getPhoneEditTextView().getText())
                    && !TextUtils.isEmpty(codeInputView.getCodeEditTextView().getText());
        } else {
            isInputAllHaveData = !TextUtils.isEmpty(passwordInputView.getPhoneEditTextView().getText())
                    && !TextUtils.isEmpty(passwordInputView.getPasswordEditTextView().getText());
        }
        loginTextView.setEnabled(isInputAllHaveData && protocolCheckImageView.isSelected());
    }

    /**
     * 切换到验证码登录或密码登录(目前仅找回密码页面有使用，并且要求不显示顶部微信登录栏，同手机登录进入)
     * @param isSwitchToCodeLogin
     */
    public void switchLoginType(boolean isSwitchToCodeLogin) {
        recommendLoginLayout.setVisibility(View.GONE);
        if (isSwitchToCodeLogin != isCodeLoginShow) {
            isCodeLoginShow = !isCodeLoginShow;
            switchLoginType();
        } else {
            trackPageHabit();
        }
    }

    /**
     * 释放动画对象资源
     */
    private void releaseAnimation() {
        if (centerToLeftAnimation != null) {
            centerToLeftAnimation.cancel();
            centerToLeftAnimation = null;
        }
        if (rightToCenterAnimation != null) {
            rightToCenterAnimation.cancel();
            rightToCenterAnimation = null;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        trackPageHabit();
    }

    /**
     * 打页面点
     */
    public void trackPageHabit() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                isCodeLoginShow ? StaPageName.login_page_code_view : StaPageName.login_page_password_view, TimeUtil.currentTime()));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        getHandler().removeCallbacksAndMessages(null);
        EventBus.getDefault().unregister(this);
        releaseAnimation();
        if (codeInputView != null) {
            codeInputView.release();
        }
        clearApiReference(codeLoginOrRegisterStrongReference);
        clearApiReference(loginStrongReference);
        clearApiReference(weixinStrongReference);
        DialogFactory.dismissAllDialog(mActivity);
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try {
                mWakeLock.release();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    /**
     * 回收接口回调资源
     */
    private void clearApiReference(StrongReference reference) {
        if (reference != null) {
            reference.clear();
            reference = null;
        }
    }
}
