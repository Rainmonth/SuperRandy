package com.hhdd.kada.main.ui.fragment;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.coin.view.MagicTextView;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.PatternUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.views.MyEditText;
import com.hhdd.kada.main.views.TimeButton;

/**
 * Created by lj on 16/4/21.
 */
public class FindPasswordFragment extends BaseFragment {


    public static FindPasswordFragment newInstance(Bundle bundle) {
        FindPasswordFragment fragment = new FindPasswordFragment();
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        return fragment;
    }

    LoginFragmentListener listener;

    public void setListener(LoginFragmentListener listener) {
        this.listener = listener;
    }


    String phonenumber;
    EditText phoneNumber;
    MyEditText verificationCode;
    TextView hintText;
    private TimeButton getVerifyCodeButton;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

//        super.onCreate(savedInstanceState);
        View rootView = inflater.inflate(R.layout.fragment_find_password, container, false);

        if (getArguments() != null) {
            phonenumber = getArguments().getString("phoneNumber");
        }
        initView(rootView);
        return rootView;

    }


    void initView(View view) {

//        view.findViewById(R.id.main_layout).getLayoutParams().height = LocalDisplay.SCREEN_HEIGHT_PIXELS - LocalDisplay.getStatusBarHeight(mActivity);

        hintText = (TextView) view.findViewById(R.id.hint_text);
        hintText.setText(getClickableSpan());
        hintText.setMovementMethod(LinkMovementMethod.getInstance());

        phoneNumber = (EditText) view.findViewById(R.id.phone_number);
        if (phonenumber != null && phonenumber.length() > 0) {
            phoneNumber.setText(phonenumber);
        }

        final View container = view.findViewById(R.id.container);
        verificationCode = (MyEditText) view.findViewById(R.id.verification_code);
        getVerifyCodeButton = (TimeButton) view.findViewById(R.id.get_verification_code);
        getVerifyCodeButton.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "forget_password_page_verificate", TimeUtil.currentTime()));
                hintText.setVisibility(View.GONE);

                final String mobile = phoneNumber.getText().toString();
                if (StringUtil.isEmpty(mobile)) {
                    ToastUtils.showToast("手机号码不能为空");
                    return;
                }

                if (!PatternUtil.isMobile(mobile)) {
                    ToastUtils.showToast("手机号码有误");
                    return;
                }

                if (!NetworkUtils.isReachable()) {
                    ToastUtils.showToast("网络异常，请检查您的网络");
                    return;
                }

                getVerifyCodeButton.setIsEffective(true);

                UserAPI.isLoginNameExists(mobile, new API.ResponseHandler<Boolean>() {
                    @Override
                    public void onSuccess(final Boolean response) {
                        getHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                if (listener != null) {
                                    listener.hideLoading();
                                }

                                if (response) {
                                    getSmsCode(mobile);
                                } else {
                                    hideKeyBoard();
                                    hintText.setVisibility(View.VISIBLE);
                                }
                            }
                        });
                    }

                    @Override
                    public void onFailure(int code, String message) {
                        if (listener != null) {
                            listener.hideLoading();
                        }
                    }
                });
                verificationCode.requestFocus();
            }
        });

        getVerifyCodeButton.setTextBefore("获取验证码").setLenght(60 * 1000);

//        final View commit = view.findViewById(R.id.btn_register);
        MagicTextView commit = (MagicTextView) view.findViewById(R.id.mtv_register);
//        commit.setStroke(4, Color.parseColor("#ded20a"));
        commit.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "forget_password_page_reset", TimeUtil.currentTime()));

                if (phoneNumber.getText() == null || phoneNumber.getText().toString().equals("")) {
                    ToastUtils.showToast("手机号码不能为空");
                    return;
                }
                if (verificationCode.getText() == null || verificationCode.getText().toString().equals("")) {
                    ToastUtils.showToast("验证码不能为空");
                    return;
                }
                if (!PatternUtil.isMobile(phoneNumber.getText().toString())) {
                    ToastUtils.showToast("手机号码有误");
                    return;
                }
                if (NetworkUtils.isReachable()) {
                    if (listener != null) {
                        listener.showLoading();
                    }
                    UserAPI.checkSmsCode(phoneNumber.getText().toString().trim(), "resetPassword", verificationCode.getText().toString().trim(), new API.ResponseHandler<Boolean>() {
                        @Override
                        public void onSuccess(final Boolean responseData) {
                            getHandler().post(new Runnable() {
                                @Override
                                public void run() {
                                    if (listener != null) {
                                        listener.hideLoading();
                                    }
                                    if (responseData) {
                                        if (listener != null) {
                                            listener.handleForgetButtonClicked(FindPasswordFragment.this, phoneNumber.getText().toString().trim());
                                        }
                                    } else {
                                        ToastUtils.showToast("验证未通过，请重新尝试");
                                    }
                                }
                            });
                        }

                        @Override
                        public void onFailure(int code, String message) {
//                            ToastUtils.showToast(message);
                            if (listener != null) {
                                listener.hideLoading();
                            }

                            ToastUtils.showToast("验证未通过，请重新尝试");
                        }
                    });
                } else {
                    ToastUtils.showToast("网络异常，请检查您的网络");
                }
            }
        });

//        final View back = view.findViewById(R.id.back);
//        back.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
//            @Override
//            public void onNoDoubleClick(View v) {
//                hideSoftKeyboard(mActivity.getCurrentFocus());
//                if (listener != null) {
//                    listener.handleBackButtonClicked(FindPasswordFragment.this);
//                } else {
//                    mActivity.finish();
//                }
//            }
//        });
        TitleBar titleBar = (TitleBar) view.findViewById(R.id.titleBar);
        titleBar.setTitle(KaDaApplication.instance.getResources().getString(R.string.reset_password_text));
        titleBar.setLeftOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
               back();
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleBarLayoutParams = titleBar.getLayoutParams();
            if (titleBarLayoutParams==null){
                titleBarLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleBarLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height)+LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleBar.setLayoutParams(titleBarLayoutParams);
            titleBar.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }

        View mLayout = view.findViewById(R.id.main_layout);
        mLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mActivity.getCurrentFocus() != null) {
                    hideSoftKeyboard(mActivity.getCurrentFocus());
                    mActivity.getCurrentFocus().clearFocus();
                }
            }
        });
    }

    private void getSmsCode(String mobile) {
        UserAPI.getSmsCode(mobile, "resetPassword", new API.ResponseHandler<String>() {
            @Override
            public void onSuccess(String responseData) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        ToastUtils.showToast("短信发送成功");
                    }
                });
            }

            @Override
            public void onFailure(int code, String message) {

            }
        });
    }

    private SpannableString getClickableSpan() {
        View.OnClickListener l = new View.OnClickListener() {
            //如下定义自己的动作
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    String text = phoneNumber.getText() == null ? "" : phoneNumber.getText().toString().trim();
                    listener.handleRegisterButtonClicked2(FindPasswordFragment.this, text);
                }
            }
        };

        SpannableString spanableInfo = new SpannableString(
                "您的手机号还未注册\n快去注册吧");
        int start = 12;
        int end = 14;
        spanableInfo.setSpan(new Clickable(l), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanableInfo.setSpan(new ForegroundColorSpan(Color.GREEN), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spanableInfo;
    }

    class Clickable extends ClickableSpan implements View.OnClickListener {
        private final View.OnClickListener mListener;

        public Clickable(View.OnClickListener l) {
            mListener = l;
        }

        @Override
        public void onClick(View v) {
            mListener.onClick(v);
        }
    }

    private void back(){
        if (listener != null) {
            listener.handleBackButtonClicked(FindPasswordFragment.this);
        } else {
            mActivity.finish();
        }
    }

    @Override
    public void onDestroyView() {
        if (getVerifyCodeButton != null) {
            getVerifyCodeButton.onDestroy();
        }
        super.onDestroyView();
    }
}
