package com.hhdd.kada.main.ui.fragment;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.kada.api.ExploreAPI;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.logger.LogHelper;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by sxh on 2018/8/17 09:34
 * E-Mail：820793721@qq.com
 * <p>
 * 服务端配置的fragment
 */
public class ServiceConfigFragment extends RecyclerDataListFragment2 {

    private String module = "";
    private String path = "";
    private String params = "";
    private String title = "";

    private StrongReference<DefaultCallback> configStrongReference;
    private List<BaseModelListVO> configList;

    public ServiceConfigFragment() {
        super(LIST_MODE_PULL_DOWN_TO_REFRESH, "", null);
    }

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        if (data instanceof String) {
            try {
                Uri uri = Uri.parse((String) data);

                String module = uri.getQueryParameter("module");
                String path = uri.getQueryParameter("path");
                String title = uri.getQueryParameter("title");
                String params = uri.getQueryParameter("params");
                //module、path参数是必选的，param、title参数可选
                if (module != null && module.length() > 0 && path != null && path.length() > 0) {
                    this.module = module;
                    this.path = path;
                }
                if (params != null && params.length() > 0) {
                    this.params = params;
                }
                try {
                    this.title = URLDecoder.decode(title, "UTF-8");
                } catch (UnsupportedEncodingException e) {
                    LogHelper.printStackTrace(e);
                }
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    @Override
    public void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }
        if (!TextUtils.isEmpty(title)) {
            useTitleBar(title);
        }

        showLoadingView();
        loadConfigData();
    }


    @Override
    protected void doRefresh() {
        super.doRefresh();
        loadConfigData();
    }

    private void loadConfigData() {
        if (configStrongReference == null) {
            configStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<BaseModelListVO>> defaultCallback = new DefaultCallback<List<BaseModelListVO>>() {
            @Override
            public void onDataReceived(final List<BaseModelListVO> data) {
                configList = data;
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reloadDataImpl();
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                handleErrorOccurred(true, 0, "加载失败");
            }
        };
        configStrongReference.set(defaultCallback);
        ExploreAPI.getConfig(module, path, params, configStrongReference);
    }


    private void reloadDataImpl() {
        if (configList != null && configList.size() > 0) {
            List<BaseModel> list = new ArrayList<>();
            list.addAll(configList);
            reloadData(list);
            handleLoadComplete(false);
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (configStrongReference != null) {
            configStrongReference.clear();
            configStrongReference = null;
        }
    }
}
