package com.hhdd.kada.main.ui.fragment;

import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.utils.AESCoder;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.logger.LogHelper;

/**
 * Created by lj on 16/4/21.
 */
public class ResetPasswordFragment extends BaseFragment {


    public static ResetPasswordFragment newInstance(Bundle bundle) {
        ResetPasswordFragment fragment = new ResetPasswordFragment();
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        return fragment;
    }

    LoginFragmentListener listener;

    public void setListener(LoginFragmentListener listener) {
        this.listener = listener;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_set_password, container, false);

        if (getArguments() != null) {
            phoneNumber = getArguments().getString("phoneNumber");
        }
        initView(rootView);
        return rootView;

    }

    EditText mPassword;
    String phoneNumber;

    void initView(View view) {

//        view.findViewById(R.id.main_layout).getLayoutParams().height = LocalDisplay.SCREEN_HEIGHT_PIXELS - LocalDisplay.getStatusBarHeight(mActivity);

        mPassword = (EditText) view.findViewById(R.id.password);
        mPassword.setHint("新密码（6位及以上）");

        final TextView btn = (TextView) view.findViewById(R.id.btn_register);
        btn.setText("完成");
        btn.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {

                String password = mPassword.getText().toString();
                if (password.length() < 6) {
                    ToastUtils.showToast("密码长度不得小于6位");
                    return;
                }
                String passwordAESCoder = null;
                try {
                    passwordAESCoder = AESCoder.encrypt(password);
                } catch (Exception e) {
                    LogHelper.printStackTrace(e);
                }

                if (passwordAESCoder == null || passwordAESCoder.equals("")) {
                    return;
                }

                if (NetworkUtils.isReachable()) {
                    if (listener != null) {
                        listener.showLoading();
                    }
                    UserAPI.resetPassword(phoneNumber, passwordAESCoder, new API.ResponseHandler<String>() {
                        @Override
                        public void onSuccess(String responseData) {
                            getHandler().post(new Runnable() {
                                @Override
                                public void run() {
                                    if (listener != null) {
                                        listener.handleForgetButtonClicked(ResetPasswordFragment.this, phoneNumber);
                                        listener.hideLoading();
                                    }
                                }
                            });
                        }

                        @Override
                        public void onFailure(int code, String message) {
                            ToastUtils.showToast(message);
                            if (listener != null) {
                                listener.hideLoading();
                            }
                        }
                    });
                } else {
                    ToastUtils.showToast("网络异常，请检查您的网络");
                }
            }
        });
        TitleBar titleBar = (TitleBar) view.findViewById(R.id.titlebar);
        titleBar.setTitle("设置密码");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleBarLayoutParams = titleBar.getLayoutParams();
            if (titleBarLayoutParams == null) {
                titleBarLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleBarLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height) + LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleBar.setLayoutParams(titleBarLayoutParams);
            titleBar.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
        }
        titleBar.setLeftOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                hideSoftKeyboard(mActivity.getCurrentFocus());
                back();
            }
        });

        View mLayout = view.findViewById(R.id.main_layout);
        mLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mActivity.getCurrentFocus() != null) {
                    hideSoftKeyboard(mActivity.getCurrentFocus());
                    mActivity.getCurrentFocus().clearFocus();
                }
            }
        });
    }

    private void back() {
        if (listener != null) {
            listener.handleBackButtonClicked(ResetPasswordFragment.this);
        } else {
            mActivity.finish();
        }
    }
}

