package com.hhdd.kada.main.ui.fragment;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.model.PopularKeywordsVO;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.SearchAPI;
import com.hhdd.kada.base.BaseFragment;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.ui.activity.LoginOrRegisterActivity;
import com.hhdd.kada.main.ui.activity.NewUserInfoActivity;
import com.hhdd.kada.main.ui.activity.SettingActivity;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.CommonBannerViewHolder;
import com.hhdd.kada.main.views.MotherHeaderView;
import com.hhdd.kada.main.views.magicindicator.MyPagerIndicator;
import com.hhdd.kada.main.views.magicindicator.ScaleTransitionPagerTitleView;
import com.hhdd.kada.module.search.SearchActivity;
import com.hhdd.kada.module.search.SearchBaseFragment;
import com.hhdd.kada.store.ui.virtual.VirtualOrderFragment;

import net.lucode.hackware.magicindicator.MagicIndicator;
import net.lucode.hackware.magicindicator.ViewPagerHelper;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.ui.fragment
 */
public class MotherFragment extends BaseFragment {

    @BindView(R.id.viewPager)
    ViewPager viewPager;
    @BindView(R.id.motherHeaderView)
    MotherHeaderView motherHeaderView;
    @BindView(R.id.magicIndicatorView)
    MagicIndicator magicIndicatorView;
    @BindView(R.id.statusView)
    View mStatusView;

    private List<Fragment> fragments = new ArrayList<>();
    private static final String ISFIRSTMOTHERFRAGMENT = "ISFIRSTMOTHERFRAGMENT";
    private static final String[] tabTitles = {"精选", "选绘本", "选听书"};
    private static final List<String> titleList = Arrays.asList(tabTitles);

    private List<PopularKeywordsVO> tempPopularWordList;

    private static final String[] TRACK_TAB_TEXT_ARR = {
            "mom_home_boutique_click",
            "mom_home_book_click",
            "mom_home_story_click",
            "mom_home_goods_click"
    };

    private StrongReference<DefaultCallback> popularStrongReference;

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_mother;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        fragments.add(new MotherExcellentFragment());
//        只保留精选页 by lazy at 2018/5/23 for v3.7
//        fragments.add(new MotherBookFragment());
//        fragments.add(new MotherStoryFragment());

//        fragments.add(new MotherStoreFragment());
        viewPager.setAdapter(new FragmentAdapter(getChildFragmentManager(), fragments));
        viewPager.setOffscreenPageLimit(fragments.size() - 1);

        initMagicIndicator();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams statusViewLayoutParams = mStatusView.getLayoutParams();

            if (statusViewLayoutParams == null) {
                statusViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            statusViewLayoutParams.height = LocalDisplay.SCREEN_STATUS_HEIGHT;
            mStatusView.setLayoutParams(statusViewLayoutParams);
        } else {
            mStatusView.setVisibility(View.GONE);
        }


        loadSearchWordsFromInternet();
    }

    @Override
    public void doInitListener() {
        super.doInitListener();

        motherHeaderView.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                doHeaderItemClick(childView);
            }
        });
    }

//    /**
//     * 显示儿童锁 若首次进入则先展示引导页，再展示儿童锁
//     *
//     * @param fromIndex
//     */
//    public void showChildLockDialog(final int fromIndex) {
//        getHandler().post(new Runnable() {
//            @Override
//            public void run() {
//                if (getContext() == null || getContext().isFinishing()) {
//                    return;
//                }
//                boolean isFirstMotherFragment = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).getBoolean(ISFIRSTMOTHERFRAGMENT, true);
//                if (isFirstMotherFragment) {
//                    ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).putBoolean(ISFIRSTMOTHERFRAGMENT, false);
//                    final MotherGuideDialog guideDialog = new MotherGuideDialog(getContext());
////                    guideDialog.show();
//                    guideDialog.setCanceledOnTouchOutside(false);
//                    guideDialog.setCancelable(false);
//                    ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).showDialog(guideDialog);
//                    guideDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//                        @Override
//                        public void onDismiss(DialogInterface dialog) {
//                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "user_guide_tip_3_3_click", TimeUtil.currentTime()));
//                        }
//                    });
//                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "user_guide_tip_3_3_view", TimeUtil.currentTime()));
//                }
////                showLockDialog(fromIndex);
//            }
//        });
//    }

//    private void showLockDialog(final int fromIndex) {
//        if (getContext() == null || getContext().isFinishing()) {
//            return;
//        }
//        ChildrenLockDialog dialog = new ChildrenLockDialog(getContext());
//        dialog.setCallback(new ChildrenDialogCallback() {
//            @Override
//            public void onAnswerRight() {
//                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.mom_home_boutique_valid_vist, TimeUtil.currentTime()));
//            }
//
//            @Override
//            public void onDirectDismiss() {
//                EventCenter.fireEvent(new UpdateMainTabEvent(fromIndex, false));
//            }
//        });
////        dialog.show();
//        ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).showDialog(dialog);
//    }

    public void setCurrentItem(final int index) {
        getHandler().post(new Runnable() {
            @Override
            public void run() {
                if (index >= 0 && index < fragments.size()) {
                    viewPager.setCurrentItem(index);
                }
            }
        });
    }

    private void doHeaderItemClick(View childView) {
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }
        switch (childView.getId()) {
            case R.id.headLayout:
                ActivityUtil.next(getActivity(), NewUserInfoActivity.class);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "common_head_mom_avatar_click", TimeUtil.currentTime()));
                break;
            case R.id.searchLayout:

                String popularWord = null;
                Object obj = childView.getTag(R.id.data);
                if (obj != null && obj instanceof String) {
                    popularWord = (String) obj;
                }

                SearchActivity.startActivity(getContext(), popularWord, SearchBaseFragment.SEARCH_FROM_EXCELLENT);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "mom_home_search_input_click", TimeUtil.currentTime()));
                break;
//            case R.id.shopCartLayout:
//                if (!UserService.getInstance().isLogining()) {
//                    LoginOrRegisterActivity.startActivity(getContext());
//                    return;
//                }
//                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "common_head_shopping_cart_click", TimeUtil.currentTime()));
//                ShopCartActivity.present(null);
//                break;
            case R.id.orderLayout:
                if (!UserService.getInstance().isLogining()) {
                    LoginOrRegisterActivity.startActivity(getContext());
                    return;
                }
                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "common_head_order_click", TimeUtil.currentTime()));
                FragmentUtil.pushFragment(VirtualOrderFragment.class, null, true);
                break;
            case R.id.settingLayout:
                ActivityUtil.next(getActivity(), SettingActivity.class);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "common_head_setting_click", TimeUtil.currentTime()));
                break;
            default:
                break;
        }
    }

    //从接口获取搜索热词，初次加载精选频道页面时获取
    private void loadSearchWordsFromInternet() {
        if (popularStrongReference == null) {
            popularStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<PopularKeywordsVO>> popularCallback = new DefaultCallback<List<PopularKeywordsVO>>() {
            @Override
            public void onDataReceived(final List<PopularKeywordsVO> data) {
                if (data == null || data.isEmpty()) {
                    return;
                }
                tempPopularWordList = new ArrayList<>();
                tempPopularWordList.addAll(data);

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        Random random = new Random();
                        int randomNum = random.nextInt(data.size());
                        motherHeaderView.updateSearchText(data.get(randomNum).getKeyWords());
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
            }
        };
        popularStrongReference.set(popularCallback);
        SearchAPI.getPopularKeywords(SearchBaseFragment.SEARCH_FROM_BOOK, popularStrongReference);
    }

    private void initMagicIndicator() {
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }

        magicIndicatorView.setBackgroundColor(Color.WHITE);

        CommonNavigator commonNavigator = new CommonNavigator(getContext());
        commonNavigator.setAdjustMode(true);
        commonNavigator.setAdapter(new MyCommonNavigatorAdapter());


        magicIndicatorView.setNavigator(commonNavigator);
        ViewPagerHelper.bind(magicIndicatorView, viewPager);
    }

    class FragmentAdapter extends FragmentPagerAdapter {

        private List<Fragment> fragmentList;

        public FragmentAdapter(FragmentManager fm, List<Fragment> fragmentList) {
            super(fm);
            this.fragmentList = fragmentList;
        }

        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

    }

    private class MyCommonNavigatorAdapter extends CommonNavigatorAdapter {

        private View.OnClickListener mOnClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int index = (int) v.getTag(R.id.position);
                viewPager.setCurrentItem(index);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", TRACK_TAB_TEXT_ARR[index], TimeUtil.currentTime()));
            }
        };

        @Override
        public int getCount() {
            return titleList == null ? 0 : titleList.size();
        }

        @Override
        public IPagerTitleView getTitleView(Context context, int index) {

            SimplePagerTitleView simplePagerTitleView = new ScaleTransitionPagerTitleView(context);
            simplePagerTitleView.setText(titleList.get(index));
            simplePagerTitleView.setTextSize(16);

            Resources resources = KaDaApplication.instance.getResources();

            simplePagerTitleView.setNormalColor(resources.getColor(R.color.book_info_title));
            simplePagerTitleView.setSelectedColor(resources.getColor(R.color.mother_tab_text_selected_color));
            simplePagerTitleView.setTag(R.id.position, index);
            simplePagerTitleView.setOnClickListener(mOnClickListener);

            return simplePagerTitleView;
        }

        @Override
        public IPagerIndicator getIndicator(Context context) {
            MyPagerIndicator indicator = new MyPagerIndicator(context);
            return indicator;
        }
    }

    @Override
    public void onDestroyView() {
        if (motherHeaderView != null) {
            motherHeaderView.onDestroyView();
        }

        if (popularStrongReference != null) {
            popularStrongReference.clear();
            popularStrongReference = null;
        }

        super.onDestroyView();

    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            fragments.get(viewPager.getCurrentItem()).setUserVisibleHint(true);

            //更新搜索框里的热词
            if (tempPopularWordList != null && tempPopularWordList.size() > 0) {
                Random random = new Random();
                motherHeaderView.updateSearchText(tempPopularWordList.get(random.nextInt(tempPopularWordList.size())).getKeyWords());
            }
        }
        EventBus.getDefault().post(new CommonBannerViewHolder.UpdateBannerTurnStatusEvent(isVisibleToUser));
    }
}
