package com.hhdd.kada.main.ui.fragment;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.main.utils.SafeHandler;
import com.squareup.leakcanary.RefWatcher;
import com.tendcloud.tenddata.TCAgent;
import com.umeng.analytics.MobclickAgent;

import java.lang.reflect.Field;

/**
 * Created by simon on 16/6/15.
 */
public class BaseFragment extends Fragment implements Handler.Callback {

    protected String TAG = BaseFragment.class.getName();
    protected Activity mActivity;
    private boolean isVisible;
    protected SafeHandler mHandler = null;

    public SafeHandler getHandler() {
        if (mHandler == null) {
            mHandler = new SafeHandler(Looper.getMainLooper(), this);
        }
        return mHandler;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (getUserVisibleHint()) {
            isVisible = true;
            onVisible();
        } else {
            isVisible = false;
            onInvisible();
        }
    }


    /**
     * 可见
     */
    protected void onVisible() {
    }

    /**
     * 不可见
     */
    protected void onInvisible() {

    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        mActivity = activity;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        UserHabitService.getInstance().commitRoute(getClass().getName()); //统计路径
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        MobclickAgent.onPageStart(getClass().getName()); //统计页面，"MainScreen"为页面名称，可自定义
        TCAgent.onPageStart(getContext(), getClass().getName());
    }

    @Override
    public void onPause() {
        super.onPause();

        MobclickAgent.onPageEnd(getClass().getName());
        TCAgent.onPageEnd(getContext(), getClass().getName());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        //RefWatcher观察Fragment的内存泄露
        if (getActivity()!= null){
            RefWatcher refWatcher = KaDaApplication.getRefWatcher(getActivity());
            if (refWatcher!=null){
                refWatcher.watch(this);
            }
        }

        if (mHandler != null) {
            mHandler.destroy();
            mHandler = null;
        }
        UserHabitService.getInstance().removeRoute(getClass().getName());
        super.onDestroy();

    }

    public void onBackPressed() {

    }


    @Override
    public void onDetach() {
        super.onDetach();

        try {
            Field childFragmentManager = Fragment.class.getDeclaredField("mChildFragmentManager");
            childFragmentManager.setAccessible(true);
            childFragmentManager.set(this, null);

        } catch (NoSuchFieldException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Deprecated
    @Override
    public void onHiddenChanged(boolean hidden) {
    }

    ;

    @Override
    public void onViewStateRestored(Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
    }

    protected void hideKeyBoard() {
//        InputMethodManager imm = (InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE);
//        // 获取软键盘的显示状态
//        boolean isOpen=imm.isActive();
//        if(isOpen){
//            imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
//        }

        View view = mActivity.getCurrentFocus();
        if (view != null) {
            ((InputMethodManager) mActivity.getSystemService(Context.INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

    }


    protected void showSoftKeyboard() {
        InputMethodManager im = ((InputMethodManager) KaDaApplication.getInstance().getSystemService(Context.INPUT_METHOD_SERVICE));
//        im.showSoftInput(edit, InputMethodManager.SHOW_FORCED);
        im.toggleSoftInput(0, InputMethodManager.SHOW_FORCED);
    }

    void hideSoftKeyboard(View view) {
        InputMethodManager im = (InputMethodManager) KaDaApplication.getInstance().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (view != null && view.getWindowToken() != null) {
            im.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }


    @Override
    public boolean handleMessage(Message message) {
        return false;
    }
}
