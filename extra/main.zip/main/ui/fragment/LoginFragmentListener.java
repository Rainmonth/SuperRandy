package com.hhdd.kada.main.ui.fragment;

import android.support.v4.app.Fragment;

/**
 * Created by lj on 16/4/21.
 */
public interface LoginFragmentListener {

    int TYPE_WX = 1; //微信
    int TYPE_HW = TYPE_WX + 1; //华为

    public void handleForgetButtonClicked(Fragment fragment, String value);

    public void handleLoginButtonClicked(Fragment fragment, String value);

    public void handleRegisterButtonClicked2(Fragment fragment, String value);

    public void handleBackButtonClicked(Fragment fragment);

    public void showLoading();

    public void hideLoading();

    public void loginSuccess(String phoneNumber);

    /**
     * 第三方登录成功回调
     * @param thirdType 三方类型 1 微信  2 华为
     * @param userName 帐号名，手机为手机号，微信和华为为unionId，用于加载对应本地数据库(由于本地数据库未与用户id关联)
     * @param isInfoCompleted 是否完善信息
     * @param isToast 是否推荐
     * @param firstLogin 是否第一次登录
     */
    void thirdLoginSuccess(int thirdType, String userName, boolean isInfoCompleted, boolean isToast, boolean firstLogin);

    public void registerSuccess(String phoneNumber, boolean isisInfoCompleted, boolean isToast);

    public void userLogin(String tag, String loginName, boolean isInfoCompleted, boolean isToast);
}
