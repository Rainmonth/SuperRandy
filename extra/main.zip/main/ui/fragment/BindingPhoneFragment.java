package com.hhdd.kada.main.ui.fragment;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.model.AccountUnifyInfo;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.PatternUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.views.TimeButton;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by lj on 17/3/7.
 */

public class BindingPhoneFragment extends com.hhdd.kada.base.BaseFragment {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.phoneNumberEditTextView)
    EditText phoneNumberEditTextView;
    @BindView(R.id.codeEditTextView)
    EditText codeEditTextView;
    @BindView(R.id.getCodeTimeButton)
    TimeButton getCodeTimeButton;
    @BindView(R.id.bindingTextView)
    TextView bindingTextView;
    private StrongReference<DefaultCallback> validatePhoneReference;

    public static BindingPhoneFragment newInstance(Bundle bundle) {
        BindingPhoneFragment fragment = new BindingPhoneFragment();
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        return fragment;
    }

    String mLoginName;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_binding, container, false);
        ButterKnife.bind(this, rootView);
        if (getArguments() != null) {
            mLoginName = getArguments().getString("loginName");
        }
        initView();
        initListener();
        return rootView;
    }

    /**
     * view初始化
     */
    private void initView() {
        titleBarView.setTitle(KaDaApplication.instance.getResources().getString(R.string.binding_phone_text));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleBarLayoutParams = titleBarView.getLayoutParams();
            if (titleBarLayoutParams == null) {
                titleBarLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleBarLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height) + LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleBarView.setLayoutParams(titleBarLayoutParams);
            titleBarView.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
        }
        getCodeTimeButton.setTextBefore("点击获取验证码").setLenght(60 * 1000);
    }

    /**
     * 事件监听初始化
     */
    private void initListener() {
        titleBarView.setLeftOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideKeyBoard();
                getContext().finish();
            }
        });
        getCodeTimeButton.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                String mobile = phoneNumberEditTextView.getText().toString();

                if (StringUtil.isEmpty(mobile)) {
                    ToastUtils.showToast(R.string.phone_not_null);
                    return;
                }

                if (!PatternUtil.isMobile(mobile)) {
                    ToastUtils.showToast(R.string.phone_error);
                    return;
                }

                if (!NetworkUtils.isReachable()) {
                    ToastUtils.showToast(R.string.network_error);
                    return;
                }

                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        StaCtrName.binding_phone_apply_code, TimeUtil.currentTime()));

                getCodeTimeButton.setIsEffective(true);

                UserAPI.getSmsCode(mobile, Constants.CODE_GET_TYPE_UNIFYPHONE, new API.ResponseHandler<String>() {
                    @Override
                    public void onSuccess(String responseData) {
                        getHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                ToastUtils.showToast(R.string.message_send_success);
                            }
                        });
                    }

                    @Override
                    public void onFailure(int code, String message) {
                    }
                });
            }
        });
        bindingTextView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                int userAccountType = UserService.getInstance().getUserAccountType();
                if (userAccountType == 0) {
                    return;
                }
                String phoneNumberStr = phoneNumberEditTextView.getText().toString();
                if (TextUtils.isEmpty(phoneNumberStr)) {
                    ToastUtils.showToast(R.string.phone_not_null);
                    return;
                }
                String codeStr = codeEditTextView.getText().toString();
                if (TextUtils.isEmpty(codeStr)) {
                    ToastUtils.showToast(R.string.code_not_null);
                    return;
                }
                if (!PatternUtil.isMobile(phoneNumberStr)) {
                    ToastUtils.showToast(R.string.phone_error);
                    return;
                }
                if (!NetworkUtils.isReachable()) {
                    ToastUtils.showToast(R.string.network_error);
                    return;
                }

                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        StaCtrName.binding_phone_binding_btn_click, TimeUtil.currentTime()));

                final Context context = getContext();
                final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
                customDialogManager.showDialog(context, new CustomProgressDialog.Listener() {
                    @Override
                    public void onClosed() {
                        clearValidatePhoneReference();
                    }
                });
                if (validatePhoneReference == null) {
                    validatePhoneReference = new StrongReference<>();
                }
                DefaultCallback callback = new DefaultCallback<List<AccountUnifyInfo>>() {
                    @Override
                    public void onDataReceived(final List<AccountUnifyInfo> data) {
                        getHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                customDialogManager.dismissDialog(context);
                                if (data != null && data.size() > 0) {
                                    ActivityUtil.nextBindingConflictActivity(getContext(), (ArrayList<AccountUnifyInfo>) data);
                                } else {
                                    // 要求服务端不能返回404，要不然按照客户端当前版本(v3.6.5)逻辑404也会回调成功的话，无法区分是绑定失败还是绑定成功
                                    ActivityUtil.nextBindingSuccessActivity(getContext(), false);
                                }
                                getContext().finish();
                            }
                        });
                    }

                    @Override
                    public void onException(int code, String reason) {
                        super.onException(reason);
                        customDialogManager.dismissDialog(context);
                    }
                };
                validatePhoneReference.set(callback);
                UserAPI.validatePhone(userAccountType, phoneNumberStr.trim(), codeStr.trim(), validatePhoneReference);
            }
        });
    }

    /**
     * 清除绑定手机接口回调强引用资源
     */
    private void clearValidatePhoneReference() {
        if (validatePhoneReference != null) {
            validatePhoneReference.clear();
            validatePhoneReference = null;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                StaPageName.binding_phone_page_view, TimeUtil.currentTime()));
    }

    @Override
    public void onDestroyView() {
        if (getCodeTimeButton != null) {
            getCodeTimeButton.onDestroy();
        }
        super.onDestroyView();
        clearValidatePhoneReference();
    }
}
