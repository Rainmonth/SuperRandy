package com.hhdd.kada.main.ui.fragment.collectdownload;

import com.google.gson.reflect.TypeToken;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.db.download.entities.DownloadInfo;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.mediaserver.MediaServer2;
import com.hhdd.kada.main.model.BaseBookStoryInfo;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.TimeUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/26
 * @describe : com.hhdd.kada.main.ui.fragment.collectdownload
 */
public class DownloadStoryFragment extends BaseDownloadFragment {

    //听书页面使用的是老的storyInfo实体，故点击跳转的时候转为老的(由于涉及到的类较多，暂时就不统一了)
    private List<com.hhdd.core.model.StoryInfo> oldStoryInfoList = new ArrayList<>();

    @Override
    protected List<DownloadInfo> getUnCompleteCollectionInfo() {
        return ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).listAllStoryCollection(false);
    }

    @Override
    protected List<DownloadInfo> getAllBookStoryInfo() {
        return ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).listAllStories(true);
    }

    @Override
    protected int getViewType() {
        return View_Type_Story_Item;
    }

    @Override
    protected void initOldStoryList(List<BaseBookStoryInfo> infoList) {
        if (infoList.size() > 0) {
            oldStoryInfoList.clear();
            for (int i = 0; i < infoList.size(); i++) {
                oldStoryInfoList.add(com.hhdd.core.model.StoryInfo.createInfoByNewStory(infoList.get(i)));
            }
        }
    }

    @Override
    protected void doItemViewClick(Object o) {
        if(getContext() == null || getContext().isFinishing()){
            return;
        }
        int id = 0;
        String type = "";
        if (o instanceof com.hhdd.kada.main.model.StoryInfo) {
            com.hhdd.kada.main.model.StoryInfo info = (com.hhdd.kada.main.model.StoryInfo) o;
            id = info.getStoryId();
            type = "1";
            ListenActivity.startActivity(getContext(), info.getStoryId(), oldStoryInfoList);
        } else if (o instanceof StoryCollectionInfo) {
            StoryCollectionInfo info = (StoryCollectionInfo) o;
            id = info.getId();
            type = "2";
//            if (storyCollectionInfoMap.get(info.getId()) != null) {
//                FragmentUtil.presentFragment(StoryCollectionFragment.class, storyCollectionInfoMap.get(info.getId()).getData(), true);

            // 在3.2.8版本上，听书合辑下载没有手动存储合辑详情数据（存储了列表Item 不包含合辑详情数据 这个数据没有用到），下载中心点击听书合辑进入详情页面加载的是缓存数据
            // 在3.3.1版本上，下载听书合辑时将合辑详情页数据同时做了缓存和手动存储到数据库（详情页json串存储在DownloadInfoDao-data字段）
            // 现在3.3.1版本上，下载中心点击进入听书合辑详情页面时 用缓存的方式展现数据（同3.2.8实现方式一样）；
            // 如果读取数据库会出现3.2.8版本上已下载的听书合辑，在升级到3.3.1版本时 进入下载中心详情页会加载不到数据
            BaseCollectionFragment.CollectionModel model = new BaseCollectionFragment.CollectionModel(info.getCollectId(), true);
            FragmentUtil.presentFragment(StoryCollectionFragment.class, model, true);
//            }
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(type + "," + id, "download_center_story_content_click", TimeUtil.currentTime()));
    }

    @Override
    protected void deleteFiles(BaseBookStoryInfo info) {
        DownloadInfo downloadInfo = null;
        String type = "";
        if (info instanceof StoryInfo) {
            type = "1";
            StoryInfo storyInfo = (StoryInfo) info;
            downloadInfo = storyInfoMap.get(storyInfo.getId());
//            List<CollectionItemStatus> itemStatusList = DatabaseManager.getInstance().collectionItemStatusDB().queryList(storyInfo.getStoryId());
//            boolean collectionCanDeleteFile = isCollectionCanDeleteFile(itemStatusList);
            boolean isHaveDownloadFinished = DatabaseManager.getInstance().collectionItemStatusDB().isDownloadFinish(storyInfo.getStoryId());
            if(!isHaveDownloadFinished) {
                if (storyInfo.getDownloadUrl() != null
                        && storyInfo.getDownloadUrl().length() > 0) {
                    String targetSoundFilePath = Dirs.getListenCachePath() + File.separator + MediaServer2.cachedFileName(storyInfo.getDownloadUrl(), storyInfo.getStoryId(), storyInfo.getVersion());
                    FileUtils.removeFile(targetSoundFilePath);
                }
            }
        } else if (info instanceof StoryCollectionInfo) {
            type = "2";
            StoryCollectionInfo storyCollectionInfo = (StoryCollectionInfo) info;
            downloadInfo = storyCollectionInfoMap.get(storyCollectionInfo.getId());
            //删除合集单本下载状态
            DatabaseManager.getInstance().collectionItemStatusDB().deleteStoryCollectionItemStatus(storyCollectionInfo.getCollectId());
            StoryCollectionDetail detailInfo = gson.fromJson(downloadInfo.getData(), new TypeToken<StoryCollectionDetail>() {
            }.getType());
            if(detailInfo != null) {
                List<StoryInfo> storyInfoList = detailInfo.getItems();
                if (storyInfoList != null) {
                    //TODO: 是否有更好方法提高效率
                    for (int j = 0; j < storyInfoList.size(); j++) {
                        StoryInfo temStoryInfo = storyInfoList.get(j);
//                        List<CollectionItemStatus> itemStatusList = DatabaseManager.getInstance().collectionItemStatusDB().queryList(temStoryInfo.getStoryId());
//                        boolean collectionCanDeleteFile = isCollectionCanDeleteFile(itemStatusList);
                        boolean isHaveDownloadFinished = DatabaseManager.getInstance().collectionItemStatusDB().isDownloadFinish(temStoryInfo.getStoryId());
                        boolean isDownloadStory = ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).isStoryDownloadCompletion(temStoryInfo.getStoryId());
                        if (!isDownloadStory && !isHaveDownloadFinished) {
                            if (temStoryInfo.getDownloadUrl() != null
                                    && temStoryInfo.getDownloadUrl().length() > 0) {
                                //如果该听书单本未下载且不存在其它合集中，删除文件
                                String targetSoundFilePath = Dirs.getListenCachePath() + File.separator + MediaServer2.cachedFileName(temStoryInfo.getDownloadUrl(), temStoryInfo.getStoryId(), temStoryInfo.getVersion());
                                FileUtils.removeFile(targetSoundFilePath);
                            }
                        }
                    }
                }
            }
        }
        if (downloadInfo != null) {
            //删除下载单本合集记录
            ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).delete(downloadInfo.getId());
        }
        int id = info != null ? info.getId() : 0;
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(type + "," + id, "download_center_story_content_delete", TimeUtil.currentTime()));
    }

//    private boolean isCollectionCanDeleteFile(List<CollectionItemStatus> itemStatusList) {
//        boolean collectionCanDeleteFile = true;
//        if(itemStatusList != null && itemStatusList.size() > 0){
//            for (CollectionItemStatus status : itemStatusList){
//                Boolean downloadFinished = status.getDownloadfinished();
//                if(downloadFinished != null && downloadFinished){
//                    collectionCanDeleteFile = false;
//                    break;
//                }
//            }
//        }
//        return collectionCanDeleteFile;
//    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if(isVisibleToUser){
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "download_center_story_view", TimeUtil.currentTime()));
        }
    }
}
