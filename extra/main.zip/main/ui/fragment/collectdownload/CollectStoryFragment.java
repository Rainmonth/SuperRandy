package com.hhdd.kada.main.ui.fragment.collectdownload;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.FavoriteService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.common.DataListModel;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.event.FavoriteEvent;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.ui.activity.StoryCollectionActivity;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.TimeUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/26
 * @describe : com.hhdd.kada.main.ui.fragment
 */
public class CollectStoryFragment extends BaseCollectFragment {

    //听书页面使用的是老的storyInfo实体，故点击跳转的时候转为老的(由于涉及到的类较多，暂时就不统一了)
    private List<com.hhdd.core.model.StoryInfo> oldStoryInfoList = new ArrayList<>();

    @Override
    protected DataListModel getDataListModel() {
        StoryAPI.PaginationCollectionListAPI storyApi = new StoryAPI.PaginationCollectionListAPI("favorite", "getStory2List.json");
        return new DataListModel(storyApi, 60);
    }

    @Override
    protected int getViewType() {
        return View_Type_Story_Item;
    }

    @Override
    protected void doItemViewClick(Object o) {
        if(getContext() == null || getContext().isFinishing()){
            return;
        }
        int id = 0;
        String type = "";
        if (o instanceof com.hhdd.kada.main.model.StoryInfo) {
            com.hhdd.kada.main.model.StoryInfo info = (com.hhdd.kada.main.model.StoryInfo) o;
            id = info.getStoryId();
            type = "1";
            ListenActivity.startActivity(getContext(), info.getStoryId(), oldStoryInfoList);
        } else if (o instanceof StoryCollectionInfo) {
            StoryCollectionInfo info = (StoryCollectionInfo) o;
            id = info.getCollectId();
            type = "2";
            //新合集
            if(info.getType() == Constants.TYPE_STORY_COLLECT){
                FragmentUtil.presentFragment(StoryCollectionFragment.class,info.getCollectId(),true);
            }else{
                StoryCollectionActivity.startActivity(getContext(), info.getCollectId());
            }
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(type + "," + id, "collect_center_story_content_click", TimeUtil.currentTime()));
    }

    @Override
    protected void doFavoriteDelete(BaseModel model) {
        if (model instanceof com.hhdd.kada.main.model.StoryInfo) {
            final com.hhdd.kada.main.model.StoryInfo info = (com.hhdd.kada.main.model.StoryInfo) model;
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getStoryId()), "collect_center_story_content_delete", TimeUtil.currentTime()));
            StoryAPI.storyAPI_collectStory(info.getStoryId(), 2,info.getVersion()).post(new API.ResponseHandler() {
                @Override
                public void onSuccess(Object responseData) {
                    ((FavoriteService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.FAVORITE_SERVICE)).removeStoryId(info.getStoryId());
                }

                @Override
                public void onFailure(int code, String message) {

                }
            });
        }
    }

    @Override
    protected void initOldStoryList(List<BaseModel> infoList) {
        if (infoList.size() > 0) {
            oldStoryInfoList.clear();
            for (int i = 0; i < infoList.size(); i++) {
                oldStoryInfoList.add(com.hhdd.core.model.StoryInfo.createInfoByNewStory(infoList.get(i)));
            }
        }
    }

    @Override
    protected void doFavoriteEvent(FavoriteEvent event) {
        if(event.getType() == FavoriteEvent.TYPE_STORY){
            loadData();
        }
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if(isVisibleToUser){
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "collect_center_story_view", TimeUtil.currentTime()));
        }
    }
}
