package com.hhdd.kada.main.ui.fragment.collectdownload;

import com.google.gson.reflect.TypeToken;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.BookService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.db.download.entities.DownloadInfo;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseBookStoryInfo;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.TimeUtil;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/26
 * @describe : com.hhdd.kada.main.ui.fragment.collectdownload
 */
public class DownloadBookFragment extends BaseDownloadFragment {

    @Override
    protected List<DownloadInfo> getUnCompleteCollectionInfo() {
        return ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).listAllBookCollection(false);
    }

    @Override
    protected List<DownloadInfo> getAllBookStoryInfo() {
        return ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).listAllBooks(true);
    }

    @Override
    protected int getViewType() {
        return View_Type_Book_Item;
    }

    @Override
    protected void doItemViewClick(Object o) {
        if(getContext() == null || getContext().isFinishing()){
            return;
        }
        int id = 0;
        String type = "";
        if (o instanceof BookInfo) {
            BookInfo info = (BookInfo) o;
            id = info.getBookId();
            type = "1";
            PlaybackActivity.startActivity(getContext(), info.getBookId(), info.getExtFlag(), info.getVersion());
        } else if (o instanceof BookCollectionInfo) {
            BookCollectionInfo info = (BookCollectionInfo) o;
            id = info.getId();
            type = "2";
            if (bookCollectionInfoMap.get(info.getId()) != null) {
                FragmentUtil.pushFragment(BookCollectionFragment.class, bookCollectionInfoMap.get(info.getId()).getData(), true);
            }
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(type + "," + id, "download_center_book_content_click", TimeUtil.currentTime()));
    }

    @Override
    protected void deleteFiles(BaseBookStoryInfo info) {
        DownloadInfo downloadInfo = null;
        String type = "";
        if (info instanceof BookInfo) {
            type = "1";
            downloadInfo = bookInfoMap.get(info.getId());
//            List<BookCollectionItemStatus> itemStatusList = DatabaseManager.getInstance().bookCollectionItemStatusDB().queryList(info.getId());
//            boolean collectionCanDeleteFile = isCollectionCanDeleteFile(itemStatusList);
            boolean isHaveDownloadFinished = DatabaseManager.getInstance().bookCollectionItemStatusDB().isDownloadFinish(info.getId());
            if(!isHaveDownloadFinished) {
                FileUtils.deleteFolderFile(BookService.getBookCachePath(info.getId()), true);
            }
        } else if (info instanceof BookCollectionInfo) {
            type = "2";
            BookCollectionInfo bookCollectionInfo = (BookCollectionInfo) info;
            downloadInfo = bookCollectionInfoMap.get(info.getId());
            //删除合集单本下载记录
            DatabaseManager.getInstance().bookCollectionItemStatusDB().deleteBookCollectionItemStatus(bookCollectionInfo.getCollectId());
            BookCollectionDetailInfo detailInfo = gson.fromJson(downloadInfo.getData(), new TypeToken<BookCollectionDetailInfo>() {
            }.getType());
            if(detailInfo != null) {
                List<BookInfo> bookInfoList = detailInfo.getItems();
                if (bookInfoList != null) {
                    //TODO: 是否有更好方法提高效率
                    for (int j = 0; j < bookInfoList.size(); j++) {
                        BookInfo bookInfo = bookInfoList.get(j);
//                        List<BookCollectionItemStatus> itemStatusList = DatabaseManager.getInstance().bookCollectionItemStatusDB().queryList(bookInfo.getBookId());
//                        boolean collectionCanDeleteFile = isCollectionCanDeleteFile(itemStatusList);
                        boolean isHaveDownloadFinished = DatabaseManager.getInstance().bookCollectionItemStatusDB().isDownloadFinish(info.getId());
                        boolean isDownloadBook = ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).isDownloadCompletion(bookInfo.getBookId());
                        if (!isDownloadBook && !isHaveDownloadFinished) {
                            //如果该绘本单本未下载且不存在其它合集中，删除文件
                            FileUtils.deleteFolderFile(BookService.getBookCachePath(bookInfo.getBookId()), true);
                        }
                    }
                }
            }
        }
        if (downloadInfo != null) {
            //删除下载单本合集记录
            ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).delete(downloadInfo.getId());
        }
        int id = info != null ? info.getId() : 0;
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(type + "," + id, "download_center_book_content_delete", TimeUtil.currentTime()));
    }

//    private boolean isCollectionCanDeleteFile(List<BookCollectionItemStatus> itemStatusList) {
//        boolean collectionCanDeleteFile = true;
//        if(itemStatusList != null && itemStatusList.size() > 0){
//            for (BookCollectionItemStatus status : itemStatusList){
//                Boolean downloadFinished = status.getDownloadfinished();
//                if(downloadFinished != null && downloadFinished){
//                    collectionCanDeleteFile = false;
//                    break;
//                }
//            }
//        }
//        return collectionCanDeleteFile;
//    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "download_center_book_view", TimeUtil.currentTime()));
        }
    }
}
