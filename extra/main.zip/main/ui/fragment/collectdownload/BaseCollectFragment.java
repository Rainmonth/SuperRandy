package com.hhdd.kada.main.ui.fragment.collectdownload;

import android.os.Bundle;
import android.view.View;

import com.hhdd.kada.main.common.DataListModel;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.FavoriteEvent;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.ui.bookshelf.BookShelfBookListViewHolder;
import com.hhdd.kada.main.ui.bookshelf.BookShelfStoryListViewHolder;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.SeparatorBigViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorViewHolder;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.main.vo.BookStoryModelListVO;
import com.hhdd.logger.LogHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/27
 * @describe : com.hhdd.kada.main.ui.fragment.collectdownload
 */
public abstract class BaseCollectFragment extends RecyclerDataListFragment2 {

    private List<BaseModel> models;
    private DataListModel dataListModel;
    private boolean isEdit = false;
    private SimpleEventHandler handler;

    protected static final int View_Type_Story_Item = 1;
    protected static final int View_Type_Book_Item = 2;
    protected static final int View_Type_Separator = 3;
    protected static final int View_Type_Big_Sep = 4;

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case BookShelfBookListViewHolder.TYPE_BOOK_SHELF_BOOK_ITEM_CLICKED:
                case BookShelfStoryListViewHolder.TYPE_BOOK_SHELF_STORY_ITEM_CLICKED:
                    try {
                        doItemViewClick(args[0]);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    return true;

                case BookShelfBookListViewHolder.TYPE_BOOK_SHELF_BOOK_DELETE_CLICKED:
                case BookShelfStoryListViewHolder.TYPE_BOOK_SHELF_STORY_DELETE_CLICKED:
                    try {
                        if (args[0] instanceof BaseModel) {
                            BaseModel model = (BaseModel) args[0];
                            doFavoriteDelete(model);
                            models.remove(model);
                            handleLoadedData(models);
                        }
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    return true;
            }
            return false;
        }
    };

    public BaseCollectFragment() {
        super(LIST_MODE_BOTH, "", null);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        getTitleBar().setVisibility(View.GONE);
        setBackgroundDrawable(null);
        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(View_Type_Story_Item, BookShelfStoryListViewHolder.class);
        viewTypeMaps.put(View_Type_Book_Item, BookShelfBookListViewHolder.class);
        viewTypeMaps.put(View_Type_Separator, SeparatorViewHolder.class);
        viewTypeMaps.put(View_Type_Big_Sep, SeparatorBigViewHolder.class);

        BaseViewHolderCreator viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(viewHolderCreator);

        loadData();

        EventCenter.bindContainerAndHandler(this, handler = new SimpleEventHandler() {

            public void onEvent(FavoriteEvent event) {
                doFavoriteEvent(event);
            }
        });
    }

    protected void loadData() {
        dataListModel = getDataListModel();
        reloadData(dataListModel);
    }

    public void doEdit(boolean isEdit) {
        BaseCollectFragment.this.isEdit = isEdit;
        handleLoadedData(models);
    }

    public boolean isEdit() {
        return isEdit;
    }

    @Override
    protected void reassembleDisplayedDataList(List<BaseVO> reassembledList, List<BaseModel> itemsAdded, boolean isFirstPage) {
        if (isFirstPage) {
            reassembledList.add(new BaseModelVO(null, View_Type_Separator));
            if (itemsAdded == null || itemsAdded.size() == 0) {
                BookStoryModelListVO vo = new BookStoryModelListVO(isEdit, null, getViewType());
                reassembledList.add(vo);

                BookStoryModelListVO vo2 = new BookStoryModelListVO(isEdit, null, getViewType());
                reassembledList.add(vo2);
            }
        }
        if (!isFirstPage && (itemsAdded == null || itemsAdded.size() == 0)) {
            reassembledList.add(new BaseModelVO(null, View_Type_Big_Sep));
        }

        models = dataListModel.getListPageInfo().getDataList();

        if (itemsAdded == null || itemsAdded.size() == 0) {
            return;
        }

        List<BaseVO> dataListTmp = new ArrayList<BaseVO>();
        List<BaseModel> tmpList = new ArrayList<>();
        for (int i = 0; i < itemsAdded.size(); i++) {
            tmpList.add(itemsAdded.get(i));
            if (tmpList.size() >= 3) {
                BookStoryModelListVO vo = new BookStoryModelListVO(isEdit, tmpList, getViewType());
                dataListTmp.add(vo);
                tmpList.clear();
            }
        }
        if (tmpList.size() > 0) {
            BookStoryModelListVO vo = new BookStoryModelListVO(isEdit, tmpList, getViewType());
            dataListTmp.add(vo);
            tmpList.clear();
        }
        initOldStoryList(itemsAdded);
        reassembledList.addAll(dataListTmp);

    }

    void handleLoadedData(List<BaseModel> modelList) {
        boolean hasmore = dataListModel.getListPageInfo().hasMore();
        reloadData(modelList);
        dataListModel.getListPageInfo().setHasMore(hasmore);
    }

    @Override
    public void onDestroyView() {
        if (handler != null) {
            handler.onDestroy();
        }
        super.onDestroyView();
    }

    protected abstract DataListModel getDataListModel();

    protected abstract int getViewType();

    protected abstract void doItemViewClick(Object o);

    protected void initOldStoryList(List<BaseModel> infoList) {

    }

    protected abstract void doFavoriteDelete(BaseModel model);

    protected abstract void doFavoriteEvent(FavoriteEvent event);
}
