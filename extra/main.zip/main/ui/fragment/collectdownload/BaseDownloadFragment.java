package com.hhdd.kada.main.ui.fragment.collectdownload;

import android.os.Bundle;
import android.util.SparseArray;
import android.view.View;

import com.google.gson.Gson;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.thread.IThread;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.db.download.entities.DownloadInfo;
import com.hhdd.kada.download.DownloadInfoUtil;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.model.BaseBookStoryInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.ui.bookshelf.BookShelfBookListViewHolder;
import com.hhdd.kada.main.ui.bookshelf.BookShelfStoryListViewHolder;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.SeparatorBigViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorViewHolder;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BookStoryModelListVO;
import com.hhdd.logger.LogHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/27
 * @describe : com.hhdd.kada.main.ui.fragment.collectdownload
 */
public abstract class BaseDownloadFragment extends RecyclerDataListFragment2 {

    private List<BaseModel> list;
    private List<BaseBookStoryInfo> models;
    private boolean isEdit = false;
    protected SparseArray<DownloadInfo> bookInfoMap = new SparseArray<>();
    protected SparseArray<DownloadInfo> bookCollectionInfoMap = new SparseArray<>();
    protected SparseArray<DownloadInfo> storyInfoMap = new SparseArray<>();
    protected SparseArray<DownloadInfo> storyCollectionInfoMap = new SparseArray<>();
    protected Gson gson = new Gson();

    protected static final int View_Type_Story_Item = 1;
    protected static final int View_Type_Book_Item = 2;
    protected static final int View_Type_Separator = 3;
    protected static final int View_Type_Big_Sep = 4;

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case BookShelfBookListViewHolder.TYPE_BOOK_SHELF_BOOK_ITEM_CLICKED:
                case BookShelfStoryListViewHolder.TYPE_BOOK_SHELF_STORY_ITEM_CLICKED:
                    try {
                        doItemViewClick(args[0]);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }

                    return true;

                case BookShelfBookListViewHolder.TYPE_BOOK_SHELF_BOOK_DELETE_CLICKED:
                case BookShelfStoryListViewHolder.TYPE_BOOK_SHELF_STORY_DELETE_CLICKED:
                    try {
                        if (args[0] instanceof BaseBookStoryInfo) {
                            BaseBookStoryInfo model = (BaseBookStoryInfo) args[0];
                            if (models != null && models.contains(model)) {
                                models.remove(model);
                                deleteFiles(model);
                                handleLoadedData(models);
                            }
                        }
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }

                    return true;
            }
            return false;
        }
    };

    public BaseDownloadFragment() {
        super(LIST_MODE_NONE, "", null);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        getTitleBar().setVisibility(View.GONE);
        setBackgroundDrawable(null);
        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(View_Type_Story_Item, BookShelfStoryListViewHolder.class);
        viewTypeMaps.put(View_Type_Book_Item, BookShelfBookListViewHolder.class);
        viewTypeMaps.put(View_Type_Separator, SeparatorViewHolder.class);
        viewTypeMaps.put(View_Type_Big_Sep, SeparatorBigViewHolder.class);

        BaseViewHolderCreator viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(viewHolderCreator);

        ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE))
                .postDaemonTask(loadDataRunnable, "LoadDownloadDataJob");
    }

    public void doEdit(boolean isEdit){
        BaseDownloadFragment.this.isEdit = isEdit;
        handleLoadedData(models);
    }

    public boolean isEdit() {
        return isEdit;
    }

    private Runnable loadDataRunnable = new Runnable() {

        private List<BaseBookStoryInfo> bookStoryInfoList = new ArrayList<>();
        private List<DownloadInfo> downloadBookStoryInfoList;

        @Override
        public void run() {
            List<DownloadInfo> downloadBookStoryInfoListTemp1 = getUnCompleteCollectionInfo();
            List<DownloadInfo> downloadBookStoryInfoListTemp2 = getAllBookStoryInfo();
            downloadBookStoryInfoList = new ArrayList<>();
            if (downloadBookStoryInfoListTemp1 != null && downloadBookStoryInfoListTemp1.size() > 0) {
                downloadBookStoryInfoList.addAll(downloadBookStoryInfoListTemp1);
            }
            if (downloadBookStoryInfoListTemp2 != null && downloadBookStoryInfoListTemp2.size() > 0) {
                downloadBookStoryInfoList.addAll(downloadBookStoryInfoListTemp2);
            }

            if (downloadBookStoryInfoList != null && downloadBookStoryInfoList.size() > 0) {
                for (DownloadInfo downloadInfo : downloadBookStoryInfoList) {
                    BaseBookStoryInfo baseModel = DownloadInfoUtil.createNewFromDownloadInfo(downloadInfo);
                    if (baseModel != null) {
                        bookStoryInfoList.add(baseModel);
                        if(baseModel instanceof StoryInfo){
                            storyInfoMap.put(baseModel.getId(), downloadInfo);
                        } else if(baseModel instanceof StoryCollectionInfo){
                            storyCollectionInfoMap.put(baseModel.getId(), downloadInfo);
                        } else if(baseModel instanceof BookInfo){
                            bookInfoMap.put(baseModel.getId(), downloadInfo);
                        } else if(baseModel instanceof BookCollectionInfo){
                            bookCollectionInfoMap.put(baseModel.getId(), downloadInfo);
                        }
                    }
                }
            }
            getHandler().post(new Runnable() {
                @Override
                public void run() {
                    handleLoadedData(bookStoryInfoList);
                }
            });
        }
    };

    public void handleLoadedData(List<BaseBookStoryInfo> modelList) {
        models = modelList;

        list = new ArrayList<>();
        list.add(new BaseModelVO(null, View_Type_Separator));
        List<BaseModel> tmpList = new ArrayList<>();

        if (modelList == null || modelList.size() == 0) {
            BookStoryModelListVO vo = new BookStoryModelListVO(isEdit, null, getViewType());
            list.add(vo);

            BookStoryModelListVO vo2 = new BookStoryModelListVO(isEdit, null, getViewType());
            list.add(vo2);
        } else {
            for (int i = 0; i < modelList.size(); i++) {
                tmpList.add(modelList.get(i));
                if (tmpList.size() >= 3) {
                    addModelList(tmpList);
                }
            }
            if (tmpList.size() > 0) {
                addModelList(tmpList);
            }

            initOldStoryList(modelList);
        }

        list.add(new BaseModelVO(null, View_Type_Big_Sep));
        reloadData(list);
    }

    private void addModelList(List<BaseModel> tmpList) {
        BookStoryModelListVO vo = new BookStoryModelListVO(isEdit, tmpList, getViewType());
        list.add(vo);
        tmpList.clear();
    }

    protected abstract List<DownloadInfo> getUnCompleteCollectionInfo();

    protected abstract List<DownloadInfo> getAllBookStoryInfo();

    protected abstract int getViewType();

    protected abstract void doItemViewClick(Object o);

    protected abstract void deleteFiles(BaseBookStoryInfo info);

    protected void initOldStoryList(List<BaseBookStoryInfo> infoList){

    }
}
