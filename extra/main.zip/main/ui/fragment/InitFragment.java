package com.hhdd.kada.main.ui.fragment;

import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.coin.event.CoinUpdateEvent;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.WeiXinLoginEvent;
import com.hhdd.kada.main.manager.WChatManager;
import com.hhdd.kada.main.model.HWLoginInfo;
import com.hhdd.kada.main.model.WeixinPayModel;
import com.hhdd.kada.main.ui.activity.MainActivity;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.HWSDKUtil;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.tencent.mm.opensdk.modelmsg.SendAuth;

import butterknife.BindView;
import butterknife.ButterKnife;


/**
 * Created by mcx on 2018/3/26.
 */

public class InitFragment extends BaseFragment {

    @BindView(R.id.leftIconView)
    public ImageView leftIconView;
    @BindView(R.id.centerIconView)
    public ImageView centerIconView;
    @BindView(R.id.rightIconView)
    public ImageView rightIconView;
    @BindView(R.id.leftTextView)
    public TextView leftTextView;
    @BindView(R.id.centerTextView)
    public TextView centerTextView;
    @BindView(R.id.rightTextView)
    public TextView rightTextView;
    @BindView(R.id.lastLoginWayView)
    public ImageView lastLoginWayView;
    @BindView(R.id.touristLayout)
    View touristLayout;
    @BindView(R.id.bottomLayout)
    View bottomLayout;
    @BindView(R.id.fl_init_fragment)
    public FrameLayout flInitFragment;

    private StrongReference<DefaultCallback> weixinStrongReference;
    private LoginFragmentListener listener;
    private PrefsManager pm;
    private boolean isShowHuaWeiInfo; //是否展示华为相关信息

    public static final int LAST_LOGIN_WAY_IS_WX = 1;
    public static final int LAST_LOGIN_WAY_IS_PHONE = LAST_LOGIN_WAY_IS_WX + 1;
    public static final int LAST_LOGIN_WAY_IS_TOURIST = LAST_LOGIN_WAY_IS_PHONE + 1;
    public static final int LAST_LOGIN_WAY_IS_HW = LAST_LOGIN_WAY_IS_TOURIST + 1;

    public static InitFragment newInstance(Bundle bundle) {
        InitFragment fragment = new InitFragment();
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        return fragment;
    }


    public void setListener(LoginFragmentListener listener) {
        this.listener = listener;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        EventCenter.register(this);

        View rootView = LayoutInflater.from(getContext()).inflate(R.layout.fragment_init, container, false);
        ButterKnife.bind(this, rootView);
        initView();
        initListeners();
        return rootView;
    }

    /**
     * view初始化
     */
    void initView() {
        if (mActivity == null || getActivity() == null || getActivity().isFinishing()) {
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            flInitFragment.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }

        pm = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
        isShowHuaWeiInfo = HWSDKUtil.isShowHuaWeiInfo();
        updateLastLoginWayView();
        touristLayout.setVisibility(isShowHuaWeiInfo ? View.VISIBLE : View.GONE);
        bottomLayout.setPadding(0, isShowHuaWeiInfo ? LocalDisplay.dp2px(25) : LocalDisplay.dp2px(40), 0, 0);
        leftIconView.setImageResource(isShowHuaWeiInfo ? R.drawable.init_fragment_hw : R.drawable.init_fragment_phone);
        centerIconView.setImageResource(R.drawable.init_fragment_wx);
        rightIconView.setImageResource(isShowHuaWeiInfo ? R.drawable.init_fragment_phone : R.drawable.icon_init_fragment_tourist);
        leftTextView.setText(isShowHuaWeiInfo ? R.string.hw_login_text : R.string.phone_login_text);
        centerTextView.setText(R.string.wx_login_text);
        rightTextView.setText(isShowHuaWeiInfo ? R.string.phone_login_text : R.string.tourist_login_text);
    }

    /**
     * 更新上次登录标志
     */
    private void updateLastLoginWayView() {
        int loginWay = pm.getInt(Constants.LAST_LOGIN_WAY, 0);
        lastLoginWayView.setVisibility(View.VISIBLE);
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) lastLoginWayView.getLayoutParams();

        switch (loginWay) {
            case LAST_LOGIN_WAY_IS_PHONE:
                params.topMargin = LocalDisplay.dp2px(7);
                params.leftMargin = isShowHuaWeiInfo ? LocalDisplay.dp2px(240) : LocalDisplay.dp2px(35);
                break;
            case LAST_LOGIN_WAY_IS_WX:
                params.leftMargin = LocalDisplay.dp2px(137);
                params.topMargin = 0;
                break;
            case LAST_LOGIN_WAY_IS_HW:
                if (isShowHuaWeiInfo) {
                    params.topMargin = LocalDisplay.dp2px(7);
                    params.leftMargin = LocalDisplay.dp2px(35);
                } else {
                    lastLoginWayView.setVisibility(View.GONE);
                }
                break;
            default:
                lastLoginWayView.setVisibility(View.GONE);
                break;
        }

    }

    /**
     * 事件监听初始化
     */
    private void initListeners() {
        KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                switch (v.getId()) {
                    case R.id.leftIconView:
                        doLeftIconClick();
                        break;
                    case R.id.centerIconView:
                        doCenterIconClick();
                        break;
                    case R.id.rightIconView:
                        doRightIconClick();
                        break;
                    case R.id.touristLayout:
                        clickTourist();
                        break;
                    default:
                        break;
                }
            }
        };
        leftIconView.setOnClickListener(listener);
        centerIconView.setOnClickListener(listener);
        rightIconView.setOnClickListener(listener);
        touristLayout.setOnClickListener(listener);
    }

    /**
     * 左边icon点击事件处理
     */
    private void doLeftIconClick() {
        if (isShowHuaWeiInfo) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                    StaCtrName.register_or_login_select_huawei_click, TimeUtil.currentTime()));
            doHWLogin();
        } else {
            clickPhone();
        }
    }

    /**
     * 华为登录
     */
    private void doHWLogin() {
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(mActivity, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                HWSDKUtil.clearLoginReference();
            }
        });
        HWSDKUtil.login(new HWSDKUtil.HWLoginHandler<HWLoginInfo>() {
            @Override
            public void onSuccess(final HWLoginInfo hwLoginInfo) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(mActivity);
                        PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                        prefsManager.putInt(Constants.LAST_LOGIN_WAY, InitFragment.LAST_LOGIN_WAY_IS_HW);

                        if (listener != null) {
                            listener.thirdLoginSuccess(LoginFragmentListener.TYPE_HW, hwLoginInfo.getLoginName(),
                                    hwLoginInfo.getComple() == 1, hwLoginInfo.isToast(), hwLoginInfo.isFirstLogin());
                        }
                    }
                });
            }

            @Override
            public void onFail(int errorCode, String message) {
                customDialogManager.dismissDialog(mActivity);
                String errorStr = KaDaApplication.applicationContext().getResources().getString(R.string.html_error);
                if(!TextUtils.isEmpty(message) && !message.contains(errorStr)) {
                    ToastUtils.showToast(message);
                }
            }
        });
    }

    /**
     * 中间icon点击事件处理
     */
    private void doCenterIconClick() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "register_or_login_select_wechat_click", TimeUtil.currentTime()));
        WChatManager wChatManager = (WChatManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.W_CHAT_MANAGER);
        wChatManager.setTag(getClass().getSimpleName());
        wChatManager.requestOauthCode(new WChatManager.IWXListener() {
            @Override
            public void wxUnInstall() {
                ToastUtils.showToast(R.string.uninstall_wx);
            }
        }, Constants.LOGIN_WX_TRANSACTION);
    }

    /**
     * 右边icon事件处理
     */
    private void doRightIconClick() {
        if (isShowHuaWeiInfo) {
            clickPhone();
        } else {
            clickTourist();
        }
    }

    /**
     * 点击手机
     */
    private void clickPhone() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "register_or_login_select_login_click", TimeUtil.currentTime()));
        if (listener != null) {
            listener.handleLoginButtonClicked(InitFragment.this, null);
        }
    }

    /**
     * 点击游客
     */
    private void clickTourist() {
        if (mActivity == null || getActivity() == null || getActivity().isFinishing()) {
            return;
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "register_or_login_select_visitor_click", TimeUtil.currentTime()));
        ActivityUtil.next(getActivity(), MainActivity.class);
        pm.putInt(Constants.LAST_LOGIN_WAY, LAST_LOGIN_WAY_IS_TOURIST);
        getActivity().finish();
    }

    public void onEvent(WeiXinLoginEvent event) {
        final SendAuth.Resp response = event.getResp();
        if (event.isSuccess() && response != null && TextUtils.equals(getClass().getSimpleName(), event.getTag())) {
            final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
            customDialogManager.showDialog(mActivity, new CustomProgressDialog.Listener() {
                @Override
                public void onClosed() {
                    clearWxLoginReference();
                }
            });
            if (weixinStrongReference == null) {
                weixinStrongReference = new StrongReference<>();
            }
            DefaultCallback<WeixinPayModel> weixinCallback = new DefaultCallback<WeixinPayModel>() {
                @Override
                public void onDataReceived(final WeixinPayModel data) {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            customDialogManager.dismissDialog(mActivity);
                            EventCenter.fireEvent(new CoinUpdateEvent());

                            if (data != null && listener != null) {
                                PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                                prefsManager.putInt(Constants.LAST_LOGIN_WAY, InitFragment.LAST_LOGIN_WAY_IS_WX);

                                WeixinPayModel model = data;
                                final boolean isInfoCompleted = model.getComple() == 1;
                                final boolean isToast = model.isToast();
                                listener.thirdLoginSuccess(LoginFragmentListener.TYPE_WX, model.getLoginName(), isInfoCompleted, isToast, model.isFirstLogin());
                            }
                        }
                    });
                }

                @Override
                public void onException(int code, String reason) {
                    super.onException(reason);
                    customDialogManager.dismissDialog(mActivity);
                }
            };
            weixinStrongReference.set(weixinCallback);
            ((WChatManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.W_CHAT_MANAGER)).login(response.code, KaDaApplication.DEVICE_ID, weixinStrongReference);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "register_or_login_select_view", TimeUtil.currentTime()));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        EventCenter.unregister(this);
        clearWxLoginReference();
        DialogFactory.dismissAllDialog(mActivity);
    }

    /**
     * 接口回调资源回收
     */
    private void clearWxLoginReference() {
        if (weixinStrongReference != null) {
            weixinStrongReference.clear();
            weixinStrongReference = null;
        }
    }
}
