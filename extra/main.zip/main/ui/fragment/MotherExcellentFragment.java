package com.hhdd.kada.main.ui.fragment;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.android.library.views.list.RecyclerPagedListDataAdapter;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BannerAPI;
import com.hhdd.kada.api.ExcellentAPI;
import com.hhdd.kada.api.TalentPlanAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.common.RecyclerDataListNoTitleFragment;
import com.hhdd.kada.main.event.ConnectivityChangedEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LimitFreeEndedEvent;
import com.hhdd.kada.main.event.RefreshTalentPlanSubscribeEvent;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.event.TalentPaySucceedEvent;
import com.hhdd.kada.main.event.TalentPlanTestFinishedEvent;
import com.hhdd.kada.main.event.TalentSubscribeStatusEvent;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.settings.UserSettings;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.Book2x2ViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentBannerViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentBigImage1x2ViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentBookViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentCircleViewHolderByConfig;
import com.hhdd.kada.main.viewholders.MotherExcellentPositionSubjectViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentSingleBookCollectViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentSingleStoryCollectViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentStoryViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentSubjectViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorLineViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorMiddleViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorViewHolder;
import com.hhdd.kada.main.viewholders.Story2x2ViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.main.vo.ViewTypes;
import com.hhdd.kada.module.exposure.ExposureTracker;
import com.hhdd.kada.module.exposure.MotherExcellentBannerExposureTrackEvent;
import com.hhdd.kada.module.talentplan.model.TalentPlanBookFragmentModel;
import com.hhdd.kada.module.talentplan.model.TalentPlanBookInfo;
import com.hhdd.kada.module.talentplan.viewholder.TalentPlanIsPaidViewHolder;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.logger.LogHelper;
import com.jcodecraeer.xrecyclerview.XRecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.ui.fragment
 */
public class MotherExcellentFragment extends RecyclerDataListNoTitleFragment {

    private List<BaseVO> bannerList = new ArrayList<>();
    private List<BaseVO> configList = new ArrayList<>();

    View tipView;
    ObjectAnimator animator;
    private boolean needPlayTipAinm = true;
    private static final int FIXED_HOLDER_COUNT = 1;   //页面固定的holder数目


    TalentPlanBookFragmentModel talentPlanModel;

    private static final int VIEW_TYPE_DATALIST_BANNER = 100;
    private static final int View_Type_Separator = 101;
    private static final int VIEW_TYPE_MOTHER_EXCELLENT_TALENT_PLAN_LAYOUT = 102;
    private static final int VIEW_TYPE_DATALIST_SUBJECT = ViewTypes.View_Type_Mother_Excellent_Subject.getId();
    private static final int VIEW_TYPE_DATALIST_BOOK = ViewTypes.View_Type_Mother_Excellent_Book.getId();
    private static final int VIEW_TYPE_DATALIST_STORY = ViewTypes.View_Type_Mother_Excellent_Story.getId();

    private StrongReference<DefaultCallback> talentPlanStrongReference;
    private StrongReference<DefaultCallback> configStrongReference;

    /**
     * 优才计划接口数据处理锁
     */
    private static final Boolean LOCK_TALENT_PLAN = false;

    public MotherExcellentFragment() {
        super(LIST_MODE_PULL_DOWN_TO_REFRESH, "", null);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        setBackgroundColor(KaDaApplication.instance.getResources().getColor(R.color.white));

        Map<Integer, Class<?>> map = new HashMap<>();
        map.put(VIEW_TYPE_DATALIST_BANNER, MotherExcellentBannerViewHolder.class);
        map.put(VIEW_TYPE_MOTHER_EXCELLENT_TALENT_PLAN_LAYOUT, TalentPlanIsPaidViewHolder.class);
        map.put(VIEW_TYPE_DATALIST_SUBJECT, MotherExcellentSubjectViewHolder.class);
        map.put(VIEW_TYPE_DATALIST_BOOK, MotherExcellentBookViewHolder.class);
        map.put(VIEW_TYPE_DATALIST_STORY, MotherExcellentStoryViewHolder.class);
        map.put(ViewTypes.View_Type_SeparatorLine.getId(), SeparatorLineViewHolder.class);
        map.put(View_Type_Separator, SeparatorMiddleViewHolder.class);
        map.put(ViewTypes.View_Type_Mother_Excellent_Position_Subject.getId(), MotherExcellentPositionSubjectViewHolder.class);
        map.put(ViewTypes.View_Type_Mother_Excellent_Big_Image_1x2.getId(), MotherExcellentBigImage1x2ViewHolder.class);
        map.put(ViewTypes.View_Type_Mother_Excellent_Circle_Image_layout.getId(), MotherExcellentCircleViewHolderByConfig.class);
        map.put(ViewTypes.View_Type_Mother_Excellent_Single_Book_Collect_layout.getId(), MotherExcellentSingleBookCollectViewHolder.class);
        map.put(ViewTypes.View_Type_Mother_Excellent_Single_Story_Collect_layout.getId(), MotherExcellentSingleStoryCollectViewHolder.class);
        map.put(ViewTypes.View_Type_DataList_BookCollect2X2.getId(), Book2x2ViewHolder.class);
        map.put(ViewTypes.View_Type_DataList_StoryCollect2X2.getId(), Story2x2ViewHolder.class);
        map.put(ViewTypes.View_Type_Separator.getId(), SeparatorViewHolder.class);


        BaseViewHolderCreator creator = new BaseViewHolderCreator(this, map);
        setViewHolderCreator(creator);

        loadTitleBarData();
        showLoadingView();

        if (!NetworkUtils.isReachable() && tipView.getVisibility() == View.GONE) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.network_not_connect, TimeUtil.currentTime()));
            startShowTipViewAnim();
        } else if (NetworkUtils.isReachable() && tipView.getVisibility() == View.VISIBLE) {
            startGoneTipViewAnim();
        }

        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {
            public void onEvent(TalentSubscribeStatusEvent event) {
                loadTalentPlan();
            }

            public void onEvent(TalentPaySucceedEvent event) {
                loadTalentPlan();
            }

            public void onEvent(UserSettings.TalentPlanShowPositionChangeEvent event) {
                loadTalentPlan();
            }

            public void onEvent(TalentPlanTestFinishedEvent event) {
                loadTalentPlan();
            }

            public void onEvent(RefreshTalentPlanSubscribeEvent event) {
                loadTalentPlan();
            }

            public void onEvent(UserService.UserInfoChangeEvent event) {
                doRefresh();
            }

            public void onEvent(AuthService.AuthorizedSuccessEvent event) {
                doRefresh();
            }

            public void onEvent(ConnectivityChangedEvent event) {
                if (event.isConnected) {
                    if (getmListView().getAdapter().getItemCount() == 0) {
                        doRefresh();
                    }
                    if (tipView.getVisibility() == View.VISIBLE) {
                        startGoneTipViewAnim();
                    }
                } else if (tipView.getVisibility() == View.GONE) {
                    //执行tip弹出动画
                    startShowTipViewAnim();
                }
            }

            public void onEvent(LimitFreeEndedEvent event) {
                //
                LogHelper.d("Randy", "StoryFragment接受到事件LimitFreeEndedEvent，限免结束");
                doRefresh();
            }
        }).tryToRegisterIfNot();
    }

    private boolean isDataCompleted = false;
//    private AtomicBoolean isNeedRecordExposureAfterDataCompleted = new AtomicBoolean(false);
    private boolean isNeedRecordExposureAfterDataCompleted = false;
    private final Object mRecordExposureLock = new Object();

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        //统计曝光量
        //数据是否已经加载完，没有的话做标记，有的话直接处理
        //不能马上获取数据的话，说明还在loading，要记录一下变量，在加载结束后统计。注意：好像所有界面的显示过程中都会load多次数据，所以要用变量控制
        EventBus.getDefault().post(new MotherExcellentBannerExposureTrackEvent(isVisibleToUser));
        if (isVisibleToUser) {
            //通知banner
            synchronized (mRecordExposureLock) {
                if (isDataCompleted) {
                    recordExposure();
                } else {
                    isNeedRecordExposureAfterDataCompleted = true;
                }
            }
        } else {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOUTIQUE_HOME_YOUCAI);
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOUTIQUE_HOME_LIST);
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOUTIQUE_HOME_BANNER);//banner已单独处理好
//            mPreLast = mPreFirst = -1;//重置
        }
    }

    @Override
    public void onScrollStateChange(RecyclerView view, int scrollState) {
        super.onScrollStateChange(view, scrollState);
        if (scrollState == RecyclerView.SCROLL_STATE_IDLE) {//空闲状0态
            synchronized (mRecordExposureLock) {
                if (isDataCompleted) {
                    recordExposure();
                } else {
                    isNeedRecordExposureAfterDataCompleted = true;
                }
            }
        }
    }

    @Override
    protected void handleLoadComplete(boolean hasMoreData) {
        super.handleLoadComplete(hasMoreData);
//        mPreLast = mPreFirst = -1;//重置 刷新不算重置
//        EventBus.getDefault().post(new MotherExcellentBannerExposureTrackEvent());//发现这里会比banner的onPageSelected()慢，重复了
        synchronized (mRecordExposureLock) {
            isDataCompleted = true;
            if (isNeedRecordExposureAfterDataCompleted) {
                isNeedRecordExposureAfterDataCompleted = false;
                recordExposure();
            }
        }

    }

//    private int mPreFirst = -1, mPreLast = -1;

    private void recordExposure() {
        final XRecyclerView xRecyclerView = getmListView();
        if (xRecyclerView == null) {
            return;
        }
        final LinearLayoutManager llm = (LinearLayoutManager) xRecyclerView.getLayoutManager();
        if (llm == null) {
            return;
        }
        final RecyclerPagedListDataAdapter adapter = (RecyclerPagedListDataAdapter) xRecyclerView.getAdapter();
        if (adapter == null) {
            return;
        }
        final int first = llm.findFirstVisibleItemPosition();//见下面的【注意】
        final int last = llm.findLastVisibleItemPosition();//见下面的【注意】
        if (first == RecyclerView.NO_POSITION || last == RecyclerView.NO_POSITION) {
            return;
        }
        //记录、对比上次的first和last，做差异，新展现出来的才统计。（场景：页面展示好，会统计一次，此时向下滑动，新出现一条，则只有心出现的这一条才统计曝光）
//        int newVisibleFirst, newVisibleLast;
//        if (mPreFirst == -1 || mPreLast == -1) {
//            //记录
//            newVisibleFirst = first;
//            newVisibleLast = last;
//        } else {
//            //对比
//            //1.判断向上还是向下
//            boolean up = false, down = false;
//            if (first < mPreFirst) up = true;
//            if (last > mPreLast) down = true;
//            if (up && down) {
//                //never reach 、or error state
//                //do nothing.
//                return;
//            } else if (!up && !down) {
//                //滑动太小，没有条目变化，不统计
//                //do nothing.
//                LogHelper.d(ExposureTracker.TAG, "没有新条目曝光");
//                return;
//            } else if (up) {
//                //向上滑动
//                newVisibleFirst = first;
//                newVisibleLast = Math.min(last, mPreFirst - 1);//-1是因为边界值上次统计过了，这次不能取
//                LogHelper.d(ExposureTracker.TAG, "向上滑动，first=" + first + ",last=" + last + ",mPreFist=" + mPreFirst + ",mPreLast=" + mPreLast + ",newFirst=" + newVisibleFirst + ",newLast=" + newVisibleLast);
//            } else {
//                //向下滑动
//                newVisibleFirst = Math.max(first, mPreLast + 1);//+1是因为边界值上次统计过了，这次不能取
//                newVisibleLast = last;
//                LogHelper.d(ExposureTracker.TAG, "向下滑动，first=" + first + ",last=" + last + ",mPreFist=" + mPreFirst + ",mPreLast=" + mPreLast + ",newFirst=" + newVisibleFirst + ",newLast=" + newVisibleLast);
//            }
//        }
//        mPreFirst = first;
//        mPreLast = last;

        //"精选首页内容列表"的曝光量，这个list会被逗号连接，放入一条记录的content字段
        //注意下面的循环中会出现优才，出现优才则内部处理，不加入这个voList
        List<ExposureTracker.ExposureVO> voList = new ArrayList<>();//10 is ok

//        for (int i = newVisibleFirst; i <= newVisibleLast; i++) {
        //如果优才条目不可见了，要reset comparison。因为优才特殊处理
        /*
            【注意】：顶部那个“松手刷新”，是ListView的第0个，所以findFirstVisibleItemPosition和findLastVisibleItemPosition都是正确的位置，
                    但是，当用adapter进行getItemViewType和getItem时，adapter内部的DataList第0个元素其实是和这里的第一个元素对应的。
                    即：xRecyclerView的第0个child，adapter内部的DataList无元素与之对应；
                       xRecyclerView的第1个child，adapter内部的DataList第0个元素对应；
                       xRecyclerView的第2个child，adapter内部的DataList第1个元素对应；
                       ...
                    所以要偏移一位
         */
        boolean hasYoucai = false;
//        for (int i = first; i <= last; i++) {
        for (int i = first - 1; i < last; i++) {//偏移一位
            if (i < 0) {
                continue;
            }

            final int itemViewType = adapter.getItemViewType(i);
            final Object item = adapter.getItem(i);
            LogHelper.d(ExposureTracker.TAG, "界面出现第" + i + "个: itemViewType=" + itemViewType + ",item=" + item);
            recordExposureByItemViewType(itemViewType, item, voList);
            if (itemViewType == VIEW_TYPE_MOTHER_EXCELLENT_TALENT_PLAN_LAYOUT) {
                hasYoucai = true;
            }
        }
        if (!hasYoucai) {
//            LogHelper.d(ExposureTracker.TAG, "这次屏幕上没出现优才，下次再出现时都算曝光(否则，上次出现过优才，这次又出现，就对比具体每个条目只统计差异)");
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOUTIQUE_HOME_YOUCAI);
        }

    }

    /**
     * 摘要：
     * 统计的type有：
     *  1. VIEW_TYPE_MOTHER_EXCELLENT_TALENT_PLAN_LAYOUT            -【优才展示，单独处理的】，不会将vo插入参数voList
     *  2. VIEW_TYPE_DATALIST_BANNER                                -【精选banner，单独处理】，不会将vo插入参数voList
     *  3. VIEW_TYPE_DATALIST_BOOK                                  -绘本合辑
     *  4. VIEW_TYPE_DATALIST_STORY                                 -听书合辑
     *  5. View_Type_Mother_Excellent_Big_Image_1x2                 - 一排显示两个图的。内容是跳转协议，跟banner一样解析
     *  6. View_Type_Mother_Excellent_Single_Book_Collect_layout    - 一排只显示一个大图的，绘本合辑
     *  7. View_Type_Mother_Excellent_Single_Story_Collect_layout   - 一排只显示一个大图的，听书合辑
     *  8. View_Type_DataList_BookCollect2X2
     *  9. View_Type_DataList_StoryCollect2X2
     */
    private void recordExposureByItemViewType(int type, @NonNull Object item, List<ExposureTracker.ExposureVO> voList) {

        if (type == VIEW_TYPE_MOTHER_EXCELLENT_TALENT_PLAN_LAYOUT) {
            //优才计划展示小板块， 优才单独处理，展示单独算作一条，不加入传入参数的voList中
            recordExposureForYoucai(item);
        } else if (type == VIEW_TYPE_DATALIST_BANNER) {
            //do nothing. banner已经单独处理
        } else if (type == VIEW_TYPE_DATALIST_BOOK) {
            //绘本合辑
            BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
            if (model == null) {
                LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
                return;
            }
            final List<BaseModel> itemList = model.getItemList();
            if (itemList == null) {
                return;
            }
            for (BaseModel itemModel : itemList) {
                if (itemModel instanceof BookCollectionInfo) {
                    BookCollectionInfo bci = (BookCollectionInfo) itemModel;
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    vo.type = ExposureTracker.TYPE_BOOK;
                    vo.collectionId = bci.getCollectId();
                    vo.itemId = 0;
                    voList.add(vo);
                    LogHelper.d(ExposureTracker.TAG, "viewType==" + VIEW_TYPE_DATALIST_BOOK + ": BookCollection," + bci.getName());
                } else {
                    LogHelper.e(ExposureTracker.TAG, "itemModel NOT instanceof BookCollectionInfo");
//                    throw new RuntimeException("itemModel NOT instanceof BookCollectionInfo");//开发过程中,上线去掉
                }
            }
        } else if (type == VIEW_TYPE_DATALIST_STORY) {
            //听书合辑
            BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
            if (model == null) {
                LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
                return;
            }
            final List<BaseModel> itemList = model.getItemList();
            if (itemList == null) {
                return;
            }
            for (BaseModel itemModel : itemList) {
                if (itemModel instanceof StoryCollectionInfo) {
                    StoryCollectionInfo sci = (StoryCollectionInfo) itemModel;
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    vo.type = ExposureTracker.TYPE_STORY;
                    vo.collectionId = sci.getCollectId();
                    vo.itemId = 0;
                    voList.add(vo);
                    LogHelper.d(ExposureTracker.TAG, "viewType==" + VIEW_TYPE_DATALIST_STORY + ": StoryCollectionInfo," + sci.getName());
                } else {
                    LogHelper.e(ExposureTracker.TAG, "itemModel NOT instanceof StoryCollectionInfo");
                }
            }
        }
        //暂时不统计
//        else if(type == ViewTypes.View_Type_Mother_Excellent_Position_Subject.getId()){
//            final BaseModelListVO listVO = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
//            if (listVO == null) {
//                LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
//                return;
//            }
//            final List<BaseModel> itemList = listVO.getItemList();
//            for (BaseModel itemModel : itemList) {
//
//                LogHelper.d(ExposureTracker.TAG, "viewType=="+ViewTypes.View_Type_Mother_Excellent_Position_Subject.getId()+": ," + itemModel);
//            }
//        }
        else if (type == ViewTypes.View_Type_Mother_Excellent_Big_Image_1x2.getId()) {
            //左右两个图的模块，可以跳转，和banner一样解析跳转协议
            BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
            if (model == null) {
                LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
                return;
            }
            final List<BaseModel> itemList = model.getItemList();
            if (itemList == null) {
                return;
            }
            for (BaseModel bm : itemList) {
                final RedirectInfo ri = bm instanceof RedirectInfo ? ((RedirectInfo) bm) : null;
                if (ri != null) {
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    final boolean success = ExposureTracker.getInstance().parseJumpProtocol(ri.getRedirectUri(), vo);
                    if (success) {
                        LogHelper.d(ExposureTracker.TAG, "viewType==" + 58 + ": RedirectInfo," + ri.getRedirectUri());
                        voList.add(vo);
                    }
                }
            }
        }
        //不统计，将来统计页面内部的。
//        else if(type == ViewTypes.View_Type_Mother_Excellent_Circle_Image_layout.getId()){
//            LogHelper.d(ExposureTracker.TAG, "viewType==" + ViewTypes.View_Type_Mother_Excellent_Circle_Image_layout.getId() );
//        }
        else if (type == ViewTypes.View_Type_Mother_Excellent_Single_Book_Collect_layout.getId()
                || type == ViewTypes.View_Type_Mother_Excellent_Single_Story_Collect_layout.getId()) {
            BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
            if (model == null) {
                LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
                return;
            }
            final List<BaseModel> itemList = model.getItemList();
            if (itemList != null && itemList.size() > 0) {
                final BaseModel baseModel = itemList.get(0);
                ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                final BookCollectionInfo bci = baseModel instanceof BookCollectionInfo ? ((BookCollectionInfo) baseModel) : null;
                if (bci != null) {
                    vo.type = ExposureTracker.TYPE_BOOK;
                    vo.collectionId = bci.getCollectId();
                    vo.itemId = 0;
                    voList.add(vo);
                    LogHelper.d(ExposureTracker.TAG, "viewType==" + 60 + ": BookCollectionInfo," + bci.getName());
                } else {
                    StoryCollectionInfo sci = baseModel instanceof StoryCollectionInfo ? ((StoryCollectionInfo) baseModel) : null;
                    if (sci != null) {
                        vo.type = ExposureTracker.TYPE_STORY;
                        vo.collectionId = sci.getCollectId();
                        vo.itemId = 0;
                        LogHelper.d(ExposureTracker.TAG, "viewType==" + 62 + ": StoryCollectionInfo," + sci.getName());
                    }
                }

            }
        } else if (type == ViewTypes.View_Type_DataList_BookCollect2X2.getId()) {
            BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
            if (model == null) {
                LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
                return;
            }
            final List<BaseModel> itemList = model.getItemList();
            if (itemList == null) {
                return;
            }
            for (BaseModel baseModel : itemList) {
                final BookCollectionInfo bci = baseModel instanceof BookCollectionInfo ? ((BookCollectionInfo) baseModel) : null;
                if (bci != null) {
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    vo.type = ExposureTracker.TYPE_BOOK;
                    vo.collectionId = bci.getCollectId();
                    vo.itemId = 0;
                    voList.add(vo);
                    LogHelper.d(ExposureTracker.TAG, "viewType==" + 54 + ": BookCollectionInfo," + bci.getName());
                }
            }
        } else if (type == ViewTypes.View_Type_DataList_StoryCollect2X2.getId()) {
            BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
            if (model == null) {
                LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
                return;
            }
            List<BaseModel> itemList = model.getItemList();
            if (itemList == null) {
                return;
            }
            if (itemList.size() > 4) {
                itemList = itemList.subList(0, 4);
            }
            for (BaseModel baseModel : itemList) {
                final StoryListItem sli = baseModel instanceof StoryListItem ? ((StoryListItem) baseModel) : null;
                if (sli != null) {
                    final BaseModel data = sli.getData();
                    final StoryCollectionInfo sci = data instanceof StoryCollectionInfo ? ((StoryCollectionInfo) data) : null;
                    if (sci != null) {
                        ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                        vo.type = ExposureTracker.TYPE_STORY;
                        vo.collectionId = sci.getCollectId();
                        vo.itemId = 0;
                        voList.add(vo);
                        LogHelper.d(ExposureTracker.TAG, "viewType==" + 15 + ": StoryCollectionInfo," + sci.getName());
                    }
                }
            }
        }
    }

    private void recordExposureForYoucai(@NonNull Object item) {
        List<ExposureTracker.ExposureVO> youcaiVOList = new ArrayList<>();
        final BaseModelVO baseModelVO = item instanceof BaseModelVO ? ((BaseModelVO) item) : null;
        if (baseModelVO == null) {
            return;
        }
        final BaseModel model = baseModelVO.getModel();
        final TalentPlanBookFragmentModel tpbm = model instanceof TalentPlanBookFragmentModel ? ((TalentPlanBookFragmentModel) model) : null;
        if (tpbm == null) {
            return;
        }
        LogHelper.d(ExposureTracker.TAG, "viewType==" + VIEW_TYPE_MOTHER_EXCELLENT_TALENT_PLAN_LAYOUT + ":" + tpbm);
        for (int i = 0; i < Math.min(tpbm.planBookVOList.size(),4); i++) {
            TalentPlanBookInfo info = tpbm.planBookVOList.get(i);
            if (info != null) {
                ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                vo.collectionId = info.getCollectId();
                vo.itemId = info.getBookId();
                vo.type = ExposureTracker.TYPE_BOOK;
//                LogHelper.d(ExposureTracker.TAG, "记录精选页面优才展示：collectionId=" + vo.collectionId + ",bookId=" + vo.itemId + ",bookName=" + info.getName());
                youcaiVOList.add(vo);
            }
        }
        //单独统计
        ExposureTracker.getInstance().record(ExposureTracker.SCENE_BOUTIQUE_HOME_YOUCAI, ExposureTracker.EVENT_VIEW, youcaiVOList);
    }

    @Override
    protected void lazyLoadData() {
        showLoadingView();

        doRefresh();
    }

    @Override
    protected void doRefresh() {

        loadBannerData();
        loadTalentPlan();

        if (configStrongReference == null) {
            configStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<BaseModelListVO>> configDefaultCallback = new DefaultCallback<List<BaseModelListVO>>() {

            @Override
            public void onLoadFromCache(final List<BaseModelListVO> cacheData) {
                super.onLoadFromCache(cacheData);
                if (null != cacheData) {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reassembleConfigList(cacheData);
                        }
                    });
                }
            }

            @Override
            public void onDataReceived(final List<BaseModelListVO> data) {
                if (data == null || data.isEmpty()) {
                    return;
                }

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reassembleConfigList(data);
                        handleLoadComplete(false);
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                handleErrorOccurred(true, 0, "加载失败");
            }
        };
        configStrongReference.set(configDefaultCallback);
        ExcellentAPI.getMotherExcellentConfig(configStrongReference);

    }

    /**
     * 重组配置数据
     *
     * @param responseData
     */
    private synchronized void reassembleConfigList(List<BaseModelListVO> responseData) {
        if (responseData != null && responseData.size() > 0) {
            configList.clear();
            for (BaseModelListVO modelListVO : responseData) {
                if (modelListVO.getViewType() == VIEW_TYPE_DATALIST_SUBJECT) {
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == ViewTypes.View_Type_Mother_Excellent_Position_Subject.getId()) {//可调文本位置标题栏配置
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == ViewTypes.View_Type_Mother_Excellent_Big_Image_1x2.getId()) {//2x2纯大图配置 以1x2单位进行配置
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == ViewTypes.View_Type_Mother_Excellent_Circle_Image_layout.getId()) {//可配置 功能入口
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == ViewTypes.View_Type_Mother_Excellent_Single_Book_Collect_layout.getId()) {//单排纯大图配置(绘本合集)
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == ViewTypes.View_Type_Mother_Excellent_Single_Story_Collect_layout.getId()) {//单排纯大图配置(听书合集)
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == ViewTypes.View_Type_DataList_BookCollect2X2.getId()) {//妈妈精选 - 2x2双排内容 绘本显示 注意传值时只能传两个数据 以便和听书组合成2x2的形式
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == ViewTypes.View_Type_DataList_StoryCollect2X2.getId()) {//妈妈精选 - 2x2双排内容 听书显示 注意传值时只能传两个数据 以便和绘本组合成2x2的形式
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == ViewTypes.View_Type_Separator.getId()) {//分割线
                    configList.add(modelListVO);
                } else if (modelListVO.getViewType() == VIEW_TYPE_DATALIST_BOOK
                        || modelListVO.getViewType() == VIEW_TYPE_DATALIST_STORY) {
                    if (modelListVO.getItemList() != null && modelListVO.getItemList().size() > 3) {
                        BaseModelListVO modelListVO1 = new BaseModelListVO();
                        modelListVO1.setViewType(modelListVO.getViewType());
                        for (int i = 0; i < modelListVO.getItemList().size(); i++) {
                            modelListVO1.getItemList().add(modelListVO.getItemList().get(i));
                            if (modelListVO1.getItemList().size() >= 3) {
                                configList.add(modelListVO1);
                                modelListVO1 = new BaseModelListVO();
                                modelListVO1.setViewType(modelListVO.getViewType());
                            }
                        }
                        if (modelListVO1.getItemList().size() > 0) {
                            configList.add(modelListVO1);
                        }
                    } else {
                        configList.add(modelListVO);
                    }
                    modelListVO = new BaseModelListVO();
                    modelListVO.setViewType(ViewTypes.View_Type_SeparatorLine.getId());
                    configList.add(modelListVO);
                }
            }

        }
        reLoadData();
    }

    private void loadBannerData() {
        BannerAPI.getMotherExcellentBanner(new API.CachedResponseHandler<List<BannerInfo>>() {
            @Override
            public void onFirstLoadFromCache(List<BannerInfo> cachedData) {
                updateBannerInfo(cachedData);
            }

            @Override
            public void onSuccess(List<BannerInfo> responseData) {
                updateBannerInfo(responseData);
            }

            @Override
            public void onFailure(int code, String message) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reLoadData();
                    }
                });
            }
        });
    }

    /**
     * 更新banner数据
     * @param data
     */
    private synchronized void updateBannerInfo(List<BannerInfo> data) {
        bannerList.clear();
        if (data != null && data.size() > 0) {
            BaseModelListVO modelListVO = new BaseModelListVO();
            modelListVO.setViewType(VIEW_TYPE_DATALIST_BANNER);
            modelListVO.getItemList().addAll(data);
            bannerList.add(modelListVO);
            modelListVO = new BaseModelListVO();
            modelListVO.setViewType(ViewTypes.View_Type_SeparatorLine.getId());
            bannerList.add(modelListVO);
        }
        getHandler().post(new Runnable() {
            @Override
            public void run() {
                reLoadData();
            }
        });
    }

    void loadTalentPlan() {
        if (UserSettings.getInstance().isBookFragmentShowTalentPlan()) {
            talentPlanModel = null;
            if (talentPlanStrongReference != null) {
                talentPlanStrongReference.clear();
            }
            reLoadData();
            return;
        }
        if (talentPlanStrongReference == null) {
            talentPlanStrongReference = new StrongReference<>();
        }
        DefaultCallback<TalentPlanBookFragmentModel> talentPlanCallback = new DefaultCallback<TalentPlanBookFragmentModel>() {

            @Override
            public void onLoadFromCache(TalentPlanBookFragmentModel cacheData) {
                super.onLoadFromCache(cacheData);
                synchronized (LOCK_TALENT_PLAN) {
                    if (talentPlanModel != null) {
                        talentPlanModel = null;
                    }

                    if (cacheData != null) {
                        talentPlanModel = cacheData;
                        talentPlanModel.setModelStatus(true);
                    }

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reLoadData();
                        }
                    });
                }
            }

            @Override
            public void onDataReceived(TalentPlanBookFragmentModel responseData) {
                synchronized (LOCK_TALENT_PLAN) {
                    if (talentPlanModel != null) {
                        talentPlanModel = null;
                    }

                    if (responseData != null) {
                        talentPlanModel = responseData;
                        talentPlanModel.setModelStatus(true);

                        PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                        UserDetail.UserInfo userInfo = UserService.getInstance().getUserInfo();
                        boolean isClicked = prefsManager.getBoolean(Constants.IS_BOOK_FRAGMENT_TALENT_NEW_CLICKED);
                        if (userInfo != null) {
                            //new展示判断逻辑
                            int prefsIssue = prefsManager.getInt(Constants.TALENT_PLAN_ISSUE + userInfo.getUserId(), -2);
                            boolean isSubscribed = false;
                            if (UserService.getInstance().isLogining() && userInfo.isSubscribePlan() && !TextUtils.isEmpty(talentPlanModel.planDate)) {
                                isSubscribed = true;
                            } else {
                                isSubscribed = false;
                            }
                            if (isSubscribed && prefsIssue != -1 && prefsIssue != talentPlanModel.issue) {
                                talentPlanModel.showNew = true;
                                prefsManager.putInt(Constants.TALENT_PLAN_ISSUE + userInfo.getUserId(), talentPlanModel.issue);
                                prefsManager.putBoolean(Constants.IS_BOOK_FRAGMENT_TALENT_NEW_CLICKED, false);
                            } else if (!isClicked && isSubscribed) {
                                talentPlanModel.showNew = true;
                            } else {
                                talentPlanModel.showNew = false;
                            }

                            //接口请求成功手动重置userInfo使其保持保持一致
                            userInfo.setPlanDate(talentPlanModel.planDate);
                            userInfo.setSubscribePlan(talentPlanModel.subscribePlan);

                            getHandler().post(new Runnable() {
                                @Override
                                public void run() {
                                    reLoadData();
                                }
                            });
                        }
                    }
                }
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reLoadData();
                    }
                });
            }
        };
        talentPlanStrongReference.set(talentPlanCallback);
        TalentPlanAPI.getTalentPlanBookFragmentModel(talentPlanStrongReference);
    }

    private void reLoadData() {
        List<BaseModel> modelListVOList = new ArrayList<>();

        if (bannerList != null && bannerList.size() > 0) {
            modelListVOList.addAll(bannerList);
        }

        int index = modelListVOList.size();

        int haveCircleImageLayoutCount = 0;

        if (configList != null && configList.size() > 0) {
            if (configList.get(0).getViewType() == ViewTypes.View_Type_Mother_Excellent_Circle_Image_layout.getId()) {
                haveCircleImageLayoutCount = 1;
                if (configList.size() >= 2) {
                    if (configList.get(1).getViewType() == ViewTypes.View_Type_Mother_Excellent_Circle_Image_layout.getId()) {
                        haveCircleImageLayoutCount = 2;
                    }
                }
            }
            modelListVOList.addAll(configList);
        }

        if (talentPlanModel != null) {
            talentPlanModel.typeFrom = TalentPlanIsPaidViewHolder.TYPE_MOTHER_EXCELLENT_FRAGMENT;
            BaseModelVO talentModelVO = new BaseModelVO(talentPlanModel, VIEW_TYPE_MOTHER_EXCELLENT_TALENT_PLAN_LAYOUT);
            modelListVOList.add(index + haveCircleImageLayoutCount, talentModelVO);//目的是将优才计划放在功能入口下面,注意后台配置功能入口时要配置在config列表的第一位
        }

        //无数据，就不展示,如果有优才计划缓存的话，则显示优才计划
        if (modelListVOList.size() > FIXED_HOLDER_COUNT) {
            modelListVOList.add(getBaseV0());
            reloadData(modelListVOList);
        } else {
            showLoadingView();
            handleErrorOccurred(true, 0, "加载数据为空");
        }

    }

    @Override
    public void handleErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg) {
        super.handleErrorOccurred(isFirstPage, errorCode, errorMsg);
        if (getDataListDisplayed().getDataList().size() > FIXED_HOLDER_COUNT) {
            mLoadingView.hide();
        }
        if (isFirstPage) {
            getmListView().setPullRefreshEnabled(true);
        }
    }

    /**
     * 增加一个底，处理被底部tab遮住问题
     *
     * @return
     */
    private BaseVO getBaseV0() {
        BaseVO baseVO = new BaseVO();
        baseVO.setViewType(View_Type_Separator);
        return baseVO;
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.mom_home_boutique_view, TimeUtil.currentTime()));
            if (NetworkUtils.isReachable() && tipView.getVisibility() == View.VISIBLE && needPlayTipAinm) {
                startTipAnim(tipView, 30, 0, 2000, true);
            }
        }
    }

    protected void loadTitleBarData() {
        tipView = LayoutInflater.from(getContext()).inflate(R.layout.view_holder_without_net, null, false);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LocalDisplay.dp2px(30));
        layoutParams.topMargin = LocalDisplay.dp2px(30) * -1;
        tipView.setLayoutParams(layoutParams);

        TextView btnSet = (TextView) tipView.findViewById(R.id.btn_set);
        btnSet.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.network_not_connect_click, TimeUtil.currentTime()));
                Intent intent = new Intent(android.provider.Settings.ACTION_SETTINGS);
                getContext().startActivity(intent);
            }
        });

        tipView.setVisibility(View.GONE);
        getInnerContainer().addView(tipView);
    }

    void startShowTipViewAnim() {
        if (needPlayTipAinm) {
            startTipAnim(tipView, 0, 30, 0, false);
        }
    }

    void startGoneTipViewAnim() {
        if (needPlayTipAinm) {
            startTipAnim(tipView, 30, 0, 1000, true);
        }
    }

    void startTipAnim(final View animView, int from, int scaleY, int delay, final boolean needGone) {
        animator = ObjectAnimator.ofFloat(animView, "translationY", LocalDisplay.dp2px(from), LocalDisplay.dp2px(scaleY));
        animator.setDuration(500);
        animator.setStartDelay(delay);
        animator.setRepeatCount(0);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                getmListView().setTranslationY((float) animation.getAnimatedValue());
            }
        });
        animator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                if (animView.getVisibility() == View.GONE) {
                    animView.setVisibility(View.VISIBLE);
                }
                if (needPlayTipAinm) {
                    needPlayTipAinm = false;
                }
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (needGone) {
                    animView.setVisibility(View.GONE);
                }
                if (!needPlayTipAinm) {
                    needPlayTipAinm = true;
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animator.start();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (animator != null) {
            animator.cancel();
            animator = null;
        }

        if (talentPlanStrongReference != null) {
            talentPlanStrongReference.clear();
            talentPlanStrongReference = null;
        }

        if (configStrongReference != null) {
            configStrongReference.clear();
            configStrongReference = null;
        }
    }
}
