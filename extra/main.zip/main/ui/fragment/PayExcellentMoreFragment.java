package com.hhdd.kada.main.ui.fragment;

import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.FrameLayout;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.ExcellentAPI;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.PayExcellentBookViewHolder;
import com.hhdd.kada.main.viewholders.PayExcellentMoreHeaderViewHolder;
import com.hhdd.kada.main.viewholders.PayExcellentStoryViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.ViewTypes;
import com.hhdd.logger.LogHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/1
 * @describe : com.hhdd.kada.main.ui.fragment
 */
public class PayExcellentMoreFragment extends RecyclerDataListFragment2 {

    private String module = "";
    private String path = "";
    private String params = "";
    private String title = "";

    public static final int TYPE_BOOK = 1;
    public static final int TYPE_STORY = TYPE_BOOK + 1;
    private StrongReference<DefaultCallback> configStrongReference;

    public PayExcellentMoreFragment() {
        super(LIST_MODE_PULL_DOWN_TO_REFRESH, "", null);
    }

    @Override
    public void onEnter(Object data) {
        if (data instanceof String) {
            try {
                Uri uri = Uri.parse((String) data);

                String module = uri.getQueryParameter("module");
                String path = uri.getQueryParameter("path");
                String title = uri.getQueryParameter("title");
                String params = uri.getQueryParameter("configType");
                if (module != null && module.length() > 0 && path != null && path.length() > 0 && params != null && params.length() > 0 && !TextUtils.isEmpty(title)) {
                    this.module = module;
                    this.path = path;
                    this.params = params;
                    this.title = title;
                }
//                try {
//                    this.title = URLDecoder.decode(title, "UTF-8");
//                } catch (UnsupportedEncodingException e) {
//                    e.printStackTrace();
//                }
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        useTitleBar(title);
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }

        getContext().getWindow().setBackgroundDrawable(null);
//        ImageView backImageView = new ImageView(getContext());
        int viewWidth = ScreenUtil.dip2px(getContext(), 40);
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(viewWidth, viewWidth);
        params.setMargins(ScreenUtil.dip2px(getContext(), 12), ScreenUtil.dip2px(getContext(), 9), 0, 0);
//        backImageView.setLayoutParams(params);
//        backImageView.setImageResource(R.drawable.btn_more_back);
//        backImageView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
//            @Override
//            public void OnClickWithAnim(View v) {
//                onBackPressed();
//            }
//        });
//        getInnerContainer().addView(backImageView);

        setBackgroundColor(KaDaApplication.instance.getResources().getColor(R.color.white));
        Map<Integer, Class<?>> map = new HashMap<>();
        map.put(ViewTypes.View_Type_Mother_Excellent_Book.getId(), PayExcellentBookViewHolder.class);
        map.put(ViewTypes.View_Type_Mother_Excellent_Story.getId(), PayExcellentStoryViewHolder.class);
        map.put(ViewTypes.View_Type_Mother_Excellent_Subject.getId(), PayExcellentMoreHeaderViewHolder.class);
        BaseViewHolderCreator creator = new BaseViewHolderCreator(this, map);
        setViewHolderCreator(creator);

        showLoadingView();
        doRefresh();
    }

    @Override
    protected void doRefresh() {
        if (configStrongReference == null) {
            configStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<BaseModelListVO>> defaultCallback = new DefaultCallback<List<BaseModelListVO>>() {
            @Override
            public void onDataReceived(final List<BaseModelListVO> data) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reassembleConfigList(data);
                        handleLoadComplete(false);
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                handleErrorOccurred(true, 0, "加载失败");
            }
        };
        configStrongReference.set(defaultCallback);
        ExcellentAPI.getPayExcellentMoreData(params, configStrongReference);
    }

    private void reassembleConfigList(List<BaseModelListVO> responseData) {
        if (responseData != null && responseData.size() > 0) {
            List<BaseModel> modelList = new ArrayList<>();
            for (BaseModelListVO modelListVO : responseData) {
                if (modelListVO.getItemList() != null && modelListVO.getItemList().size() > 0) {
                    if (modelListVO.getViewType() == ViewTypes.View_Type_Mother_Excellent_Subject.getId()) {
                        modelList.add(modelListVO);
                    } else {
                        for (BaseModel model : modelListVO.getItemList()) {
                            BaseModelListVO modelListVO1 = new BaseModelListVO();
                            modelListVO1.setViewType(modelListVO.getViewType());
                            modelListVO1.getItemList().add(model);
                            modelList.add(modelListVO1);
                        }
                    }
                }
            }
            reloadData(modelList);
        }
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "recommended_purchase_view", TimeUtil.currentTime()));
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (configStrongReference != null) {
            configStrongReference.clear();
            configStrongReference = null;
        }
    }
}
