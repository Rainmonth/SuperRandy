//package com.hhdd.kada.main.ui.search;
//
//import android.app.Activity;
//import android.os.Bundle;
//
//import com.hhdd.android.ref.StrongReference;
//import com.hhdd.core.service.DefaultCallback;
//import com.hhdd.core.service.UserHabitService;
//import com.hhdd.kada.Constants;
//import com.hhdd.kada.R;
//import com.hhdd.kada.api.SearchAPI;
//import com.hhdd.kada.main.common.DataListFragment2;
//import com.hhdd.kada.main.common.FragmentUtil;
//import com.hhdd.kada.main.listen.ListenActivity;
//import com.hhdd.kada.main.model.BaseModel;
//import com.hhdd.kada.main.model.SearchBookResultInfo;
//import com.hhdd.kada.main.model.SearchStoryResultInfo;
//import com.hhdd.kada.main.model.StoryInfo;
//import com.hhdd.kada.main.playback.PlaybackActivity;
//import com.hhdd.kada.main.ui.activity.SearchActivity;
//import com.hhdd.kada.main.ui.book.BookCollectionFragment;
//import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
//import com.hhdd.kada.main.utils.TimeUtil;
//import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
//import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
//import com.hhdd.kada.main.vo.BaseModelVO;
//import com.hhdd.kada.main.vo.BaseVO;
//import com.hhdd.logger.LogHelper;
//
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
///**
// * Created by lj on 17/2/28.
// */
//
//public class SearchResultFragment extends DataListFragment2 {
//
//    static final int View_Type_Item_Title = 1;
//    static final int View_Type_Item_Search_Book = 100;
//    static final int View_Type_Item_Search_Story = 200;
//    static final int View_Type_Item_Search_Not_Found = 300;
//    BaseViewHolderCreator viewHolderCreator;
//
//    String keywords;
//    int type;
//
//    List<SearchBookResultInfo> bookListItems;
//    List<SearchStoryResultInfo> storyListItems;
//
//    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
//        @Override
//        public boolean process(int type, Object... args) {
//            switch (type) {
//                case SearchBookViewHolder.TYPE_SEARCH_BOOK_ITEM_CLICKED:
//                    try {
//                        SearchBookResultInfo info = (SearchBookResultInfo) args[0];
//                        processBookItemClicked(info);
//                    } catch (Throwable e) {
//                        LogHelper.printStackTrace(e);
//                    }
//                    return true;
//
//                case SearchStoryViewHolder.TYPE_SEARCH_STORY_ITEM_CLICKED:
//                    try {
//                        processStoryItemClicked(args[0]);
//                    } catch (Throwable e) {
//                        LogHelper.printStackTrace(e);
//                    }
//                    return true;
//            }
//            return false;
//        }
//    };
//    private StrongReference<DefaultCallback> bookStrongReference;
//    private StrongReference<DefaultCallback> storyStrongReference;
//
//    public SearchResultFragment() {
//        super(LIST_MODE_NONE, "", null);
//    }
//
//    @Override
//    protected void onCreateView(Bundle savedInstanceState) {
//        super.onCreateView(savedInstanceState);
//        initView();
//        loadData();
//    }
//
//    void initView() {
//        type = (int) getArguments().get("type");
//        keywords = (String) getArguments().get("keyword");
//
//        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
//        viewTypeMaps.put(View_Type_Item_Title, TitleViewHolder.class);
//        viewTypeMaps.put(View_Type_Item_Search_Book, SearchBookViewHolder.class);
//        viewTypeMaps.put(View_Type_Item_Search_Story, SearchStoryViewHolder.class);
//        viewTypeMaps.put(View_Type_Item_Search_Not_Found, SearchNotFoundViewHolder.class);
//
//        viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
//        viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
//        setViewHolderCreator(viewHolderCreator);
//
//        setBackgroundDrawable(getResources().getDrawable(R.drawable.bg_mother_header));
//    }
//
//    void loadData() {
//        switch (type) {
//            case SearchActivity.SEARCH_ALL:
//                searchBook();
//                searchStory();
//                break;
//            case SearchActivity.SEARCH_FROM_BOOK:
//                searchBook();
//                break;
//            case SearchActivity.SEARCH_FROM_STORY:
//                searchStory();
//                break;
//        }
//    }
//
//    void searchBook() {
//        if (bookStrongReference == null) {
//            bookStrongReference = new StrongReference<>();
//        }
//
//        DefaultCallback bookCallback = new DefaultCallback<List<SearchBookResultInfo>>() {
//            @Override
//            public void onDataReceived(List<SearchBookResultInfo> data) {
//                bookListItems = data;
//                getHandler().post(new Runnable() {
//                    @Override
//                    public void run() {
//                        reloadDataImpl();
//                    }
//                });
//            }
//
//            @Override
//            public void onException(int code, String reason) {
//                super.onException(code, reason);
//                handleErrorOccurred(true, code, reason);
//            }
//        };
//
//        bookStrongReference.set(bookCallback);
//        SearchAPI.bookAPI_search(keywords, 0, 30, 1, bookStrongReference);
//    }
//
//    void searchStory() {
//        if (storyStrongReference == null) {
//            storyStrongReference = new StrongReference<>();
//        }
//        DefaultCallback<List<SearchStoryResultInfo>> storyCallback = new DefaultCallback<List<SearchStoryResultInfo>>() {
//            @Override
//            public void onDataReceived(List<SearchStoryResultInfo> data) {
//                storyListItems = data;
//                getHandler().post(new Runnable() {
//                    @Override
//                    public void run() {
//                        reloadDataImpl();
//                    }
//                });
//            }
//
//            @Override
//            public void onException(int code, String reason) {
//                super.onException(reason);
//                handleErrorOccurred(true, code, reason);
//            }
//        };
//        storyStrongReference.set(storyCallback);
//        SearchAPI.storyAPI_search(keywords, 0, 30, 1, storyStrongReference);
//    }
//
//    @Override
//    protected void doRefresh() {
//        super.doRefresh();
//        loadData();
//    }
//
//    void reloadDataImpl() {
//        final List<BaseModel> list = new ArrayList<>();
//        if (bookListItems != null && bookListItems.size() > 0) {
//            int bookListSize = bookListItems.size();
//            TitleViewHolder.TitleVO titleVO = new TitleViewHolder.TitleVO(Constants.TYPE_BOOK);
//            titleVO.setViewType(View_Type_Item_Title);
//            list.add(titleVO);
//
//            for (int i = 0; i < bookListSize; i++) {
//                SearchVO baseModelVO = new SearchVO();
//                baseModelVO.setModel(bookListItems.get(i));
//                baseModelVO.setViewType(View_Type_Item_Search_Book);
//                list.add(baseModelVO);
//            }
//
//        } else if (storyListItems != null && storyListItems.size() > 0) {
//            int storyListSize = storyListItems.size();
//            TitleViewHolder.TitleVO titleVO = new TitleViewHolder.TitleVO(Constants.TYPE_STORY);
//            titleVO.setViewType(View_Type_Item_Title);
//            list.add(titleVO);
//
//            for (int i = 0; i < storyListSize; i++) {
//                SearchVO baseModelVO = new SearchVO();
//                baseModelVO.setModel(storyListItems.get(i));
//                baseModelVO.setViewType(View_Type_Item_Search_Story);
//                list.add(baseModelVO);
//            }
//        }  else {
//            BaseVO vo = new BaseVO();
//            vo.setViewType(View_Type_Item_Search_Not_Found);
//            list.add(vo);
//        }
//        reloadData(list);
//    }
//
//    private void processStoryItemClicked(Object o) {
//        Activity activity = getActivity();
//        if (activity == null || activity.isFinishing()) {
//            return;
//        }
//
//        if (o == null) {
//            return;
//        }
//
//        String type = "";
//        int id = 0;
//        if (o instanceof StoryInfo) {
//            StoryInfo info = (StoryInfo) o;
//            type = "1,";
//            id = info.getStoryId();
//            ListenActivity.startActivity(getContext(), info.getStoryId());
//        } else if (o instanceof SearchStoryResultInfo) {
//            SearchStoryResultInfo info = (SearchStoryResultInfo) o;
//            if (info.getCategory() == 1) {
//                type = "1,";
//                id = info.getSourceId();
//                ListenActivity.startActivity(getContext(), info.getSourceId());
//            } else {
//                type = "2,";
//                id = info.getSourceId();
//                FragmentUtil.presentFragment(StoryCollectionFragment.class, info.getSourceId(), true);
//            }
//        }
//
//        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(type + id + "," + keywords, "search_result_story_list_click", TimeUtil.currentTime()));
//    }
//
//    private void processBookItemClicked(SearchBookResultInfo info) {
//        Activity activity = getContext();
//        if (activity == null || activity.isFinishing()) {
//            return;
//        }
//
//        if (info.getCategory() == 1) {
//            PlaybackActivity.startActivity(activity, info.getSourceId());
//        } else {
//            FragmentUtil.pushFragment(BookCollectionFragment.class, info.getSourceId(), true);
//        }
//        String type = info.getCategory() == 1 ? "1," : "2,";
//        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(type + info.getSourceId() + "," + keywords, "search_result_book_list_click", TimeUtil.currentTime()));
//    }
//
//    @Override
//    public void onDestroyView() {
//        if (bookStrongReference != null) {
//            bookStrongReference.clear();
//            bookStrongReference = null;
//        }
//        if (storyStrongReference != null) {
//            storyStrongReference.clear();
//            storyStrongReference = null;
//        }
//        super.onDestroyView();
//    }
//
//
//    public class SearchVO extends BaseModelVO implements Serializable {
//        private int itemType;
//
//        public int getItemType() {
//            return itemType;
//        }
//
//        public void setItemType(int itemType) {
//            this.itemType = itemType;
//        }
//    }
//
//    @Override
//    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
//        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
//        if (isVisibleToUser) {
//            String track = "";
//            switch (type) {
//                case SearchActivity.SEARCH_FROM_BOOK:
//                    track = "search_result_book_view";
//                    break;
//                case SearchActivity.SEARCH_FROM_STORY:
//                    track = "search_result_story_view";
//                    break;
//            }
//            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", track, TimeUtil.currentTime()));
//        }
//    }
//}
