//package com.hhdd.kada.main.ui.search;
//
//
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.support.v4.app.Fragment;
//import android.support.v4.app.FragmentManager;
//import android.support.v4.app.FragmentPagerAdapter;
//import android.support.v4.view.ViewPager;
//import android.text.TextUtils;
//import android.view.MotionEvent;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.EditText;
//import android.widget.ImageView;
//
//import com.hhdd.core.service.UserHabitService;
//import com.hhdd.kada.R;
//import com.hhdd.kada.android.library.utils.LocalDisplay;
//import com.hhdd.kada.base.BaseFragmentActivity;
//import com.hhdd.kada.main.ui.activity.SearchActivity;
//import com.hhdd.kada.main.utils.TimeUtil;
//import com.hhdd.kada.main.views.magicindicator.ScaleTransitionPagerTitleView;
//
//import net.lucode.hackware.magicindicator.MagicIndicator;
//import net.lucode.hackware.magicindicator.ViewPagerHelper;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import butterknife.BindView;
//import butterknife.OnClick;
//
///**
// * Created by sxh on 2017/7/25.
// */
//
//public class SearchResultActivity extends BaseFragmentActivity {
//    @BindView(R.id.back)
//    ImageView back;
//    @BindView(R.id.search_text)
//    EditText searchText;
//    @BindView(R.id.explore_titlebar_search_icon)
//    ImageView exploreTitlebarSearchIcon;
//    @BindView(R.id.clear_text)
//    ImageView clearText;
//    @BindView(R.id.vp_search)
//    ViewPager vpSearch;
//    @BindView(R.id.indicator_search)
//    MagicIndicator indicatorSearch;
//    @BindView(R.id.statusView)
//    View statusView;
//
//    private int mSearchType;
//    private String mSearchText;
//    private List<Fragment> mFragmentList = new ArrayList<>();
//
//    private SearchResultFragment bookResultFg;
//    private SearchResultFragment storyResultFg;
//
//    public static void startActivity(Context context, int type, String searchText) {
//        if (context == null) {
//            return;
//        }
//
//        Intent intent = new Intent(context, SearchResultActivity.class);
//        intent.putExtra(SearchActivity.SEARCH_TYPR, type);
//        intent.putExtra("searchText", searchText);
//        context.startActivity(intent);
//    }
//
//
//    @OnClick(R.id.back)
//    public void back() {
//        hideKeyBoard();
//        finish();
//    }
//
//    @Override
//    public int getLayoutId() {
//        return R.layout.layout_search_result_activity;
//    }
//
//    @Override
//    protected int getFragmentContainerId() {
//        return 0;
//    }
//
//    @Override
//    public void doInitView() {
//        this.mSearchType = getIntent().getIntExtra(SearchActivity.SEARCH_TYPR, SearchActivity.SEARCH_FROM_BOOK);
//        this.mSearchText = getIntent().getStringExtra("searchText");
//
//        bookResultFg = new SearchResultFragment();
//        Bundle bundle1 = new Bundle();
//        bundle1.putInt("type", SearchActivity.SEARCH_FROM_BOOK);
//        bundle1.putString("keyword", mSearchText);
//        bookResultFg.setArguments(bundle1);
//
//        storyResultFg = new SearchResultFragment();
//        Bundle bundle2 = new Bundle();
//        bundle2.putInt("type", SearchActivity.SEARCH_FROM_STORY);
//        bundle2.putString("keyword", mSearchText);
//        storyResultFg.setArguments(bundle2);
//
//        mFragmentList.add(bookResultFg);
//        mFragmentList.add(storyResultFg);
//
//        initMagicIndicator();
//
//        vpSearch.setOffscreenPageLimit(mFragmentList.size() - 1);
//        vpSearch.setAdapter(new FragmentAdapter(getSupportFragmentManager(), mFragmentList));
//
//        ViewGroup.LayoutParams statusViewLayoutParams = statusView.getLayoutParams();
//        if (statusViewLayoutParams == null) {
//            statusViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        }
//        statusViewLayoutParams.height = LocalDisplay.SCREEN_STATUS_HEIGHT;
//        statusView.setLayoutParams(statusViewLayoutParams);
//    }
//
//    private void initMagicIndicator() {
//        indicatorSearch.setBackgroundColor(getResources().getColor(R.color.mother_header_color_3));
//        CommonNavigator commonNavigator = new CommonNavigator(this);
//        commonNavigator.setAdjustMode(true);
//        commonNavigator.setAdapter(new CommonNavigatorAdapter() {
//            @Override
//            public int getCount() {
//                return SearchActivity.titleList == null ? 0 : SearchActivity.titleList.size();
//            }
//
//            @Override
//            public IPagerTitleView getTitleView(Context context, final int index) {
//                SimplePagerTitleView simplePagerTitleView = new ScaleTransitionPagerTitleView(context);
//                simplePagerTitleView.setText(SearchActivity.titleList.get(index));
//                simplePagerTitleView.setTextSize(16);
//                simplePagerTitleView.setNormalColor(getResources().getColor(R.color.white));
//                simplePagerTitleView.setSelectedColor(getResources().getColor(R.color.white));
//                simplePagerTitleView.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        vpSearch.setCurrentItem(index);
//                    }
//                });
//                return simplePagerTitleView;
//            }
//
//            @Override
//            public IPagerIndicator getIndicator(Context context) {
//                LinePagerIndicator indicator = new LinePagerIndicator(context);
//                indicator.setColors(getResources().getColor(R.color.white));
//                indicator.setLineWidth(LocalDisplay.dp2px(100));
//                return indicator;
//            }
//        });
//        indicatorSearch.setNavigator(commonNavigator);
//        ViewPagerHelper.bind(indicatorSearch, vpSearch);
//    }
//
//    @Override
//    public void doInitData() {
//        searchText.setFocusable(false);
//        switch (mSearchType) {
//            case SearchActivity.SEARCH_FROM_BOOK:
//                vpSearch.setCurrentItem(0);
//                break;
//            case SearchActivity.SEARCH_FROM_STORY:
//                vpSearch.setCurrentItem(1);
//                break;
//        }
//        searchText.setText(mSearchText);
//
//    }
//
//    @Override
//    public void doInitListener() {
//        vpSearch.addOnPageChangeListener(pageChangeListener);
//
//        searchText.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                finish();
//                return true;
//            }
//        });
//
//    }
//
//    private ViewPager.OnPageChangeListener pageChangeListener = new ViewPager.OnPageChangeListener() {
//        @Override
//        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//        }
//
//        @Override
//        public void onPageSelected(int position) {
//            String track = "";
//            switch (position) {
//                case 0:
//                    track = "search_result_book_tab_click";
//                    mSearchType = SearchActivity.SEARCH_FROM_BOOK;
//                    break;
//                case 1:
//                    track = "search_result_story_tab_click";
//                    mSearchType = SearchActivity.SEARCH_FROM_STORY;
//                    break;
//            }
//            if (!TextUtils.isEmpty(track)) {
//                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", track, TimeUtil.currentTime()));
//            }
//        }
//
//        @Override
//        public void onPageScrollStateChanged(int state) {
//
//        }
//    };
//
//    @Override
//    protected void onDestroy() {
//        if (pageChangeListener != null && vpSearch != null) {
//            vpSearch.removeOnPageChangeListener(pageChangeListener);
//        }
//        super.onDestroy();
//    }
//
//    public static class FragmentAdapter extends FragmentPagerAdapter {
//
//        private List<Fragment> fragmentList;
//
//        public FragmentAdapter(FragmentManager fm, List<Fragment> fragmentList) {
//            super(fm);
//            this.fragmentList = fragmentList;
//        }
//
//        @Override
//        public Fragment getItem(int position) {
//            return fragmentList.get(position);
//        }
//
//        @Override
//        public int getCount() {
//            return fragmentList.size();
//        }
//    }
//}
