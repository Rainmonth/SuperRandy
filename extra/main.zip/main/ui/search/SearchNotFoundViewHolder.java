//package com.hhdd.kada.main.ui.search;
//
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import com.hhdd.kada.R;
//import com.hhdd.kada.main.utils.FrescoUtils;
//import com.hhdd.kada.main.viewholders.BaseViewHolder;
//import com.hhdd.kada.main.views.ScaleDraweeView;
//
///**
// * Created by lj on 17/3/1.
// */
//
//public class SearchNotFoundViewHolder extends BaseViewHolder {
//    @Override
//    public View createView(ViewGroup parent) {
//        View view = View.inflate(parent.getContext(), R.layout.search_not_found_layout, null);
//        TextView notFoundText = (TextView) view.findViewById(R.id.text_not_found);
//        ScaleDraweeView notFoundGif = (ScaleDraweeView) view.findViewById(R.id.error_icon);
//        notFoundGif.setVisibility(View.VISIBLE);
//
//        FrescoUtils.showGif("res://"+parent.getContext().getPackageName()+"/" + R.raw.searchcrab,notFoundGif);
//        notFoundText.setText("未搜索到相关的内容\n看看大家都在搜什么吧");
//
//        return view;
//    }
//
//    @Override
//    public void showData(int position, Object itemData) {
//
//    }
//}
