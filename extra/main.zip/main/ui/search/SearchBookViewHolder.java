//package com.hhdd.kada.main.ui.search;
//
//import android.content.Context;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.FrameLayout;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//
//import com.hhdd.kada.KaDaApplication;
//import com.hhdd.kada.R;
//import com.hhdd.kada.main.model.BookCollectionInfo;
//import com.hhdd.kada.main.model.BookInfo;
//import com.hhdd.kada.main.model.SearchBookResultInfo;
//import com.hhdd.kada.main.ui.book.BookItemView;
//import com.hhdd.kada.main.viewholders.BaseViewHolder;
//
//import butterknife.BindView;
//
//
///**
// * Created by lj on 17/2/28.
// */
//
//public class SearchBookViewHolder extends BaseViewHolder<SearchResultFragment.SearchVO> implements View.OnClickListener {
//
//    public static final int TYPE_SEARCH_BOOK_ITEM_CLICKED = 2100;
//
//    int mItemHeight;
//    int mItemWidth;
//
//    @BindView(R.id.cover_container)
//    FrameLayout coverContainer;
//    @BindView(R.id.text_book_name)
//    TextView textBookName;
//    @BindView(R.id.text_author)
//    TextView textAuthor;
//    @BindView(R.id.text_age)
//    TextView textAge;
//    @BindView(R.id.container)
//    RelativeLayout container;
//    @BindView(R.id.cover)
//    BookItemView cover;
//    private Context context;
//
//    public SearchBookViewHolder() {
//        mItemWidth = KaDaApplication.getInstance().getResources().getDimensionPixelOffset(R.dimen.search_cover_size);
//        mItemHeight = (int) (mItemWidth * 32f / 25f);
//    }
//
//    @Override
//    protected int getLayoutId() {
//        return R.layout.view_holder_search_book_result;
//    }
//
//    @Override
//    public View createView(ViewGroup parent) {
//        context = parent.getContext();
//        cover.setViewSize(mItemWidth);
//        return rootView;
//    }
//
//    @Override
//    public void showData(int position, SearchResultFragment.SearchVO itemData) {
//        if (itemData.getModel() != null && itemData.getModel() instanceof SearchBookResultInfo) {
//            final SearchBookResultInfo info = (SearchBookResultInfo) itemData.getModel();
//            if (info.getCategory() == 1) {
//                cover.update(BookInfo.createBySearchBookResultInfo(info), false);
//            } else {
//                cover.update(BookCollectionInfo.createBySearchBookResultInfo(info), false);
//            }
//            textBookName.setText(info.getName());
//            textAuthor.setText(info.getAuthor());
//            textAge.setText("适应年龄：" + info.getMinAge() + "-" + info.getMaxAge() + "岁");
//            container.setTag(R.id.container, info);
//            container.setOnClickListener(this);
//        }
//    }
//
//
//    @Override
//    public void onClick(View v) {
//        if (mOnEventProcessor == null) {
//            return;
//        }
//
//        SearchBookResultInfo info = (SearchBookResultInfo) v.getTag(R.id.container);
//        mOnEventProcessor.process(TYPE_SEARCH_BOOK_ITEM_CLICKED, info);
//    }
//}