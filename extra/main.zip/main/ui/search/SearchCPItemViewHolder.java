//package com.hhdd.kada.main.ui.search;
//
//import android.content.Context;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import com.hhdd.kada.CdnUtils;
//import com.hhdd.kada.KaDaApplication;
//import com.hhdd.kada.R;
//import com.hhdd.kada.android.library.utils.LocalDisplay;
//import com.hhdd.kada.main.model.OrganizationInfo;
//import com.hhdd.kada.main.utils.FrescoUtils;
//import com.hhdd.kada.main.utils.ScreenUtil;
//import com.hhdd.kada.main.viewholders.BaseViewHolder;
//import com.hhdd.kada.main.views.ScaleDraweeView;
//import com.hhdd.kada.main.vo.BaseModelVO;
//
///**
// * Created by lj on 17/3/30.
// */
//
//public class SearchCPItemViewHolder extends BaseViewHolder<BaseModelVO> {
//
//    public static final int TYPE_CP_ITEM_CLICKED = 2000;
//
//
//    int mItemSize;
//    ScaleDraweeView cover;
//    TextView name;
//
//    public SearchCPItemViewHolder() {
//
////        int viewMarginLeft = (int) KaDaApplication.getInstance().getResources().getDimension(
////                R.dimen.grid_view_item_padding_left);
////        int viewMarginRight = (int) KaDaApplication.getInstance().getResources().getDimension(
////                R.dimen.grid_view_item_padding_right);
//
//        int itemSpacing = LocalDisplay.dp2px(4);
//
//        int screenWidth = ScreenUtil.getScreenSize(KaDaApplication.getInstance()).x < ScreenUtil.getScreenSize(KaDaApplication.getInstance()).y
//                ? ScreenUtil.getScreenSize(KaDaApplication.getInstance()).x : ScreenUtil.getScreenSize(KaDaApplication.getInstance()).y;
//        mItemSize = (int) ((screenWidth - 8 * itemSpacing) / 5);
//    }
//
//    @Override
//    public View createView(ViewGroup parent) {
//        final Context mContext = parent.getContext();
//        View view = View.inflate(mContext, R.layout.view_holder_cp_item, null);
//
//        cover = (ScaleDraweeView) view.findViewById(R.id.item);
//        name = (TextView) view.findViewById(R.id.cp_name);
//        cover.getLayoutParams().width = mItemSize;
//        cover.getLayoutParams().height = mItemSize;
//
//        cover.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
//            @Override
//            public void OnClickWithAnim(View v) {
//                if (mOnEventProcessor == null) {
//                    return;
//                }
//
//                Object position = v.getTag(R.id.position);
//                Object info = v.getTag(R.id.info);
//                mOnEventProcessor.process(TYPE_CP_ITEM_CLICKED, position, info);
//            }
//        });
//        return view;
//    }
//
//    @Override
//    public void showData(int position, BaseModelVO itemData) {
//        if (itemData != null && itemData.getModel() != null && itemData.getModel() instanceof OrganizationInfo) {
////            FrescoUtils.showUrl(((OrganizationInfo) itemData.getModel()).getIconUrl(), cover, mItemSize, mItemSize);
//
//            String iconUrl = CdnUtils.getImgCdnUrl(((OrganizationInfo) itemData.getModel()).getIconUrl(), true);
//            FrescoUtils.showImg(cover, iconUrl, mItemSize, mItemSize);
//
//            name.setText(((OrganizationInfo) itemData.getModel()).getOrgName());
//            cover.setTag(R.id.info, itemData.getModel());
//            cover.setTag(R.id.position, position);
//        } else {
//            cover.setTag(R.id.position, position);
//            cover.setImageResource(R.drawable.btn_more_normal);
//            name.setVisibility(View.GONE);
//        }
//    }
//}