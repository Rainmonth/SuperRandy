package com.hhdd.kada.main.ui.search;

import com.hhdd.kada.Dirs;
import com.hhdd.kada.module.search.SearchBaseFragment;

import java.io.File;

/**
 * Created by sxh on 2017/7/25.
 */

public class SearchDirs {
    //热门搜索文件路径
    public static String popKeywordsPath(int type) {
        String popularFile = "";
        switch (type) {
//            case SearchBaseFragment.SEARCH_ALL:
//                popularFile = Dirs.getSearchCachePath() + File.separator + "all_keyword.dat";
//                break;
            case SearchBaseFragment.SEARCH_FROM_BOOK:
            case SearchBaseFragment.SEARCH_FROM_EXCELLENT:
                popularFile = Dirs.getSearchCachePath() + File.separator + "book_keyword.dat";
                break;
            case SearchBaseFragment.SEARCH_FROM_STORY:
                popularFile = Dirs.getSearchCachePath() + File.separator + "story_keyword.dat";
                break;
        }
        return popularFile;
    }

    //历史搜索文件路径
    public static String searchHistoryFilePath(int type) {
        String historyFile = "";
        switch (type) {
//            case SearchBaseFragment.SEARCH_ALL:
//                historyFile = Dirs.getSearchCachePath() + File.separator + "all_history.dat";
//                break;
            case SearchBaseFragment.SEARCH_FROM_BOOK:
            case SearchBaseFragment.SEARCH_FROM_EXCELLENT:
                historyFile = Dirs.getSearchCachePath() + File.separator + "book_history.dat";
                break;
            case SearchBaseFragment.SEARCH_FROM_STORY:
                historyFile = Dirs.getSearchCachePath() + File.separator + "story_history.dat";
                break;
        }
        return historyFile;
    }

    public static String searchHistoryFilePath() {
        return Dirs.getSearchCachePath() + File.separator + "search_history.dat";
    }

}
