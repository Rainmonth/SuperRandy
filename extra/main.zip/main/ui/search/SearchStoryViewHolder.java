//package com.hhdd.kada.main.ui.search;
//
//import android.content.Context;
//import android.graphics.Color;
//import android.text.TextUtils;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import com.hhdd.kada.KaDaApplication;
//import com.hhdd.kada.R;
//import com.hhdd.kada.android.library.utils.LocalDisplay;
//import com.hhdd.kada.main.model.SearchStoryResultInfo;
//import com.hhdd.kada.main.utils.FrescoUtils;
//import com.hhdd.kada.main.viewholders.BaseViewHolder;
//import com.hhdd.kada.main.views.ScaleDraweeView;
//
///**
// * Created by lj on 17/2/28.
// */
//
//public class SearchStoryViewHolder extends BaseViewHolder<SearchResultFragment.SearchVO> implements View.OnClickListener {
//
//    public static final int TYPE_SEARCH_STORY_ITEM_CLICKED = 2200;
//
//    View view;
//    View container;
//    ScaleDraweeView cover;
//    TextView bookName, bookAuthor, bookAge;
//    private Context mContext;
//
//
//    @Override
//    public View createView(ViewGroup parent) {
//        mContext = parent.getContext();
//        view = LayoutInflater.from(mContext).inflate(R.layout.fragment_search_story_result, null);
//        cover = (ScaleDraweeView) view.findViewById(R.id.cover);
//        bookName = (TextView) view.findViewById(R.id.text_book_name);
//        bookAuthor = (TextView) view.findViewById(R.id.text_author);
//        bookAge = (TextView) view.findViewById(R.id.text_age);
//        container = view.findViewById(R.id.container);
//
//        //解决LISTVIEW ITEM长按事件收不到问题
//        view.setOnLongClickListener(new View.OnLongClickListener() {
//            @Override
//            public boolean onLongClick(View v) {
//                return false;
//            }
//        });
//        view.setOnClickListener(this);
//        return view;
//    }
//
//    @Override
//    public void showData(int position, SearchResultFragment.SearchVO itemData) {
//        if (itemData.getModel() != null && itemData.getModel() instanceof SearchStoryResultInfo) {
//            final SearchStoryResultInfo searchInfo = (SearchStoryResultInfo) itemData.getModel();
//            bookName.setText(searchInfo.getName());
//            if (searchInfo.getCategory() == 2) {
//                cover.setBackgroundResource(R.drawable.story_album_bg);
//                cover.setPadding(0, KaDaApplication.getInstance().getResources().getDimensionPixelSize(R.dimen.search_view_padding_top), KaDaApplication.getInstance().getResources().getDimensionPixelSize(R.dimen.search_view_padding), 0);
//            } else {
//                cover.setBackgroundColor(Color.TRANSPARENT);
//                cover.setPadding(0, 0, 0, 0);
//            }
//            String coverUrl = searchInfo.getCoverUrl();
//            boolean needResetImageUrl = true;
//            if (cover.getTag(R.id.book_list_item_image_url) != null) {
//                String url = (String) cover.getTag(R.id.book_list_item_image_url);
//                if (TextUtils.equals(url, coverUrl)) {
//                    needResetImageUrl = false;
//                }
//            }
//            if (needResetImageUrl) {
//                cover.setTag(R.id.book_list_item_image_url, coverUrl);
//                FrescoUtils.showUrl(coverUrl, cover, LocalDisplay.dp2px(100), LocalDisplay.dp2px(100));
//            }
//            if (searchInfo.getAuthor() != null && searchInfo.getAuthor().trim().length() > 0) {
//                bookAuthor.setText(searchInfo.getAuthor());
//            } else {
//                bookAuthor.setText("");
//            }
//            if (searchInfo.getMaxAge() != 0) {
//                bookAge.setText("适读年龄：" + searchInfo.getMinAge() + "-" + searchInfo.getMaxAge() + "岁");
//            } else {
//                bookAge.setText("");
//            }
//            container.setTag(R.id.view_holder_item, searchInfo);
//        }
//    }
//
//
//    @Override
//    public void onClick(View v) {
//        if (mOnEventProcessor == null) {
//            return;
//        }
//
//        Object o = container.getTag(R.id.view_holder_item);
//        mOnEventProcessor.process(TYPE_SEARCH_STORY_ITEM_CLICKED, o);
//    }
//}