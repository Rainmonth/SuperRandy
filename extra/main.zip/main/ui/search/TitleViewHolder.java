package com.hhdd.kada.main.ui.search;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;



/**
 * Created by lj on 17/2/28.
 */

public class TitleViewHolder extends BaseViewHolder<TitleViewHolder.TitleVO> {

    TextView textView;

    @Override
    public View createView(ViewGroup parent) {
        View view = View.inflate(parent.getContext(), R.layout.search_title_bar_layout, null);
        textView = (TextView) view.findViewById(R.id.title);
        return view;
    }

    @Override
    public void showData(int position, TitleVO itemData) {
        if(itemData != null && textView != null){
            if(itemData.getType() == Constants.TYPE_BOOK){
                textView.setText("您可能要找的绘本");
            }else if (itemData.getType() == Constants.TYPE_STORY){
                textView.setText("您可能要找的听书");
            }else if (itemData.getType() == Constants.TYPE_STORE){
                textView.setText("您可能要找的商品");
            }
        }
    }

    public static class TitleVO extends BaseModelVO {

        public TitleVO(int type){
            this.type = type;
        }
        private int type;

        public int getType() {
            return type;
        }

        public void setType(int type) {
            this.type = type;
        }
    }

}
