//package com.hhdd.kada.main.ui.search;
//
//
//import android.app.Activity;
//import android.app.AlertDialog;
//import android.content.DialogInterface;
//import android.support.v7.widget.GridLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.text.TextUtils;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.LinearLayout;
//import android.widget.RelativeLayout;
//import android.widget.ScrollView;
//import android.widget.TextView;
//
//import com.google.gson.reflect.TypeToken;
//import com.hhdd.android.ref.StrongReference;
//import com.hhdd.core.model.PopularKeywordsVO;
//import com.hhdd.core.service.DefaultCallback;
//import com.hhdd.core.service.UserHabitService;
//import com.hhdd.kada.KaDaApplication;
//import com.hhdd.kada.R;
//import com.hhdd.kada.android.library.views.list.RecyclerPagedListDataAdapter;
//import com.hhdd.kada.api.API;
//import com.hhdd.kada.api.SearchAPI;
//import com.hhdd.kada.base.BaseFragment;
//import com.hhdd.kada.main.common.FragmentUtil;
//import com.hhdd.kada.main.model.OrganizationInfo;
//import com.hhdd.kada.main.ui.activity.SearchActivity;
//import com.hhdd.kada.main.ui.activity.WebViewActivity;
//import com.hhdd.kada.main.utils.FileUtils;
//import com.hhdd.kada.main.utils.ListUtils;
//import com.hhdd.kada.main.utils.StringUtil;
//import com.hhdd.kada.main.utils.TimeUtil;
//import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
//import com.hhdd.kada.main.views.CustomLayout;
//import com.hhdd.kada.main.vo.BaseModelVO;
//import com.hhdd.kada.organization.CPFragment;
//import com.hhdd.logger.LogHelper;
//import com.jcodecraeer.xrecyclerview.XRecyclerView;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import butterknife.BindView;
//
//
///**
// * Created by sxh on 2017/7/24.
// */
//
//public class SearchPageFragment extends BaseFragment {
//
//    @BindView(R.id.history_search)
//    TextView historySearch;
//    @BindView(R.id.btn_clear)
//    ImageView btnClearHistory;
//    @BindView(R.id.history_container)
//    CustomLayout mHistoryContainer;
//    @BindView(R.id.history_layout)
//    RelativeLayout mHistoryLayout;
//    @BindView(R.id.hot_text)
//    TextView hotText;
//    @BindView(R.id.hot_container)
//    CustomLayout mHotContainer;
//    @BindView(R.id.cp_text)
//    TextView cpText;
//    @BindView(R.id.cp_list)
//    XRecyclerView cpList;
//    @BindView(R.id.cp_container)
//    LinearLayout cpContainer;
//    @BindView(R.id.hot_and_history_container)
//    ScrollView hotAndHistoryContainer;
//
//    private int searchFromType;
//    private RecyclerPagedListDataAdapter mCpAdapter;
//    private AlertDialog dialog;
//    private SearchActivity currentActivity;
//
//    private static int TEXT_COLOR = KaDaApplication.applicationContext().getResources().getColor(R.color.text_color);
//    private static int TEXT_PADDING_LEFT_AND_RIGHT = KaDaApplication.applicationContext().getResources().getDimensionPixelOffset(R.dimen.search_history_padding_left_right);
//    private static int TEXT_PADDING_TOP_AND_BOTTOM = KaDaApplication.applicationContext().getResources().getDimensionPixelOffset(R.dimen.search_history_padding_top_bottom);
//
//    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
//        @Override
//        public boolean process(int type, Object... args) {
//            switch (type) {
//                case SearchCPItemViewHolder.TYPE_CP_ITEM_CLICKED:
//                    try {
//                        int position = (int) args[0];
//                        OrganizationInfo info = (OrganizationInfo) args[1];
//                        processCpItemClicked(position, info);
//                    } catch (Throwable e) {
//                        LogHelper.printStackTrace(e);
//                    }
//                    return true;
//            }
//            return false;
//        }
//    };
//    private StrongReference<DefaultCallback> popularStrongReference;
//    private List<String> mHistoryList;
//
//    public SearchPageFragment() {
//    }
//
//    @Override
//    public int getLayoutId() {
//        return R.layout.fragment_search_page;
//    }
//
//    @Override
//    public void doInitView() {
//        if (getContext() == null || getContext().isFinishing()) {
//            return;
//        }
//        searchFromType = (int) getArguments().get(SearchActivity.SEARCH_TYPR);
//        if (getActivity() instanceof SearchActivity) {
//            currentActivity = (SearchActivity) getActivity();
//        }
//
//        cpList.setLoadingMoreEnabled(false);
//        cpList.setPullRefreshEnabled(false);
//        cpList.setLayoutManager(new GridLayoutManager(getContext(), 5));
//    }
//
//
//    @Override
//    public void doInitData() {
//        if (getContext() == null || getContext().isFinishing()) {
//            return;
//        }
//        loadHistoryData();
//        loadHotData();
//    }
//
//    @Override
//    public void doInitListener() {
//        btnClearHistory.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
//            @Override
//            public void OnClickWithAnim(View v) {
//                if (getContext() == null || getContext().isFinishing()) {
//                    return;
//                }
//                if (dialog == null) {
//                    dialog = new AlertDialog.Builder(getContext()).setMessage("确认删除全部历史记录？")
//                            .setNegativeButton("取消",
//                                    new DialogInterface.OnClickListener() {
//                                        @Override
//                                        public void onClick(DialogInterface dialog, int whichButton) {
//                                            dialog.dismiss();
//                                        }
//                                    })
//                            .setPositiveButton("确定",
//                                    new DialogInterface.OnClickListener() {
//                                        @Override
//                                        public void onClick(DialogInterface dialog, int which) {
//                                            FileUtils.removeFile(SearchDirs.searchHistoryFilePath(searchFromType));
//                                            mHistoryLayout.setVisibility(View.GONE);
//                                            mHistoryList.clear();
//                                        }
//                                    })
//                            .create();
//                }
//                dialog.show();
//            }
//        });
//    }
//
//    //最近搜索
//    public void loadHistoryData() {
//        if (mHistoryLayout == null) {
//            return;
//        }
//
//        if (FileUtils.fileExist(SearchDirs.searchHistoryFilePath(searchFromType))) {
//            mHistoryLayout.setVisibility(View.VISIBLE);
//            String mHistoryText = FileUtils.readStringFromFile(SearchDirs.searchHistoryFilePath(searchFromType));
//            if (mHistoryText.length() > 0) {
//                List tempList = Arrays.asList(mHistoryText.split(","));
//                mHistoryList = new ArrayList<>(tempList);
//                refreshHistoryList(null);
//            }
//        } else {
//            mHistoryLayout.setVisibility(View.GONE);
//        }
//    }
//
//    /**
//     * 刷新最近搜索UI
//     *
//     * @param addHistoryText 添加的text
//     */
//    public void refreshHistoryList(final String addHistoryText) {
//        if (mHistoryLayout.getVisibility() != View.VISIBLE) {
//            mHistoryLayout.setVisibility(View.VISIBLE);
//        }
//        if (mHistoryList == null) {
//            mHistoryList = new ArrayList<>();
//        }
//        if (!TextUtils.isEmpty(addHistoryText)) {
//            if (!mHistoryList.contains(addHistoryText)) {
//                mHistoryList = ListUtils.addElementToFirst(mHistoryList, addHistoryText);
//            } else {
//                mHistoryList = ListUtils.moveElementToFirst(mHistoryList, addHistoryText);
//            }
//        }
//        mHistoryContainer.removeAllViews();
//        int size = mHistoryList.size();
//        for (int i = 0; i < size; i++) {
//            final TextView textView = new TextView(getContext());
//            final String keywordsStr = mHistoryList.get(i).trim();
//            textView.setText(keywordsStr);
//            textView.setTextColor(TEXT_COLOR);
//            textView.setPadding(TEXT_PADDING_LEFT_AND_RIGHT, TEXT_PADDING_TOP_AND_BOTTOM, TEXT_PADDING_LEFT_AND_RIGHT, TEXT_PADDING_TOP_AND_BOTTOM);
//            textView.setBackgroundResource(R.drawable.search_text_background);
//            textView.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
//                @Override
//                public void onNoDoubleClick(View v) {
//                    if (!TextUtils.isEmpty(textView.getText().toString().trim())) {
//                        switch (searchFromType) {
//                            case SearchActivity.SEARCH_FROM_BOOK:
//                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(keywordsStr, "search_page_book_recent_word", TimeUtil.currentTime()));
//                                break;
//                            case SearchActivity.SEARCH_FROM_STORY:
//                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(keywordsStr, "search_page_story_recent_word", TimeUtil.currentTime()));
//                                break;
//                        }
//
//                        if (currentActivity != null) {
//                            currentActivity.setUserEdit(false);
//                            currentActivity.doSearch(keywordsStr,false);
//                        }
//                    }
//                }
//            });
//            mHistoryContainer.addView(textView);
//        }
//    }
//
//    //热门搜索
//    void loadHotData() {
//        List<PopularKeywordsVO> hotList = FileUtils.loadFromFile(SearchDirs.popKeywordsPath(searchFromType), new TypeToken<List<PopularKeywordsVO>>() {
//        });
//        if (hotList != null && hotList.size() > 0) {
//            if (mHotContainer != null) {
//                mHotContainer.removeAllViews();
//            }
//            int hotSize = hotList.size();
//            for (int i = 0; i < hotSize; i++) {
//                final TextView textView = new TextView(getContext());
//                final String keyWordsStr = hotList.get(i).getKeyWords().trim();
//                textView.setText(keyWordsStr);
//                textView.setTextColor(TEXT_COLOR);
//                textView.setPadding(TEXT_PADDING_LEFT_AND_RIGHT, TEXT_PADDING_TOP_AND_BOTTOM, TEXT_PADDING_LEFT_AND_RIGHT, TEXT_PADDING_TOP_AND_BOTTOM);
//                textView.setBackgroundResource(R.drawable.search_text_background);
//                textView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
//                    @Override
//                    public void OnClickWithAnim(View v) {
//                        switch (searchFromType) {
//                            case SearchActivity.SEARCH_FROM_BOOK:
//                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(keyWordsStr, "search_page_book_hot_word", TimeUtil.currentTime()));
//                                break;
//                            case SearchActivity.SEARCH_FROM_STORY:
//                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(keyWordsStr, "search_page_story_hot_word", TimeUtil.currentTime()));
//                                break;
//                        }
//                        if (!TextUtils.isEmpty(keyWordsStr)) {
//                            currentActivity.setUserEdit(false);
//                            currentActivity.doSearch(keyWordsStr,false);
//                        }
//                    }
//                });
//                if (mHotContainer != null) {
//                    mHotContainer.addView(textView);
//                }
//
//            }
//        }
//
//        if (popularStrongReference == null) {
//            popularStrongReference = new StrongReference<>();
//        }
//        DefaultCallback<List<PopularKeywordsVO>> popularCallback = new DefaultCallback<List<PopularKeywordsVO>>() {
//            @Override
//            public void onDataReceived(final List<PopularKeywordsVO> data) {
//                if (data == null || data.isEmpty()) {
//                    return;
//                }
//
//                FileUtils.saveToFile(data, SearchDirs.popKeywordsPath(searchFromType));
//
//                getHandler().post(new Runnable() {
//                    @Override
//                    public void run() {
//                        if (mHotContainer == null) {
//                            return;
//                        }
//
//                        Activity activity = getActivity();
//                        if (activity == null || activity.isFinishing()) {
//                            return;
//                        }
//
//                        mHotContainer.removeAllViews();
//
//                        int size = data.size();
//                        for (int i = 0; i < size; i++) {
//                            final String keywords = data.get(i).getKeyWords().trim();
//                            if (StringUtil.isEmpty(keywords)) {
//                                continue;
//                            }
//
//                            final TextView textView = new TextView(activity);
//                            textView.setText(keywords);
//                            textView.setTextColor(TEXT_COLOR);
//                            textView.setPadding(TEXT_PADDING_LEFT_AND_RIGHT, TEXT_PADDING_TOP_AND_BOTTOM, TEXT_PADDING_LEFT_AND_RIGHT, TEXT_PADDING_TOP_AND_BOTTOM);
//                            textView.setBackgroundResource(R.drawable.search_text_background);
//                            textView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
//                                @Override
//                                public void OnClickWithAnim(View v) {
//                                    switch (searchFromType) {
//                                        case SearchActivity.SEARCH_FROM_BOOK:
//                                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(keywords, "search_page_book_hot_word", TimeUtil.currentTime()));
//                                            break;
//                                        case SearchActivity.SEARCH_FROM_STORY:
//                                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(keywords, "search_page_story_hot_word", TimeUtil.currentTime()));
//                                            break;
//                                    }
//
//                                    currentActivity.setUserEdit(false);
//                                    currentActivity.doSearch(keywords,false);
//                                }
//                            });
//
//                            mHotContainer.addView(textView);
//                        }
//                    }
//                });
//            }
//
//            @Override
//            public void onException(int code, String reason) {
//                super.onException(code, reason);
//            }
//        };
//        popularStrongReference.set(popularCallback);
//        SearchAPI.getPopularKeywords(searchFromType, popularStrongReference);
//    }
//
//    //咔哒伙伴
//    public void refreshCP(final List<BaseModelVO> cpDataList) {
//        mCpAdapter = new RecyclerPagedListDataAdapter<BaseModelVO>() {
//            @Override
//            public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//                SearchCPItemViewHolder viewHolder = new SearchCPItemViewHolder();
//                viewHolder.setOnEventProcessor(mOnEventProcessor);
//                RecyclerViewHolder recyclerHolder = new RecyclerViewHolder(viewHolder, viewHolder.createView(parent));
//                return recyclerHolder;
//            }
//
//            @Override
//            public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
//                BaseModelVO itemData = getItem(position);
//
//                if (holder != null && holder instanceof RecyclerViewHolder) {
//                    RecyclerViewHolder recyclerViewHolder = (RecyclerViewHolder) holder;
//                    recyclerViewHolder.viewHolderBaseRef.setItemData(position, holder.itemView);
//
//                    if (position == 4) {
//                        BaseModelVO baseModelVO = new BaseModelVO();
//                        recyclerViewHolder.viewHolderBaseRef.showData(position, baseModelVO);
//                    } else {
//                        recyclerViewHolder.viewHolderBaseRef.showData(position, itemData);
//                    }
//                }
//            }
//
//
//            @Override
//            public int getItemCount() {
//                if (cpDataList != null && cpDataList.size() > 0) {
//                    if (cpDataList.size() > 4) {
//                        return 5;
//                    } else {
//                        return cpDataList.size();
//                    }
//                }
//                return 0;
//            }
//
//            @Override
//            public BaseModelVO getItem(int position) {
//                if (cpDataList != null && cpDataList.size() > position) {
//                    return cpDataList.get(position);
//                } else {
//
//                }
//                return null;
//            }
//        };
//        cpList.setAdapter(mCpAdapter);
//    }
//
//    @Override
//    public void onDestroyView() {
//        if (popularStrongReference != null) {
//            popularStrongReference.clear();
//            popularStrongReference = null;
//        }
//        super.onDestroyView();
//    }
//
//    @Override
//    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
//        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
//        if (isVisibleToUser) {
//            switch (searchFromType) {
//                case SearchActivity.SEARCH_FROM_BOOK:
//                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "search_page_book_view", TimeUtil.currentTime()));
//                    break;
//                case SearchActivity.SEARCH_FROM_STORY:
//                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "search_page_story_view", TimeUtil.currentTime()));
//                    break;
//            }
//        }
//    }
//
//    private void processCpItemClicked(int position, OrganizationInfo organizationInfo) {
//        Activity activity = getContext();
//        if (activity == null || activity.isFinishing()) {
//            return;
//        }
//
//        if (position == 4) {
//            FragmentUtil.presentFragment(CPFragment.class, null, true);
//
//            switch (searchFromType) {
//                case SearchActivity.SEARCH_FROM_BOOK:
//                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "search_page_book_cp_more_click", TimeUtil.currentTime()));
//                    break;
//                case SearchActivity.SEARCH_FROM_STORY:
//                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "search_page_story_cp_more_click", TimeUtil.currentTime()));
//                    break;
//            }
//
//            return;
//        }
//
//        if (organizationInfo == null) {
//            return;
//        }
//
//        switch (searchFromType) {
//            case SearchActivity.SEARCH_FROM_BOOK:
//                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(organizationInfo.getOrgId() + "", "search_page_book_cp", TimeUtil.currentTime()));
//                break;
//            case SearchActivity.SEARCH_FROM_STORY:
//                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(organizationInfo.getOrgId() + "", "search_page_story_cp", TimeUtil.currentTime()));
//                break;
//        }
//
//        WebViewActivity.startActivity(getContext(), API.CP_DETAIL_URL + organizationInfo.getOrgId());
//    }
//}
