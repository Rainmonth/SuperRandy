package com.hhdd.kada.main.ui.explore;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.CoinService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.CoinAPI;
import com.hhdd.kada.api.ExploreAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.coin.BillFragment;
import com.hhdd.kada.coin.event.CoinUpdateEvent;
import com.hhdd.kada.coin.event.FinishDailyTaskEvent;
import com.hhdd.kada.coin.event.FinishTaskFragmentEvent;
import com.hhdd.kada.coin.event.GetDailyTaskListEvent;
import com.hhdd.kada.coin.model.CoinAmountInfo;
import com.hhdd.kada.coin.model.CoinMedal;
import com.hhdd.kada.coin.model.DailyTaskInfo;
import com.hhdd.kada.coin.view.CoinDialog;
import com.hhdd.kada.coin.viewholder.ExploreTaskViewHolder;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.event.TaskAnimStopEvent;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.manager.DialogManager;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.main.vo.ViewTypes;
import com.hhdd.kada.medal.Medal;
import com.hhdd.kada.medal.MedalDialog;
import com.hhdd.kada.medal.MedalGrantedEvent;
import com.hhdd.kada.medal.MedalManager;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;
import com.hhdd.logger.LogHelper;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;

/**
 * Created by simon on 18/11/2016.
 */

public class ExploreFragment extends RecyclerDataListFragment2 {

    private static final String TAG_FIRST_OPEN_DAILY_TASK_AUDIO = "tagFirstOpenDailyTask";

    private IMediaPlayer mShortMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);

    private boolean isNeetContinuePlayListen = false;

    private ArrayList<CoinMedal> medalList;

    private boolean isRedDotShow = false;   //每日任务是否全部完成
    private StrongReference<DefaultCallback> dailyStrongReference;
    private StrongReference<DefaultCallback> exploreStrongReference;
    private StrongReference<DefaultCallback> coinStrongReference;

    public ExploreFragment() {
        super(LIST_MODE_PULL_DOWN_TO_REFRESH);
    }

    boolean isStartTask = false;
    boolean needShowCoinDialog = false;//完成每日任务 返回才展示dialog
    boolean isTaskFragmentFinish = false;

    int coin = 0;
    CoinAmountInfo coinAmountInfo;
    DailyTaskInfo dailyTaskInfo;

    List<BaseModelListVO> discoveryList;

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case ExploreTaskViewHolder.TYPE_EXPLORE_TASK_COVER_CLICKED:
                case ExploreTaskViewHolder.TYPE_EXPLORE_TASK_CAT_LEFT_CLICKED:
                case ExploreTaskViewHolder.TYPE_EXPLORE_TASK_CAT_RIGHT_CLICKED:
                    try {
                        DailyTaskInfo dailyTaskInfo = (DailyTaskInfo) args[0];
                        processDailyTaskClicked(dailyTaskInfo);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    return true;
            }
            return false;
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mShortMediaPlayer.addOnPlayListener(mOnPlayListener);
    }

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        if (data instanceof Boolean) {
            isRedDotShow = (boolean) data;
        }
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        if (getContentView() != null) {
            return;
        }
        super.onCreateView(savedInstanceState);

        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }

        getViewHolderCreator().setOnEventProcessor(mOnEventProcessor);

        initTitleBar();

        playEnterAudio();

        reloadData();

        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {
            //完成任务
            public void onEvent(final FinishDailyTaskEvent event) {
                if (isStartTask) {
                    isStartTask = false;

                    if (isVisibleToUser()) {
                        needShowCoinDialog = false;
                        showDialog(event.getCoin());
                    } else {
                        needShowCoinDialog = true;
                        coin = event.getCoin();
                    }
                    getTaskList();
                }
            }

            public void onEventMainThread(GetDailyTaskListEvent event) {
                List<DailyTaskInfo> taskInfos = ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getDaliyTaskList();
                if (taskInfos != null &&
                        taskInfos.size() > 0) {
                    reloadDataImpl();
                }
            }

            public void onEvent(MedalGrantedEvent event) {
                loadHeadMedal();
            }

            public void onEvent(FinishTaskFragmentEvent event) {
                isTaskFragmentFinish = true;
            }

            public void onEvent(CoinUpdateEvent event){
                loadHeadCoin();
                doCheckIfNeedDisplayMedal();
            }
        }).tryToRegisterIfNot();

    }

    private void playEnterAudio() {
        List<DailyTaskInfo> taskInfos = ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getDaliyTaskList();
        if (taskInfos != null && taskInfos.size() > 0) {
            int coin = 0;
            DailyTaskInfo info = taskInfos.get(0);
            coin = info.getCoin();

            if (isRedDotShow) {

                if (!info.isFinished() && coin > 0) {
                    isNeetContinuePlayListen = ListenManager.getInstance().isPlaying();
                    if (isNeetContinuePlayListen) {
                        ListenManager.getInstance().setPausedByShortAudio(true);
                        ListenManager.getInstance().pause(false);
                    }
                    mShortMediaPlayer.addPlayQueue(R.raw.first_open_daily_task, PlayMode.IMMEDIATELY_PLAY_MODE, TAG_FIRST_OPEN_DAILY_TASK_AUDIO);
                }
            }
        }
    }

    private void initTitleBar() {
        View title = LayoutInflater.from(getContext()).inflate(R.layout.title_explore_fragment, null);
        ImageView bill = (ImageView) title.findViewById(R.id.bill);
        bill.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "kada_coin_detail_record_click", TimeUtil.currentTime()));
                FragmentUtil.pushFragment(BillFragment.class, null, true);
            }
        });
        useTitleBar(true);
        getTitleBar().setCustomizedCenterView(title);
    }

    @Override
    protected void doRefresh() {
        showLoadingView();
        reloadData();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (coin > 0 && needShowCoinDialog && !isTaskFragmentFinish) {
            needShowCoinDialog = false;
            showDialog(coin);
        }
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().post(new TaskAnimStopEvent());
        if (dailyStrongReference != null) {
            dailyStrongReference.clear();
            dailyStrongReference = null;
        }

        if (exploreStrongReference != null) {
            exploreStrongReference.clear();
            exploreStrongReference = null;
        }
        if (coinStrongReference != null) {
            coinStrongReference.clear();
            coinStrongReference = null;
        }
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, TAG_FIRST_OPEN_DAILY_TASK_AUDIO);

            mShortMediaPlayer.removeOnPlayListener(mOnPlayListener);

            continuePlayListen();
        }
    }


    public void loadHeadCoin() {
        if (((CoinService)ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getCoinAmountInfo()!=null){
            coinAmountInfo = ((CoinService)ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getCoinAmountInfo();
            reloadDataImpl();
        }else {
            if (coinStrongReference == null) {
                coinStrongReference = new StrongReference<>();
            }
            DefaultCallback<CoinAmountInfo> defaultCallback = new DefaultCallback<CoinAmountInfo>() {

                @Override
                public void onLoadFromCache(CoinAmountInfo cacheData) {
                    super.onLoadFromCache(cacheData);
                    if (cacheData != null) {
                        coinAmountInfo = cacheData;

                        getHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                reloadDataImpl();
                            }
                        });
                    }
                }

                @Override
                public void onDataReceived(final CoinAmountInfo data) {
                    Activity activity = getActivity();
                    if (activity == null || activity.isFinishing()) {
                        return;
                    }

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            if (data != null) {
                                coinAmountInfo = data;
                                ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).setCoinAmountInfo(coinAmountInfo);
                            }
                            reloadDataImpl();
                        }
                    });
                }

                @Override
                public void onException(int code, String reason) {
                    super.onException(code, reason);
                    Activity activity = getActivity();
                    if (activity == null || activity.isFinishing()) {
                        return;
                    }

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadDataImpl();
                        }
                    });
                }
            };
            coinStrongReference.set(defaultCallback);
            CoinAPI.getCoinAmount(coinStrongReference);
        }
    }

    public void loadHeadMedal() {
        if (((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getCoinMedalList() != null
                && ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getCoinMedalList().size() > 0) {
            medalList = ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getCoinMedalList();
            List<Integer> currentUserMedalIds = ((MedalManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.MEDAL_MANAGER)).getMedalIds();
            for (int i = 0; i < medalList.size(); i++) {
                if (currentUserMedalIds.contains(medalList.get(i).getMedalId())) {
                    medalList.get(i).setReceive(true);
                } else {
                    medalList.get(i).setReceive(false);
                }
            }
            reloadDataImpl();
        } else {
            CoinAPI.getCoinMedalList(new API.ResponseHandler<ArrayList<CoinMedal>>() {
                @Override
                public void onSuccess(ArrayList<CoinMedal> response) {
                    medalList = new ArrayList<>();
                    List<Integer> currentUserMedalIds = ((MedalManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.MEDAL_MANAGER)).getMedalIds();
                    if (response != null && response.size() > 0) {
                        for (int i = 0; i < response.size(); i++) {
                            if (currentUserMedalIds.contains(response.get(i).getMedalId())) {
                                response.get(i).setReceive(true);
                            } else {
                                response.get(i).setReceive(false);
                            }
                            medalList.add(response.get(i));
                        }

                        ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).setCoinMedalList(medalList);
                    }
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadDataImpl();
                        }
                    });
                }

                @Override
                public void onFailure(int code, String message) {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadDataImpl();
                        }
                    });
                }
            });
        }
    }

    public void getTaskList() {
        if (dailyStrongReference == null) {
            dailyStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<DailyTaskInfo>> dailyCallback = new DefaultCallback<List<DailyTaskInfo>>() {
            @Override
            public void onDataReceived(List<DailyTaskInfo> data) {
                if (data != null && data.size() > 0) {
                    dailyTaskInfo = data.get(0);
                }
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reloadDataImpl();
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reloadDataImpl();
                    }
                });
            }
        };
        dailyStrongReference.set(dailyCallback);
        CoinAPI.getTaskList(dailyStrongReference);
    }

    private void loadExploreConfigData() {
        if (exploreStrongReference == null) {
            exploreStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<BaseModelListVO>> defaultCallback = new DefaultCallback<List<BaseModelListVO>>() {

            @Override
            public void onLoadFromCache(List<BaseModelListVO> cacheData) {
                super.onLoadFromCache(cacheData);
                if (cacheData != null && cacheData.size() > 0) {
                    discoveryList = cacheData;

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadDataImpl();
                        }
                    });
                }
            }

            @Override
            public void onDataReceived(List<BaseModelListVO> responseData) {
                if (responseData != null && responseData.size() > 0) {
                    discoveryList = responseData;

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadDataImpl();
                        }
                    });
                } else {
                    if (discoveryList != null) {
                        discoveryList.clear();
                    }

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadDataImpl();
                        }
                    });
                }

            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reloadDataImpl();
                    }
                });
            }
        };
        exploreStrongReference.set(defaultCallback);
        ExploreAPI.getExploreConfig(exploreStrongReference);
    }

    void reloadData() {
        loadExploreConfigData();
        getTaskList();
        loadHeadCoin();
        loadHeadMedal();
    }

    synchronized void reloadDataImpl() {
        List<BaseVO> dataList = getDataListDisplayed().getDataList();
        dataList.clear();
        if (medalList!=null&&medalList.size()>0) {
            BaseModelListVO listVO = new BaseModelListVO();
            listVO.setViewType(ViewTypes.View_Type_Explore_Head);
            listVO.getItemList().addAll(medalList);
            dataList.add(listVO);
        }
        if (dailyTaskInfo != null) {
            BaseModelVO vo = new BaseModelVO();
            vo.setModel(dailyTaskInfo);
            vo.setViewType(ViewTypes.View_Type_DataList_DailyTask);
            dataList.add(vo);
        }
        if (discoveryList != null && discoveryList.size() > 0) {
            dataList.addAll(discoveryList);
            List<BaseModel> list = new ArrayList<BaseModel>();
            list.addAll(dataList);
            reloadData(list);
        }
        if (dataList.size() > 0) {
            List<BaseModel> list = new ArrayList<>();
            list.addAll(dataList);
            reloadData(list);
            handleLoadComplete(false);
        }else {
            handleErrorOccurred(false,0,"暂无数据");
        }
    }

    private void processDailyTaskClicked(DailyTaskInfo info) {
        if (info == null) {
            return;
        }

        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getId()), "discovery_home_page_daily_task", TimeUtil.currentTime()));

        if (!info.isFinished()) {
            isStartTask = true;
            ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).startTask(info.getId(), 0);
        } else {
            isStartTask = false;
        }

        //每日任务点击需要判断是否登录
        RedirectActivity.startActivity(activity, info.getOperator());
    }

    private void doCheckIfNeedDisplayMedal() {
        if (((AuthService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.AUTH_SERVICE)).isAuthorized()) {
            getHandler().removeCallbacks(mDisplayMedalRunnable);
            getHandler().postDelayed(mDisplayMedalRunnable, 2000);
        }
    }

    private Runnable mDisplayMedalRunnable = new Runnable() {
        @Override
        public void run() {
            synchronized (ExploreFragment.this) {
                Medal medalInfo = ((MedalManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.MEDAL_MANAGER)).fetchOneNewGrantedMealForDisplay();
                if (medalInfo != null) {
                    Activity activity = ActivityHelper.getTopActivity();
                    if (activity == null || activity.isFinishing()) {
                        return;
                    }

                    String imageUrl = medalInfo.isReceive() ? medalInfo.getGainImg() : medalInfo.getUnGainImg();
                    MedalDialog mMedalDialog = new MedalDialog(activity, medalInfo, medalInfo.getMedalId(), CdnUtils.getImgCdnUrl(imageUrl), medalInfo.getName(), true, true);
                    //获得勋章 只在界面没有dialog展示时显示 否则不加入dialog显示列表
                    ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).showDialog(mMedalDialog);
                }
            }
        }
    };

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "kada_coin_view", TimeUtil.currentTime()));
        }
    }

    void showDialog(final int coin) {
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                synchronized (ExploreFragment.this) {
                    if (isVisibleToUser()) {
                        if (getContext() == null || getContext().isFinishing()) {
                            return;
                        }
                        CoinDialog coinDialog = new CoinDialog(getContext(), coin, true, true);
                        ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).showDialog(coinDialog);
                    }
                }
            }
        }, 500);
    }

    private void continuePlayListen() {
        if (isNeetContinuePlayListen || ListenManager.getInstance().isPausedByShortAudio()) {
            isNeetContinuePlayListen = false;

            ListenManager.getInstance().setPause(false);
            ListenManager.getInstance().play();
        }
    }

    private OnPlayListener mOnPlayListener = new OnPlayListener() {
        @Override
        public void onPrepared(String audioTag, int playMode) {

        }

        @Override
        public void onCompletion(String audioTag, int playMode) {
            if (TAG_FIRST_OPEN_DAILY_TASK_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onError(String audioTag, int playMode) {
            if (TAG_FIRST_OPEN_DAILY_TASK_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onStop(String audioTag, int playMode) {

        }
    };
}
