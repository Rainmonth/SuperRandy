package com.hhdd.kada.main.ui.book;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.model.BookListItem;
import com.hhdd.kada.main.model.BookOtherCollectListModel;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;

import java.util.List;

import butterknife.BindView;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;

/**
 * Created by mcx on 2017/8/8.
 */

public class BookOtherListViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.book_one)
    BookItemView bookOne;
    @BindView(R.id.book_two)
    BookItemView bookTwo;
    @BindView(R.id.book_three)
    BookItemView bookThree;
    @BindView(R.id.fl_one)
    FrameLayout frameLayoutOne;
    @BindView(R.id.fl_two)
    FrameLayout flTwo;
    @BindView(R.id.fl_three)
    FrameLayout flThree;
    @BindView(R.id.container)
    LinearLayout container;

    int mWidth;
    int mHeight;
    Context context;

    @Override
    protected int getLayoutId() {
        return R.layout.book_other_item_single;
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(params);
        context = parent.getContext();
        mWidth = (LocalDisplay.SCREEN_WIDTH_DP - (7 * 2 + 5 * 6)) / 3;
        mHeight = (int) (mWidth * 32.0f / 25.0f);

        return rootView;
    }

    @Override
    public void showData(int position, final BaseModelListVO itemData) {
        if (itemData == null) {
            return;
        }

        List<BaseModel> models = itemData.getItemList();
        if (models == null || models.isEmpty()) {
            return;
        }

        int count = models.size() > 3 ? 3 : models.size();

        for (int i = 0; i < count; i++) {
            BaseModel model = models.get(i);
            if (model != null && model instanceof BookOtherCollectListModel) {
                final BookOtherCollectListModel bookOtherCollectListModel = (BookOtherCollectListModel) model;
                if (bookOtherCollectListModel.getType() == BookListItem.TYPE_BOOK) {
                    FrameLayout frameLayout = (FrameLayout) container.getChildAt(i);
                    BookItemView bookItemView = (BookItemView) frameLayout.getChildAt(0);
                    ImageView hotFlag = (ImageView) frameLayout.getChildAt(1);
                    frameLayout.setVisibility(VISIBLE);

                    final BookInfo info = BookOtherCollectListModel.creatBookInfo(bookOtherCollectListModel);
                    frameLayout.setTag(R.id.container, info);
                    bookItemView.update(info, false, bookItemView.mItemWidth, bookItemView.mItemHeight);

                    if (bookItemView.flagMoneyImage.getVisibility() == VISIBLE) {
                        bookItemView.flagMoneyImage.setVisibility(GONE);
                    }
                    if (bookItemView.goldBorder.getVisibility() == VISIBLE) {
                        bookItemView.goldBorder.setVisibility(GONE);
                    }
                    if ((info.getExtFlag() & Extflag.EXT_FLAG_64) == Extflag.EXT_FLAG_64) {
                        bookItemView.flagNew.setVisibility(VISIBLE);
                    } else {
                        bookItemView.flagNew.setVisibility(GONE);
                    }
                    if ((info.getExtFlag() & Extflag.EXT_FLAG_8) == Extflag.EXT_FLAG_8) {
                        hotFlag.setVisibility(VISIBLE);
                    } else {
                        hotFlag.setVisibility(GONE);
                    }
                    //优先展示小编推荐
                    if (hotFlag.getVisibility() == VISIBLE && bookItemView.getVisibility() == VISIBLE) {
                        bookItemView.flagNew.setVisibility(GONE);
                    }

                    frameLayout.setOnClickListener(listener);
                } else {
                    FrameLayout frameLayout = (FrameLayout) container.getChildAt(i);
                    BookItemView bookItemView = (BookItemView) frameLayout.getChildAt(0);
                    ImageView hotFlag = (ImageView) frameLayout.getChildAt(1);
                    frameLayout.setVisibility(VISIBLE);

                    final BookCollectionInfo info = BookOtherCollectListModel.creatBookCollectionInfo(bookOtherCollectListModel);

                    frameLayout.setTag(R.id.container, info);
                    bookItemView.update(info, false, bookItemView.mItemWidth, bookItemView.mItemHeight);

                    if ((info.getExtFlag() & Extflag.EXT_FLAG_64) == Extflag.EXT_FLAG_64) {
                        bookItemView.flagNew.setVisibility(VISIBLE);
                    } else {
                        bookItemView.flagNew.setVisibility(GONE);
                    }
                    if ((info.getExtFlag() & Extflag.EXT_FLAG_1024) == Extflag.EXT_FLAG_1024) {
                        int rightMargin = LocalDisplay.dp2px(5);
                        int bottomMargin = LocalDisplay.dp2px(6.2f);
                        FrameLayout.LayoutParams flagMoneyImageParams = (FrameLayout.LayoutParams) bookItemView.flagMoneyImage.getLayoutParams();
                        flagMoneyImageParams.setMargins(0, 0, rightMargin, bottomMargin);
                        bookItemView.flagMoneyImage.setVisibility(VISIBLE);
                        bookItemView.goldBorder.setVisibility(VISIBLE);
                        FrameLayout.LayoutParams goldBorderParams = (FrameLayout.LayoutParams) bookItemView.goldBorder.getLayoutParams();
                        goldBorderParams.setMargins(0, 0, rightMargin, bottomMargin);
                    } else {
                        bookItemView.flagMoneyImage.setVisibility(GONE);
                        bookItemView.goldBorder.setVisibility(GONE);
                    }
                    if ((info.getExtFlag() & Extflag.EXT_FLAG_8) == Extflag.EXT_FLAG_8) {
                        hotFlag.setVisibility(VISIBLE);
                    } else {
                        hotFlag.setVisibility(GONE);
                    }
                    //优先展示小编推荐
                    if (hotFlag.getVisibility() == VISIBLE && bookItemView.getVisibility() == VISIBLE) {
                        bookItemView.flagNew.setVisibility(GONE);
                    }
                    frameLayout.setOnClickListener(listener);
                }
            }
        }
        for (int i = count; i < 3; i++) {
            final View layout = container.getChildAt(i);
            layout.setVisibility(View.INVISIBLE);
            layout.setTag(R.id.view_holder_item, null);
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            Object object = v.getTag(R.id.container);
            if (object instanceof BookInfo) {
                BookInfo info = (BookInfo) object;
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1," + info.getBookId(), "child_book_home_recommend_click_" + info.getIndex(), TimeUtil.currentTime()));
                PlaybackActivity.startActivity(context, info.getBookId(), info.getExtFlag(), info.getVersion());
            } else {
                BookCollectionInfo info = (BookCollectionInfo) object;
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("2," + info.getCollectId(), "child_book_home_recommend_click_" + info.getIndex(), TimeUtil.currentTime()));
                FragmentUtil.pushFragment(BookCollectionFragment.class, new BaseCollectionFragment.CollectionModel(info.getCollectId(), true), true);

            }

        }
    };
}
