package com.hhdd.kada.main.ui.book;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.model.ReadingHistoryInfo;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.BookService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.URLScheme;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.android.library.views.list.RecyclerPagedListDataAdapter;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BannerAPI;
import com.hhdd.kada.api.BookAPI;
import com.hhdd.kada.api.OtherAPI;
import com.hhdd.kada.api.TalentPlanAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.db.main.entities.ReadingHistory;
import com.hhdd.kada.main.common.DataListModel;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.event.BookSubscribeStatusEvent;
import com.hhdd.kada.main.event.ConnectivityChangedEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.RefreshTalentPlanSubscribeEvent;
import com.hhdd.kada.main.event.SameAccountUnifySuccessEvent;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.event.TalentAnimStopEvent;
import com.hhdd.kada.main.event.TalentPaySucceedEvent;
import com.hhdd.kada.main.event.TalentPlanTestFinishedEvent;
import com.hhdd.kada.main.event.TalentSubscribeStatusEvent;
import com.hhdd.kada.main.event.UnLockEvent;
import com.hhdd.kada.main.event.UserSubscribeChangeEvent;
import com.hhdd.kada.main.manager.DialogManager;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.model.BookListItem;
import com.hhdd.kada.main.model.BookOtherCollectListModel;
import com.hhdd.kada.main.model.BookSubscribeListModel;
import com.hhdd.kada.main.model.DialogConfigInfo;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.settings.UserSettings;
import com.hhdd.kada.main.ui.activity.BaseRestActivity;
import com.hhdd.kada.main.ui.dialog.ActivityDialog;
import com.hhdd.kada.main.ui.dialog.ChildrenLockDialog;
import com.hhdd.kada.main.ui.viewholder.ShelfTitleViewHolder;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.LocalSubscribeUtil;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.AutoLayoutViewHolder;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.BookHistoriesViewHolder;
import com.hhdd.kada.main.viewholders.OldBannerViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorViewHolder_15;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.views.CommonHeaderView;
import com.hhdd.kada.main.views.FastScrollLinearLayoutManager;
import com.hhdd.kada.main.views.SubscribeLoadingMoreFooter;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.main.vo.ViewTypes;
import com.hhdd.kada.medal.UserTrack;
import com.hhdd.kada.module.exposure.ExposureTracker;
import com.hhdd.kada.module.exposure.OldBannerShownOnScreenEvent;
import com.hhdd.kada.module.shelf.ShelfActivity;
import com.hhdd.kada.module.talentplan.model.TalentPlanBookFragmentModel;
import com.hhdd.kada.module.talentplan.model.TalentPlanBookInfo;
import com.hhdd.kada.module.talentplan.viewholder.TalentPlanIsPaidViewHolder;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.kada.record.callback.ChildrenDialogCallback;
import com.hhdd.kada.widget.support.KdLinearLayoutManager;
import com.hhdd.logger.LogHelper;
import com.jcodecraeer.xrecyclerview.XRecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

import de.greenrobot.event.EventBus;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


/**
 * Created by mcx on 2017/7/24.
 */

public class BookFragment extends RecyclerDataListFragment2 {

    public static final String TYPE_CHILDREN_BOOK = "type_children_book";

    private static final int FIXED_HOLDER_COUNT = 2;   //页面固定的holder数目

    private Map<Integer, Class<?>> viewTypeMaps;
    DataListModel dataListModel;
    API.PaginationUrlAPI listAPI;

    API.UrlAPI subscribeApi;

    TalentPlanBookFragmentModel talentPlanModel;
    CopyOnWriteArrayList<BookOtherCollectListModel> subscribeList = new CopyOnWriteArrayList<>();

    private CommonHeaderView commonHeaderView;

    List<BaseVO> bannerInfoList = new ArrayList<>();
    List<BaseModelListVO> configList = new ArrayList<>();
    List<BaseModel> historyList = new ArrayList<>();
    List<BaseVO> reassembledList = new ArrayList<>();

    static final int View_Type_Talent_Plan_Is_Paid = 99;
    public static final int View_Type_Banner = 100;
    static final int View_Type_Subscribe_List = 101;
    static final int View_Type_DataList_BookHistories = 102;
    static final int View_Type_Book_Title = 103;
    static final int View_Type_LOOK_AROUND_Title = 104;
    static final int View_Type_Other_BookList = 105;
    static final int View_Type_Separator = 107;

    View floatLayout;
    ImageView floatIcon;
    View tipView;
    ObjectAnimator animator;

    AnimatorSet animatorSet;
    private int lastVisibleItemPosition = 0;// 标记上次滑动位置
    private boolean isTouched = false;
    boolean showIcon = false; //设置火箭显示标志
    private boolean needPlayTipAinm = true;

    /**
     * 优才计划接口数据处理锁
     */
    private static final Boolean LOCK_TALENT_PLAN = false;

    public static final String ACTIVITY_DIALOG_SHOW_ID_LIST = "ACTIVITY_DIALOG_SHOW_ID_LIST";

//    private ChildrenLockDialog mChildrenLockDialog;

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case BookSubscribeListViewHolder.TYPE_BOOK_SUBSCRIBE_ITEM_CLICKED:
                    if (args != null && args.length > 0) {
                        BookCollectionInfo itemInfo = (BookCollectionInfo) args[0];
                        processBookSubscribeItemClicked(itemInfo);
                    }
                    return true;
                case BookSubscribeListViewHolder.TYPE_BOOK_SHELF_CLICKED://更多-跳转到书架
                    processShelfManageClick(false);
                    return true;

                case ShelfTitleViewHolder.TYPE_MANAGE_CLICKED:
                    processShelfManageClick(true);
                    return true;
                case BookHistoriesViewHolder.TYPE_BOOK_HISTORY_ITEM_CLICKED:
                    try {
                        int position = (int) args[0];
                        ReadingHistoryInfo historyInfo = (ReadingHistoryInfo) args[1];
                        processBookHistoryItemClicked(position, historyInfo);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
            }

            return false;
        }
    };

    private StrongReference<DefaultCallback> talentPlanStrongReference;

    public BookFragment() {
        super(LIST_MODE_BOTH, "", null);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        viewTypeMaps = new HashMap<Integer, Class<?>>();
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }
        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {

            public void onEvent(BookSubscribeStatusEvent event) {
                if (event.getStatus() == 1) {
                    if (event.getCollectId() > 0) {
                        LocalSubscribeUtil.addBookSubscribeId(event.getCollectId());
                    }
                    loadSubscribeList();
                } else if (event.getStatus() == 3) {
                    if (event.getCollectId() > 0) {
                        LocalSubscribeUtil.removeBookSubscribeId(event.getCollectId());
                    }
                    loadSubscribeList();
                } else if (event.getStatus() == 0) {
                    loadSubscribeList();
                }
            }

//            public void onEvent(ShowRecommendEvent event) {
//                int isInRestSleepTime = RestSleepUtil.checkTimeInRestSleep();
//                if (isInRestSleepTime == RestSleepUtil.NOT_IN_REST) {
//                    checkShowRecommend();
//                }
//            }

            public void onEvent(UnLockEvent event) {
                //以后这种注册取消注册如果应用中有使用到，可以放到onStop中，根据isFinishing来判断，否则等onDestroy会有延时
                Activity topActivity = ActivityHelper.getTopActivity();
                if (topActivity instanceof BaseRestActivity) {
                    ActivityHelper.unregisterActivity(topActivity);
                }
//                checkShowRecommend();
            }

            public void onEvent(TalentSubscribeStatusEvent event) {
                loadTalentPlan();
            }

            public void onEvent(TalentPaySucceedEvent event) {
                moveToPosition(0);
                loadTalentPlan();
            }

            public void onEvent(BookService.SyncReadingHistoryDoneEvent event) {
                reloadHistoryData();
            }

            public void onEvent(BookService.ReadingHistoryUpdatedEvent event) {
                reloadHistoryData();
            }

            public void onEvent(ConnectivityChangedEvent event) {
                if (event.isConnected) {
                    if (getDataListDisplayed().getDataList().size() == 0) {
                        reloadData();
                    }
                    if (tipView.getVisibility() == View.VISIBLE) {
                        startGoneTipViewAnim();
                    }
                } else if (tipView.getVisibility() == View.GONE) {
                    //执行tip弹出动画
                    startShowTipViewAnim();
                }
            }

            public void onEvent(UserService.UserInfoChangeEvent event) {
                LocalSubscribeUtil.recycle();
                loadTalentPlan();
                loadSubscribeList();
                loadConfData();
                reloadData();
            }

            public void onEvent(AuthService.AuthorizedSuccessEvent event) {
                reloadData();
            }

            public void onEvent(UserSettings.TalentPlanShowPositionChangeEvent event) {
                loadTalentPlan();
            }

            public void onEvent(UserSettings.SubscribedCollectionIdChangedEvent event){
                if (event.type==1){
                    notifyDataSetChanged();
                }
            }

            public void onEvent(UserSubscribeChangeEvent event) {
                loadSubscribeList();
            }

            public void onEvent(TalentPlanTestFinishedEvent event) {
                int bookId = event.bookId;
                int rightNum = event.starCount;
                List<TalentPlanBookInfo> planBookVOList = talentPlanModel.planBookVOList;
                if (planBookVOList != null && planBookVOList.size() > 0) {
                    for (TalentPlanBookInfo bookInfo : planBookVOList) {
                        if (bookInfo.getBookId() == bookId && bookInfo.getRightNum() != rightNum) {
                            bookInfo.setRightNum(rightNum);
                            reloadDataImpl();
                            break;
                        }
                    }
                }
            }

            public void onEvent(RefreshTalentPlanSubscribeEvent event) {
                loadTalentPlan();
            }

            public void onEvent(SameAccountUnifySuccessEvent event) {
                loadTalentPlan();
                loadSubscribeList();
            }


        }).tryToRegisterIfNot();

//        int isInRestSleepTime = RestSleepUtil.checkTimeInRestSleep();
//        if (isInRestSleepTime == RestSleepUtil.NOT_IN_REST) {
//            checkShowRecommend();
//        }

        viewTypeMaps.put(View_Type_Talent_Plan_Is_Paid, TalentPlanIsPaidViewHolder.class);
        viewTypeMaps.put(View_Type_Banner, OldBannerViewHolder.class);
        viewTypeMaps.put(View_Type_DataList_BookHistories, BookHistoriesViewHolder.class);
        viewTypeMaps.put(View_Type_Subscribe_List, BookSubscribeListViewHolder.class);
        viewTypeMaps.put(View_Type_Book_Title, ShelfTitleViewHolder.class);
        viewTypeMaps.put(View_Type_Other_BookList, BookOtherListViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_AutoLayout.getId(), AutoLayoutViewHolder.class);
        viewTypeMaps.put(View_Type_Separator, SeparatorViewHolder_15.class);

        BaseViewHolderCreator viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(viewHolderCreator);

        //浮动icon
        floatLayout = LayoutInflater.from(getContext()).inflate(R.layout.list_float_layout, null);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.BOTTOM;
        getInnerContainer().addView(floatLayout, lp);


        floatIcon = (ImageView) floatLayout.findViewById(R.id.float_icon);
        floatIcon.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                isTouched = true;
                showIcon = true;
                floatIcon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.youyu_move));
                getmListView().smoothScrollToPosition(0);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_book_home_back_top_click", TimeUtil.currentTime()));
            }
        });

        FastScrollLinearLayoutManager manager = new FastScrollLinearLayoutManager(getContext(), KdLinearLayoutManager.VERTICAL, false);
        getmListView().setLayoutManager(manager);


        loadTitleBarData();

        showLoadingView();
        reloadData();

        getDialogConfigInfo();
        if (!NetworkUtils.isReachable() && tipView.getVisibility() == View.GONE) {
            startShowTipViewAnim();
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.network_not_connect, TimeUtil.currentTime()));
        } else if (NetworkUtils.isReachable() && tipView.getVisibility() == View.VISIBLE) {
            startGoneTipViewAnim();
        }
    }

    /**
     * 检查是否需要跳转推荐页面
     */
//    private void checkShowRecommend() {
//        List<DimensionInfo> dimensionInfoList = UserService.getInstance().getRecommendDimensionList();
//        if (isResume && !isShowRecommend && dimensionInfoList != null && dimensionInfoList.size() > 0) {
//            isShowRecommend = true;
//            if (getActivity() != null && !getActivity().isFinishing()) {
//                ActivityUtil.nextRecommendSettingActivity(getActivity(), dimensionInfoList);
//            }
//        }
//    }
    protected void loadTitleBarData() {
        tipView = LayoutInflater.from(getContext()).inflate(R.layout.view_holder_without_net, null, false);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LocalDisplay.dp2px(30));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            layoutParams.topMargin = KaDaApplication.getInstance().getResources().getDimensionPixelOffset(R.dimen.tab_activity_bottom_small_height) + LocalDisplay.SCREEN_STATUS_HEIGHT - LocalDisplay.dp2px(30);
        } else {
            layoutParams.topMargin = KaDaApplication.getInstance().getResources().getDimensionPixelOffset(R.dimen.tab_activity_bottom_small_height) - LocalDisplay.dp2px(30);
        }
        tipView.setLayoutParams(layoutParams);
        TextView btnSet = (TextView) tipView.findViewById(R.id.btn_set);
        btnSet.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.network_not_connect_click, TimeUtil.currentTime()));
                Intent intent = new Intent(android.provider.Settings.ACTION_SETTINGS);
                if (getContext() != null && !getContext().isFinishing()) {
                    getContext().startActivity(intent);
                }
            }
        });
        tipView.setVisibility(View.GONE);
        getInnerContainer().addView(tipView);


        getTitleBar().removeAllViews();
        getTitleBar().setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            View statusView = new View(getActivity());
            statusView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LocalDisplay.SCREEN_STATUS_HEIGHT));
            statusView.setBackgroundColor(KaDaApplication.getInstance().getResources().getColor(R.color.color_4abbf6));
            getInnerContainer().addView(statusView);
            getInnerContainer().addView(commonHeaderView = new CommonHeaderView(getActivity()));
            commonHeaderView.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
            commonHeaderView.setType(CommonHeaderView.TYPE_BOOK);
            setInnerViewPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT + KaDaApplication.getInstance().getResources().getDimensionPixelOffset(R.dimen.tab_activity_bottom_small_height), 0, 0);

        } else {
            getInnerContainer().addView(commonHeaderView = new CommonHeaderView(getActivity()));
            commonHeaderView.setType(CommonHeaderView.TYPE_BOOK);
            setInnerViewPadding(0, KaDaApplication.getInstance().getResources().getDimensionPixelOffset(R.dimen.tab_activity_bottom_small_height), 0, 0);
        }
    }

    void loadBannerData() {
        BannerAPI.getBookBanner(new API.CachedResponseHandler<List<BannerInfo>>() {
            @Override
            public void onFirstLoadFromCache(List<BannerInfo> cachedData) {
                updateBannerInfo(cachedData);
            }

            @Override
            public void onSuccess(List<BannerInfo> responseData) {
                updateBannerInfo(responseData);
            }

            @Override
            public void onFailure(int code, String message) {
                reloadDataImpl();
            }
        });
    }

    /**
     * 更新banner数据
     * @param data
     */
    private synchronized void updateBannerInfo(List<BannerInfo> data) {
        bannerInfoList.clear();
        if (data != null && data.size() > 0) {
            BaseModelListVO modelListVO = new BaseModelListVO();
            modelListVO.setModelStatus(TYPE_CHILDREN_BOOK);
            modelListVO.setViewType(View_Type_Banner);
            modelListVO.getItemList().addAll(data);
            bannerInfoList.add(modelListVO);
        }
        getHandler().post(new Runnable() {
            @Override
            public void run() {
                reloadDataImpl();
            }
        });
    }

    void loadTalentPlan() {
        if (!UserSettings.getInstance().isBookFragmentShowTalentPlan()) {
            talentPlanModel = null;
            if (talentPlanStrongReference != null) {
                talentPlanStrongReference.clear();
            }
            reloadDataImpl();
            return;
        }

        if (talentPlanStrongReference == null) {
            talentPlanStrongReference = new StrongReference<>();
        }
        DefaultCallback<TalentPlanBookFragmentModel> talentPlanCallback = new DefaultCallback<TalentPlanBookFragmentModel>() {

            @Override
            public void onLoadFromCache(TalentPlanBookFragmentModel cacheData) {
                super.onLoadFromCache(cacheData);
                synchronized (LOCK_TALENT_PLAN) {
                    if (talentPlanModel != null) {
                        talentPlanModel = null;
                    }

                    if (cacheData != null) {
                        talentPlanModel = cacheData;
                        talentPlanModel.setModelStatus(true);

                        UserDetail.UserInfo userInfo = UserService.getInstance().getUserInfo();
                        if (userInfo != null) {
                            //new展示判断逻辑
                            PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                            boolean isClicked = prefsManager.getBoolean(Constants.IS_BOOK_FRAGMENT_TALENT_NEW_CLICKED);

                            boolean isSubscribed = false;

                            if (UserService.getInstance().isLogining() && userInfo.isSubscribePlan() && !TextUtils.isEmpty(talentPlanModel.planDate)) {
                                isSubscribed = true;
                            }

                            if (!isClicked && isSubscribed) {
                                talentPlanModel.showNew = true;
                            } else {
                                talentPlanModel.showNew = false;
                            }
                        }
                    }
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadDataImpl();
                        }
                    });
                }
            }

            @Override
            public void onDataReceived(TalentPlanBookFragmentModel responseData) {
                synchronized (LOCK_TALENT_PLAN) {
                    if (talentPlanModel != null) {
                        talentPlanModel = null;
                    }

                    if (responseData != null) {
                        talentPlanModel = responseData;
                        talentPlanModel.setModelStatus(true);

                        UserService.getInstance().updateTalentPlanUserDetail(responseData.subscribePlan, responseData.planDate);

                        PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                        UserDetail.UserInfo userInfo = UserService.getInstance().getUserInfo();
                        boolean isClicked = prefsManager.getBoolean(Constants.IS_BOOK_FRAGMENT_TALENT_NEW_CLICKED);
                        if (userInfo != null) {
                            //new展示判断逻辑
                            int prefsIssue = prefsManager.getInt(Constants.TALENT_PLAN_ISSUE + userInfo.getUserId(), -2);
                            boolean isSubscribed = false;
                            if (UserService.getInstance().isLogining() && userInfo.isSubscribePlan() && !TextUtils.isEmpty(talentPlanModel.planDate)) {
                                isSubscribed = true;
                            } else {
                                isSubscribed = false;
                            }
                            if (isSubscribed && prefsIssue != -1 && prefsIssue != talentPlanModel.issue) {
                                talentPlanModel.showNew = true;
                                prefsManager.putInt(Constants.TALENT_PLAN_ISSUE + userInfo.getUserId(), talentPlanModel.issue);
                                prefsManager.putBoolean(Constants.IS_BOOK_FRAGMENT_TALENT_NEW_CLICKED, false);
                            } else if (!isClicked && isSubscribed) {
                                talentPlanModel.showNew = true;
                            } else {
                                talentPlanModel.showNew = false;
                            }
                        }
                    }
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadDataImpl();
                        }
                    });
                }
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                reloadDataImpl();
            }
        };

        talentPlanStrongReference.set(talentPlanCallback);
        TalentPlanAPI.getTalentPlanBookFragmentModel(talentPlanStrongReference);

    }

    void loadConfData() {
        if (UserService.getInstance().getCurrentUserLevel() > 0) {
            BookAPI.getBookConfig(new API.CachedResponseHandler<List<BaseModelListVO>>() {
                @Override
                public void onFirstLoadFromCache(List<BaseModelListVO> cachedData) {
                    updateConfigData(cachedData);
                }

                @Override
                public void onSuccess(List<BaseModelListVO> responseData) {
                    updateConfigData(responseData);
                }

                @Override
                public void onFailure(int code, String message) {
                    reloadDataImpl();
                }
            });
        }
    }

    /**
     * 更新配置数据
     * @param data
     */
    private synchronized void updateConfigData(List<BaseModelListVO> data) {
        configList.clear();
        if (data != null && data.size() > 0) {
            configList.addAll(data);
        }
        getHandler().post(new Runnable() {
            @Override
            public void run() {
                reloadDataImpl();
            }
        });
    }

    private static class LoadHistoryDataFlowableOnSubscribe implements FlowableOnSubscribe<List<ReadingHistoryInfo>> {
        @Override
        public void subscribe(FlowableEmitter<List<ReadingHistoryInfo>> e) throws Exception {

            List<ReadingHistory> readingHistoryList = DatabaseManager.getInstance().historyDB().query(4);

            if (readingHistoryList == null || readingHistoryList.isEmpty()) {

                e.onNext(new ArrayList<ReadingHistoryInfo>());

            } else {
                List<ReadingHistoryInfo> readingHistoryInfos = new ArrayList<>();
                for (int i = 0; i < readingHistoryList.size(); i++) {
                    readingHistoryInfos.add(ReadingHistoryInfo.createByReadingHistory(readingHistoryList.get(i)));
                }

                e.onNext(readingHistoryInfos);
            }

            e.onComplete();
        }
    }

    private class LoadHistoryDataConsumer implements Consumer<List<ReadingHistoryInfo>> {
        @Override
        public void accept(List<ReadingHistoryInfo> historyInfos) throws Exception {
            historyList.clear();

            if (historyInfos != null && !historyInfos.isEmpty()) {
                historyList.addAll(historyInfos);
            }

            reloadDataImpl();
        }
    }

    void reloadHistoryData() {

        Flowable.create(new LoadHistoryDataFlowableOnSubscribe(), BackpressureStrategy.BUFFER)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new LoadHistoryDataConsumer());
    }

    void loadSubscribeList() {
        subscribeApi = BookAPI.bookAPI_subscribeList();
        subscribeApi.get(new API.CachedResponseHandler<BookSubscribeListModel>() {
            @Override
            public void onFirstLoadFromCache(BookSubscribeListModel cachedData) {
                updateSubscribeInfo(cachedData);
            }

            @Override
            public void onSuccess(BookSubscribeListModel responseData) {
                updateSubscribeInfo(responseData);
            }

            @Override
            public void onFailure(int code, String message) {
                reloadDataImpl();
            }
        });
    }

    /**
     * 更新书架订阅数据
     * @param data
     */
    private synchronized void updateSubscribeInfo(BookSubscribeListModel data) {
        subscribeList.clear();
        if (data != null) {
            List<BookOtherCollectListModel> chargeList = data.getChargeList();
            if (chargeList != null && chargeList.size() > 0) {
                initChargeExtFlag(chargeList);
                subscribeList.addAll(chargeList);
            }
            List<BookOtherCollectListModel> freeList = data.getFreeList();
            if (freeList != null && freeList.size() > 0) {
                subscribeList.addAll(freeList);
            }
        }
        getHandler().post(new Runnable() {
            @Override
            public void run() {
                reloadDataImpl();
            }
        });
    }

    /**
     * 初始化收费订阅列表extFlag值
     *
     * @param chargeList
     */
    private void initChargeExtFlag(List<BookOtherCollectListModel> chargeList) {
        for (BookOtherCollectListModel model : chargeList) {
            model.setExtFlag((int) Extflag.EXT_FLAG_1024);
        }
    }

    void reloadData() {
        listAPI = new BookAPI.RecommendBookPaginationListAPI("book2", "otherCollectList.json");
        dataListModel = new DataListModel(listAPI, 60);
        reloadData(dataListModel);
    }

    @Override
    protected void initListViewFooter(XRecyclerView listView) {
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }
        SubscribeLoadingMoreFooter footer = new SubscribeLoadingMoreFooter(getContext());
        footer.setType(SubscribeLoadingMoreFooter.TYPE_BOOK);
        footerView = footer;
        listView.setFootView(footer);
    }

    synchronized void reloadDataImpl() {
        List<BaseVO> dataList = getDataListDisplayed().getDataList();
        dataList.clear();

        updateList(dataList);

        dataList.addAll(reassembledList);
        //这里如果只有View_Type_LOOK_AROUND_Title和View_Type_Separator这两个holder，则证明无数据，就不展示
        if (dataList.size() > FIXED_HOLDER_COUNT) {
            notifyDataSetChanged();
        } else {
            handleErrorOccurred(true, 0, "加载数据为空");
        }
    }

    @Override
    public void handleErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg) {
        super.handleErrorOccurred(isFirstPage, errorCode, errorMsg);
        if (getDataListDisplayed().getDataList().size() > FIXED_HOLDER_COUNT) {
            mLoadingView.hide();
        }
        if (isFirstPage) {
            getmListView().setPullRefreshEnabled(true);
        }
    }

    /**
     * 更新列表数据
     *
     * @param dataList
     */
    private void updateList(final List<BaseVO> dataList) {

        if (bannerInfoList != null && bannerInfoList.size() > 0) {
            dataList.addAll(bannerInfoList);
        }

        if (talentPlanModel != null) {
            BaseModelVO talentModelVO = new BaseModelVO();
            talentPlanModel.typeFrom = TalentPlanIsPaidViewHolder.TYPE_BOOK_FRAGMENT;
            talentModelVO.setModel(talentPlanModel);
            talentModelVO.setViewType(View_Type_Talent_Plan_Is_Paid);
            dataList.add(talentModelVO);
        }

        if (subscribeList != null && !subscribeList.isEmpty()) {
            BaseModelVO baseVO = new BaseModelVO();
            baseVO.setViewType(View_Type_Book_Title);
            RedirectInfo redirectInfo = new RedirectInfo();
            redirectInfo.setTitle("我的书架");
            redirectInfo.setImageUrl("res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.icon_book_shelf_title);
            redirectInfo.setRedirectUri("toBookShelf");//只要不为空就行
            baseVO.setModel(redirectInfo);
            dataList.add(baseVO);

            List<BaseVO> dataListTmp = new ArrayList<BaseVO>();
            List<BaseModel> singleLineTmp = new ArrayList<BaseModel>();

            for (int i = 0; i < Math.min(subscribeList.size(), 8); i++) {
                BookOtherCollectListModel model = subscribeList.get(i);
                model.setIndex(i);
                singleLineTmp.add(model);

                if (singleLineTmp.size() >= 3) {
                    BaseModelListVO vo = new BaseModelListVO();
                    vo.setViewType(View_Type_Subscribe_List);
                    vo.setItemList(singleLineTmp);
                    dataListTmp.add(vo);
                    singleLineTmp.clear();
                }
            }

            if (subscribeList.size() > 8) {
                RedirectInfo info = new RedirectInfo();
                info.setRedirectUri(URLScheme.SCHEMA + "://" + URLScheme.REDIRECT_URI_FORMAT_OPENBOOKSHELF);
                info.setImageUrl("res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.book_shelf_more);
                singleLineTmp.add(info);
            }

            // 对不足3条的添加list
            if (!singleLineTmp.isEmpty()) {
                BaseModelListVO vo = new BaseModelListVO();
                vo.setViewType(View_Type_Subscribe_List);
                vo.setItemList(singleLineTmp);
                dataListTmp.add(vo);
                singleLineTmp.clear();
            }


            dataList.addAll(dataListTmp);
        }

        if (historyList != null && historyList.size() > 0) {
            BaseModelListVO baseModelListVO = new BaseModelListVO(View_Type_DataList_BookHistories);
            baseModelListVO.getItemList().addAll(historyList);
            dataList.add(baseModelListVO);
        }

        BaseModelVO baseVO = new BaseModelVO();
        baseVO.setViewType(View_Type_Book_Title);
        RedirectInfo redirectInfo = new RedirectInfo();
        redirectInfo.setTitle("随便看看");
        redirectInfo.setImageUrl("res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.icon_story_recommend);
        baseVO.setModel(redirectInfo);
        dataList.add(baseVO);

        if (configList != null && configList.size() > 0 && UserService.getInstance().getCurrentUserLevel() > 0) {
            dataList.addAll(configList);
        }

        BaseModelVO separatorModel = new BaseModelVO(null, View_Type_Separator);
        dataList.add(separatorModel);
    }


    @Override
    protected void reassembleDisplayedDataList(List<BaseVO> reassembledListTemp, List<BaseModel> itemsAdded, boolean isFirstPage) {
        int index = 0;
        if (isFirstPage) {
            reassembledList.clear();
            updateList(reassembledListTemp);
        }
        if (reassembledListTemp.size() > 0) {
            BaseVO baseVO = reassembledListTemp.get(reassembledListTemp.size() - 1);
            if (baseVO instanceof BaseModelListVO) {
                BaseModelListVO modelListVO = (BaseModelListVO) baseVO;
                if (modelListVO.getItemList().size() < 3) {
                    for (int i = 0; i < itemsAdded.size(); i++) {
                        modelListVO.getItemList().add(itemsAdded.get(i));
                        if (modelListVO.getItemList().size() >= 3) {
                            index = i + 1;
                            break;
                        }

                    }
                }
            }
        }

        List<BaseVO> dataListTmp = new ArrayList<BaseVO>();
        List<BaseModel> singleLineTmp = new ArrayList<BaseModel>();
        for (int i = index; i < itemsAdded.size(); i++) {
            BaseModel model = itemsAdded.get(i);
            model.setIndex(i);
            singleLineTmp.add(model);
            if (singleLineTmp.size() >= 3) {
                addLookAroundModel(dataListTmp, singleLineTmp);
            }
        }

        if (singleLineTmp.size() != 0) {
            addLookAroundModel(dataListTmp, singleLineTmp);
        }

        reassembledListTemp.addAll(dataListTmp);
        reassembledList.addAll(dataListTmp);
    }

    /**
     * 添加随便看看内容model
     *
     * @param dataListTmp
     * @param singleLineTmp
     */
    private void addLookAroundModel(List<BaseVO> dataListTmp, List<BaseModel> singleLineTmp) {
        BaseModelListVO modelListVO = new BaseModelListVO(View_Type_Other_BookList);
        modelListVO.setItemList(singleLineTmp);
        singleLineTmp.clear();
        dataListTmp.add(modelListVO);
    }


    @Override
    protected void doRefresh() {
        super.doRefresh();
        if (!((AuthService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.AUTH_SERVICE)).isAuthorized()) {
            return;
        }
        commonHeaderView.upDateCoinCount();
        loadBannerData();
        loadTalentPlan();
        loadConfData();
        loadSubscribeList();
        reloadHistoryData();
    }

    /**
     * 获取运营弹窗配置信息
     */
    private void getDialogConfigInfo() {
        String isNew = KaDaApplication.IS_NEW_USER ? "1" : "0";
        OtherAPI.getDialogConfig(isNew, new API.ResponseHandler<List<DialogConfigInfo>>() {
            @Override
            public void onSuccess(List<DialogConfigInfo> responseData) {
                if (responseData == null || responseData.isEmpty()) {
                    return;
                }

                PrefsManager prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
                String showIdListStr = prefsManager.getString(ACTIVITY_DIALOG_SHOW_ID_LIST);

                final List<Integer> showIdList = new ArrayList<>();
                Gson gson = new Gson();
                if (!TextUtils.isEmpty(showIdListStr)) {
                    List<Integer> idList = gson.fromJson(showIdListStr, new TypeToken<List<Integer>>() {
                    }.getType());
                    showIdList.addAll(idList);
                }

//                Collections.sort(responseData);

                DialogConfigInfo dialogConfigInfo = null;
                for (DialogConfigInfo info : responseData) {
//                    long timeStart = TimeUtil.date2TimeStamp(info.getTimeBegin());
//                    long timeEnd = TimeUtil.date2TimeStamp(info.getTimeEnd());
//                    long nowTime = System.currentTimeMillis() / 1000;
//                    if (nowTime >= timeStart && nowTime <= timeEnd && !showIdList.contains(info.getRedirectId())) {
//                        dialogConfigInfo = info;
//                        break;
//                    }
                    if (!showIdList.contains(info.getRedirectId())) {
                        dialogConfigInfo = info;
                        break;
                    }
                }

                if (dialogConfigInfo == null) {
                    return;
                }

                final DialogConfigInfo configInfo = dialogConfigInfo;

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        if (getContext() == null || getContext().isFinishing()) {
                            return;
                        }

                        ActivityDialog dialog = new ActivityDialog(getContext());
                        dialog.setShowIdList(showIdList);

                        View coinLayout = commonHeaderView.getCoinLayout();
                        int[] location = new int[2];
                        coinLayout.getLocationOnScreen(location);
                        float translateX = location[0] + coinLayout.getWidth() / 2;
                        dialog.setAnimValue(translateX, coinLayout.getHeight() / 2);

                        DialogManager dialogManager = (DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER);
//                        if (!dialogManager.isDialogShow() && !KaDaApplication.IS_NEW_USER) {
                        dialog.setDialogConfigInfo(configInfo);
                        dialogManager.showDialog(dialog);

                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(configInfo.getRedirectId()), "home_pop_out_view", TimeUtil.currentTime()));
//                        }
                    }
                });
            }

            @Override
            public void onFailure(int code, String message) {

            }
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (listAPI != null) {
            listAPI.cancel();
            listAPI = null;
        }

        if (talentPlanStrongReference != null) {
            talentPlanStrongReference.clear();
            talentPlanStrongReference = null;
        }

        if (subscribeApi != null) {
            subscribeApi.cancel();
            subscribeApi = null;
        }

        if (animator != null) {
            animator.cancel();
            animator = null;
        }

        getHandler().removeCallbacksAndMessages(null);
        EventCenter.fireEvent(new TalentAnimStopEvent());
    }

    @Override
    public void onPause() {
        super.onPause();
        if (commonHeaderView != null) {
            commonHeaderView.doCoinAnim(false);
            commonHeaderView.doMedalAnim(false);
        }

        // 停止动画
        EventBus.getDefault().post(new TalentPlanIsPaidViewHolder.UpdateCrabAnimStatusEvent(false));
    }


    @Override
    public void onResume() {
        super.onResume();
//        checkShowRecommend();
        if (commonHeaderView != null) {
            commonHeaderView.doCoinAnim(true);
            commonHeaderView.doMedalAnim(true);
        }

        // 开启动画
        EventBus.getDefault().post(new TalentPlanIsPaidViewHolder.UpdateCrabAnimStatusEvent(true));
    }

    @Override
    protected void onVisible() {
        super.onVisible();
        if (commonHeaderView != null) {
            commonHeaderView.doCoinAnim(true);
            commonHeaderView.doMedalAnim(true);
        }

    }

    @Override
    protected void onInvisible() {
        super.onInvisible();
        if (commonHeaderView != null) {
            commonHeaderView.doCoinAnim(false);
            commonHeaderView.doMedalAnim(false);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (commonHeaderView != null) {
            commonHeaderView.onDestroyView();
        }

        if (animatorSet != null) {
            if (animatorSet.isRunning()) {
                animatorSet.cancel();
            }
            animatorSet.end();
            animatorSet = null;
        }

    }

    private boolean isDataCompleted = false;
    private boolean isNeedRecordExposureAfterDataCompleted = false;
    private final Object mRecordExposureLock = new Object();
    private boolean isBannerShownOnScreen = true;//Banner是否在屏幕上展示出来了，用以曝光统计

    @Override
    public void handleLoadComplete(boolean hasMoreData) {
        super.handleLoadComplete(hasMoreData);
        synchronized (mRecordExposureLock) {
            isDataCompleted = true;
            if (isNeedRecordExposureAfterDataCompleted) {
                isNeedRecordExposureAfterDataCompleted = false;
                recordExposure();
            }
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            synchronized (mRecordExposureLock) {
                if (isDataCompleted) {
                    recordExposure();
                    EventBus.getDefault().post(new OldBannerShownOnScreenEvent(ExposureTracker.SCENE_BOOK_HOME_BANNER, isBannerShownOnScreen));
                } else {
                    isNeedRecordExposureAfterDataCompleted = true;
                }
            }
        } else {
            EventBus.getDefault().post(new OldBannerShownOnScreenEvent(ExposureTracker.SCENE_BOOK_HOME_BANNER, false));
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_BOOKSHELF);
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_HISTORY);
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_YOUCAI);
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_IP);
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_WATERFALL);
        }
    }

    @Override
    public void onScrollStateChange(RecyclerView view, int scrollState) {
        super.onScrollStateChange(view, scrollState);

        switch (scrollState) {
            // 是当屏幕停止滚动时
            case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:

                //统计曝光
                synchronized (mRecordExposureLock) {
                    if (isDataCompleted) {
                        recordExposure();
                    } else {
                        isNeedRecordExposureAfterDataCompleted = true;
                    }
                }

                if (lastVisibleItemPosition == 0 && isTouched) {
                    isTouched = false;
                    if (animatorSet == null) {
                        animatorSet = new AnimatorSet();
                        ValueAnimator animator = ObjectAnimator.ofFloat(floatIcon, "y", floatIcon.getTop(), 0);
                        ValueAnimator alpha = ObjectAnimator.ofFloat(floatIcon, "alpha", 1.0f, 0.1f);

                        animatorSet.playTogether(animator, alpha);
                        animatorSet.setDuration(600);
                        animatorSet.addListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                                floatIcon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.youyu_stop));
                                floatIcon.setTranslationY(0);
                                floatIcon.setAlpha(1.0f);
                                floatIcon.setVisibility(View.GONE);
                                showIcon = false;
                                isTouched = false;
                            }
                        });
                    }
                    animatorSet.start();
                }
                break;
            default:
                break;
        }
    }

    private void recordExposure() {
        //曝光统计相关注释见MotherExcellentFragment
        final XRecyclerView xRecyclerView = getmListView();
        if (xRecyclerView == null) {
            return;
        }
        final LinearLayoutManager llm = (LinearLayoutManager) xRecyclerView.getLayoutManager();
        if (llm == null) {
            return;
        }
        final RecyclerPagedListDataAdapter adapter = (RecyclerPagedListDataAdapter) xRecyclerView.getAdapter();
        if (adapter == null) {
            return;
        }
        final int first = llm.findFirstVisibleItemPosition();//见下面的【注意】
        final int last = llm.findLastVisibleItemPosition();//见下面的【注意】
        if (first == RecyclerView.NO_POSITION || last == RecyclerView.NO_POSITION) {
            return;
        }

        List<ExposureTracker.ExposureVO> shelfVoList = new ArrayList<>();//10 is ok
        List<ExposureTracker.ExposureVO> historyVoList = new ArrayList<>();//10 is ok
        List<ExposureTracker.ExposureVO> waterfallVoList = new ArrayList<>();//10 is ok
        List<ExposureTracker.ExposureVO> ipVoList = new ArrayList<>();//10 is ok
        List<ExposureTracker.ExposureVO> youcaiVoList = new ArrayList<>();//10 is ok

        boolean hasShelf = false;
        boolean hasHistory = false;
        boolean hasWaterfall = false;
        boolean hasBanner = false;
        boolean hasYoucai = false;
        boolean hasIp = false;
        for (int i = first - 1; i < last; i++) {//偏移一位
            if (i < 0) continue;
            final int itemViewType = adapter.getItemViewType(i);
            final Object item = adapter.getItem(i);
            LogHelper.d(ExposureTracker.TAG, "绘本界面出现第" + i + "个: itemViewType=" + itemViewType + ",item=" + item);
            if (itemViewType == View_Type_Subscribe_List) {
                //书架
                hasShelf = true;
                recordExposureShelf(item, shelfVoList);
            } else if (itemViewType == View_Type_DataList_BookHistories) {
                //历史
                hasHistory = true;
                recordExposureHistory(item, historyVoList);
            } else if (itemViewType == View_Type_Banner) {
                hasBanner = true;
            } else if (itemViewType == View_Type_Talent_Plan_Is_Paid) {
                //已付费才展示的优才
                hasYoucai = true;
                recordExposureYoucai(item, youcaiVoList);
            } else if (itemViewType == ViewTypes.View_Type_DataList_AutoLayout.getId()) {
                //ip
                hasIp = true;
                recordExposureIp(item, ipVoList);
            } else if (itemViewType == View_Type_Other_BookList) {
                //ip
                hasWaterfall = true;
                recordExposureWaterfall(item, waterfallVoList);
            }
        }
        isBannerShownOnScreen = hasBanner;
//        if (!hasBanner) {
//            LogHelper.d(ExposureTracker.TAG, "绘本banner不可见");
//        } else {
//            LogHelper.d(ExposureTracker.TAG, "绘本banner可见");
//        }
        EventBus.getDefault().post(new OldBannerShownOnScreenEvent(ExposureTracker.SCENE_BOOK_HOME_BANNER, isBannerShownOnScreen));

        if (!hasShelf) {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_BOOKSHELF);
        } else {
            ExposureTracker.getInstance().record(ExposureTracker.SCENE_BOOK_HOME_BOOKSHELF, ExposureTracker.EVENT_VIEW, shelfVoList);
        }
        if (!hasHistory) {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_HISTORY);
        } else {
            ExposureTracker.getInstance().record(ExposureTracker.SCENE_BOOK_HOME_HISTORY, ExposureTracker.EVENT_VIEW, historyVoList);
        }
        if (!hasWaterfall) {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_WATERFALL);
        } else {
            ExposureTracker.getInstance().record(ExposureTracker.SCENE_BOOK_HOME_WATERFALL, ExposureTracker.EVENT_VIEW, waterfallVoList);
        }
        if (!hasYoucai) {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_YOUCAI);
        } else {
            ExposureTracker.getInstance().record(ExposureTracker.SCENE_BOOK_HOME_YOUCAI, ExposureTracker.EVENT_VIEW, youcaiVoList);
        }
        if (!hasIp) {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_BOOK_HOME_IP);
        } else {
            ExposureTracker.getInstance().record(ExposureTracker.SCENE_BOOK_HOME_IP, ExposureTracker.EVENT_VIEW, ipVoList);
        }
    }

    private void recordExposureIp(Object item, List<ExposureTracker.ExposureVO> ipVoList) {
        final BaseModelListVO baseVO = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
        if (baseVO != null) {
            final List<BaseModel> itemList = baseVO.getItemList();
            if (itemList != null) {
                for (BaseModel baseModel : itemList) {
                    final RedirectInfo info = baseModel instanceof RedirectInfo ? ((RedirectInfo) baseModel) : null;
                    if (info != null) {
                        ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                        final boolean success = ExposureTracker.getInstance().parseJumpProtocol(info.getRedirectUri(), vo);
                        if (success) {
                            LogHelper.d(ExposureTracker.TAG, "recordExposureIp:" + info.getRedirectUri());
                            ipVoList.add(vo);
                        }
                    }
                }
            }
        }
    }

    private void recordExposureWaterfall(Object item, List<ExposureTracker.ExposureVO> waterfallVoList) {
        final BaseModelListVO listVO = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
        if (listVO != null) {
            final List<BaseModel> itemList = listVO.getItemList();
            if (itemList != null) {
                for (int i = 0; i < itemList.size(); i++) {
                    final BaseModel baseModel = itemList.get(i);
                    final BookOtherCollectListModel bo = baseModel instanceof BookOtherCollectListModel ? ((BookOtherCollectListModel) baseModel) : null;
                    if (bo != null) {
                        ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                        vo.type = ExposureTracker.TYPE_BOOK;
                        if (bo.getType() == BookListItem.TYPE_BOOK) {
                            final BookInfo info = BookOtherCollectListModel.creatBookInfo(bo);
                            vo.collectionId = info.getCollectId();//其实一直为0
                            vo.itemId = info.getBookId();
                        } else {
                            final BookCollectionInfo info = BookOtherCollectListModel.creatBookCollectionInfo(bo);
                            vo.collectionId = info.getCollectId();
                            vo.itemId = 0;
                        }
                        LogHelper.d(ExposureTracker.TAG, "recordExposureWaterfall:" + bo.getSourceId() + "," + bo.getImage());
                        waterfallVoList.add(vo);
                    }

                    if (i >= 3) {
                        break;//最多显示3个
                    }
                }
            }
        }
    }

    private void recordExposureHistory(Object item, List<ExposureTracker.ExposureVO> historyVoList) {
        final BaseModelListVO baseVO = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
        if (baseVO != null) {
            final List<BaseModel> itemList = baseVO.getItemList();
            if (itemList != null) {
                for (int i = 0; i < itemList.size(); i++) {
                    final BaseModel baseModel = itemList.get(i);
                    final ReadingHistoryInfo rhi = baseModel instanceof ReadingHistoryInfo ? ((ReadingHistoryInfo) baseModel) : null;
                    if (rhi != null) {
                        ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                        vo.type = ExposureTracker.TYPE_BOOK;
                        vo.collectionId = rhi.getCollectId();
                        vo.itemId = rhi.getCollectId() == 0 ? rhi.getBookId() : 0;//collectionId不为0则为合辑。合辑的itemId置为0
                        LogHelper.d(ExposureTracker.TAG, "recordExposureShelf,ReadingHistoryInfo:" + rhi.getCoverUrl());
                        historyVoList.add(vo);
                    }

                    if (i >= 4) {
                        break;//最多显示4个
                    }
                }
            }
        }
    }

    private void recordExposureShelf(Object item, List<ExposureTracker.ExposureVO> shelfVoList) {
        BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
        if (model == null) {
            LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
            return;
        }
        final List<BaseModel> itemList = model.getItemList();
        if (itemList == null) {
            return;
        }
        for (int i = 0; i < Math.min(itemList.size(), 3); i++) {//根据SubscribeListViewHolder代码，大于3个是不显示的，不算曝光
            final BaseModel baseModel = itemList.get(i);
            final BookOtherCollectListModel boclm = baseModel instanceof BookOtherCollectListModel ? ((BookOtherCollectListModel) baseModel) : null;
            if (boclm != null) {
                final BookCollectionInfo info = BookOtherCollectListModel.creatBookCollectionInfo(boclm);
                if (info != null) {
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    vo.type = ExposureTracker.TYPE_BOOK;
                    vo.collectionId = info.getCollectId();
                    vo.itemId = 0;
                    LogHelper.d(ExposureTracker.TAG, "recordExposureShelf,BookCollectionInfo:" + info.getName());
                    shelfVoList.add(vo);
                }
            }
        }
    }

    private void recordExposureYoucai(Object item, List<ExposureTracker.ExposureVO> voList) {
        final BaseModelVO baseModelVO = item instanceof BaseModelVO ? ((BaseModelVO) item) : null;
        if (baseModelVO != null) {
            final BaseModel model = baseModelVO.getModel();
            final TalentPlanBookFragmentModel tpbf = model instanceof TalentPlanBookFragmentModel ? ((TalentPlanBookFragmentModel) model) : null;
            if (tpbf != null) {
                List<TalentPlanBookInfo> planBookVOList = tpbf.planBookVOList;
                for (int i = 0; i < Math.min(planBookVOList.size(), 4); i++) {//只会曝光4个
                    final TalentPlanBookInfo tpbi = planBookVOList.get(i);
                    if (tpbi != null) {
                        ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                        vo.type = ExposureTracker.TYPE_BOOK;
                        vo.collectionId = tpbi.getCollectId();
                        vo.itemId = tpbi.getBookId();
                        LogHelper.d(ExposureTracker.TAG, "recordExposureYoucai:" + tpbi.getName());
                        voList.add(vo);
                    }
                }
            }
        }
    }

    @Override
    public void onScroll(RecyclerView recyclerView, int dx, int dy) {
        super.onScroll(recyclerView, dx, dy);

        RecyclerView.LayoutManager layoutManager = recyclerView.getLayoutManager();
        //判断是当前layoutManager是否为LinearLayoutManager
        // 只有LinearLayoutManager才有查找第一个和最后一个可见view位置的方法
        if (layoutManager instanceof LinearLayoutManager) {
            LinearLayoutManager linearManager = (LinearLayoutManager) layoutManager;
            //获取第一个可见view的位置
            int firstItemPosition = linearManager.findFirstVisibleItemPosition();
            if (firstItemPosition > 15) {
                floatIcon.setVisibility(View.VISIBLE);
            } else {
                if (!showIcon) {
                    floatIcon.setVisibility(View.GONE);
                }
            }
        }
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_book_home_view", TimeUtil.currentTime()));
            if (NetworkUtils.isReachable() && tipView.getVisibility() == View.VISIBLE && needPlayTipAinm) {
                startTipAnim(tipView, 30, 0, 2000, true);
            }
        }
    }

    void startTipAnim(final View animView, int from, int scaleY, int delay, final boolean needGone) {

        animator = ObjectAnimator.ofFloat(animView, "translationY", LocalDisplay.dp2px(from), LocalDisplay.dp2px(scaleY));
        animator.setDuration(500);
        animator.setStartDelay(delay);
        animator.setRepeatCount(0);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                getmListView().setTranslationY((float) animation.getAnimatedValue());
            }
        });
        animator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                if (animView.getVisibility() == View.GONE) {
                    animView.setVisibility(View.VISIBLE);
                }
                if (needPlayTipAinm) {
                    needPlayTipAinm = false;
                }
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (needGone) {
                    animView.setVisibility(View.GONE);
                }
                if (!needPlayTipAinm) {
                    needPlayTipAinm = true;
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animator.start();
    }

    void startShowTipViewAnim() {
        if (needPlayTipAinm) {
            startTipAnim(tipView, 0, 30, 0, false);
        }
//        tipView.setVisibility(View.VISIBLE);
//        setInnerViewPadding(0, KaDaApplication.getInstance().getResources().getDimensionPixelOffset(R.dimen.tab_activity_bottom_small_height) + LocalDisplay.dp2px(30), 0, 0);
    }

    void startGoneTipViewAnim() {
        if (needPlayTipAinm) {
            startTipAnim(tipView, 30, 0, 1000, true);
        }
    }

    private void processShelfManageClick(final boolean editing) {
        final Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        String userHabitName;
        if(editing) {//点击了管理按钮
            userHabitName = "book_home_bookshelf_manage_click";
        }else{//点击了“更多”进入书架
            userHabitName = "book_bookshelf_more_view";
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", userHabitName, TimeUtil.currentTime()));

        if(editing){
            ChildrenLockDialog lockDialogEnter = new ChildrenLockDialog(activity);
            lockDialogEnter.setCallback(new ChildrenDialogCallback() {
                @Override
                public void onAnswerRight() {
                    ShelfActivity.start(activity, ShelfActivity.SHELF_TYPE_BOOK, true);
                }

                @Override
                public void onDirectDismiss() {
                }
            });
            lockDialogEnter.show();
        }else{
            ShelfActivity.start(activity, ShelfActivity.SHELF_TYPE_BOOK, false);
        }
    }

    private void processBookHistoryItemClicked(int position, ReadingHistoryInfo historyInfo) {
        if (historyInfo == null) {
            return;
        }

        Activity context = getContext();
        if (context == null || context.isFinishing()) {
            return;
        }

        if (historyInfo.getBookId() == -1) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_book_home_history_more_click", TimeUtil.currentTime()));
            FragmentUtil.presentFragment(BookHistoryFragment.class, null, true);
        } else {
            if (historyInfo.getCollectId() != 0) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("2" + "," + historyInfo.getCollectId(), "child_book_home_history_click_" + position, TimeUtil.currentTime()));
                FragmentUtil.pushFragment(BookCollectionFragment.class, new BaseCollectionFragment.CollectionModel(historyInfo.getCollectId(), true), true);
            } else {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1" + "," + historyInfo.getBookId(), "child_book_home_history_click_" + position, TimeUtil.currentTime()));
                PlaybackActivity.startActivity(context, historyInfo.getBookId(), historyInfo.getVersion(), historyInfo.getCoverUrl(), historyInfo.getReadCurrentPage());

                UserTrack.track(UserTrack.fubh);
            }
        }
    }

    private void processBookSubscribeItemClicked(BookCollectionInfo info) {
        if (info == null) {
            return;
        }
        Activity context = getContext();
        if (context == null || context.isFinishing()) {
            return;
        }
        String name = "child_book_home_bookshelf_click_" + info.getIndex();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getCollectId() + "", name, TimeUtil.currentTime()));
        FragmentUtil.pushFragment(BookCollectionFragment.class, new BaseCollectionFragment.CollectionModel(info.getCollectId(), true), true);
    }

}

