package com.hhdd.kada.main.ui.book;

import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;

import butterknife.BindView;

/**
 * Created by sxh on 2018/8/15 14:22
 * E-Mail：820793721@qq.com
 */
public class BookCollectResumeViewHolder extends BaseViewHolder<BaseModelVO> {

    public static final int TYPE_BOOK_RESUME_CLICKED = 300;

    @BindView(R.id.name)
    TextView name;
    @BindView(R.id.container)
    LinearLayout container;


    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_story_collect_resume;
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(LocalDisplay.SCREEN_WIDTH_PIXELS, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(params);
        container.setOnClickListener(listener);
        return rootView;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        if (itemData != null && itemData.getModel() != null && itemData.getModel() instanceof BookInfo) {
            BookInfo info = (BookInfo) itemData.getModel();
            if (name != null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("继续播放：《");
                stringBuilder.append(info.getName());
                stringBuilder.append("》");
                name.setText(stringBuilder.toString());
            }
        }
    }

    View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (mOnEventProcessor == null) {
                return;
            }
            mOnEventProcessor.process(TYPE_BOOK_RESUME_CLICKED);
        }
    };
}
