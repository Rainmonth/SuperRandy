package com.hhdd.kada.main.ui.book;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.download.DownloadStatus;
import com.hhdd.kada.main.views.base.BaseLinearLayout;

import butterknife.BindView;

/**
 * Created by sxh on 2017/7/27.
 */

public class BookCollectionTitleBar extends BaseLinearLayout {

    @BindView(R.id.shareLayout)
    FrameLayout shareLayout;
    @BindView(R.id.btn_download)
    ImageView btnDownload;
    @BindView(R.id.downloadLayout)
    FrameLayout downloadLayout;
    @BindView(R.id.titleView)
    TextView titleView;
    @BindView(R.id.title_container)
    RelativeLayout titleContainer;

    public BookCollectionTitleBar(Context context) {
        super(context);
    }

    public BookCollectionTitleBar(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.view_holder_book_collecion_title_bar;
    }

    @Override
    public void doInitListener() {
        shareLayout.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                onChildViewClick(v, 100);
            }
        });

        downloadLayout.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                onChildViewClick(v, 100);
            }
        });
    }

    public void initialize(int type) {
        if (type == 1) {
            downloadLayout.setVisibility(VISIBLE);
        } else {
            downloadLayout.setVisibility(GONE);
        }
        int rightPadding = downloadLayout.getVisibility() == VISIBLE ? LocalDisplay.dp2px(40) : 0;
        titleView.setPadding(0, 0, rightPadding, 0);
    }

    public void setResIdByStatus(int status) {
        if (status == DownloadStatus.STATUS_DOWNLOADING) {
            btnDownload.setImageResource(R.drawable.icon_download_pause);
        } else if (status == DownloadStatus.STATUS_PAUSED) {
            btnDownload.setImageResource(R.drawable.book_download_all);
        } else if (status == DownloadStatus.STATUS_COMPLETE) {
            btnDownload.setImageResource(R.drawable.book_download_all);
        }
    }

    public void updateTitle(String title) {
        titleView.setText(title);
    }

}
