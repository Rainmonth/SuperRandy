package com.hhdd.kada.main.ui.book;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.model.ReadingHistoryInfo;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.BookService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.android.library.views.list.SpacesItemDecoration;
import com.hhdd.kada.db.main.entities.ReadingHistory;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.BookHistoryViewHolder;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.views.NoDoubleClickListener;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.medal.UserTrack;
import com.hhdd.kada.widget.support.KdGridLayoutManager;
import com.hhdd.logger.LogHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lj on 17/2/8.
 */

public class BookHistoryFragment extends RecyclerDataListFragment2 {

    static final int View_Type_Item = 100;

    BaseViewHolderCreator viewHolderCreator;
    private ImageView btnBack;
    private TextView historyNum;
    private TextView historyTime;

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case BookHistoryViewHolder.TYPE_BOOK_HISTORY_ITEM_CLICKED:
                    try {
                        processHistoryItemClicked((ReadingHistoryInfo) args[0]);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }

                    return true;
            }
            return false;
        }
    };

    public BookHistoryFragment() {
        super(LIST_MODE_NONE, "", null);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }

        initView();

        showLoadingView();
        reloadData();

        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {
            public void onEvent(BookService.SyncReadingHistoryDoneEvent event) {
                reloadData();
            }
        }).tryToRegisterIfNot();
    }

    private StrongReference<DefaultCallback<UserDetail>> mLoadUserDetailCallbackRef;

    private void reloadData() {
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                reloadHistoryData();
            }
        }, 1000);

        historyNum.setText(KaDaApplication.getInstance().getResources().getString(R.string.book_history_title_count, UserService.getInstance().currentUserReadNumber()));
        historyTime.setText(KaDaApplication.getInstance().getResources().getString(R.string.book_history_title_time, TimeUtil.formatListenTime(UserService.getInstance().currentUserReadTimes())));

        DefaultCallback<UserDetail> callback = new DefaultCallback<UserDetail>() {
            @Override
            public void onDataReceived(UserDetail data) {
                if (data != null) {
                    UserService.getInstance().setUserDetail(data);
                    historyNum.setText(KaDaApplication.getInstance().getResources().getString(R.string.book_history_title_count, data.getReadInfo().getTotalCount()));
                    historyTime.setText(KaDaApplication.getInstance().getResources().getString(R.string.book_history_title_time, TimeUtil.formatListenTime(data.getReadInfo().getReadTimes())));
                }
            }

            @Override
            public void onException(String reason) {
                super.onException(reason);
            }
        };

        if (mLoadUserDetailCallbackRef == null) {
            mLoadUserDetailCallbackRef = new StrongReference<>();
        }
        mLoadUserDetailCallbackRef.set(callback);

        UserService.getInstance().loadUserDetail(mLoadUserDetailCallbackRef, false);
    }


    void initView() {
        initTitleBar();

        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(View_Type_Item, BookHistoryViewHolder.class);
        viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(viewHolderCreator);

        getmListView().setLayoutManager(new KdGridLayoutManager(getContext(), 4));
        SpacesItemDecoration decoration = new SpacesItemDecoration(LocalDisplay.dp2px(3));
        getmListView().addItemDecoration(decoration);
        getmListView().setPadding(LocalDisplay.dp2px(3), 0, LocalDisplay.dp2px(3), 0);
        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {

            public void onEvent(BookService.ReadingHistoryUpdatedEvent event) {
                reloadData();
            }
        }).tryToRegisterIfNot();
    }

    protected void initTitleBar() {
        View headview = inflater.inflate(R.layout.activitiy_history_headview, null);
        btnBack = (ImageView) headview.findViewById(R.id.back);
        historyNum = (TextView) headview.findViewById(R.id.listen_num);
        historyTime = (TextView) headview.findViewById(R.id.listen_time);
        btnBack.setOnClickListener(new NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                onBackPressed();
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            headview.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
            ViewGroup.LayoutParams layoutParams = headview.getLayoutParams();
            if (layoutParams==null){
                layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            layoutParams.height = LocalDisplay.dp2px(80)+LocalDisplay.SCREEN_STATUS_HEIGHT;
            headview.setLayoutParams(layoutParams);
            setInnerViewPadding(0, LocalDisplay.dp2px(80) + LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
        }else {
            setInnerViewPadding(0, LocalDisplay.dp2px(80) , 0, 0);
        }
        getInnerContainer().addView(headview);
    }

    void reloadHistoryData() {
        //========历史听书=========
        List<ReadingHistory> readingHistoryList = DatabaseManager.getInstance().historyDB().query(-1);

        if (readingHistoryList != null && readingHistoryList.size() > 0) {
            List<ReadingHistoryInfo> historyList = new ArrayList<>();
            for (int i = 0; i < readingHistoryList.size(); i++) {
                historyList.add(ReadingHistoryInfo.createByReadingHistory(readingHistoryList.get(i)));
                historyList.get(i).setIndex(i);
            }
            if (historyList.size() > 0) {
                List<BaseModel> historyVOList = new ArrayList<>();
                for (int i = 0; i < historyList.size(); i++) {
                    BaseModelVO vo = new BaseModelVO(historyList.get(i), View_Type_Item);
                    historyVOList.add(vo);
                }
                reloadData(historyVOList);
            }
        }
    }

    private void processHistoryItemClicked(ReadingHistoryInfo info) {
        if (info == null) {
            return;
        }

        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (info.getCollectId() > 0) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("2" + "," + info.getCollectId(), "child_book_history_list_click_" + info.getIndex(), TimeUtil.currentTime()));
            FragmentUtil.pushFragment(BookCollectionFragment.class, info.getCollectId(), true);
        } else {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1" + "," + info.getBookId(), "child_book_history_list_click_" + info.getIndex(), TimeUtil.currentTime()));
            PlaybackActivity.startActivity(getActivity(), info.getBookId(), info.getVersion(), info.getCoverUrl(), info.getReadCurrentPage());

            UserTrack.track(UserTrack.fubh);
        }
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_book_history_list_view", TimeUtil.currentTime()));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mLoadUserDetailCallbackRef != null) {
            mLoadUserDetailCallbackRef.clear();
            mLoadUserDetailCallbackRef = null;
        }
    }
}

