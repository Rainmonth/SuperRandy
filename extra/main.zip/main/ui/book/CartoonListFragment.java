package com.hhdd.kada.main.ui.book;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.API;
import com.hhdd.kada.main.common.DataListModel;
import com.hhdd.kada.main.common.FragParamData;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.OrganizationInfo;
import com.hhdd.kada.main.ui.activity.WebViewActivity;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.organization.OrganizationAPI;
import com.hhdd.logger.LogHelper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by mcx on 2017/7/28.
 */

public class CartoonListFragment extends RecyclerDataListFragment2 {

    static final int View_Type_Item_Cartoon = 100;
    BaseViewHolderCreator viewHolderCreator;

    API.PaginationUrlAPI mUrlAPI;
    DataListModel dataListModel;
    int type = OrganizationAPI.ORG_TYPE_BOOK;
    private String title;

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case CartoonListViewHolder.TYPE_CARTOON_ITEM_CLICKED:
                    try {
                        processCartoonItemClicked((OrganizationInfo) args[0]);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }

                    return true;
            }
            return false;
        }
    };

    public CartoonListFragment() {
        super(LIST_MODE_BOTH, "", null);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        initView();

        showLoadingView();
        reloadData();

    }

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        if (data != null && data instanceof FragParamData) {
            title = ((FragParamData) data).title;
            type = (int) ((FragParamData) data).paramObject;
        }
    }

    void initView() {
        if (TextUtils.isEmpty(title)) {
            title = "卡通人物";
        }
        useTitleBar(title);

        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(View_Type_Item_Cartoon, CartoonListViewHolder.class);
        viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(viewHolderCreator);


        setBackgroundColor(KaDaApplication.getInstance().getResources().getColor(R.color.white));
        footerView.setTextColor(KaDaApplication.getInstance().getResources().getColor(R.color.color_6c6c6c));

        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }
    }

    private void reloadData() {
        mUrlAPI = new OrganizationAPI.OrgInfoPaginationListAPI("organization", "getOrgList.json", type);
        dataListModel = new DataListModel(mUrlAPI, 60);
        reloadData(dataListModel);
    }

    @Override
    protected void reassembleDisplayedDataList(List<BaseVO> dataListDisplayed, List<BaseModel> itemsAdded, boolean isFirstPage) {
        if (dataListDisplayed == null || itemsAdded == null) return;

        for (int i = 0; i < itemsAdded.size(); i++) {
            BaseModel model = itemsAdded.get(i);
            if (model instanceof OrganizationInfo) {
                model.setIndex(i);
                BaseModelVO vo = new BaseModelVO(model, View_Type_Item_Cartoon);
                dataListDisplayed.add(vo);
            }
        }
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "book_ip_view", TimeUtil.currentTime()));
        }
    }

    private void processCartoonItemClicked(OrganizationInfo info) {
        if (info == null) {
            return;
        }

        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getOrgId() + "", "book_ip_list_click_" + info.getIndex(), TimeUtil.currentTime()));
        WebViewActivity.startActivity(activity, API.BOOK_CARTOON_DETAIL_URL() + info.getOrgId());
    }

}
