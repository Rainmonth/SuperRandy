package com.hhdd.kada.main.ui.book;

import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.download.DownloadItemType;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.model.BookListItem;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

/**
 * Created by sxh on 2017/7/27.
 */

public class BookCollectionListViewHolder extends BaseViewHolder<BaseModelListVO> {

    public static final int TYPE_BOOK_ITEM_CLICKED = 100;

    @BindView(R.id.book_one)
    BookItemView bookOne;
    @BindView(R.id.book_two)
    BookItemView bookTwo;
    @BindView(R.id.book_three)
    BookItemView bookThree;
    @BindView(R.id.container)
    LinearLayout container;
    private int mWidth;

    @Override
    protected int getLayoutId() {
        return R.layout.book_item_single;
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(params);
        mWidth = (LocalDisplay.SCREEN_WIDTH_PIXELS - 2 * LocalDisplay.dp2px(7) - 6 * LocalDisplay.dp2px(4)) / 3;
        bookOne.setViewSize(mWidth);
        bookTwo.setViewSize(mWidth);
        bookThree.setViewSize(mWidth);
        return rootView;
    }

    @Override
    public void showData(int position, final BaseModelListVO itemData) {
        if (itemData != null && itemData.getItemList() != null && itemData.getItemList().size() > 0) {
            for (int i = 0; i < itemData.getItemList().size(); i++) {
                if (itemData.getItemList().get(i) instanceof BookListItem) {
                    if (itemData.getItemList().size() == 1) {
                        bookOne.setVisibility(View.VISIBLE);
                        bookTwo.setVisibility(View.INVISIBLE);
                        bookThree.setVisibility(View.INVISIBLE);
                    } else if (itemData.getItemList().size() == 2) {
                        bookOne.setVisibility(View.VISIBLE);
                        bookTwo.setVisibility(View.VISIBLE);
                        bookThree.setVisibility(View.INVISIBLE);
                    } else {
                        bookOne.setVisibility(View.VISIBLE);
                        bookTwo.setVisibility(View.VISIBLE);
                        bookThree.setVisibility(View.VISIBLE);
                    }
                    final BookListItem info = (BookListItem) itemData.getItemList().get(i);
                    if (info.getData() instanceof BookInfo) {
                        final BookItemView bookItemView = (BookItemView) container.getChildAt(i);
                        bookItemView.setSubscribeStatus(info.getSubscribeStatus());
                        final BookInfo bookInfo = (BookInfo) info.getData();
                        String tag = "" + ((BookInfo) info.getData()).getBookId() + "_" + DownloadItemType.BOOK;
                        bookItemView.setTag(tag);
                        info.setItemView(bookItemView);
                        bookItemView.update(bookInfo);
                        bookItemView.setTag(R.id.container, bookInfo);
                        bookItemView.bookCover.setBackgroundDrawable(null);
                        bookItemView.showDatabaseFlag();
                        bookItemView.clearBackground();
                        bookItemView.showCollectionParam();
                        bookItemView.bookCover.setPadding(0, 0, 0, 0);
                        bookItemView.setOnClickListener(onItemClickedListener);
                    }
                }
            }
        }
    }

    private KaDaApplication.OnClickWithAnimListener onItemClickedListener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            BookInfo bookInfo = (BookInfo) v.getTag(R.id.container);
            if (bookInfo == null) {
                return;
            }

            mOnEventProcessor.process(TYPE_BOOK_ITEM_CLICKED, bookInfo);
        }
    };


}
