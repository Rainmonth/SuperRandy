package com.hhdd.kada.main.ui.book;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.generic.GenericDraweeHierarchy;
import com.facebook.drawee.generic.RoundingParams;
import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.db.main.entities.BookCollectionItemStatus;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.model.BookListItem;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.story.CircleProgressBar;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.base.BaseDataFrameLayout;
import com.hhdd.kada.module.search.model.vo.SearchResultChildItemVo;
import com.hhdd.kada.module.search.model.vo.SearchResultItemVo;

import java.io.Serializable;

import butterknife.BindView;

/**
 * Created by sxh on 2017/7/27.
 */

public class BookItemView extends BaseDataFrameLayout<BaseModel> implements Serializable {

    @BindView(R.id.book_left_border)
    ImageView bookLeftBorder;
    @BindView(R.id.flag_money_image)
    View flagMoneyImage;
    @Nullable
    @BindView(R.id.flag_new)
    ImageView flagNew;
    @Nullable
    @BindView(R.id.flag_hasRead)
    TextView flagHasRead;
    @Nullable
    @BindView(R.id.flag_hasDownloaded)
    ImageView flagHasDownloaded;
    @BindView(R.id.lock_view)
    ImageView lockView;
    @BindView(R.id.lock_view_container)
    FrameLayout lockViewContainer;
    @BindView(R.id.container)
    FrameLayout container;
    @Nullable
    @BindView(R.id.download_progress_per)
    CircleProgressBar downloadProgressPer;
    @Nullable
    @BindView(R.id.alpha_container2)
    FrameLayout alphaContainer2;
    @BindView(R.id.gold_border)
    ImageView goldBorder;
    @BindView(R.id.book_cover)
    SimpleDraweeView bookCover;
    @Nullable
    @BindView(R.id.book_subscribe_border)
    ImageView subscribeBorder;
//    @BindView(R.id.flag_hot)
//    ImageView flagHot;

    private BaseModel info;
    protected int subscribeStatus;

    private int currentType;   //当前数据类型

    int mItemWidth;
    int mItemHeight;
    private BookCollectionItemStatus itemStatus;

    private boolean isAllShowCrown = false; // 是否单本、合辑收费图片都显示皇冠样式

    private int radius = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.book_cover_corner_radius));

    public int getSubscribeStatus() {
        return subscribeStatus;
    }

    public void setSubscribeStatus(int subscribeStatus) {
        this.subscribeStatus = subscribeStatus;
    }

    public BookItemView(Context context) {
        super(context);
    }

    public BookItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.book_item_view;
    }

    @Override
    public void doInitView() {
        setViewSize((LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(7 * 2 + 5 * 6)) / 3);
        setLockRadius(LocalDisplay.dp2px(6));
    }

    public void setViewSize(int width) {
        mItemWidth = width;
        mItemHeight = (int) (mItemWidth * 32.0f / 25.0f);
        LayoutParams params = new LayoutParams(mItemWidth, mItemHeight);
        container.setLayoutParams(params);
    }

    @Override
    public void update(BaseModel data) {
        update(data, true);
    }

    public void update(BaseModel data, boolean isShowFlag, int width, int height) {
        if (data != null) {
            info = data;
            if (data instanceof BookInfo) {
                BookInfo info = (BookInfo) data;
                currentType = BookListItem.TYPE_BOOK;
                setBackground(currentType);
                showCover(info.getCoverUrl(), width, height);
                if (isShowFlag) {
                    showFlag(info.getExtFlag());
                }
            } else if (data instanceof BookCollectionInfo) {
                BookCollectionInfo info = (BookCollectionInfo) data;
                currentType = BookListItem.TYPE_BOOK_COLLECTION;
                setBackground(currentType);
                showCover(info.getCoverUrl(), width, height);
                if (isShowFlag) {
                    showFlag(info.getExtFlag());
                }
            } else if (data instanceof SearchResultItemVo) {
                SearchResultItemVo itemVo = (SearchResultItemVo) data;
                if (itemVo.sourceType == 1) {
                    currentType = BookListItem.TYPE_BOOK;
                } else if (itemVo.sourceType == 2) {
                    currentType = BookListItem.TYPE_BOOK_COLLECTION;
                } else {
                    return;
                }

                setBackground(currentType);
                showCover(itemVo.coverUrl, width, height);
                if (isShowFlag) {
                    showFlag((int) itemVo.extFlag);
                }
            } else if (data instanceof RedirectInfo) {
                //更多-跳转到书架
                currentType = BookListItem.TYPE_BOOK;
                RedirectInfo info = (RedirectInfo) data;
                bookCover.setBackground(null);
                showCover(info.getImageUrl());

                //隐藏复用的图标
                if (alphaContainer2 != null) {
                    alphaContainer2.setVisibility(GONE);
                }
                if (flagHasDownloaded != null) {
                    flagHasDownloaded.setVisibility(GONE);
                }
                lockViewContainer.setVisibility(GONE);
                flagMoneyImage.setVisibility(GONE);
                goldBorder.setVisibility(GONE);
                bookLeftBorder.setVisibility(GONE);

            }
        }
    }

    public void update(BaseModel data, boolean isShowFlag) {
        update(data, isShowFlag, 0, 0);
    }

    public void update(SearchResultChildItemVo itemVo, boolean isShowFlag, int width, int height) {
        if (itemVo == null) {
            return;
        }

        currentType = BookListItem.TYPE_BOOK;
        setBackground(currentType);
        showCover(itemVo.coverUrl, width, height);

        if (isShowFlag) {
            showFlag((int) itemVo.extFlag);
        }
    }

    //设置背景
    public void setBackground(int type) {
        bookLeftBorder.setVisibility(VISIBLE);
        if (type == BookListItem.TYPE_BOOK) {
            bookCover.setBackgroundResource(R.drawable.bg_single_book);
//            bookLeftBorder.setImageResource(R.drawable.icon_book_left_border_single);
            //v3.6.0去除单本书脊
            bookLeftBorder.setImageDrawable(null);
        } else if (type == BookListItem.TYPE_BOOK_COLLECTION) {
            bookCover.setBackgroundResource(R.drawable.bg_collect_book);
            bookLeftBorder.setImageResource(R.drawable.book_left_border);
        }
    }

    public void clearBackground() {
        bookLeftBorder.setVisibility(GONE);
    }

    /**
     * 绘本合集显示为最先样式，圆角，无底
     */
    public void showCollectionParam() {
        setCoverRadius(radius);

        bookCover.getHierarchy().setPlaceholderImage(R.drawable.icon_book_collection_default);
    }

    protected void setCoverRadius(int radius) {
        setCoverRadius(radius, radius, radius, radius);
    }

    protected void setCoverRadius(int leftTopRadius, int rightTopRadius, int rightBottomRadius, int leftBottomRadius) {
        GenericDraweeHierarchy hierarchy = bookCover.getHierarchy();
        RoundingParams params = hierarchy.getRoundingParams();
        if (params == null) {
            params = new RoundingParams();
        }
        params.setCornersRadii(leftTopRadius, rightTopRadius, rightBottomRadius, leftBottomRadius);
        hierarchy.setRoundingParams(params);
    }

    //设置cover
    public void showCover(String coverUrl) {
        showCover(coverUrl, 0, 0);
    }

    public void showCover(String coverUrl, int width, int height) {
        if (TextUtils.isEmpty(coverUrl)) {
            return;
        }

        setCoverRadius(0, radius, radius, 0);
        boolean needResetImageUrl = true;
        Object tag = bookCover.getTag(R.id.book_cover);
        if (tag != null) {
            String url = (String) tag;
            if (TextUtils.equals(url, coverUrl)) {
                needResetImageUrl = false;
            }
        }

        if (needResetImageUrl) {
            bookCover.setTag(R.id.book_cover, coverUrl);

            String imgUrl = CdnUtils.getImgCdnUrl(coverUrl, CdnUtils.getBookCoverSize(), true);
            FrescoUtils.showImg(bookCover, imgUrl, width, height);
        }
    }

    //已读标志   已下载标志(因为涉及到查询数据库，比较耗性能，所以用的地方直接调用，不统一处理)
    public void showDatabaseFlag() {
        if (info instanceof BookInfo) {
            boolean isHideLock = (((BookInfo) info).getExtFlag() & Extflag.EXT_FLAG_8192) == Extflag.EXT_FLAG_8192 || subscribeStatus == 1;
            //已读标志 加锁不显示已读标志
            if (isHideLock && DatabaseManager.getInstance().historyDB().exist(((BookInfo) info).getBookId(), ((BookInfo) info).getCollectId())) {
                flagHasRead.setVisibility(VISIBLE);
            } else {
                flagHasRead.setVisibility(GONE);
            }

            //已下载标志
            if (((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).isDownloadCompletion(((BookInfo) info).getBookId())) {
                // 1、检查单本下载表记录
                flagHasDownloaded.setVisibility(VISIBLE);
            } else if (DatabaseManager.getInstance().bookCollectionItemStatusDB().isDownloadFinish(((BookInfo) info).getBookId())) {
                // 2、检查合辑状态表
                flagHasDownloaded.setVisibility(VISIBLE);
            } else {
                flagHasDownloaded.setVisibility(GONE);
            }
        }
    }

    public void setLockRadius(float radius) {
        setLockRadius(radius, radius, radius, radius);
    }

    public void setLockRadius(float leftTopRadius, float rightTopRadius, float rightBottomRadius, float leftBottomRadius) {
        Drawable drawable = lockViewContainer.getBackground();
        if (drawable != null && drawable instanceof GradientDrawable) {
            GradientDrawable lockDrawable = (GradientDrawable) drawable;
            lockDrawable.setCornerRadii(new float[]{leftTopRadius, leftTopRadius, rightTopRadius, rightTopRadius,
                    rightBottomRadius, rightBottomRadius, leftBottomRadius, leftBottomRadius});
            lockViewContainer.setBackgroundDrawable(lockDrawable);
        }
    }

    //设置相关标签（new标志、锁等）

    /**
     * 设置相关标签，new标志，金框，收费(限免)，蒙层锁
     *
     * @param extflag
     */
    public void showFlag(int extflag) {
        LayoutParams goldBorderParams = (LayoutParams) goldBorder.getLayoutParams();
        if (currentType == BookListItem.TYPE_BOOK) {
            //默认隐藏下载相关标志
            alphaContainer2.setVisibility(GONE);
            flagHasDownloaded.setVisibility(GONE);
            //锁标志
            if ((extflag & Extflag.EXT_FLAG_8192) == Extflag.EXT_FLAG_8192 || subscribeStatus == 1) {
                lockViewContainer.setVisibility(GONE);
                flagMoneyImage.setVisibility(GONE);
            } else {
                if (!isAllShowCrown) {
                    lockViewContainer.setVisibility(VISIBLE);

                    flagMoneyImage.setVisibility(GONE);

                } else { // 显示皇冠样式
                    lockViewContainer.setVisibility(GONE);

                    int rightMargin = LocalDisplay.dp2px(2.5f);
                    int bottomMargin = LocalDisplay.dp2px(2.5f);
                    LayoutParams flagMoneyImageParams = (LayoutParams) flagMoneyImage.getLayoutParams();
                    flagMoneyImageParams.width = LocalDisplay.dp2px(21);
                    flagMoneyImageParams.height = LocalDisplay.dp2px(21);
                    flagMoneyImageParams.setMargins(0, 0, rightMargin, bottomMargin);
                    flagMoneyImage.setVisibility(VISIBLE);
                }
            }
            showNewFlag(extflag);

            goldBorder.setVisibility(GONE);
        } else if (currentType == BookListItem.TYPE_BOOK_COLLECTION) {
            showNewFlag(extflag);
            //收费标志
            if ((extflag & Extflag.EXT_FLAG_1024) == Extflag.EXT_FLAG_1024) {
                int rightMargin = LocalDisplay.dp2px(5);
                int bottomMargin = LocalDisplay.dp2px(6.2f);
                LayoutParams flagMoneyImageParams = (LayoutParams) flagMoneyImage.getLayoutParams();
                flagMoneyImageParams.setMargins(0, 0, rightMargin, bottomMargin);
                flagMoneyImage.setVisibility(VISIBLE);
                goldBorderParams.setMargins(0, 0, rightMargin, bottomMargin);
                goldBorder.setVisibility(VISIBLE);
                setCoverRadius(LocalDisplay.dp2px(5));
            } else {
                flagMoneyImage.setVisibility(GONE);
                goldBorder.setVisibility(GONE);
            }
            lockViewContainer.setVisibility(GONE);
        }
    }

    /**
     * 显示新标志
     *
     * @param extflag
     */
    private void showNewFlag(int extflag) {
        //new标志
        if ((extflag & Extflag.EXT_FLAG_64) == Extflag.EXT_FLAG_64) {
            flagNew.setVisibility(VISIBLE);
        } else {
            flagNew.setVisibility(GONE);
        }
    }

    //设置下载进度条
    public void updateProgress(int progress) {
        if (progress >= 100) {
            alphaContainer2.setVisibility(GONE);
            flagHasDownloaded.setVisibility(VISIBLE);
        } else {
            alphaContainer2.setVisibility(VISIBLE);
            downloadProgressPer.setProgress(progress);
            flagHasDownloaded.setVisibility(INVISIBLE);
        }
    }

    //隐藏下载进度条
    public void hideDownloadContainer() {
        alphaContainer2.setVisibility(GONE);
    }

    //已下载是否显示
    public boolean isAlreadyShowDownloadFinished() {
        return flagHasDownloaded.getVisibility() == VISIBLE;

    }

    //显示、隐藏订阅边框
    public void showSubscribeBorder(int visible){
        subscribeBorder.setVisibility(visible);
    }

    /**
     * 设置单本、合辑收费样式是否都显示皇冠样式
     *
     * @param allShowCrown
     */
    public void setAllShowCrown(boolean allShowCrown) {
        isAllShowCrown = allShowCrown;
    }
}
