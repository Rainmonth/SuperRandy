package com.hhdd.kada.main.ui.book;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.module.talentplan.model.TalentPlanBookInfo;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/3/12
 * @describe : com.hhdd.kada.main.ui.book
 */
public class TalentBookItemView extends BookItemView {

    @BindView(R.id.icon_talent_plan_clock)
    ImageView iconTalentPlanClock;
    @BindView(R.id.flag_money)
    TextView flagMoney;
    @BindView(R.id.flag_money_image)
    ImageView flagMoneyImage;

    public TalentBookItemView(Context context) {
        super(context);
    }

    public TalentBookItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.talent_book_item_view;
    }

    @Override
    public void update(BaseModel data) {
        super.update(data);
    }

    @Override
    public void update(BaseModel data, boolean isShowFlag, int width, int height) {
        if (data != null) {
            TalentPlanBookInfo info = (TalentPlanBookInfo) data;
            //v3.6.0去除单本书脊
//            bookLeftBorder.setImageResource(R.drawable.book_left_border);
            bookCover.setBackgroundResource(R.drawable.bg_single_book);
            showCover(info.getCoverUrl(), width, height);
            if (isShowFlag) {
                showFlag(info.getExtFlag());
            }
        }
    }

    /**
     * 设置金框 付费标志 蒙层锁
     *
     * @param extflag
     */
    @Override
    public void showFlag(int extflag) {
        String freeLimitStr = getResources().getString(R.string.talent_flag_free_limit);
//        String chargeStr = getResources().getString(R.string.talent_flag_charge);
        //锁标志 收费标志
        if ((extflag & Extflag.EXT_FLAG_8192) == Extflag.EXT_FLAG_8192 || subscribeStatus == 1) {
            if(subscribeStatus == 1) {
//                flagMoney.setText(chargeStr);
                flagMoney.setVisibility(GONE);
                flagMoneyImage.setVisibility(VISIBLE);
            } else {
                flagMoney.setText(freeLimitStr);
                flagMoney.setVisibility(VISIBLE);
                flagMoneyImage.setVisibility(GONE);
            }
            lockViewContainer.setVisibility(GONE);
        } else {
//            flagMoney.setText(chargeStr);
            flagMoney.setVisibility(GONE);
            flagMoneyImage.setVisibility(VISIBLE);
            lockViewContainer.setVisibility(VISIBLE);
        }
    }

    /**
     * 显示锁标志
     *
     * @param lockFlag 0默认，不展示蒙层锁，1展示蒙层不展示锁，2展示蒙层展示锁
     */
    public void showTalentPlanLockView(int lockFlag) {
        lockView.setVisibility(VISIBLE);
        if (lockFlag != -1) {
            //非试读页面，标志均显示为付费(其实客户端仅根据extFlag判断显示限免还是付费，其它这些逻辑交给服务端处理更灵活...)
//            String chargeStr = getResources().getString(R.string.talent_flag_charge);
//            flagMoney.setText(chargeStr);
            flagMoney.setVisibility(GONE);
            flagMoneyImage.setVisibility(VISIBLE);
        }
        iconTalentPlanClock.setVisibility(GONE);
        if (lockFlag > 0) {
            lockViewContainer.setVisibility(VISIBLE);
            // 优才计划已开通下周预告及以后需要加闹钟
            if (lockFlag == 1) {
                lockViewContainer.setVisibility(GONE);
                iconTalentPlanClock.setVisibility(VISIBLE);
            }
        }
    }

    public void setTalentFlagMoneyParams() {
        FrameLayout.LayoutParams layoutParams = (LayoutParams) flagMoney.getLayoutParams();
        layoutParams.setMargins(0, 0, LocalDisplay.dp2px(8), LocalDisplay.dp2px(8));
        layoutParams.gravity = (Gravity.RIGHT | Gravity.BOTTOM);
    }

    public void setFlagMoneyTextSize(float size) {
        flagMoney.setTextSize(size);
    }

    public void setClockSize(int size){
        iconTalentPlanClock.getLayoutParams().width = size;
        iconTalentPlanClock.getLayoutParams().height = size;
    }
}
