package com.hhdd.kada.main.ui.book;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.android.library.views.list.SpacesItemDecoration;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BookAPI;
import com.hhdd.kada.main.common.DataListModel;
import com.hhdd.kada.main.common.FragParamData;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.event.SubscribeSuccessEvent;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.BookCollectionPayListViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by mcx on 2017/7/28.
 */

public class BookCollectionPayListFragment extends RecyclerDataListFragment2 {
    static final int View_Type_Item_Collection_Pay = 100;
    BaseViewHolderCreator viewHolderCreator;
    private API.PaginationUrlAPI payAPI;
    String mTitle;
    int extFlag;

    public BookCollectionPayListFragment() {
        super(LIST_MODE_BOTH, "", null);
    }


    @Override
    public void onEnter(Object o) {
        if (o != null && (o instanceof FragParamData)) {
            mTitle = ((FragParamData) o).title;
            extFlag = (int) ((FragParamData) o).paramObject;
        }
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        initView();
        if (mTitle == null || mTitle.length() <= 0) {
            useTitleBar("付费精品");
        } else {
            useTitleBar(mTitle);
        }

        showLoadingView();
        reloadData();

        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {

            public void onEvent(SubscribeSuccessEvent event) {
                doRefresh();
                notifyDataSetChanged();
            }

        }).tryToRegisterIfNot();

    }

    void initView() {
        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }

        setBackgroundColor(KaDaApplication.getInstance().getResources().getColor(R.color.white));
        footerView.setTextColor(KaDaApplication.getInstance().getResources().getColor(R.color.color_6c6c6c));

        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(View_Type_Item_Collection_Pay, BookCollectionPayListViewHolder.class);
        viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        setViewHolderCreator(viewHolderCreator);
        SpacesItemDecoration decoration = new SpacesItemDecoration(LocalDisplay.dp2px(7));
        getmListView().addItemDecoration(decoration);
    }

    private void reloadData() {
        if(extFlag == 0){
            extFlag = (int) Extflag.EXT_FLAG_1024;
        }
        payAPI = new BookAPI.PaginationSpecialCollectionListAPI("book2", "getCollectList.json", extFlag, Settings.getInstance().getStoryAgeType());
        DataListModel dataListModel = new DataListModel(payAPI, 20);
        reloadData(dataListModel);
    }


    @Override
    protected void reassembleDisplayedDataList(List<BaseVO> dataListDisplayed, List<BaseModel> itemsAdded, boolean isFirstPage) {
        if (dataListDisplayed == null || itemsAdded == null) return;

        for (int i = 0; i < itemsAdded.size(); i++) {
            BaseModel model = itemsAdded.get(i);
            if (model instanceof BookCollectionInfo) {
                model.setIndex(i);
                dataListDisplayed.add(new BaseModelVO(model, View_Type_Item_Collection_Pay));
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (this.payAPI != null) {
            this.payAPI.cancel();
            this.payAPI = null;
        }
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser){
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "book_premium_view", TimeUtil.currentTime()));
        }
    }

}
