package com.hhdd.kada.main.ui.book;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.FrameLayout;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.download.DownloadStatus;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.event.CollectionAnimStopEvent;
import com.hhdd.kada.main.event.ConnectivityChangedEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.manager.DialogManager;
import com.hhdd.kada.main.manager.PermissionManager;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.ui.dialog.CommonDialog;
import com.hhdd.kada.main.ui.dialog.NoWifiDownloadDialog;
import com.hhdd.kada.main.ui.dialog.SubscribeGuideDialog;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.MemorySizeUtils;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;

import java.io.Serializable;

import de.greenrobot.event.EventBus;

import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;

/**
 * Created by sxh on 2017/8/8.
 * 合辑详情基类
 */

public abstract class BaseCollectionFragment extends RecyclerDataListFragment2 {

    public static final String ISFIRSTCOLLECTIONRFRAGMENT = "ISFIRSTCOLLECTIONRFRAGMENT";

    protected boolean needDownLoading = false; //标识连上wifi后是否要自动下载
    protected BookCollectionTitleBar bookTitleBar;
    protected int collectId;
//    protected boolean isFromUser = false;   //合辑入口标签
    protected int downloadStatus = DownloadStatus.STATUS_INITIAL;
    protected BookCollectionDetailInfo mBookCollectionDetailInfo;   //单独用来处理下载中心传过来的model
//    protected StoryCollectionDetail mStoryCollectionDetailInfo;   //单独用来处理下载中心传过来的model

    protected FrameLayout.LayoutParams headerParams;

    public BookCollectionDetailInfo getBookCollectionDetailInfo() {
        return mBookCollectionDetailInfo;
    }

    public BaseCollectionFragment() {
        super(LIST_MODE_PULL_DOWN_TO_REFRESH, null, null);
    }

    public int getCollectId() {
        return collectId;
    }

//    public boolean isFromUser() {
//        return isFromUser;
//    }
//
//    public void setFromUser(boolean fromUser) {
//        isFromUser = fromUser;
//    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        // 在Fragment生命周期中，onCreateView在onActivityCreated之前执行，这时getActivity可能是空的
        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }

        initTitleBar();
        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {

            public void onEvent(ConnectivityChangedEvent event) {
                if (event.isConnectedWifi) {
                    if (needDownLoading) {
                        doStartDownload();
                        needDownLoading = false;
                    }
                } else if (event.isConnected) {
                    if (needDownLoading) {
                        doPauseDownload();
                        Activity activity = ActivityHelper.getTopActivity();
                        if (activity == null || activity.isFinishing()) {
                            return;
                        }
                        final NoWifiDownloadDialog dialog = new NoWifiDownloadDialog(activity);
                        dialog.setCallback(new CommonDialog.CommonDialogCallback() {
                            @Override
                            public void doYes() {
                                needDownLoading = true;
                                doStartDownload();
                            }

                            @Override
                            public void doNo() {
                                needDownLoading = false;
                            }
                        });
                        dialog.show();
                    }

                } else {
                    if (downloadStatus == DownloadStatus.STATUS_ERROR) {
                        needDownLoading = true;
                    }
                }
                bookTitleBar.setResIdByStatus(downloadStatus);
            }
        }).tryToRegisterIfNot();
    }

    @Override
    public void onEnter(Object data) {
        if (data != null && data instanceof Integer) {
            collectId = (int) data;
        } else if (data != null && data instanceof CollectionModel) {
            CollectionModel model = (CollectionModel) data;
            collectId = model.getCollectId();
//            isFromUser = model.isFromUser();
        }
    }

    protected void initTitleBar() {
        useTitleBar(true);
        bookTitleBar = new BookCollectionTitleBar(getContext());
        bookTitleBar.setResIdByStatus(downloadStatus);
        headerParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        headerParams.gravity = Gravity.TOP;
        bookTitleBar.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                switch (childView.getId()) {
                    case R.id.downloadLayout:
                        doDownload();
                        break;
                    case R.id.shareLayout:
                        doShare();
                        break;
                    case R.id.rl_title_bar_left:
                        onBackPressed();
                        break;
                }
            }
        });
    }

    protected void doDownload() {
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }
        if (downloadStatus == DownloadStatus.STATUS_INITIAL || downloadStatus == DownloadStatus.STATUS_PAUSED || downloadStatus == DownloadStatus.STATUS_ERROR) {
            if (this instanceof BookCollectionFragment) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(getCollectId() + "", "book_collection_begin_all_download_click", TimeUtil.currentTime()));
            } else if (this instanceof StoryCollectionFragment) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(getCollectId() + "", "story_collection_begin_all_download_click", TimeUtil.currentTime()));
            }

            if (NetworkUtils.isReachableViaWiFi()) {
                //全部下载
                if (ContextCompat.checkSelfPermission(getContext(), WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    //申请WRITE_EXTERNAL_STORAGE权限
                    ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).requestPermission(BaseCollectionFragment.this, PermissionManager.PERMISSION_WRITE_EXTERNAL_STORAGE);
                    ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).getDialog().setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialogInterface) {
                            ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissDialog(((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).getDialog());
                            downloadStatus = DownloadStatus.STATUS_PAUSED;
                        }
                    });
                } else {
                    if (MemorySizeUtils.getAvailableMemoryByMb() >= 200) {
                        doStartDownload();
                    } else {
                        ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).requestPermission(BaseCollectionFragment.this, PermissionManager.STORAGE_NOT_ENOUGH);
                        ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).getDialog().setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissDialog(((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).getDialog());
                                downloadStatus = DownloadStatus.STATUS_PAUSED;
                            }
                        });
                    }
                }
            } else if (NetworkUtils.isConnectedMobile(getContext())) {
                final NoWifiDownloadDialog dialog = new NoWifiDownloadDialog(getContext());
                dialog.setCallback(new CommonDialog.CommonDialogCallback() {
                    @Override
                    public void doYes() {
                        doStartDownload();
                    }

                    @Override
                    public void doNo() {

                    }
                });
                dialog.show();
            } else {
                ToastUtils.showToast("当前处于无网络状态");
                downloadStatus = DownloadStatus.STATUS_PAUSED;
            }
        } else if (downloadStatus == DownloadStatus.STATUS_DOWNLOADING) {
            if (this instanceof BookCollectionFragment) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(getCollectId() + "", "book_collection_cancel_all_download_click", TimeUtil.currentTime()));
            } else if (this instanceof StoryCollectionFragment) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(getCollectId() + "", "story_collection_cancel_all_download_click", TimeUtil.currentTime()));
            }

            //取消下载
            doPauseDownload();
        } else if (downloadStatus == DownloadStatus.STATUS_COMPLETE) {
            ToastUtils.showToast("内容已下载");
        }
    }

    public void showGuideDialog() {
        getHandler().post(new Runnable() {
            @Override
            public void run() {
                final boolean isFirstBookCollectionFragment = ((PrefsManager) ServiceProxyFactory.getProxy()
                        .getService(ServiceProxyName.PREFS_MANAGER)).getBoolean(BaseCollectionFragment.ISFIRSTCOLLECTIONRFRAGMENT, true);
                if (isFirstBookCollectionFragment) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "user_guide_tip_subscribe_view", TimeUtil.currentTime()));
                    ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).putBoolean(BaseCollectionFragment.ISFIRSTCOLLECTIONRFRAGMENT, false);
                    if (getContext() == null || getContext().isFinishing()) {
                        return;
                    }
                    SubscribeGuideDialog guideDialog = new SubscribeGuideDialog(getContext());
                    ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).showDialog(guideDialog);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == PermissionManager.PERMISSION_WRITE_EXTERNAL_STORAGE) {
            if (grantResults != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (MemorySizeUtils.getAvailableMemoryByMb() >= 200) {
                    doStartDownload();
                } else {
                    ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).requestPermission(BaseCollectionFragment.this, PermissionManager.STORAGE_NOT_ENOUGH);
                    ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).getDialog().setOnDismissListener(new DialogInterface.OnDismissListener() {
                        @Override
                        public void onDismiss(DialogInterface dialog) {
                            ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissDialog(((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).getDialog());
                            downloadStatus = DownloadStatus.STATUS_PAUSED;
                        }
                    });
                }
            } else {
                // Permission Denied
                ToastUtils.showToast("没有权限,无法下载");
                downloadStatus = DownloadStatus.STATUS_PAUSED;
            }
            return;
        }
    }

    @Override
    public void onDestroyView() {
        EventBus.getDefault().post(new CollectionAnimStopEvent());
        super.onDestroyView();
    }

    //开始下载
    public abstract void doStartDownload();

    //暂停下载
    public abstract void doPauseDownload();

    //分享
    protected abstract void doShare();


    public static class CollectionModel implements Serializable {
        int collectId;
        boolean isFromUser;//未订阅是否展示内置合集样式，目前仅绘本首页和听书首页展示内置合集样式

        public CollectionModel(int collectId, boolean isFromUser) {
            this.collectId = collectId;
            this.isFromUser = isFromUser;
        }

        public int getCollectId() {
            return collectId;
        }

        public boolean isFromUser() {
            return isFromUser;
        }
    }

}
