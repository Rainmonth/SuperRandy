package com.hhdd.kada.main.ui.book;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.BackgroundColorSpan;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.dialog.ConfirmDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.common.DataLoadingView;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.common.TitleBasedFragment;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.PayResultEvent;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.model.TalentPlanCollectInfo;
import com.hhdd.kada.main.ui.activity.WebViewActivity;
import com.hhdd.kada.main.ui.dialog.ConfirmDialog;
import com.hhdd.kada.main.ui.story.PaySucceedFragment;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.kada.pay.PayManager;
import com.hhdd.kada.pay.controller.BasePayController;
import com.hhdd.kada.store.model.OrderFragParamData;
import com.hhdd.kada.store.model.VirtualOrderListInfo;
import com.hhdd.kada.store.utils.PriceUtil;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by mcx on 2017/11/7.
 */

public abstract class BasePayFragment extends TitleBasedFragment {

    SimpleDraweeView mCover;
    private ImageView ivZfb, ivWx;
    private TextView tvCommit;
    private TextView tvService, tvInstructions;
    private TextView mRecommend, mCount, mSubscribeCount;
    private LinearLayout llZfb;
    private LinearLayout llWx;
    private TextView mName;
    private TextView mPrice;
    private TextView mOriginalPrice;
    DataLoadingView mLoadingView;
    ImageView leftBorder;
    RelativeLayout coverContainer;

    BookCollectionDetailInfo mBookCollectionDetailInfo;
    StoryCollectionDetail mStoryCollectionDetail;
    TalentPlanCollectInfo mTalentPlanCollectInfo;
    VirtualOrderListInfo.OrderItemInfo mOrderItemInfo;

    OrderFragParamData mOrderFragParamData;

    StrongReference<DefaultCallback> mStrongReference;

    private int channel = BasePayController.CHANNEL_PAY_WX; //默认为微信支付

    int mOrderId;
    int mCollectionId;
    int mWidth, mHeight;

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        setInnerContentView(R.layout.fragment_book_pay);

        mCover = (SimpleDraweeView) findViewById(R.id.cover);
        ivWx = (ImageView) findViewById(R.id.select_wx);
        ivZfb = (ImageView) findViewById(R.id.select_zfb);
        tvCommit = (TextView) findViewById(R.id.commit);
        llZfb = (LinearLayout) findViewById(R.id.ll_zfb);
        llWx = (LinearLayout) findViewById(R.id.ll_wx);
        mName = (TextView) findViewById(R.id.tv_book_name);
        mPrice = (TextView) findViewById(R.id.tv_price);
        mOriginalPrice = (TextView) findViewById(R.id.tv_cost_price);
        mLoadingView = (DataLoadingView) findViewById(R.id.loading);
        leftBorder = (ImageView) findViewById(R.id.book_left_border);
        coverContainer = (RelativeLayout) findViewById(R.id.cover_container);
        tvService = (TextView) findViewById(R.id.custom_service);
        tvInstructions = (TextView) findViewById(R.id.customer_instructions);
        mRecommend = (TextView) findViewById(R.id.tv_summary);
        mCount = (TextView) findViewById(R.id.tv_count);
        mSubscribeCount = (TextView) findViewById(R.id.tv_subscribe_count);

        initView();
        loadDetailData();

        EventCenter.register(this);

        if (mOrderId != 0 || mCollectionId != 0) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mOrderId + ","
                    + mCollectionId + "," + getOrderType(), StaPageName.order_payment_view, TimeUtil.currentTime()));
        }
    }

    private void initView() {
        useTitleBar("订单支付");

        mLoadingView = (DataLoadingView) findViewById(R.id.loading);
        if (mLoadingView != null) {
            mLoadingView.showLoading();
            mLoadingView.setOnRetryClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mLoadingView.showLoading();
                    loadData();
                }
            });
        }

        getTitleBar().setLeftOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                showDialog();
            }
        });
    }

    protected void loadData() {
        if (mBookCollectionDetailInfo != null) {
            refreshUI(mBookCollectionDetailInfo);
            if (mLoadingView != null) {
                mLoadingView.hide();
            }
        } else if (mStoryCollectionDetail != null) {
            refreshUI(mStoryCollectionDetail);
            if (mLoadingView != null) {
                mLoadingView.hide();
            }
        } else if (mTalentPlanCollectInfo != null) {
            refreshUI(mTalentPlanCollectInfo);
            if (mLoadingView != null) {
                mLoadingView.hide();
            }
        }
    }

    //填充UI

    protected void refreshUI(final BaseModel info) {
        String coverUrl = "";
        String name = "";
        double price = 0;
        double originalPrice = 0;
        long extFlag = 0;
        String recommend = "";
        int count = 0;
        int subscribeCount = 0;
        setCoverBackground();

        tvService.setText(getClickableSpan());
        tvService.setMovementMethod(LinkMovementMethod.getInstance());
        tvInstructions.setText(KaDaApplication.getInstance().getResources().getString(R.string.pay_customer_instructions));

        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) mCover.getLayoutParams();
        layoutParams.width = LocalDisplay.dp2px(mWidth);
        layoutParams.height = LocalDisplay.dp2px(mHeight);
        mCover.setLayoutParams(layoutParams);

        if (info instanceof BookCollectionDetailInfo) {
            BookCollectionDetailInfo bookDetailInfo = (BookCollectionDetailInfo) info;
            coverUrl = bookDetailInfo.getCoverUrl();
            name = bookDetailInfo.getName();
            price = bookDetailInfo.getPrice();
            originalPrice = bookDetailInfo.getOriginalPrice();
            recommend = bookDetailInfo.getRecommend();
            count = bookDetailInfo.getCount();
            subscribeCount = bookDetailInfo.getSubscribeCount();
            extFlag = bookDetailInfo.getExtFlag();
            if ((extFlag & Extflag.EXT_FLAG_SALE) == Extflag.EXT_FLAG_SALE && originalPrice > price) {
                produceIsOnSale(originalPrice, price);
            } else {
                produceNotOnSale();
            }
            mName.setText("《" + name + "》");
        } else if (info instanceof StoryCollectionDetail) {
            StoryCollectionDetail storyDetailInfo = (StoryCollectionDetail) info;
            coverUrl = storyDetailInfo.getCoverUrl();
            name = storyDetailInfo.getName();
            price = storyDetailInfo.getPrice();
            originalPrice = storyDetailInfo.getOriginalPrice();
            recommend = storyDetailInfo.getRecommend();
            count = storyDetailInfo.getCount();
            subscribeCount = storyDetailInfo.getSubscribeCount();
            extFlag = storyDetailInfo.getExtFlag();
            if ((extFlag & Extflag.STORY_EXT_FLAG_SLAE) == Extflag.STORY_EXT_FLAG_SLAE && originalPrice > price) {
                produceIsOnSale(originalPrice, price);
            } else {
                produceNotOnSale();
            }
            mName.setText("《" + name + "》");
        } else if (info instanceof TalentPlanCollectInfo) {
            TalentPlanCollectInfo talentPlanInfo = (TalentPlanCollectInfo) info;
            coverUrl = talentPlanInfo.getCoverUrl();
            name = talentPlanInfo.getName();
            price = talentPlanInfo.getPrice();
            originalPrice = talentPlanInfo.getOriginalPrice();
            subscribeCount = talentPlanInfo.getSubscribeCount();
            extFlag = talentPlanInfo.getExtFlag();
            if ((extFlag & Extflag.TALENT_EXT_FLAG_1) == Extflag.TALENT_EXT_FLAG_1 && originalPrice > price) {
                produceIsOnSale(originalPrice, price);
            } else {
                produceNotOnSale();
            }
            mName.setText(name);
        }

        if (coverUrl != null && coverUrl.length() > 0) {
            FrescoUtils.showUrl(coverUrl, mCover, LocalDisplay.dp2px(mWidth), LocalDisplay.dp2px(mHeight));
        }

        if (recommend != null && !TextUtils.isEmpty(recommend)) {
            mRecommend.setText(recommend);
            mRecommend.setVisibility(View.VISIBLE);
        } else {
            mRecommend.setVisibility(View.INVISIBLE);
        }
        if (count > 0) {
            mCount.setText(count + "本");
            mCount.setVisibility(View.VISIBLE);
        } else {
            mCount.setVisibility(View.INVISIBLE);
        }

        if (subscribeCount > 0) {
            mSubscribeCount.setText(subscribeCount + "人已购");
            mSubscribeCount.setVisibility(View.VISIBLE);
        } else {
            mSubscribeCount.setVisibility(View.INVISIBLE);
        }

        mPrice.setText("¥" + getPriceText(price));

        setClickListener();
    }

    private String getPriceText(double price) {
        String priceText = PriceUtil.formatPrice(String.valueOf(price / 100));
        return priceText;
    }

    private void produceIsOnSale(double originalPrice, double price) {
        mOriginalPrice.setVisibility(View.VISIBLE);
        mOriginalPrice.getPaint().setFlags(Paint.STRIKE_THRU_TEXT_FLAG);
        mOriginalPrice.setText("（" + "¥" +getPriceText(originalPrice) + "）");
        tvCommit.setText("确认支付" + "（节省" + getPriceText(originalPrice - price) + "元）");
    }

    private void produceNotOnSale() {
        mOriginalPrice.setVisibility(View.INVISIBLE);
        tvCommit.setText("确认支付");
    }

    private void setClickListener() {

        llZfb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ivZfb.setImageResource(R.drawable.pay_is_select);
                ivWx.setImageResource(R.drawable.pay_not_select);
                channel = BasePayController.CHANNEL_PAY_ALI;
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        "order_payment_alipay_check", TimeUtil.currentTime()));
            }
        });

        llWx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ivWx.setImageResource(R.drawable.pay_is_select);
                ivZfb.setImageResource(R.drawable.pay_not_select);
                channel = BasePayController.CHANNEL_PAY_WX;
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        "order_payment_wechat_pay_check", TimeUtil.currentTime()));
            }
        });

        tvCommit.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                doPayClick();
            }
        });
    }

    public void onEvent(PayResultEvent event) {
        if (event.isSuccess()) {
            paySuccess();
        } else {
            payFail();
        }
    }

    void paySuccess() {
        /**
         * 由于oppo r9s在支付完成后不会跳转到支付成功页面，暂未查找到原因，延迟100ms可以正常跳转
         * 【【oppo r9s 】【必现】成功购买合辑后，微信里点击返回商家，没有出现倒计时页面】
         https://www.tapd.cn/23384181/bugtrace/bugs/view?bug_id=1123384181001003523
         */
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mOrderFragParamData != null) {
                    mOrderFragParamData.setPayChannel(channel);
                    FragmentUtil.pushFragment(PaySucceedFragment.class, mOrderFragParamData, true);
                } else {
                    mOrderItemInfo.setPayChannel(channel);
                    FragmentUtil.pushFragment(PaySucceedFragment.class, mOrderItemInfo, true);
                }
                if (getContext() != null && !getContext().isFinishing()) {
                    getContext().finish();
                }
            }
        }, 100);
    }

    void payFail() {
        ToastUtils.showToast(KaDaApplication.getInstance().getResources().getString(R.string.pay_failed));
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mOrderId +
                "," + getOrderType() + "," + mCollectionId + "," + channel, StaPageName.payment_result_failure_view, TimeUtil.currentTime()));
    }

    void showDialog() {
        final Context context = getContext();
        final ConfirmDialogManager confirmDialogManager = DialogFactory.getConfirmDialogManager();
        confirmDialogManager.showDialog(context, R.string.confirm_dialog_pay_content,
                R.string.confirm_dialog_pay_cancel, R.string.confirm_dialog_pay_confirm, false,
                new ConfirmDialog.OnConfirmDialogListener() {
                    @Override
                    public void onCancel() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("0",
                                StaCtrName.order_payment_giveup_pay_popup_select, TimeUtil.currentTime()));
                        confirmDialogManager.dismissDialog(context);
                        getContext().finish();
                    }

                    @Override
                    public void onConfirm() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1",
                                StaCtrName.order_payment_giveup_pay_popup_select, TimeUtil.currentTime()));
                        confirmDialogManager.dismissDialog(context);
                    }
                });
    }

    //在fragment中监听返回键
    private void getFocus() {
        getView().setFocusable(true);
        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_BACK) {
                    // 监听到返回按钮点击事件
                    showDialog();
                }
                return false;
            }
        });
    }

    /**
     * 点击对应渠道支付
     */
    private void doPayClick() {

        if (getContext() == null || getContext().isFinishing()) {
            return;
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mOrderId + ","
                + mCollectionId + "," + getOrderType(), getPayClickTrackHabitName(), TimeUtil.currentTime()));
        Map<String, Object> param = new HashMap<>();
        param.put(BasePayController.KEY_ORDER_ID, mOrderId);
        param.put(BasePayController.KEY_ORDER_TYPE, getOrderType());
        param.put(BasePayController.KEY_ORDER_COLLECTION_ID, mCollectionId);
        if (mOrderFragParamData != null) {
            param.put(BasePayController.KEY_ORDER_ATTACH_PARAM, mOrderFragParamData);
        } else {
            param.put(BasePayController.KEY_ORDER_ATTACH_PARAM, mOrderItemInfo);
        }
        BasePayController controller = PayManager.getPayController(getContext(), channel);
        if (controller != null) {
            controller.continuePay(param);
        }
    }

    /**
     * 获取对应渠道支付打点名称
     * @return
     */
    private String getPayClickTrackHabitName() {
        String trackHabitName = "";
        switch (channel) {
            case BasePayController.CHANNEL_PAY_ALI:
                trackHabitName = StaCtrName.order_payment_alipay_click;
                break;
            case BasePayController.CHANNEL_PAY_WX:
                trackHabitName = StaCtrName.order_payment_wechat_pay_click;
                break;
            default:
                break;
        }
        return trackHabitName;
    }

    private SpannableString getClickableSpan() {
        View.OnClickListener l = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getContext() == null || getContext().isFinishing()) {
                    return;
                }
                WebViewActivity.startActivity(getContext(), API.URL_CUSTOM());
            }
        };

        SpannableString spanableInfo = new SpannableString(
                KaDaApplication.getInstance().getResources().getString(R.string.pay_custom_service));

        int start = 10;
        int end = 14;
        spanableInfo.setSpan(new Clickable(l), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanableInfo.setSpan(new ForegroundColorSpan(Color.RED), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spanableInfo.setSpan(new BackgroundColorSpan(Color.WHITE), start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spanableInfo;
    }

    class Clickable extends ClickableSpan implements View.OnClickListener {
        private final View.OnClickListener mListener;

        public Clickable(View.OnClickListener l) {
            mListener = l;
        }

        @Override
        public void onClick(View v) {
            mListener.onClick(v);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getFocus();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventCenter.unregister(this);
        PayManager.destroy(getContext());
        DialogFactory.dismissAllDialog(getContext());
        if (mStrongReference != null) {
            mStrongReference.clear();
            mStrongReference = null;
        }
    }

    /**
     * 根据不同的场景设置不同的背景
     */
    protected abstract void setCoverBackground();

    /**
     * 请求接口加载数据
     */
    protected abstract void loadDetailData();

    /**
     * 获取订单类型
     * @return
     */
    protected abstract int getOrderType();
}
