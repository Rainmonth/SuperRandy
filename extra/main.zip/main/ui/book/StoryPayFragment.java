package com.hhdd.kada.main.ui.book;

import android.graphics.Color;
import android.view.View;

import com.facebook.drawee.generic.RoundingParams;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.PayAPI;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.store.model.OrderFragParamData;
import com.hhdd.kada.store.model.VirtualOrderListInfo;

/**
 * Created by mcx on 2017/11/8.
 */

public class StoryPayFragment extends BasePayFragment {

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        //从详情页面进入
        if (data != null && data instanceof OrderFragParamData) {
            mOrderFragParamData = (OrderFragParamData) data;
            if (mOrderFragParamData.getOrderDetail() instanceof StoryCollectionDetail) {
                mStoryCollectionDetail = (StoryCollectionDetail) mOrderFragParamData.getOrderDetail();
            }
            mOrderId = mOrderFragParamData.getOrderId();
            mCollectionId = mOrderFragParamData.getCollectId();
        }
        //从订单页面进入
        else if (data != null && data instanceof VirtualOrderListInfo.OrderItemInfo) {
            mOrderItemInfo = (VirtualOrderListInfo.OrderItemInfo) data;
            mOrderId = mOrderItemInfo.getId();
            mCollectionId = mOrderItemInfo.getCollectId();
        }
    }

    @Override
    protected void loadDetailData() {
        if (mStoryCollectionDetail == null) {
            if (mStrongReference == null) {
                mStrongReference = new StrongReference<>();
            }
            DefaultCallback storyCollectionCallback = new DefaultCallback<StoryCollectionDetail>() {

                @Override
                public void onDataReceived(final StoryCollectionDetail responseData) {
                    if (responseData != null && responseData.getItems() != null && responseData.getItems().size() > 0) {
                        mStoryCollectionDetail = responseData;
                        getHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                loadData();
                            }
                        });
                    }
                }

                @Override
                public void onException(int code, String reason) {
                    mLoadingView.showError();
                }
            };
            mStrongReference.set(storyCollectionCallback);
            StoryAPI.storyAPI_collectItemList(mCollectionId, false, mStrongReference);
        } else {
            loadData();
        }
    }

    @Override
    protected void setCoverBackground() {
        mCover.setBackgroundResource(R.drawable.bg_story_collect);
        RoundingParams roundingParams = mCover.getHierarchy().getRoundingParams();
        roundingParams.setCornersRadii(LocalDisplay.designedDP2px(6), LocalDisplay.designedDP2px(6), LocalDisplay.designedDP2px(6), LocalDisplay.designedDP2px(6));
        roundingParams.setBorderWidth(LocalDisplay.designedDP2px(2));
        roundingParams.setBorderColor(Color.WHITE);
        mCover.getHierarchy().setRoundingParams(roundingParams);
        mCover.setPadding(LocalDisplay.designedDP2px(5), LocalDisplay.designedDP2px(5), LocalDisplay.designedDP2px(5), LocalDisplay.designedDP2px(5));

        leftBorder.setVisibility(View.GONE);
        mWidth = 120;
        mHeight = 120;
    }

    @Override
    protected int getOrderType() {
        return PayAPI.TYPE_ORDER_STORY;
    }
}
