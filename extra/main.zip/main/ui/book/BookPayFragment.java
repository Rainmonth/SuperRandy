package com.hhdd.kada.main.ui.book;

import android.view.View;

import com.facebook.drawee.generic.RoundingParams;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.BookAPI;
import com.hhdd.kada.api.PayAPI;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.store.model.OrderFragParamData;
import com.hhdd.kada.store.model.VirtualOrderListInfo;

/**
 * Created by mcx on 2017/11/7.
 */

public class BookPayFragment extends BasePayFragment {

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        //从详情页面进入
        if (data != null && data instanceof OrderFragParamData) {
            mOrderFragParamData = (OrderFragParamData) data;
            if (mOrderFragParamData.getOrderDetail() instanceof BookCollectionDetailInfo) {
                mBookCollectionDetailInfo = (BookCollectionDetailInfo) mOrderFragParamData.getOrderDetail();
            }
            mOrderId = mOrderFragParamData.getOrderId();
            mCollectionId = mOrderFragParamData.getCollectId();
        }
        //从订单页面进入
        else if (data != null && data instanceof VirtualOrderListInfo.OrderItemInfo) {
            mOrderItemInfo = (VirtualOrderListInfo.OrderItemInfo) data;
            mOrderId = mOrderItemInfo.getId();
            mCollectionId = mOrderItemInfo.getCollectId();
        }
    }

    @Override
    protected void setCoverBackground() {
        mCover.setBackgroundResource(R.drawable.bg_collect_book);
        RoundingParams roundingParams = mCover.getHierarchy().getRoundingParams();
        roundingParams.setCornersRadii(LocalDisplay.designedDP2px(2), LocalDisplay.designedDP2px(5), LocalDisplay.designedDP2px(5), LocalDisplay.designedDP2px(2));
        mCover.getHierarchy().setRoundingParams(roundingParams);
        leftBorder.setVisibility(View.VISIBLE);
        mWidth = 110;
        mHeight = 140;
    }

    @Override
    protected void loadDetailData() {
        if (mBookCollectionDetailInfo == null) {
            DefaultCallback bookCollectionCallback = new DefaultCallback<BookCollectionDetailInfo>() {

                @Override
                public void onDataReceived(BookCollectionDetailInfo data) {
                    if (data != null) {
                        mBookCollectionDetailInfo = data;
                        KaDaApplication.mainLooperHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                loadData();
                            }
                        });
                    }
                }

                @Override
                public void onException(int code, String reason) {
                    super.onException(reason);
                    mLoadingView.showError();
                }
            };
            if (mStrongReference == null) {
                mStrongReference = new StrongReference<>();
            }
            mStrongReference.set(bookCollectionCallback);
            BookAPI.getBookCollectionItem(mCollectionId, false, mStrongReference);
        } else {
            loadData();
        }
    }

    @Override
    protected int getOrderType() {
        return PayAPI.TYPE_ORDER_BOOK;
    }
}
