package com.hhdd.kada.main.ui.book;

import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BookAPI;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.controller.BookCollectionSubscribeController;
import com.hhdd.kada.main.event.BookSubscribeStatusEvent;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.ui.activity.BaseTitleWebViewActivity;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.widget.BookCollectionSubscribeView;
import com.umeng.socialize.bean.SHARE_MEDIA;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/4/14
 * @describe : com.hhdd.kada.main.ui.book
 */
public class BookCollectionTitleWebViewActivity extends BaseTitleWebViewActivity {

    @BindView(R.id.subscribeView)
    BookCollectionSubscribeView subscribeView;
    private BookCollectionDetailInfo info;
    private String url;
    private BookCollectionSubscribeController bookCollectionSubscribeController;
    private StrongReference<DefaultCallback> bookCollectionStrongReference;

    private static final String CREATE_ORDER = BookCollectionTitleWebViewActivity.class.getSimpleName() + "_CREATE_ORDER";
    private static final String SUBSCRIBE = BookCollectionTitleWebViewActivity.class.getSimpleName() + "_SUBSCRIBE";

    @Override
    public int getLayoutId() {
        return R.layout.activity_book_collection_intro;
    }

    @Override
    public void doInitData() {
        super.doInitData();
        Intent intent = getIntent();
        if (intent != null) {
            info = (BookCollectionDetailInfo) intent.getSerializableExtra(Constants.INTENT_KEY_COLLECTION_INFO);
            if (info != null) {
                bookCollectionSubscribeController = new BookCollectionSubscribeController(this, SUBSCRIBE, CREATE_ORDER);
                bookCollectionSubscribeController.setBookCollectionDetailInfo(info);
                invalidateSubscribeView();
                subscribeView.setVisibility(View.VISIBLE);
                String introduction = info.getIntroduction();
                if (!TextUtils.isEmpty(introduction)) {
                    url = API.URL_BOOK_COLLECTION_INTRODUCTION() + "cid=" + info.getCollectId() + "&url=" + introduction;
                    loadUrl();
                }
            }
        }
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        subscribeView.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                switch (childView.getId()) {
                    case R.id.subscribeLayout:
                        if (info != null) {
                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getCollectId()),
                                    "book_collection_introduction_subscribe_click", TimeUtil.currentTime()));
                        }
                        if (bookCollectionSubscribeController != null) {
                            bookCollectionSubscribeController.doSubscribe();
                        }
                        break;
                    case R.id.subscribeTextViewContainer:
                        if (info != null) {
                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getCollectId()),
                                    "book_collection_introduction_subscribed_click", TimeUtil.currentTime()));
                        }
                        if (bookCollectionSubscribeController != null) {
                            bookCollectionSubscribeController.doCancelSubscribe();
                        }
                        break;
                    default:
                        break;
                }
            }
        });
    }

    @Override
    protected void loadUrl() {
        if (!NetworkUtils.isReachable()) {
            showError();
            return;
        }
        if (contentWebView != null && !TextUtils.isEmpty(url)) {
            contentWebView.loadUrl(url);
        }
    }

    @Override
    protected void doShareHabit() {
        if (info != null) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getCollectId()),
                    "book_collection_introduction_begin_share_click", TimeUtil.currentTime()));
        }
    }

    @Override
    protected void doShareHabitSuccess(SHARE_MEDIA share_media) {
        if (info != null) {
            int collectId = info.getCollectId();
            switch (share_media) {
                case WEIXIN:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "1", "book_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                case WEIXIN_CIRCLE:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "2", "book_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                case QQ:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "3", "book_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                case QZONE:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "4", "book_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                case SINA:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "5", "book_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                default:
                    break;
            }
        }
    }

    public void onEventMainThread(BookSubscribeStatusEvent event) {
        finish();
    }

    public void onEventMainThread(LoginEvent event) {
        getBookCollectionDetailInfo(event.getType());
    }

    /**
     * 刷新订阅view
     */
    private void invalidateSubscribeView() {
        subscribeView.updateIntroduction(info.getSubscribe() == 1, info.getExtFlag(), info.getPrice(), info.getOriginalPrice());
    }

    /**
     * 获取绘本合集详情信息
     */
    private void getBookCollectionDetailInfo(final String type) {
        if (info == null) {
            return;
        }
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                clearBookCollectionReference();
            }
        });
        final int collectId = info.getCollectId();
        if (bookCollectionStrongReference == null) {
            bookCollectionStrongReference = new StrongReference<>();
        }
        DefaultCallback bookCollectionCallback = new DefaultCallback<BookCollectionDetailInfo>() {

            @Override
            public void onDataReceived(final BookCollectionDetailInfo data) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(BookCollectionTitleWebViewActivity.this);
                        if (data != null) {
                            info = data;
                            invalidateSubscribeView();
                            if (info.getSubscribe() != 1) {
                                if (SUBSCRIBE.equals(type)) {
                                    bookCollectionSubscribeController.subscribe(1);
                                } else if (CREATE_ORDER.equals(type)) {
                                    bookCollectionSubscribeController.createOrder();
                                }
                            }
                        }
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                customDialogManager.dismissDialog(BookCollectionTitleWebViewActivity.this);
            }
        };
        bookCollectionStrongReference.set(bookCollectionCallback);
        BookAPI.getBookCollectionItem(collectId, false, bookCollectionStrongReference);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (info != null) {
            String habitName = info.getSubscribe() == 1 ? "book_subscribed_collection_introduction_view" : "book_unsubscribed_collection_introduction_view";
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getCollectId()), habitName, TimeUtil.currentTime()));
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clearBookCollectionReference();
        if (bookCollectionSubscribeController != null) {
            bookCollectionSubscribeController.destroy();
        }
        DialogFactory.dismissAllDialog(this);
    }

    private void clearBookCollectionReference() {
        if (bookCollectionStrongReference != null) {
            bookCollectionStrongReference.clear();
            bookCollectionStrongReference = null;
        }
    }


}
