package com.hhdd.kada.main.ui.book;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.SafeHandler;
import com.hhdd.kada.main.views.base.BaseFrameLayout;
import com.plattysoft.leonids.ParticleSystem;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

public class SubscribeBookItemView extends BaseFrameLayout {

    @BindView(R.id.book_item_view)
    BookItemView bookItemView;
    @BindView(R.id.subscribe_book_item_view)
    FrameLayout subscribeBookItemView;

    private final int PARTICLE_SYSTEM_COUNT = 4;   //发射器数量
    private final int EMIT_ING_TIME = 1000 * 60 * 60;   //持续发射时间
    private final int PARTICLE_ALIVE_TIME = 1000;   //粒子存货时间
    private final int PARTICLES_PER_SECOND = 5;   //每秒钟发射的粒子数量
    private final float SPEED_MIN = 0.01f;   //最小速度
    private final float SPEED_MAX = 0.04f;   //最大速度
    private final int ROTATION_SPEED = 90;   //粒子自身旋转速度

    private SafeHandler handler;
    private List<ParticleSystem> particleSystemList;
    private ParticleSystemRunnable particleSystemRunnable;

    public SubscribeBookItemView(Context context) {
        super(context);
    }

    public SubscribeBookItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.subscribe_book_item_view;
    }

    public BookItemView getBookItemView() {
        return bookItemView;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        handler = new SafeHandler();
    }

    /**
     * 订阅合辑边缘的星星动画
     */
    public synchronized void startSubscribedAnim() {
        stopSubscribedAnim();
        bookItemView.showSubscribeBorder(View.VISIBLE);
        particleSystemList = new ArrayList<>();
        particleSystemRunnable = new ParticleSystemRunnable(3);
        for (int i = 0; i < PARTICLE_SYSTEM_COUNT; i++) {
            particleSystemRunnable = new ParticleSystemRunnable(i % 4 + 1);
            handler.postDelayed(particleSystemRunnable, i * 200 + 200);
        }
    }

    class ParticleSystemRunnable implements Runnable {

        private int mType;   // 1 往左边发射粒子   2 往上边发射粒子   3 往右边发射粒子  4  往下边发射粒子

        ParticleSystemRunnable(int type) {
            mType = type;
        }

        @Override
        public void run() {
            if (mType == 4) {
                ParticleSystem particleSystem = new ParticleSystem(subscribeBookItemView, 100, KaDaApplication.getInstance().getResources().getDrawable(R.drawable.subscribe_star), PARTICLE_ALIVE_TIME)
                        .setSpeedModuleAndAngleRange(SPEED_MIN, SPEED_MAX, 0, 180)
                        .setRotationSpeed(ROTATION_SPEED);
                particleSystem.emitWithGravity(bookItemView, Gravity.BOTTOM, PARTICLES_PER_SECOND, EMIT_ING_TIME);
                particleSystemList.add(particleSystem);
            } else if (mType == 3) {
                ParticleSystem particleSystem = new ParticleSystem(subscribeBookItemView, 100, KaDaApplication.getInstance().getResources().getDrawable(R.drawable.subscribe_star), PARTICLE_ALIVE_TIME)
                        .setSpeedModuleAndAngleRange(SPEED_MIN, SPEED_MAX, 270, 90)
                        .setRotationSpeed(ROTATION_SPEED);
                particleSystem.emitWithGravity(bookItemView, Gravity.RIGHT, PARTICLES_PER_SECOND, EMIT_ING_TIME);
                particleSystemList.add(particleSystem);
            } else if (mType == 2) {
                ParticleSystem particleSystem = new ParticleSystem(subscribeBookItemView, 100, KaDaApplication.getInstance().getResources().getDrawable(R.drawable.subscribe_star), PARTICLE_ALIVE_TIME)
                        .setSpeedModuleAndAngleRange(SPEED_MIN, SPEED_MAX, 180, 360)
                        .setRotationSpeed(ROTATION_SPEED);
                particleSystem.emitWithGravity(bookItemView, Gravity.TOP, PARTICLES_PER_SECOND, EMIT_ING_TIME);
                particleSystemList.add(particleSystem);
            } else if (mType == 1) {
                ParticleSystem particleSystem = new ParticleSystem(subscribeBookItemView, 100, KaDaApplication.getInstance().getResources().getDrawable(R.drawable.subscribe_star), PARTICLE_ALIVE_TIME)
                        .setSpeedModuleAndAngleRange(SPEED_MIN, SPEED_MAX, 90, 270)
                        .setRotationSpeed(ROTATION_SPEED);
                particleSystem.emitWithGravity(bookItemView, Gravity.LEFT, PARTICLES_PER_SECOND, EMIT_ING_TIME);
                particleSystemList.add(particleSystem);
            }
        }
    }

    public synchronized void stopSubscribedAnim() {
        bookItemView.showSubscribeBorder(View.GONE);
        if (handler != null) {
            handler.removeCallbacks(particleSystemRunnable);
        }
        if (particleSystemList == null || particleSystemList.isEmpty()) {
            return;
        }
        for (ParticleSystem particleSystem : particleSystemList) {
            particleSystem.cancel();
        }
    }
}
