package com.hhdd.kada.main.ui.book;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BookAPI;
import com.hhdd.kada.main.common.DataListModel;
import com.hhdd.kada.main.common.FragParamData;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.ui.dialog.AgeOptionDialog;
import com.hhdd.kada.main.ui.story.StoryCollectionListFragment;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.widget.support.KdGridLayoutManager;
import com.hhdd.logger.LogHelper;

import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

/**
 * Created by mcx on 2017/8/8.
 */

public class BookCollectionListFragment extends RecyclerDataListFragment2 {

    public static final int COLLECTION_TYPE_CATEGORY = 0x01;   //categoryId参数
    public static final int COLLECTION_TYPE_EXTFLAG = 0x02;   //extFlag参数
    public static final int COLLECTION_TYPE_SORTFLAG = 0x03;   //sortFlag参
    public static final int COLLECTION_TYPE_EXTFLAG_SORTFLAG = 0x04; //extFlag + sortFlag
    public static final int COLLECTION_TYPE_LIMITAGE = 0x05;  //limitAge参数

    static final int View_Type_Item_Collection_Item = 100;

    API.PaginationUrlAPI listAPI;
    private String mTitle;
    private StoryCollectionListFragment.CollectionTypeInfo mData;
    private int categoryId;
    private int extFlag;
    private int sortFlag;
    BaseViewHolderCreator viewHolderCreator;
    private int paraType;
    private TextView ageTv;
    private AgeOptionDialog mAgeOptionDialog;
    private String ageType;
    private String limitAge;

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case BookCollectionListItemViewHolder.TYPE_BOOK_COLLECTION_ITEM_CLICKED:
                    try {
                        processBookCollectionItemClicked((BookCollectionInfo) args[0]);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }

                    return true;
            }
            return false;
        }
    };

    public BookCollectionListFragment() {
        super(LIST_MODE_BOTH, null, null);
    }

    public static void pushFragment(StoryCollectionListFragment.CollectionTypeInfo paramCollectionTypeInfo) {
        FragmentUtil.presentFragment(BookCollectionListFragment.class, new FragParamData(LIST_MODE_PULL_UP_TO_REFRESH, paramCollectionTypeInfo.getTitle(), paramCollectionTypeInfo), true);
    }

    public void onEnter(Object o) {
        if (o != null && (o instanceof FragParamData)) {
            mTitle = ((FragParamData) o).title;
            mData = ((StoryCollectionListFragment.CollectionTypeInfo) ((FragParamData) o).paramObject);
            paraType = mData.getType();
            categoryId = mData.getCategoryId();
            extFlag = mData.getExtFlag();
            sortFlag = mData.getSortFlag();
            limitAge = mData.getLimitAge();
        }
    }

    protected void onCreateView(Bundle paramBundle) {
        super.onCreateView(paramBundle);
        initView();
        showLoadingView();
        reloadData();
    }

    private void initTitleView() {
        useTitleBar(mTitle);

        View titleView = View.inflate(getContext(), R.layout.title_story_collection_list, null);
        getTitleBar().getRightViewContainer().removeAllViews();
        getTitleBar().getRightViewContainer().addView(titleView);
        ageTv = (TextView) titleView.findViewById(R.id.age_tv);
        if (limitAge == null || Integer.parseInt(limitAge) == -1) {
            ageTv.setVisibility(View.VISIBLE);
        } else {
            ageTv.setVisibility(View.GONE);
        }
        ageTv.setTextSize(16);
        ageTv.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {

                if(getContext() == null || getContext().isFinishing()){
                    return;
                }
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_normal_list_age_click", TimeUtil.currentTime()));

                if (mAgeOptionDialog == null) {
                    mAgeOptionDialog = new AgeOptionDialog(getContext(), true);
                    mAgeOptionDialog.setCanceledOnTouchOutside(true);
                    mAgeOptionDialog.setCallback(new AgeOptionDialog.DefaultCallback() {
                        @Override
                        public void onSelect(String name) {
                            if (!name.equals(ageType)) {
                                ageType = name;
                                updateAgeOption();
                                if (!TextUtils.equals(ageType, "所有年龄")) {
                                    if (TextUtils.equals(ageType, "7-9")) {
                                        ToastUtils.showToast("已为您优先推荐7岁以上绘本", Gravity.CENTER);
                                    } else if (TextUtils.equals(ageType, "我的年龄")) {
                                        ToastUtils.showToast("已为您优先推荐宝宝年龄的绘本", Gravity.CENTER);
                                    } else {
                                        ToastUtils.showToast("已为您优先推荐" + ageType + "岁绘本", Gravity.CENTER);
                                    }
                                }
                            }

                        }
                    });
                }
                if (ageType != null && ageType.length() > 0) {
                    if (ageType.equals("0-3")) {
                        mAgeOptionDialog.setSelectIndex(1);
                    } else if (ageType.equals("4-6")) {
                        mAgeOptionDialog.setSelectIndex(2);
                    } else if (ageType.equals("7-9")) {
                        mAgeOptionDialog.setSelectIndex(3);
                    } else if (TextUtils.equals(ageType, "我的年龄")) {
                        mAgeOptionDialog.setSelectIndex(0);
                    } else {
                        mAgeOptionDialog.setSelectIndex(4);
                    }
                }
                mAgeOptionDialog.show();
            }
        });
    }

    private void initView() {
        initTitleView();

        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }


        setBackgroundColor(KaDaApplication.getInstance().getResources().getColor(R.color.white));
        footerView.setTextColor(KaDaApplication.getInstance().getResources().getColor(R.color.color_6c6c6c));

        getmListView().setPadding(LocalDisplay.dp2px(10), LocalDisplay.dp2px(0), LocalDisplay.dp2px(10), 0);

        HashMap map = new HashMap();
        map.put(View_Type_Item_Collection_Item, BookCollectionListItemViewHolder.class);
        this.viewHolderCreator = new BaseViewHolderCreator(this, map);
        this.viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(this.viewHolderCreator);

        getmListView().setPullRefreshEnabled(false);
        getmListView().setLoadingMoreEnabled(true);
        GridLayoutManager localGridLayoutManager = new KdGridLayoutManager(getContext(), 2, RecyclerView.VERTICAL, false);
        getmListView().setLayoutManager(localGridLayoutManager);
    }

    private void reloadData() {
        if (mData != null) {
            switch (paraType) {
                case COLLECTION_TYPE_EXTFLAG_SORTFLAG:
                    this.listAPI = new BookAPI.PaginationExtSortCollectionListAPI("book2", "getCollectList.json", this.extFlag, this.sortFlag, ageType);
                    break;
                case COLLECTION_TYPE_CATEGORY:
                    this.listAPI = new BookAPI.PaginationCategoryCollectionListAPI("book2", "getCollectList.json", this.categoryId, ageType);
                    break;
                case COLLECTION_TYPE_EXTFLAG:
                    this.listAPI = new BookAPI.PaginationSpecialCollectionListAPI("book2", "getCollectList.json", this.extFlag, ageType);
                    break;
                case COLLECTION_TYPE_SORTFLAG:
                    this.listAPI = new BookAPI.PaginationSortCollectionListAPI("book2", "getCollectList.json", this.sortFlag, ageType);
                    break;
                case COLLECTION_TYPE_LIMITAGE:
                    this.listAPI = new BookAPI.PaginationSortCollectionListAPI("book2", "getCollectList.json", this.sortFlag, limitAge);

            }
            DataListModel dataListModel = new DataListModel(listAPI, 20);
            reloadData(dataListModel);
        }

    }

    @Override
    protected void reassembleDisplayedDataList(List<BaseVO> dataListDisplayed, List<BaseModel> itemsAdded, boolean isFirstPage) {
        if (dataListDisplayed == null || itemsAdded == null || itemsAdded.size() == 0) {
            mLoadingView.showLoading();
            return;
        }

        for (int i = 0; i < itemsAdded.size(); i++) {
            BaseModel model = itemsAdded.get(i);
            if (model instanceof BookCollectionInfo) {
                model.setIndex(i);
                BaseModelVO vo = new BaseModelVO(model, View_Type_Item_Collection_Item);
                dataListDisplayed.add(vo);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (this.listAPI != null) {
            this.listAPI.cancel();
            this.listAPI = null;
        }
    }

    void updateAgeOption() {
        if (ageType != null && ageType.length() > 0) {
            if (ageType.equals("所有年龄")) {
                ageTv.setText("全部年龄");
            } else if (ageType.equals("我的年龄")) {
                String birthday = UserService.getInstance().currentUserBirthday();
                if (birthday != null && birthday.length() > 0 && birthday.split("-").length == 3) {
                    String[] arg = birthday.split("-");
                    Calendar now = Calendar.getInstance();
                    int year = Integer.parseInt(arg[0]);
                    int month = Integer.parseInt(arg[1]);
                    int day = Integer.parseInt(arg[2]);
                    int nowYear = now.get(Calendar.YEAR);
                    int nowMonth = now.get(Calendar.MONTH) + 1;
                    int nowDay = now.get(Calendar.DAY_OF_MONTH);

                    int age = nowYear - year - 1;
                    if (month < nowMonth) {
                        age += 1;
                    } else if (month == nowMonth) {
                        if (day <= nowDay) {
                            age += 1;
                        }
                    }
                    if (age < 0) {
                        age = 0;
                    }
                    if (age >= 0 && age <= 3) {
                        ageTv.setText("0-3岁");
                    } else if (age >= 4 && age <= 6) {
                        ageTv.setText("4-6岁");
                    } else {
                        ageTv.setText("7岁以上");
                    }
                } else {
                    ageTv.setText("0-7岁+");
                }
            } else if ("7-9".equals(ageType)) {
                ageTv.setText("7岁以上 ");
            } else {
                ageTv.setText(ageType + "岁");
            }
            reloadData();
        }
    }

    String getAgeInfo(int limitAge) {
        switch (limitAge) {
            case 0-3:
                return "所有年龄";
            case 0:
                return "我的年龄";
            case 1:
                return "1";
            case 4:
                return "4";
            case 7:
                return "7";
        }
        return "所有年龄";
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "book_normal_view", TimeUtil.currentTime()));
        }
    }

    private void processBookCollectionItemClicked(BookCollectionInfo info) {
        if (info == null) {
            return;
        }

        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getCollectId() + "", "book_normal_list_click_" + info.getIndex(), TimeUtil.currentTime()));
        FragmentUtil.presentFragment(BookCollectionFragment.class, new BaseCollectionFragment.CollectionModel(info.getCollectId(), false), true);
    }
}
