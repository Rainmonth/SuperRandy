package com.hhdd.kada.main.ui.book;

import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.OrganizationInfo;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;

import butterknife.BindView;

/**
 * Created by mcx on 2017/7/28.
 */

public class CartoonListViewHolder extends BaseViewHolder<BaseModelVO> implements View.OnClickListener{

    public static final int TYPE_CARTOON_ITEM_CLICKED = 100;

    @BindView(R.id.container_cartoon)
    View container;
    @BindView(R.id.cover)
    SimpleDraweeView cover;
    @BindView(R.id.cartoon_name)
    TextView name;
    @BindView(R.id.listen_count)
    TextView count;
    @BindView(R.id.cartoon_des)
    TextView des;

    @Override
    public View createView(ViewGroup parent) {
        container.setOnClickListener(this);
        return rootView;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_cartoon_list;
    }

    @Override
    public void showData(int position, BaseModelVO baseModelVO) {
        if (baseModelVO!=null){
            BaseModel baseModel = baseModelVO.getModel();
            if (baseModel!=null&&baseModel instanceof OrganizationInfo){
                final OrganizationInfo organizationInfo = (OrganizationInfo) baseModel;
                name.setText(organizationInfo.getOrgName());
                des.setText(organizationInfo.getDescription());
                count.setText(organizationInfo.clickCountString());
                count.setVisibility(View.INVISIBLE);

                String iconUrl = CdnUtils.getImgCdnUrl(organizationInfo.getIconUrl(), true);
                FrescoUtils.showImg(cover, iconUrl);
                container.setTag(organizationInfo);
            }
        }
    }


    @Override
    public void onClick(View v) {
        if (mOnEventProcessor != null) {
            mOnEventProcessor.process(TYPE_CARTOON_ITEM_CLICKED, v.getTag());
        }
    }
}
