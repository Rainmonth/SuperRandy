package com.hhdd.kada.main.ui.book;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.event.BookSubscribeStatusEvent;
import com.hhdd.kada.main.event.CollectionAnimStopEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.widget.CollectionReadingModelView;
import com.hhdd.kada.widget.CollectionRecommendView;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * Created by sxh on 2017/7/27.
 */

public class BookCollectionBannerViewHolder extends BaseViewHolder<BaseModelVO> {

    @BindView(R.id.subscribed_ll)
    View subscribedLayout;
    @BindView(R.id.collectionReadingModelView)
    CollectionReadingModelView collectionReadingModelView;
    @BindView(R.id.collectionRecommendView)
    CollectionRecommendView collectionRecommendView;
    @BindView(R.id.topLayout)
    View topLayout;
    private BookCollectionDetailInfo info;
    private Context context;

    public BookCollectionBannerViewHolder() {
        EventBus.getDefault().register(this);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_book_collect_banner;
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(params);
        context = parent.getContext();
        return rootView;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        if (itemData != null && itemData.getModel() != null) {
            if (itemData.getModel() instanceof BookCollectionDetailInfo) {
                info = (BookCollectionDetailInfo) itemData.getModel();
                subscribedLayout.setVisibility(info.getSubscribe() == 1 ? View.VISIBLE : View.GONE);
                collectionRecommendView.setVisibility(View.GONE);
                if(info.getSubscribe() != 1) {
                    collectionRecommendView.setVisibility(View.VISIBLE);
                    collectionRecommendView.update(info);
                    // 此控件听书和绘本共用，绘本合集是隐藏倒计时
                    collectionRecommendView.stopRefreshTime();
                    collectionRecommendView.hideCountdownContainer();
                }

                collectionReadingModelView.update(info.getDimensionIdList());
            }

            subscribedLayout.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(View v) {
                    if(context == null){
                        return;
                    }
                    if(context instanceof Activity){
                        if(((Activity) context).isFinishing()){
                            return;
                        }
                    }
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getCollectId() + "", "book_collection_subscribed_btn_click", TimeUtil.currentTime()));
                    if (NetworkUtils.isReachable()) {
                        //取消订阅行为，只是提示弹出对话框，并不是真正的取消订阅
                        EventCenter.fireEvent(new BookSubscribeStatusEvent(info.getCollectId(),0));
                    } else {
                        ToastUtils.showToast("网络异常，请检查网络");
                    }
                }
            });

            collectionReadingModelView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(View v) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getCollectId() + "", "book_collection_tree_btn_click", TimeUtil.currentTime()));
                    jumpToIntroductionFragment();
                }
            });
        }
    }

    /**
     * 跳转到合集简介页面
     */
    private void jumpToIntroductionFragment() {
        if (info.getIntroduction() != null) {
            ActivityUtil.nextBookCollectionTitleWebViewActivity(context, info);
        }
    }

    public void onEvent(CollectionAnimStopEvent event){
        if(collectionReadingModelView != null) {
            collectionReadingModelView.recycle();
        }
        EventBus.getDefault().unregister(this);
    }
}
