package com.hhdd.kada.main.ui.book;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.BookOtherCollectListModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.utils.LocalSubscribeUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.module.userhabit.StaCtrName;

import java.util.List;

import butterknife.BindView;

/**
 * Created by mcx on 2017/8/10.
 */

public class BookSubscribeListViewHolder extends BaseViewHolder<BaseModelListVO> {

    public static final int TYPE_BOOK_SUBSCRIBE_ITEM_CLICKED = 500;
    public static final int TYPE_BOOK_SHELF_CLICKED = 501;
    int mWidth;
    int mHeight;
    Context context;

    @BindView(R.id.bottom_shelf)
    ImageView shelf;
    @BindView(R.id.container)
    LinearLayout container;
    @BindView(R.id.subscribeBookView1)
    SubscribeBookItemView subscribeBookView1;
    @BindView(R.id.subscribeBookView2)
    SubscribeBookItemView subscribeBookView2;
    @BindView(R.id.subscribeBookView3)
    SubscribeBookItemView subscribeBookView3;

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(params);
        context = parent.getContext();
        mWidth = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(54)) / 3;
        mHeight = (int) (mWidth * 32.0f / 25.0f);
        return rootView;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_book_subscribe_list;
    }

    @Override
    public void showData(int position, final BaseModelListVO itemData) {
        if (itemData == null) {
            return;
        }

        List<BaseModel> list = itemData.getItemList();
        if (list == null || list.isEmpty()) {
            return;
        }

        shelf.setBackgroundResource(R.drawable.bg_book_shelf_charge);

        int size = list.size();
        for (int i = 0; i < size; i++) {
            final SubscribeBookItemView subscribeBookItemView = (SubscribeBookItemView) container.getChildAt(i);
            BookItemView bookItemView = subscribeBookItemView.getBookItemView();
            bookItemView.setViewSize(mWidth);
            BaseModel model = list.get(i);
            if (model instanceof BookOtherCollectListModel) {
                final BookCollectionInfo itemInfo = BookOtherCollectListModel.creatBookCollectionInfo((BookOtherCollectListModel) model);
                bookItemView.update(itemInfo, true, bookItemView.mItemWidth, bookItemView.mItemHeight);
                subscribeBookItemView.setTag(R.id.container, itemInfo);
                subscribeBookItemView.setOnClickListener(listener);
                if (LocalSubscribeUtil.containBookSubscribeId(itemInfo.getCollectId())) {
                    subscribeBookItemView.startSubscribedAnim();
                } else {
                    subscribeBookItemView.stopSubscribedAnim();
                }
            } else if (model instanceof RedirectInfo) {
                RedirectInfo info = (RedirectInfo) model;
                bookItemView.update(info, true, bookItemView.mItemWidth, bookItemView.mItemHeight);
                subscribeBookItemView.setTag(R.id.container, info);
                subscribeBookItemView.setOnClickListener(listener);
            }
        }
        if (list.size() == 1) {
            container.getChildAt(0).setVisibility(View.VISIBLE);
            container.getChildAt(1).setVisibility(View.INVISIBLE);
            container.getChildAt(2).setVisibility(View.INVISIBLE);
        } else if (list.size() == 2) {
            container.getChildAt(1).setVisibility(View.VISIBLE);
            container.getChildAt(2).setVisibility(View.INVISIBLE);
            container.getChildAt(0).setVisibility(View.VISIBLE);
        } else {
            container.getChildAt(1).setVisibility(View.VISIBLE);
            container.getChildAt(2).setVisibility(View.VISIBLE);
            container.getChildAt(0).setVisibility(View.VISIBLE);
        }

    }

    @Override
    public void onRecycled() {
        super.onRecycled();
        if (subscribeBookView1.getVisibility() == View.VISIBLE) {
            subscribeBookView1.stopSubscribedAnim();
        }
        if (subscribeBookView2.getVisibility() == View.VISIBLE) {
            subscribeBookView2.stopSubscribedAnim();
        }
        if (subscribeBookView3.getVisibility() == View.VISIBLE) {
            subscribeBookView3.stopSubscribedAnim();
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            final Object tag = v.getTag(R.id.container);
            if (tag == null) {
                return;
            }
            if (tag instanceof BookCollectionInfo) {
                int collectId = ((BookCollectionInfo) tag).getCollectId();
                if (LocalSubscribeUtil.containBookSubscribeId(collectId)) {
                    ((SubscribeBookItemView) v).stopSubscribedAnim();
                    LocalSubscribeUtil.removeBookSubscribeId(collectId);
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.book_home_bookshelf_new_subscribed_click, TimeUtil.currentTime()));
                }
                mOnEventProcessor.process(TYPE_BOOK_SUBSCRIBE_ITEM_CLICKED, tag);
            } else if (tag instanceof RedirectInfo) {
                mOnEventProcessor.process(TYPE_BOOK_SHELF_CLICKED);
            }
        }
    };


}
