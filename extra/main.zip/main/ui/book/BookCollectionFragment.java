package com.hhdd.kada.main.ui.book;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.google.gson.Gson;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.BookService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.download.DownloadItemType;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.download.DownloadStatus;
import com.hhdd.kada.download.DownloadStatusVO;
import com.hhdd.kada.download.DownloadTask;
import com.hhdd.kada.download.DownloadTaskListener;
import com.hhdd.kada.main.controller.BookCollectionFragmentController;
import com.hhdd.kada.main.controller.BookCollectionSubscribeController;
import com.hhdd.kada.main.event.BookFinishDownloadEvent;
import com.hhdd.kada.main.event.BookSubscribeStatusEvent;
import com.hhdd.kada.main.event.ConnectivityChangedEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.model.BookListItem;
import com.hhdd.kada.main.model.ShareInfo;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.share.ShareProvider;
import com.hhdd.kada.share.ShareUtils;
import com.hhdd.kada.widget.BookCollectionSubscribeView;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by sxh on 2017/7/27.
 */

public class BookCollectionFragment extends BaseCollectionFragment {

    private BookCollectionFragmentController fragmentController;
    private BookCollectionSubscribeView subscribeLayout;
    private int currentDownloadId;
    private DownloadAllView downloadAllView;
    private StrongReference<DefaultCallback> cancelSubscribeStrongReference;
    private StrongReference<DefaultCallback> subscribeStrongReference;
    private StrongReference<DefaultCallback> orderStrongReference;

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        if (data != null && data instanceof String) {
            Gson gson = new Gson();
            mBookCollectionDetailInfo = gson.fromJson((String) data, BookCollectionDetailInfo.class);
            collectId = mBookCollectionDetailInfo.getCollectId();
        }
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        fragmentController = new BookCollectionFragmentController(this);

        if (((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).isBookCollectDownloading(collectId)) {
            downloadStatus = DownloadStatus.STATUS_DOWNLOADING;
        } else if (((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).isBookCollectDownloadCompletion(collectId)) {
            downloadStatus = DownloadStatus.STATUS_COMPLETE;
        }
        bookTitleBar.setResIdByStatus(downloadStatus);
        ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).addListener(downloadTaskListener);
        initView();

        showLoadingView();
        loadData("");
        initListener();

        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {

            public void onEvent(BookSubscribeStatusEvent event) {
                fragmentController.setSubscribedStatus(event.getStatus());
                if (event.getStatus() == 2) {
                    refreshUIBySubscribeStatus();
                    fragmentController.reloadDataImpl();
                } else if (event.getStatus() == 1) {
                    //订阅成功
                    fragmentController.getBookCollectionItemInfo();
                } else if (event.getStatus() == 0) {
                    BookCollectionSubscribeController subscribeController = fragmentController.getSubscribeController();
                    if (subscribeController != null) {
                        subscribeController.doCancelSubscribe();
                    }
                    fragmentController.setSubscribedStatus(1);
                } else if (event.getStatus() == 3) {
                    int collectId = 0;
                    BookCollectionDetailInfo info = fragmentController.getBookCollectionDetailInfo();
                    if (info != null) {
                        collectId = info.getCollectId();
                    }
                    String habitName = "";
                    String from = event.getFrom();
                    if (BookCollectionFragment.class.getSimpleName().equals(from)) {
                        habitName = "book_collection_cancel_subscribed_success";
                    } else if (BookCollectionTitleWebViewActivity.class.getSimpleName().equals(from)) {
                        habitName = "book_collection_introduction_cancel_subscribed_success";
                    }
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "", habitName, TimeUtil.currentTime()));

                    //取消订阅成功
                    doPauseDownload();
                    fragmentController.getBookCollectionItemInfo();
                }
                //滑到顶部
                getHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getmListView().scrollToPosition(0);
                    }
                }, 500);
                track(event);
            }

            public void onEvent(LoginEvent event) {
                loadData(event.getType());
            }

            public void onEvent(BookFinishDownloadEvent event) {
                mAdapter.notifyDataSetChanged();
            }

            public void onEvent(AuthService.AuthorizedSuccessEvent event) {
                loadData("");
            }

            public void onEvent(BookService.ReadingHistoryUpdatedEvent event) {
                refreshHasReadFlag();
                if (fragmentController!=null){
                    fragmentController.loadResumeData();
                }
            }

            public void onEvent(ConnectivityChangedEvent event) {
                if (event.isConnected) {
                    fragmentController.getBookCollectionItemInfo();
                }
            }

        }).tryToRegisterIfNot();
    }

    void initView() {
        fragmentController.initView();
        initBottomView();
    }

    private void loadData(String type) {
        if (mBookCollectionDetailInfo != null) {
            fragmentController.setBookCollectionDetailInfo(mBookCollectionDetailInfo);
        }
        fragmentController.getBookCollectionItemInfo(type);
    }

    @Override
    protected void initTitleBar() {
        super.initTitleBar();
        getTitleBar().addView(bookTitleBar, headerParams);
    }

    void initListener() {

    }

    void initBottomView() {
        /* 订阅底部栏 */
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }
        subscribeLayout = new BookCollectionSubscribeView(getContext());
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.BOTTOM;
        getInnerContainer().addView(subscribeLayout, params);
        subscribeLayout.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                switch (childView.getId()) {
                    case R.id.introduceLayout:
                        BookCollectionDetailInfo info = fragmentController.getBookCollectionDetailInfo();
                        if(info == null) {
                            return;
                        }
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getCollectId() + "", "book_collection_introduction_btn_click", TimeUtil.currentTime()));
                        if (info.getIntroduction() != null) {
                            ActivityUtil.nextBookCollectionTitleWebViewActivity(getContext(), info);
                        }
                        break;
                    case R.id.subscribeLayout:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "", "book_collection_subscribe_btn_click", TimeUtil.currentTime()));
                        BookCollectionSubscribeController subscribeController = fragmentController.getSubscribeController();
                        if (subscribeController != null) {
                            subscribeController.doSubscribe();
                        }
                        break;
                    default:
                        break;
                }
            }
        });
        subscribeLayout.setVisibility(View.GONE);

        /* 全部下载进度底部栏 */
        downloadAllView = new DownloadAllView(getContext());
        FrameLayout.LayoutParams downloadParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LocalDisplay.dp2px(50));
        downloadParams.gravity = Gravity.BOTTOM;
        getInnerContainer().addView(downloadAllView, downloadParams);
        downloadAllView.refresh(downloadStatus);
    }

    @Override
    protected void doRefresh() {
        fragmentController.getBookCollectionItemInfo();
    }

    @Override
    protected void handleRetry() {
        showLoadingView();
        fragmentController.getBookCollectionItemInfo();
    }

    @Override
    public void onPause() {
        super.onPause();
        if (fragmentController != null) {
            fragmentController.onPause();
        }
    }

    @Override
    public void doStartDownload() {
        BookCollectionDetailInfo bookCollectionDetailInfo = fragmentController.getBookCollectionDetailInfo();
        if (bookCollectionDetailInfo == null) {
            return;
        }
        if (bookCollectionDetailInfo.getStatus() != Constants.ONLINE) {
            ToastUtils.showToast(getResources().getString(R.string.content_is_offline_can_not_download));
            return;
        }

        if (bookCollectionDetailInfo.getSubscribe() == 1) {
            downloadStatus = DownloadStatus.STATUS_DOWNLOADING;
            fragmentController.reloadDataImpl();
            ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).download(bookCollectionDetailInfo);
            bookTitleBar.setResIdByStatus(downloadStatus);
            downloadAllView.refresh(downloadStatus);
        }
    }

    @Override
    public void doPauseDownload() {
        if (taskId > 0) {
            ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).pause(taskId);
            downloadStatus = DownloadStatus.STATUS_PAUSED;
            downloadAllView.refresh(downloadStatus);
            bookTitleBar.setResIdByStatus(downloadStatus);
            BookListItem item = downloadStatusVOMap.get(currentDownloadId);
            if (isVisible() && item != null) {
                String tag = "" + currentDownloadId + "_" + DownloadItemType.BOOK;
                View itemView = item.getItemView();
                if (itemView != null && itemView.getTag() != null && TextUtils.equals(tag, (String) itemView.getTag())) {
                    BookItemView bookItemView = (BookItemView) itemView;
                    bookItemView.hideDownloadContainer();
                }
            }
        }
    }

    @Override
    protected void doShare() {
        final BookCollectionDetailInfo detailInfo = fragmentController.getBookCollectionDetailInfo();
        if (detailInfo != null) {
            if (detailInfo.getStatus() != Constants.ONLINE && detailInfo.getStatus() != 0) {
                ToastUtils.showToast(getResources().getString(R.string.content_is_offline_can_not_share));
                return;
            }
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(detailInfo.getCollectId() + "", "book_collection_begin_share_click", TimeUtil.currentTime()));

            String recommend;
            if (TextUtils.isEmpty(detailInfo.getRecommend())) {
                recommend = detailInfo.getName();
            } else {
                recommend = detailInfo.getRecommend();
            }
            if (getContext() == null || getContext().isFinishing()) {
                return;
            }
            String title = detailInfo.getName();
            if (TextUtils.isEmpty(title)) {
                title = getResources().getString(R.string.share_story_default_title);
            }
            String content = recommend;
            if (TextUtils.isEmpty(content)) {
                content = getResources().getString(R.string.share_default_content);
            }

            int collectionId = detailInfo.getCollectId();
            ShareInfo shareInfo = new ShareInfo();
            shareInfo.setTitle(title);
            shareInfo.setContent(content);
            shareInfo.setImageUrl(detailInfo.getCoverUrl());
            String smallAppSquare = detailInfo.getSmallAppSquare();
            if (TextUtils.isEmpty(smallAppSquare)) {
                smallAppSquare = shareInfo.getImageUrl();
            }
            shareInfo.setSmallAppSquare(smallAppSquare);
            shareInfo.setTargetUrl(API.BOOK_COLLECTION_SHARE_URL() + collectionId);
            shareInfo.setWxMinPath(ShareUtils.getWxMinBookPagePath(String.valueOf(collectionId)));
            ShareProvider.share(getActivity(), shareInfo, new MyShareListener(collectionId));
        }
    }

    public void refreshUIBySubscribeStatus() {
        BookCollectionDetailInfo detailInfo = fragmentController.getBookCollectionDetailInfo();
        if (detailInfo.getSubscribe() != 1) {
            doPauseDownload();
        }
        showBackground(detailInfo.getBackImage());
        if (detailInfo.getSubscribe() == 1) {
            setInnerViewPaddingBottom(0);
            subscribeLayout.setVisibility(View.GONE);
        } else {
            setInnerViewPaddingBottom(LocalDisplay.dp2px(50));
            subscribeLayout.setVisibility(View.VISIBLE);
            subscribeLayout.update(detailInfo.getExtFlag(), detailInfo.getCount(), detailInfo.getPrice(), detailInfo.getOriginalPrice());
        }

        bookTitleBar.initialize(detailInfo.getSubscribe());
        bookTitleBar.updateTitle(detailInfo.getName());
    }

    public void showBackground(String imageUrl) {
        if (!TextUtils.isEmpty(imageUrl)) {
            String imgUrl = CdnUtils.getImgCdnUrl(imageUrl, CdnUtils.SIZE_700x1244, true);
            setBackground(imgUrl, R.drawable.collection_bg);
        } else {
            setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        }
    }

    long taskId;
    Map<Integer, BookListItem> downloadStatusVOMap = new HashMap<>();

    DownloadTaskListener downloadTaskListener = new DownloadTaskListener() {
        @Override
        public void addedDownloads(List<DownloadTask> taskList) {
        }

        @Override
        public void addedDownload(DownloadTask task) {
            if (task == null || task.getDownloadInfo() == null) {
                return;
            }

            if (task.getDownloadInfo().getItemId() == collectId) {
                taskId = task.getDownloadInfo().getId();
            }
        }

        @Override
        public void preDownload(DownloadTask task) {

        }

        @Override
        public void pausedDownload(long downloadId) {

        }

        @Override
        public void updateCollectItemProcess(int downloadId, int progress) {
            if (downloadStatus != DownloadStatus.STATUS_DOWNLOADING) {
                return;
            }
            currentDownloadId = downloadId;
            BookListItem item = downloadStatusVOMap.get(downloadId);
            if (item == null) {
                List<BookListItem> datalist = fragmentController.getDownloadList();
                for (int i = 0; i < datalist.size(); i++) {
                    BookListItem bookListItem = datalist.get(i);
                    bookListItem.setDownloadStatusVO(new DownloadStatusVO());
                    if (bookListItem.getData() instanceof BookInfo) {
                        BookInfo info = (BookInfo) bookListItem.getData();
                        if (info.getBookId() == downloadId) {
                            downloadStatusVOMap.put(downloadId, datalist.get(i));
                            break;
                        }
                    }
                }
                item = downloadStatusVOMap.get(downloadId);
                if (item != null) {
                    DownloadStatusVO downloadStatusVO = item.getDownloadStatusVO();
                    if (downloadStatusVO != null) {
                        downloadStatusVO.setDownloadStatus(DownloadStatus.STATUS_ADDED);
                    } else {
                        downloadStatusVO = new DownloadStatusVO();
                        downloadStatusVO.setDownloadId(downloadId);
                        downloadStatusVO.setDownloadStatus(DownloadStatus.STATUS_ADDED);
                        item.setDownloadStatusVO(downloadStatusVO);
                    }
                }
            }
            if (item != null) {
                DownloadStatusVO downloadStatusVO = item.getDownloadStatusVO();
                if (downloadStatusVO != null) {
                    downloadStatusVO.setProcess(progress);
                    if (progress == 100) {
                        downloadStatusVO.setDownloadStatus(DownloadStatus.STATUS_COMPLETE);
                    }
                }
                if (isVisible()) {
                    updateDownloadView(downloadId, progress, item);
                }
            }
        }

        @Override
        public void finishDownload(DownloadTask task) {
            if (task == null || task.getDownloadInfo() == null) {
                return;
            }
            if (task.getDownloadInfo().getItemId() == collectId) {
                downloadStatusVOMap.clear();
                downloadStatus = DownloadStatus.STATUS_COMPLETE;
                downloadAllView.refresh(downloadStatus);
                bookTitleBar.setResIdByStatus(downloadStatus);
                ToastUtils.showToast("下载完成");
            }
        }

        @Override
        public void updateProcess(DownloadTask task) {
            if (task == null || task.getDownloadInfo() == null) {
                return;
            }
            if (task.getDownloadInfo().getItemId() == collectId) {
                taskId = task.getDownloadInfo().getId();
                downloadAllView.setProgress((int) task.getDownloadProcess());
            }
        }

        @Override
        public void errorDownload(DownloadTask task, Throwable error) {
            doPauseDownload();
            downloadStatus = DownloadStatus.STATUS_ERROR;
            ToastUtils.showToast("网络有问题，请稍后再试");
        }
    };

    private void updateDownloadView(int downloadId, int progress, BookListItem item) {
        String tag = "" + downloadId + "_" + DownloadItemType.BOOK;
        View taskListItem = item.getItemView();
        if (taskListItem != null && taskListItem.getTag() != null && TextUtils.equals(tag, (String) taskListItem.getTag())) {
            BookItemView bookItemView = (BookItemView) taskListItem;
            bookItemView.updateProgress(progress);
            if (progress == 100) {
                item.getDownloadStatusVO().setDownloadStatus(DownloadStatus.STATUS_COMPLETE);
                refreshBeforeBook(item.getIndex());
            }
        }
    }

    /**
     * 避免添加回调前状态丢失问题，下载完单本时，需要检查上一本的下载状态
     *
     * @param position
     */
    private void refreshBeforeBook(int position) {
        if (position <= 0) {
            return;
        }
        BookItemView itemView = fragmentController.getDownloadList().get(position - 1).getItemView();
        if (itemView != null && !itemView.isAlreadyShowDownloadFinished()) {
            itemView.showDatabaseFlag();
        }
    }

    /**
     * 刷新已读标记
     */
    private void refreshHasReadFlag() {
        for (int i = 0; i < fragmentController.getDownloadList().size(); i++) {
            BookItemView itemView = fragmentController.getDownloadList().get(i).getItemView();
            if (itemView != null) {
                itemView.showDatabaseFlag();
            }
        }
    }

    @Override
    public void handleErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg) {
        super.handleErrorOccurred(isFirstPage, errorCode, errorMsg);
        if (getDataListDisplayed().getDataList().size() > 0) {
            mLoadingView.hide();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (fragmentController != null) {
            fragmentController.onDestroy();
        }

        if (orderStrongReference != null) {
            orderStrongReference.clear();
            orderStrongReference = null;
        }
        if (cancelSubscribeStrongReference != null) {
            cancelSubscribeStrongReference.clear();
            cancelSubscribeStrongReference = null;
        }
        if (subscribeStrongReference != null) {
            subscribeStrongReference.clear();
            subscribeStrongReference = null;
        }

        ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeListener(downloadTaskListener);
    }


    private boolean isInit = true;   //是否是第一次进页面初始化

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser,
                                       boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                track(null);
            }
        };
        //防止第一次重复打两个相同点
        if (isVisibleToUser && !isInit) {
            getHandler().postDelayed(runnable, 500);
        }
        isInit = false;

    }

    public void showSubscribeFingerGuideAnim() {
        if (subscribeLayout != null) {
            subscribeLayout.showSubscribeFingerGuideAnim();
        }
    }

    /**
     * 页面展示打点
     *
     * @param event
     */
    private void track(BookSubscribeStatusEvent event) {
        if (event == null) {
            if (fragmentController.getBookCollectionDetailInfo() != null) {
                int subscribe = fragmentController.getBookCollectionDetailInfo().getSubscribe();
                if (subscribe == 1) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "", "book_collection_subscribed_view", TimeUtil.currentTime()));
                } else {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "", "book_collection_unsubscribed_view", TimeUtil.currentTime()));
                }
            }
        } else {
            switch (event.getStatus()) {
                case 1:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "", "book_collection_subscribed_view", TimeUtil.currentTime()));
                    break;
                case 3:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "", "book_collection_unsubscribed_view", TimeUtil.currentTime()));
                    break;
                default:
                    break;
            }
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }


    private static class MyShareListener implements ShareProvider.Listener {

        private long mCollectId;

        public MyShareListener(long id) {
            mCollectId = id;
        }

        @Override
        public void onComplete(boolean success, SHARE_MEDIA share_media) {
            if (success) {
                //成功
                switch (share_media) {
                    case WEIXIN:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mCollectId + "," + "1", "book_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    case WEIXIN_CIRCLE:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mCollectId + "," + "2", "book_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    case QQ:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mCollectId + "," + "3", "book_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    case QZONE:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mCollectId + "," + "4", "book_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    case SINA:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mCollectId + "," + "5", "book_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    default:
                        break;
                }
            } else {
                //失败
            }
        }
    }
}
