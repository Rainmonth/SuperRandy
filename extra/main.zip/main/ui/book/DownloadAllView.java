package com.hhdd.kada.main.ui.book;

import android.content.Context;
import android.util.AttributeSet;

import com.hhdd.kada.R;
import com.hhdd.kada.download.DownloadStatus;
import com.hhdd.kada.main.ui.story.FishProgressBar;
import com.hhdd.kada.main.views.base.BaseLinearLayout;

import butterknife.BindView;

/**
 * Created by sxh on 2017/9/1.
 */

public class DownloadAllView extends BaseLinearLayout {

    @BindView(R.id.pb_download_all)
    FishProgressBar fishProgressBar;

    public DownloadAllView(Context context) {
        super(context);
    }

    public DownloadAllView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.download_all_progress_layout;
    }

    @Override
    public void doInitView() {
        fishProgressBar.setMax(100);
        fishProgressBar.setProgress(0);
    }

    public void setProgress(int progress){
        fishProgressBar.setProgress(progress);
    }

    public void refresh(int status){
        if (status==DownloadStatus.STATUS_DOWNLOADING){
            setVisibility(VISIBLE);
        }else if (status==DownloadStatus.STATUS_PAUSED||status==DownloadStatus.STATUS_COMPLETE||status==DownloadStatus.STATUS_INITIAL){
            setVisibility(GONE);
        }
    }

}
