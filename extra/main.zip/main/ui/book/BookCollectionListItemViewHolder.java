package com.hhdd.kada.main.ui.book;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelVO;

/**
 * Created by mcx on 2017/8/8.
 */

public class BookCollectionListItemViewHolder extends BaseViewHolder<BaseModelVO> {

    public static final int TYPE_BOOK_COLLECTION_ITEM_CLICKED = 100;

    private View holderView;

    int itemWidth = 0;
    int itemHeight = 0;

    View view;
    TextView tvName;
    TextView tvDetail;
    ImageView newFlag;
    View charge;
    ImageView serialize;
    ScaleDraweeView cover;


    @Override
    public View createView(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        holderView = layoutInflater.inflate(R.layout.view_holder_book_collect_list_item, parent, false);
        itemWidth = (LocalDisplay.SCREEN_WIDTH_PIXELS - 2 * LocalDisplay.dp2px(10) - LocalDisplay.dp2px(11)) / 2;
        itemHeight = (int) (itemWidth * 28.0f / 45.0f);
        view = holderView.findViewById(R.id.item_container);
        tvName = (TextView) holderView.findViewById(R.id.name);
        tvDetail = (TextView) holderView.findViewById(R.id.detail);
        newFlag = (ImageView) holderView.findViewById(R.id.new_flag);
        charge = holderView.findViewById(R.id.charge);
        serialize = (ImageView) holderView.findViewById(R.id.serialize);
        cover = (ScaleDraweeView) holderView.findViewById(R.id.cover);

        return holderView;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        BaseModel baseModel = itemData.getModel();
        if (baseModel instanceof BookCollectionInfo) {
            final BookCollectionInfo info = (BookCollectionInfo) baseModel;
            view.getLayoutParams().height = (int) (itemHeight + LocalDisplay.dp2px(55));
            view.setPadding(LocalDisplay.dp2px(6), 0, LocalDisplay.dp2px(5), 0);
            tvName.setText(info.getName());
            tvDetail.setText(info.getRecommend());
            //new标志
            if ((info.getExtFlag() & Extflag.EXT_FLAG_64) == Extflag.EXT_FLAG_64) {
                newFlag.setVisibility(View.VISIBLE);
            } else {
                newFlag.setVisibility(View.GONE);
            }
            //收费标志
            if ((info.getExtFlag() & Extflag.EXT_FLAG_1024) == Extflag.EXT_FLAG_1024) {
                charge.setVisibility(View.VISIBLE);
            } else {
                charge.setVisibility(View.GONE);
            }
            //连载中标志

            serialize.setVisibility(View.GONE);

            view.setTag(R.id.container,info);
            view.setOnClickListener(listener);

            cover.getLayoutParams().width = itemWidth;
            cover.getLayoutParams().height = itemHeight;
//            cover.setPadding(0, 0, LocalDisplay.dp2px(6), 0);

            int width = itemWidth;//view.getWidth();
            int height = itemHeight;//view.getHeight();

            if (info.getBannerUrl() != null) {
                String coverUrl = CdnUtils.getImgCdnUrl(info.getBannerUrl(), CdnUtils.getTwoCoverImgSize());
                FrescoUtils.showUrl(coverUrl, cover, width, height);
                //不用做这些逻辑，showUrl里面做过了。
//                boolean needResetImageUrl = true;
//                if (cover.getTag(R.id.list_item_image_url) != null) {
//                    String url = (String) cover.getTag(R.id.list_item_image_url);
//                    Log.d("BUG",info.getName()+":tag url = "+url);
//                    Log.d("BUG",info.getName()+":img url = "+coverUrl);
//                    if (TextUtils.equals(url, coverUrl)) {
//                        needResetImageUrl = false;
//                    }
//                }
//                if (needResetImageUrl) {
//                    Log.d("BUG",info.getName()+":needResetImageUrl");
//                    cover.setTag(R.id.list_item_image_url, coverUrl);
//                    FrescoUtils.showUrl(coverUrl, cover, width, height);
//                }
            }
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            BookCollectionInfo info = (BookCollectionInfo) view.getTag(R.id.container);
            mOnEventProcessor.process(TYPE_BOOK_COLLECTION_ITEM_CLICKED, info);
        }
    };
}
