package com.hhdd.kada.main.ui.book;

import android.graphics.Color;
import android.view.View;

import com.facebook.drawee.generic.RoundingParams;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.PayAPI;
import com.hhdd.kada.api.TalentPlanAPI;
import com.hhdd.kada.main.model.TalentPlanCollectInfo;
import com.hhdd.kada.store.model.OrderFragParamData;
import com.hhdd.kada.store.model.VirtualOrderListInfo;

/**
 * Created by mcx on 2017/12/1.
 */

public class TalentPlanPayFragment extends BasePayFragment {

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        //从详情页面进入
        if (data != null && data instanceof OrderFragParamData) {
            mOrderFragParamData = (OrderFragParamData) data;
            if (mOrderFragParamData.getOrderDetail() instanceof TalentPlanCollectInfo) {
                mTalentPlanCollectInfo = (TalentPlanCollectInfo) mOrderFragParamData.getOrderDetail();
            }
            mOrderId = mOrderFragParamData.getOrderId();
            mCollectionId = mOrderFragParamData.getCollectId();
//            mCollectionId = mTalentPlanCollectInfo.getCollectId();
        }
        //从订单页面进入
        else if (data != null && data instanceof VirtualOrderListInfo.OrderItemInfo) {
            mOrderItemInfo = (VirtualOrderListInfo.OrderItemInfo) data;
            mOrderId = mOrderItemInfo.getId();
            mCollectionId = mOrderItemInfo.getCollectId();
        }
    }

    @Override
    protected void loadDetailData() {
        if (mTalentPlanCollectInfo == null) {
            DefaultCallback callback = new DefaultCallback<TalentPlanCollectInfo>() {
                @Override
                public void onDataReceived(final TalentPlanCollectInfo data) {
                    if (data != null) {
                        mTalentPlanCollectInfo = data;
                        KaDaApplication.mainLooperHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                loadData();
                            }
                        });
                    }
                }

                @Override
                public void onException(String reason) {
                    super.onException(reason);
                    mLoadingView.showError();
                }
            };
            if (mStrongReference == null) {
                mStrongReference = new StrongReference<>();
            }
            mStrongReference.set(callback);
            TalentPlanAPI.getTalentPlanCollectInfo(mCollectionId, mStrongReference);
        } else {
            loadData();
        }
    }

    @Override
    protected void setCoverBackground() {
        RoundingParams roundingParams = mCover.getHierarchy().getRoundingParams();
        roundingParams.setCornersRadii(LocalDisplay.designedDP2px(6), LocalDisplay.designedDP2px(6), LocalDisplay.designedDP2px(6), LocalDisplay.designedDP2px(6));
        roundingParams.setBorderWidth(LocalDisplay.designedDP2px(2));
        roundingParams.setBorderColor(Color.WHITE);
        mCover.getHierarchy().setRoundingParams(roundingParams);
        mCover.setPadding(0, 0, 0, 0);
        mCover.setBackgroundDrawable(null);

        leftBorder.setVisibility(View.GONE);

        mHeight = 120;
        mWidth = 120;
    }

    @Override
    protected int getOrderType() {
        return PayAPI.TYPE_ORDER_TALENT_PLAN;
    }
}
