package com.hhdd.kada.main.ui.adapter;

import com.hhdd.kada.android.library.views.list.RecyclerAdapterBase;
import com.hhdd.kada.android.library.views.list.ViewHolderCreator;
import com.hhdd.kada.main.vo.BaseVO;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/23
 * @describe : com.hhdd.kada.main.ui.adapter
 */
public class RecommendSubscribeContentAdapter extends RecyclerAdapterBase<BaseVO> {

    private List<BaseVO> contentList;

    public RecommendSubscribeContentAdapter() {
        super(null);
    }

    public RecommendSubscribeContentAdapter(ViewHolderCreator<BaseVO> viewHolderCreator) {
        super(viewHolderCreator);
    }

    public List<BaseVO> getContentList() {
        return contentList;
    }

    public void setContentList(List<BaseVO> contentList) {
        this.contentList = contentList;
    }

    @Override
    public int getItemCount() {
        if (null == contentList) {
            return 0;
        }
        return contentList.size();
    }

    @Override
    public BaseVO getItem(int position) {
        if (null == contentList) {
            return null;
        }
        return contentList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }
}
