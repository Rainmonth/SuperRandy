package com.hhdd.kada.main.ui.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseCollectionInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/3
 * @describe : com.hhdd.kada.main.ui.adapter
 */
public class Book2X2GridViewAdapter extends QuickAdapter<BaseModel> {

    int itemWidth = 0;
    int itemHeight = 0;

    public Book2X2GridViewAdapter(Context context) {
        super(context, R.layout.view_holder_book_collect_item_2x2);
        itemWidth = (ScreenUtil.getScreenWidth() - LocalDisplay.dp2px(10 + 10 + 10)) / 2;
        itemHeight = (int) (itemWidth * Constants.MOTHER_TOW_COVER_RATIO);
    }

    @Override
    protected void convert(BaseAdapterHelper helper, BaseModel model) {
        if (model != null && model instanceof BaseCollectionInfo) {
            BookCollectionInfo info = (BookCollectionInfo) model;
            View view = helper.getView(R.id.item_container);
            view.getLayoutParams().width = itemWidth;
            view.getLayoutParams().height = itemHeight + LocalDisplay.dp2px(60);

            TextView tvName = helper.getView(R.id.name);
            tvName.setText(info.getName());

            TextView tvDetail = helper.getView(R.id.detail);
            tvDetail.setText(info.getRecommend());

            View newFlag = helper.getView(R.id.new_flag);
            View charge = helper.getView(R.id.charge);
            TextView count = helper.getView(R.id.count);
            //new标志
            if ((info.getExtFlag() & Extflag.EXT_FLAG_64) == Extflag.EXT_FLAG_64) {
                newFlag.setVisibility(View.VISIBLE);
            } else {
                newFlag.setVisibility(View.GONE);
            }
            //收费标志
            if ((info.getExtFlag() & Extflag.EXT_FLAG_1024) == Extflag.EXT_FLAG_1024) {
                charge.setVisibility(View.VISIBLE);
            } else {
                charge.setVisibility(View.GONE);
            }
            //本数标志
            if (info.getCount()>0){
                count.setVisibility(View.VISIBLE);
                count.setText(info.getCount()+"本");
            }else {
                count.setVisibility(View.GONE);
            }


            SimpleDraweeView coverView = helper.getView(R.id.cover);
            coverView.getLayoutParams().width = itemWidth;
            coverView.getLayoutParams().height = itemHeight;

            int width = itemWidth;//view.getWidth();
            int height = itemHeight;//view.getHeight();

            String coverUrl = CdnUtils.getImgCdnUrl(info.getBannerUrl(), CdnUtils.getTwoCoverImgSize());
            if(TextUtils.isEmpty(coverUrl)){
                coverUrl = info.getCoverUrl();
            }
            if(TextUtils.isEmpty(coverUrl)){
                return;
            }
            boolean needResetImageUrl = true;
            if (coverView.getTag(R.id.list_item_image_url) != null) {
                String url = (String) coverView.getTag(R.id.list_item_image_url);
                if (TextUtils.equals(url, coverUrl)) {
                    needResetImageUrl = false;
                }
            }
            if (needResetImageUrl) {
                coverView.setTag(R.id.list_item_image_url, coverUrl);
                FrescoUtils.showImg(coverView, coverUrl, width, height);
            }
        }
    }
}
