package com.hhdd.kada.main.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AbsListView;
import android.widget.BaseAdapter;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by simon on 11/6/15.
 */
public abstract class MyBaseAdapter<T> extends BaseAdapter {

    protected Context mContext = null;
    protected LayoutInflater mInflater = null;
    protected List<T> mItems = null;
    protected WeakReference<AbsListView> mListView = null;
    protected View mHeaderView = null;

    public void recycle() {

    }

    public MyBaseAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
        this.mContext = context;
        this.mItems = new ArrayList<T>();
    }

    public void addAll(List<T> item) {
        if (mItems != null) {
            mItems.addAll(item);
        }
    }

    public void add(T item) {
        if (mItems != null) {
            mItems.add(item);
        }
    }
    public void add(int position,T item){
        if(mItems != null){
            mItems.add(position,item);
        }
    }

    public void removeAll(List<T> item) {
        if (mItems != null) {
            mItems.removeAll(item);
        }
    }

    public void remove(int position){
        if(mItems != null && mItems.size() > position){
            mItems.remove(position);
        }
    }

    public void clear() {
        if (mItems != null && mItems.size() > 0) {
            mItems.clear();
        }
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    public List<T> getItems(){
        return mItems;
    }

    public T getItemAt(int position) {
        T t = null;
        if (mItems != null && mItems.size() > position) {
            t = mItems.get(position);
        }
        return t;
    }

    @Override
    public int getCount() {
        return mItems != null ? mItems.size() : 0;
    }

    @Override
    public Object getItem(int position) {
        return mItems != null ? mItems.get(position) : null;
    }

    public void setListView(AbsListView listView){
        mListView = new WeakReference<AbsListView>(listView);
    }

    /**
     * 调用此方法注意ListView的头部个数,默认为DEFAULT_HEADER_COUNT
     * @param index
     * @return
     */
    public View getChildAt(int index){
        View view = null;
        if(mListView == null || mListView.get() == null){
            return view;
        }
        int firstVisiblePos = mListView.get().getFirstVisiblePosition();
        view = mListView.get().getChildAt(index - firstVisiblePos);
        return view;
    }

    public void push(List<T> items){
        if(mItems != null && items != null){
            mItems.addAll(0, items);
        }
    }

    public void push(T item){
        if(mItems != null && item != null){
            mItems.add(0, item);
        }
    }

    public void setHeaderView(View view){
        this.mHeaderView = view;
    }
}
