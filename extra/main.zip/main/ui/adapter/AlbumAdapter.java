package com.hhdd.kada.main.ui.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.core.model.BaseVO;
import com.hhdd.core.model.HomeVO;
import com.hhdd.core.model.StoryInfo;
import com.hhdd.core.service.StoryService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.main.ui.viewholder.AlbumBannerViewHolder;
import com.hhdd.kada.main.ui.viewholder.AlbumBookListViewHolder;
import com.hhdd.kada.main.ui.viewholder.AlbumListenListViewHolder;
import com.hhdd.kada.main.ui.viewholder.BaseViewHolder;
import com.hhdd.kada.main.ui.viewholder.SepViewHolder;
import com.hhdd.kada.main.ui.viewholder.UnkownViewHolder;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;

import static com.hhdd.kada.Constants.PLAY_MODE;
import static com.hhdd.kada.Constants.STOP_MODE;


/**
 * Created by zhengkaituo on 15/12/28.
 */
public class AlbumAdapter extends MyBaseAdapter<HomeVO> {
    public static final int ITEM_VIEW_TYPE_SEP2 = 0;
    public static final int ITEM_VIEW_TYPE_ALBUM_STORY_BANNER = 1;
    public static final int ITEM_VIEW_TYPE_ALBUM_BOOK_BANNER = 2;
    public static final int ITEM_VIEW_TYPE_BOOK_LIST = 3;
    public static final int ITEM_VIEW_TYPE_STORY_LIST = 4;
    public static final int ITEM_VIEW_TYPE_UNKNOWN = 5;
    public static int UPWARD = 1;
    public static int DOWNWARD = 2;

    public AlbumAdapter(Context context) {
        super(context);
        EventBus.getDefault().register(this);
    }

    List<AlbumListenListViewHolder> viewHolders = new ArrayList<AlbumListenListViewHolder>();

    @Override
    public void recycle() {
        super.recycle();
        EventBus.getDefault().unregister(this);

        for (AlbumListenListViewHolder viewHolder : viewHolders) {
            viewHolder.recycle();
        }
        viewHolders.clear();
    }


    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        BaseViewHolder viewHolder = null;
        int type = getItemViewType(position);

        if (convertView == null) {
            viewHolder = getViewHolder(mContext, type);

            convertView = viewHolder.initView();
            convertView.setTag(R.id.album_list_view_holder, viewHolder);
        } else {
            viewHolder = (BaseViewHolder) convertView.getTag(R.id.album_list_view_holder);
        }
        viewHolder.loadData(getItemAt(position).getItemList());

        if (viewHolder instanceof AlbumListenListViewHolder) {
            if (!viewHolders.contains(viewHolder)) {
                viewHolders.add((AlbumListenListViewHolder) viewHolder);
            }
        }

        List<BaseVO> list = getItemAt(position).getItemList();
        if(viewHolder instanceof AlbumListenListViewHolder){
            if (storyInfo != null) {
                if (list.contains(storyInfo))
                    ((AlbumListenListViewHolder) viewHolder).setMode(mode, list.indexOf(storyInfo));
                else {
                    ((AlbumListenListViewHolder) viewHolder).setMode(STOP_MODE, -1);
                }
            } else {
                ((AlbumListenListViewHolder) viewHolder).setMode(STOP_MODE, -1);
            }
        }

        return convertView;
    }

    StoryInfo storyInfo;
    int mode;

    public void onEvent(StoryService.StartReadingEvent event) {
        storyInfo = event.getStoryInfo();
        mode = PLAY_MODE;
    }

    public void onEvent(StoryService.PauseReadingEvent event) {
        storyInfo = event.getStoryInfo();
        mode = STOP_MODE;
    }

    public void onEvent(StoryService.StopReadingEvent event) {
        storyInfo = null;
        mode = STOP_MODE;
    }

    @Override
    public int getItemViewType(int position) {
        return getItemAt(position).getItemType();
    }

    @Override
    public int getViewTypeCount() {
        return ITEM_VIEW_TYPE_UNKNOWN;
    }

    public static BaseViewHolder getViewHolder(Context context, int type) {
        BaseViewHolder viewHolder = null;
        switch (type) {
            case ITEM_VIEW_TYPE_ALBUM_STORY_BANNER:
                viewHolder = new AlbumBannerViewHolder(context, Constants.TYPE_STORY);
                break;
            case ITEM_VIEW_TYPE_ALBUM_BOOK_BANNER:
                viewHolder = new AlbumBannerViewHolder(context, Constants.TYPE_BOOK);
                break;
            case ITEM_VIEW_TYPE_STORY_LIST:
                viewHolder = new AlbumListenListViewHolder(context);
                break;
            case ITEM_VIEW_TYPE_BOOK_LIST:
                viewHolder = new AlbumBookListViewHolder(context);
                break;
            case ITEM_VIEW_TYPE_SEP2:
                viewHolder = new SepViewHolder(context);
                break;
            default:
                viewHolder = new UnkownViewHolder(context);
                break;
        }
        return viewHolder;
    }
}

