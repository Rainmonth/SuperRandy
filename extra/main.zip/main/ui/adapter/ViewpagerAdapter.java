package com.hhdd.kada.main.ui.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.core.model.StoryInfo;
import com.hhdd.kada.R;
import com.hhdd.kada.main.ui.viewholder.ListenBookViewHolder;
import com.hhdd.kada.main.views.RecyclingPagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lj on 15/9/24.
 */
public class ViewpagerAdapter extends RecyclingPagerAdapter {

    private int[] mBgImgResIds = new int[]{R.drawable.bg_listen_viewpager_1, R.drawable.bg_listen_viewpager_2, R.drawable.bg_listen_viewpager_3, R.drawable.bg_listen_viewpager_4};

    private List<StoryInfo> storyList;
    private Context mContext;

    List<ListenBookViewHolder> viewHolders = new ArrayList<ListenBookViewHolder>();

    public ViewpagerAdapter(Context context) {
        this(context,new ArrayList<StoryInfo>());
    }

    public ViewpagerAdapter(Context context,List<StoryInfo> list) {
        mContext = context;
        storyList = list;
    }

    public void clear(){
        this.storyList.clear();
    }
    public void setStoryList(List<StoryInfo> storyList) {
        this.storyList.addAll(storyList);
    }


    public StoryInfo getItem(int position){
        if(storyList != null && position<storyList.size()){
            return storyList.get(position);
        }
        return null;
    }


    @Override
    public int getCount() {
        return storyList.size() == 0? 1:storyList.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup viewGroup) {
        ListenBookViewHolder viewHolder = null;
        if (convertView == null) {
            viewHolder = new ListenBookViewHolder(mContext);
            convertView = viewHolder.initView();
            convertView.setTag(R.id.listen_book_view_holder, viewHolder);

            if (!viewHolders.contains(viewHolder)) {
                viewHolders.add(viewHolder);
            }
        } else {
            viewHolder = (ListenBookViewHolder) convertView.getTag(R.id.listen_book_view_holder);
        }

        viewHolder.setBackground(mBgImgResIds[position % mBgImgResIds.length]);

        if (storyList.size() > position) {
            viewHolder.loadData(storyList.get(position));
        }

        convertView.setTag(R.id.listen_book_index,position);

        return convertView;
    }


    public void recycle(){
        for (ListenBookViewHolder viewHolder : viewHolders) {
            viewHolder.recycle();
        }
        viewHolders.clear();
    }
    int mChildCount = 0;

        @Override
    public void notifyDataSetChanged() {
        mChildCount = getCount();
        super.notifyDataSetChanged();
    }
    @Override
    public int getItemPosition(Object object)   {
        if ( mChildCount > 0) {
            mChildCount --;
            return POSITION_NONE;
        }
        return super.getItemPosition(object);
    }
}
