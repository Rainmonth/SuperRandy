package com.hhdd.kada.main.ui.activity;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.event.CloseRestEvent;
import com.hhdd.kada.main.event.UnLockEvent;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.logger.LogHelper;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/4
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class RestActivity extends BaseRestActivity {

    @BindView(R.id.clockLayout)
    View clockLayout;
    @BindView(R.id.clockImageView)
    ImageView clockImageView;
    @BindView(R.id.crabImageView)
    ImageView crabImageView;
    @BindView(R.id.restLayout)
    LinearLayout restLayout;
    private ScheduledExecutorService service;
    //倒计时秒数
    private int restTimeCountDownSecond;
    private Handler handler;
    private PrefsManager prefsManager;
    private PowerManager.WakeLock mWakeLock;

    @Override
    public int getLayoutId() {
        return R.layout.activity_rest;
    }

    @Override
    protected int getRawId() {
        return R.raw.have_a_rest;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            restLayout.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }
    }

    @Override
    public void doInitData() {
        super.doInitData();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getName());
        mWakeLock.acquire();

        EventBus.getDefault().register(this);
        handler = getHandler();
        int restTimeSecond = Settings.getInstance().getRestTime();
        prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
        long restTimeStart = prefsManager.getLong(Constants.REST_TIME_START);
        if (restTimeStart <= 0) {
            prefsManager.putLong(Constants.REST_TIME_START, System.currentTimeMillis());
            restTimeCountDownSecond = restTimeSecond;
        } else {
            restTimeCountDownSecond = restTimeSecond - (int) ((System.currentTimeMillis() - restTimeStart) / 1000);
            if (restTimeCountDownSecond <= 0 || restTimeCountDownSecond > restTimeSecond) {
                unLockRest(UnLockEvent.TYPE_REST_AUTO);
                animFinish();
                return;
            }
        }
        updateTime(restTimeCountDownSecond);
        service = new ScheduledThreadPoolExecutor(1);
        service.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                restTimeCountDownSecond--;
                handler.sendEmptyMessage(restTimeCountDownSecond);
                if (restTimeCountDownSecond == -1 && !service.isShutdown()) {
                    service.shutdownNow();
                }
            }
        }, 1000, 1000, TimeUnit.MILLISECONDS);
    }

    @Override
    protected void initAnimation() {
        rotationAnimator = ObjectAnimator.ofFloat(clockImageView, "rotation", 0, -30, 0, 30, 0);
        rotationAnimator.setDuration(4000);
        rotationAnimator.setInterpolator(new LinearInterpolator());
        rotationAnimator.setRepeatCount(-1);
        rotationAnimator.start();
    }

    @Override
    protected void doMotherUnLock() {
        unLockRest(UnLockEvent.TYPE_REST_USER);
    }

    @Override
    protected void doModifyTime() {
        unLockRest(UnLockEvent.TYPE_REST_USER);
    }

    @Override
    protected void doMotherUnLockHabit() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "once_timing_mom_unlock_click", TimeUtil.currentTime()));
    }

    @Override
    protected void doModifyTimeHabit() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "once_timing_modify_setting_click", TimeUtil.currentTime()));
    }

    /**
     * 解锁
     */
    private void unLockRest(int type) {
        UnLockEvent event = new UnLockEvent();
        event.setType(type);
        EventBus.getDefault().post(event);
        prefsManager.putLong(Constants.REST_TIME_START, 0);
    }

    @Override
    public boolean handleMessage(Message msg) {
        int allTimeSecond = msg.what;
        if (allTimeSecond >= 0) {
            updateTime(allTimeSecond);
        } else {
            unLockRest(UnLockEvent.TYPE_REST_AUTO);
            animFinish();
        }
        return super.handleMessage(msg);
    }

    public void onEvent(CloseRestEvent event) {
        prefsManager.putLong(Constants.REST_TIME_START, 0);
        animFinish();
    }

    /**
     * 更新时间
     *
     * @param allTimeSecond
     */
    private void updateTime(int allTimeSecond) {
        int timeMinute = allTimeSecond / 60;
        String timeMinuteStr = String.valueOf(timeMinute);
        if (timeMinute < 10) {
            timeMinuteStr = "0" + timeMinuteStr;
        }
        int timeSecond = allTimeSecond % 60;
        String timeSecondStr = String.valueOf(timeSecond);
        if (timeSecond < 10) {
            timeSecondStr = "0" + timeSecondStr;
        }
        timeTextView.setText(String.format(getResources().getString(R.string.setting_rest_time), timeMinuteStr, timeSecondStr));
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "once_timing_lock_view", TimeUtil.currentTime()));
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
            handler = null;
        }
        if (service != null) {
            if (!service.isShutdown()) {
                service.shutdownNow();
            }
            service = null;
        }
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try {
                mWakeLock.release();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        }
        super.onDestroy();
    }

}
