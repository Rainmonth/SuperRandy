package com.hhdd.kada.main.ui.activity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.coin.view.MagicTextView;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.utils.HHTimeUtil;
import com.hhdd.kada.main.utils.TextLengthFilter;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.medal.UserTrack;
import com.hhdd.logger.LogHelper;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import static com.hhdd.kada.medal.UserTrack.fmi;

/**
 * Created by lj on 16/4/22.
 */
public class BabyInfoSettingActivity extends BaseActivity {

    private boolean isNameTooLong = false;
    private MagicTextView confirm;

    public static void startActivity(Context context) {
        if (context == null) {
            return;
        }

        Intent intent = new Intent(context, BabyInfoSettingActivity.class);
        context.startActivity(intent);
    }

    //此构造方法暂时无用已注释
//    public static void startActivity(Context context, boolean isForcedUpdate) {
//        if (context == null) {
//            return;
//        }
//
//        Intent intent = new Intent(context, BabyInfoSettingActivity.class);
//        intent.putExtra("isForcedUpdate", isForcedUpdate);
//        context.startActivity(intent);
//    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getIntent() != null) {
            isForcedUpdate = getIntent().getBooleanExtra("isForcedUpdate", false);
        }
        setContentView(R.layout.activity_baby_info_setting);
        initView();
    }

    //是否强制要求填写宝宝信息
    boolean isForcedUpdate;

    EditText name;
    TextView birthday;
    int babyYear;
    int babyMonth;
    int babyDay;
    ImageView btnBoy;
    ImageView btnGirl;
    String gender;

    private StrongReference<DefaultCallback<UserDetail>> mUpdateUserInfoCallbackRef;

    void initView() {

        btnBoy = (ImageView) findViewById(R.id.btn_boy);
        btnGirl = (ImageView) findViewById(R.id.btn_girl);

        String currentGender = UserService.getInstance().currentUserGender();
        if (currentGender != null && currentGender.length() > 0) {
            if ("m".equalsIgnoreCase(currentGender)) {
                btnGirl.setSelected(false);
                btnBoy.setSelected(true);
                gender = "m";
            } else if ("f".equalsIgnoreCase(currentGender)) {
                btnGirl.setSelected(true);
                btnBoy.setSelected(false);
                gender = "f";
            }
        }
        name = (EditText) findViewById(R.id.name);
        name.setText(UserService.getInstance().currentUserNickName());
        name.setFilters(new InputFilter[]{new TextLengthFilter(Constants.NAME_LENGHT)});
        name.addTextChangedListener(new nameWatcher());
        name.setSelection(name.getText().length());
        isNameTooLong = name.getText().toString().getBytes().length > Constants.NAME_LENGHT;
        String string = name.getText().toString();
        try {
            if (string.getBytes(TextLengthFilter.CHARSET_NAME).length > Constants.NAME_LENGHT) {
                isNameTooLong = true;
            } else {
                isNameTooLong = false;
            }
        } catch (UnsupportedEncodingException e) {
            LogHelper.printStackTrace(e);
        }

        birthday = (TextView) findViewById(R.id.birthday);
        String userBirthday = UserService.getInstance().currentUserBirthday();
        if (!TextUtils.isEmpty(userBirthday) && HHTimeUtil.isInRange(userBirthday, Constants.USER_BEGIN_DATE, HHTimeUtil.currentDate())) {
            babyYear = HHTimeUtil.getYear(userBirthday);
            babyMonth = HHTimeUtil.getMonth(userBirthday);
            babyDay = HHTimeUtil.getDay(userBirthday);
            birthday.setText(userBirthday);
        }

//        View back = findViewById(R.id.back);
//        back.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
//            @Override
//            public void onNoDoubleClick(View v) {
//                hideKeyBoard();
//                finish();
//            }
//        });
        TitleBar titleBar = (TitleBar) findViewById(R.id.titleBar);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleViewLayoutParams = titleBar.getLayoutParams();
            if (titleViewLayoutParams == null) {
                titleViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleViewLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height) + LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleBar.setLayoutParams(titleViewLayoutParams);
            titleBar.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
        }

        titleBar.setLeftOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (isForcedUpdate) {
                    return;
                }
                hideKeyBoard();
                finish();
            }
        });

        birthday.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (babyYear == 0 || babyMonth == 0 || babyDay == 0) {
                    babyYear = HHTimeUtil.getCurrentYear();
                    babyMonth = 1;
                    babyDay = 1;
                }
//                android.R.style.Theme_Holo_Light_Dialog
                DatePickerDialog dialog = new DatePickerDialog(BabyInfoSettingActivity.this, AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        babyYear = year;
                        babyMonth = monthOfYear + 1;
                        babyDay = dayOfMonth;
                        String date = HHTimeUtil.getFormatDate(babyYear, babyMonth, babyDay);
                        birthday.setText(date);

                    }
                }, babyYear, babyMonth - 1, babyDay);

                // 如果手机系统时间小于{@link Constants.USER_BEGIN_DATE}，则minTime使用(systemCurrentTime - 1秒)
                long minTime = HHTimeUtil.milliTimeFromDate2(Constants.USER_BEGIN_DATE);
                long systemCurrentTime = System.currentTimeMillis();
                if (systemCurrentTime <= minTime) {
                    minTime = systemCurrentTime - 1000;
                }

                dialog.getDatePicker().setMinDate(minTime);// 设置可选择最小日期
                dialog.getDatePicker().setMaxDate(systemCurrentTime); // 设置可选择最大日期

                if (isFinishing()) {
                    return;
                }
                dialog.show();
            }
        });

        btnGirl.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                btnGirl.setSelected(true);
                btnBoy.setSelected(false);
                gender = "f";
            }
        });

        btnBoy.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                btnBoy.setSelected(true);
                btnGirl.setSelected(false);
                gender = "m";
            }
        });

        confirm = (MagicTextView) findViewById(R.id.btn_confirm);
//        magicTextView.setStroke(4, Color.parseColor("#ded20a"));

        confirm.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                Map<String, String> params = new HashMap<String, String>();
                if (name != null && name.getText().toString().trim().length() > 0) {
                    if (isNameTooLong) {
                        ToastUtils.showToast("昵称最长支持6个汉字、12个英文或数字");
                    } else {
                        params.put("nick", name.getText().toString().trim());
                    }
                } else {
                    ToastUtils.showToast("昵称不能为空");
                    return;
                }

                final String birthdayStr = birthday.getText().toString();
                if (!TextUtils.isEmpty(birthdayStr) && birthdayStr.length() > 0) {
                    params.put("birthday", birthdayStr.trim());
                } else {
                    ToastUtils.showToast("请填写宝宝生日");
                    return;
                }
                if (gender != null) {
                    params.put("gender", gender);
                } else {
                    ToastUtils.showToast("请填写宝宝性别");
                    return;
                }

//                if(isForcedUpdate){
//                    if(params.size() < 3){
//                        ToastUtils.showToast("请填写宝宝信息");
//                        return;
//                    }
//                }

                UserTrack.track(fmi);
                if (params.size() > 0 && !isNameTooLong) {
                    updateUserInfo(params);
                }
            }
        });
    }


    private void updateUserInfo(Map<String, String> params) {
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                clearUpdateUserInfoReference();
            }
        });
        DefaultCallback<UserDetail> callback = new DefaultCallback<UserDetail>() {
            @Override
            public void onDataReceived(UserDetail data) {
                customDialogManager.dismissDialog(BabyInfoSettingActivity.this);
                ToastUtils.showToast("更新宝宝信息成功");
                finish();
            }

            @Override
            public void onException(String reason) {
                customDialogManager.dismissDialog(BabyInfoSettingActivity.this);
                // ToastUtils.showToast(reason);
                ToastUtils.showToast("更新宝宝信息失败");
            }
        };

        if (mUpdateUserInfoCallbackRef == null) {
            mUpdateUserInfoCallbackRef = new StrongReference<>();
        }
        mUpdateUserInfoCallbackRef.set(callback);

        UserService.getInstance().updateUserInfo(params, mUpdateUserInfoCallbackRef);
    }

    @Override
    public void onBackPressed() {
        if (isForcedUpdate) {
            ToastUtils.showToast("请填写宝宝信息");
            return;
        }
        super.onBackPressed();
    }

    @Override
    public void finish() {
        super.finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clearUpdateUserInfoReference();
    }

    /**
     * 清除更新用户信息接口请求回调资源
     */
    private void clearUpdateUserInfoReference() {
        if (mUpdateUserInfoCallbackRef != null) {
            mUpdateUserInfoCallbackRef.clear();
            mUpdateUserInfoCallbackRef = null;
        }
    }

    class nameWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            String string = editable.toString();
            try {
                if (string.getBytes(TextLengthFilter.CHARSET_NAME).length > Constants.NAME_LENGHT) {
                    ToastUtils.showToast("昵称最长支持6个汉字、12个英文或数字");
                    isNameTooLong = true;
                } else {
                    isNameTooLong = false;
                }

                } catch (UnsupportedEncodingException e) {
                    LogHelper.printStackTrace(e);
                }
            }
        }
}
