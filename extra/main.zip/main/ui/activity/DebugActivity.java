package com.hhdd.kada.main.ui.activity;

import android.accounts.NetworkErrorException;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.thread.IThread;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.CookieUtil;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.download.NoMemoryException;
import com.hhdd.kada.download.SimpleFileDownloader;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LogoutEvent;
import com.hhdd.kada.main.event.TokenExpiredEvent;
import com.hhdd.kada.main.mediaserver.MediaServer3;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.widget.SettingMoreView;
import com.hhdd.logger.LogHelper;

import java.io.File;
import java.io.IOException;

import butterknife.BindView;

/**
 * Created by Xiaoyu on 2018/6/25 下午6:28.
 * ilzq@foxmail.com
 */
public class DebugActivity extends BaseActivity {

    private static final String TAG = "DebugActivity";
    private static final String SHARED_NAME = "debug_activity_setting";
    private static final String SETTING_NETWORK_ENVIRONMENT = "network_env";


    @BindView(R.id.decryptView)
    public SettingMoreView decryptView;
    @BindView(R.id.switchNetEnvironment)
    public SettingMoreView environmentView;
    @BindView(R.id.generateCrash)
    public SettingMoreView generateCrashView;
    @BindView(R.id.statusView)
    View statusView;

    private SimpleFileDownloader simpleFileDownloader;
    private final int FILE_SELECT_CODE = 199;

    public static void start(Context context) {
        if (context != null) {
            context.startActivity(new Intent(context, DebugActivity.class));
        }
    }

    public static int getSavedNetworkEnvironment(int env) {
        Log.d(TAG, "getSavedNetworkEnvironment");
        final SharedPreferences sp = KaDaApplication.getInstance().getSharedPreferences(SHARED_NAME, Context.MODE_PRIVATE);
        return sp.getInt(SETTING_NETWORK_ENVIRONMENT, env);
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_debug;
    }

    @Override
    public void doInitView() {
        super.doInitView();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            statusView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LocalDisplay.SCREEN_STATUS_HEIGHT));
            statusView.setVisibility(View.VISIBLE);
        }
        decryptView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("*/*");
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"), FILE_SELECT_CODE);
                } catch (ActivityNotFoundException ex) {
                    // Potentially direct the user to the Market with a Dialog
                    Toast.makeText(DebugActivity.this, "Please install a File Manager.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        environmentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showNetEnvSettingDlg();
            }
        });

        generateCrashView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                throw new RuntimeException("dead crash");
            }
        });

    }

    private void showNetEnvSettingDlg() {
        View view = View.inflate(this, R.layout.dialog_debug_net_env_setting, null);
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(view);

        TextView tvCurrentEnv = (TextView) view.findViewById(R.id.dialog_setting_current_env_tv);
        TextView tvOnline = (TextView) view.findViewById(R.id.dialog_setting_env_online);
        TextView tvPre = (TextView) view.findViewById(R.id.dialog_setting_env_pre);
        TextView tvTest = (TextView) view.findViewById(R.id.dialog_setting_env_test);

        String currentEnv = null;
        switch (API.currentEnvType) {
            case API.ENV_ONLINE:
                currentEnv = "当前环境: 线上环境";
                break;

            case API.ENV_PRE:
                currentEnv = "当前环境: 预发环境";
                break;

            case API.ENV_TEST:
                currentEnv = "当前环境: 测试环境";
                break;

            default:
                break;
        }
        tvCurrentEnv.setText(currentEnv);

        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.dialog_setting_env_online:
                        if (API.currentEnvType == API.ENV_ONLINE) {
                            ToastUtils.showToast("当前已经是线上环境了");
                        } else {
                            switchNetworkEnvironment(API.ENV_ONLINE);
                            ToastUtils.showToast("已切换到线上环境");
                        }
                        break;
                    case R.id.dialog_setting_env_pre:
                        if (API.currentEnvType == API.ENV_PRE) {
                            ToastUtils.showToast("当前已经是预发环境了");
                        } else {
                            switchNetworkEnvironment(API.ENV_PRE);
                            ToastUtils.showToast("已切换到预发环境");
                        }
                        break;
                    case R.id.dialog_setting_env_test:
                        if (API.currentEnvType == API.ENV_TEST) {
                            ToastUtils.showToast("当前已经是测试环境了");
                        } else {
                            switchNetworkEnvironment(API.ENV_TEST);
                            ToastUtils.showToast("已切换到测试环境");
                        }
                        break;
                }

                dialog.dismiss();
            }
        };
        tvOnline.setOnClickListener(onClickListener);
        tvPre.setOnClickListener(onClickListener);
        tvTest.setOnClickListener(onClickListener);

        dialog.show();
    }

    private void switchNetworkEnvironment(int env) {
        API.currentEnvType = env;

        saveNetworkEvnironment(env); // 保存网络环境类型

        ((CookieUtil) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COOKIE_UTIL)).clearCookie();

        // 退出登陆，刷新Token
        if (UserService.getInstance().isLogining()) {

            try {
                UserService.getInstance().setIsLogining(false);
                UserService.getInstance().logout();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
            try {
                DatabaseManager.getInstance().localDatabase();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            EventCenter.fireEvent(new LogoutEvent());

            EventCenter.fireEvent(new AuthService.CookieExpiredEvent());
        } else {
            EventCenter.fireEvent(new TokenExpiredEvent());
        }
    }

    private void saveNetworkEvnironment(int env) {
        final SharedPreferences sp = KaDaApplication.getInstance().getSharedPreferences(SHARED_NAME, Context.MODE_PRIVATE);
        sp.edit().putInt(SETTING_NETWORK_ENVIRONMENT, env).apply();
    }

    private void startDecryptAudio(String fileTemp) {
        String fileToDownload = MediaServer3.prepareDebug(fileTemp);
        String targetFile = fileTemp.substring(fileTemp.lastIndexOf("/"));
        String targetDir = Dirs.getCachePath(KaDaApplication.getInstance());
        if (!TextUtils.isEmpty(targetDir)) {
            targetDir = FileUtils.makeDirIfNoExist(targetDir + File.separator + "decryptAudio");
        }
        String targetFilePath = targetDir + targetFile;
        File tf = new File(targetFilePath);
        if (tf.exists()) {
            //noinspection ResultOfMethodCallIgnored
            tf.delete();
        }
        simpleFileDownloader = new SimpleFileDownloader(KaDaApplication.applicationContext(), fileToDownload, targetDir + targetFile,
                new SimpleFileDownloader.Listener() {
                    @Override
                    public void updateProcess(final long downloadPercent) {
                        if (decryptView != null) {
                            KaDaApplication.mainLooperHandler().post(new Runnable() {
                                @Override
                                public void run() {
                                    if (decryptView != null) {
                                        decryptView.setRightText("" + downloadPercent + "%");
                                        if (downloadPercent == 100.0) {
                                            Toast.makeText(decryptView.getContext(), "还原完成，在Cache目录下的decryptAudio", Toast.LENGTH_LONG).show();
                                        }
                                    }
                                }
                            });
                        }
                    }
                });
        ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE))
                .postNetworkTask(new Runnable() {
                    @Override
                    public void run() {
                        if (simpleFileDownloader != null) {
                            Exception ex = null;
                            try {
                                simpleFileDownloader.download();
                            } catch (IOException e) {
                                LogHelper.d(TAG, "21======================>" + e.toString());
                                ex = e;
                                LogHelper.printStackTrace(e);
                            } catch (NetworkErrorException e) {
                                LogHelper.d(TAG, "22======================>" + e.toString());
                                ex = e;
                                LogHelper.printStackTrace(e);
                            } catch (NoMemoryException e) {
                                LogHelper.d(TAG, "23======================>" + e.toString());
                                ex = e;
                                LogHelper.printStackTrace(e);
                            }
                            if (decryptView != null && ex != null) {
                                final Exception finalEx = ex;
                                KaDaApplication.mainLooperHandler().post(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (decryptView != null) {
                                            decryptView.setRightText("" + finalEx.toString());
                                        }
                                    }
                                });

                            }
                        }
                    }
                }, "downloadJob");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case FILE_SELECT_CODE:
                if (resultCode == RESULT_OK) {
                    // Get the Uri of the selected file
                    Uri uri = data.getData();
                    // Get the path
                    if (uri != null) {
                        String path = getSelectPath(uri);
                        LogHelper.d(TAG, "Select file path: " + path);
                        // Get the file instance
                        if (!TextUtils.isEmpty(path)) {
                            startDecryptAudio(path);
                        } else {
                            LogHelper.d(TAG, "Select file path is null: ");
                        }
                    } else {
                        LogHelper.d(TAG, "Select file path exception : can't get uri ");
                    }
                }
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private String getSelectPath(Uri uri) {
        if ("content".equalsIgnoreCase(uri.getScheme())) {
            String[] projection = {"_data"};
            Cursor cursor = null;
            try {
                cursor = getContentResolver().query(uri, projection, null, null, null);
                if (cursor != null) {
                    int column_index = cursor.getColumnIndexOrThrow("_data");
                    if (cursor.moveToFirst()) {
                        return cursor.getString(column_index);
                    }
                } else {
                    LogHelper.d(TAG, "can't get cursor by uri");
                }
            } catch (Exception e) {
                // Eat it  Or Log it.
                LogHelper.d(TAG, "failed to get select File Path: ");
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }
        return null;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }

}
