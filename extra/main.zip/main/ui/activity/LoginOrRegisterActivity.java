package com.hhdd.kada.main.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.text.TextUtils;
import android.view.View;
import android.view.inputmethod.InputMethodManager;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.TalentPlanAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.base.BaseFragmentActivity;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.LoginStatusForJsBridgeEvent;
import com.hhdd.kada.main.event.TokenExpiredEvent;
import com.hhdd.kada.main.model.DimensionInfo;
import com.hhdd.kada.main.ui.fragment.FindPasswordFragment;
import com.hhdd.kada.main.ui.fragment.InitFragment;
import com.hhdd.kada.main.ui.fragment.LoginFragmentListener;
import com.hhdd.kada.main.ui.fragment.NewLoginFragment;
import com.hhdd.kada.main.ui.fragment.ResetPasswordFragment;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.HWSDKUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.views.CatLoadingView;
import com.hhdd.logger.LogHelper;

import java.util.List;

/**
 * Created by lj on 16/2/19.
 */
public class LoginOrRegisterActivity extends BaseFragmentActivity implements LoginFragmentListener {

    public static final void startActivity(Context context) {
        Intent intent = new Intent(context, LoginOrRegisterActivity.class);
        context.startActivity(intent);
    }

    public static final void startActivity(Context context, String title, String redirect) {
        Intent intent = new Intent(context, LoginOrRegisterActivity.class);
        intent.putExtra("title", title);
        intent.putExtra("redirect", redirect);
        context.startActivity(intent);
    }

    public static final void startActivity(Context context, String title, String redirect, boolean isRegister) {
        Intent intent = new Intent(context, LoginOrRegisterActivity.class);
        intent.putExtra("title", title);
        intent.putExtra("redirect", redirect);
        intent.putExtra("isRegister", isRegister);
        context.startActivity(intent);
    }

    public static final void startActivity(Context context, String title, boolean isInit) {
        Intent intent = new Intent(context, LoginOrRegisterActivity.class);
        intent.putExtra("title", title);
        intent.putExtra("isInit", isInit);
        context.startActivity(intent);
    }

    public static final void startActivity(Context context, String type) {
        Intent intent = new Intent(context, LoginOrRegisterActivity.class);
        intent.putExtra("type", type);
        context.startActivity(intent);
    }

    String title;
    String redirectUrl;
    boolean isInit; //新用户打开app显示提示界面
    boolean isRegister;
    boolean isNeedCommit; //新用户提交打点
    CatLoadingView catLoadingView;
    int count = 0; //fragment数量
    private StrongReference<DefaultCallback> strongReference;
    private String type; //其它页面带进来的类型type(目前为听书绘本合集带入，用于登录后未订阅直接订阅或创建订单)

    private StrongReference<DefaultCallback> dimensInfoCallbackRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        title = getIntent().getStringExtra("title");
        redirectUrl = getIntent().getStringExtra("redirect");
        isInit = getIntent().getBooleanExtra("isInit", false);
        isNeedCommit = getIntent().getBooleanExtra("isNeedCommit", false);
        isRegister = getIntent().getBooleanExtra("isRegister", false);
        type = getIntent().getStringExtra("type");
        setContentView(R.layout.activity_login_register);

        getWindow().setBackgroundDrawable(null);
        setupFragment();

    }

    @Override
    protected int getFragmentContainerId() {
        return 0;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (onHomeIntent != null) { // home键退出后通过intent启动程序
            if (catLoadingView != null) {
                catLoadingView.dismissAllowingStateLoss();
            }
            onHomeIntent = null;
        }
        hideKeyBoard();
    }

    void setupFragment() {
        if (isInit) {
            InitFragment newFragment = InitFragment.newInstance(null);
            newFragment.setListener(this);
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.add(R.id.frag_container, newFragment, InitFragment.class.getSimpleName());
            ft.commitAllowingStateLoss();
        } else {
            NewLoginFragment newFragment = NewLoginFragment.newInstance(null);
            newFragment.setListener(this);
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.add(R.id.frag_container, newFragment, NewLoginFragment.class.getSimpleName());
            ft.commitAllowingStateLoss();
        }
        count++;
    }

    @Override
    public void handleForgetButtonClicked(Fragment fragment, String value) {

        if (isFinishing()) {
            return;
        }

        hideSoftKeyboard(getCurrentFocus());
        if (fragment instanceof NewLoginFragment) {
            try {
                Bundle bundle = new Bundle();
                bundle.putString("phoneNumber", value);
                FindPasswordFragment newFragment = FindPasswordFragment.newInstance(bundle);
                newFragment.setListener(this);
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_out, R.anim.push_right_in);
                ft.add(R.id.frag_container, newFragment, FindPasswordFragment.class.getSimpleName());
                ft.addToBackStack(null);
                ft.commitAllowingStateLoss();

                count++;
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        } else if (fragment instanceof FindPasswordFragment) {
            try {
                Bundle bundle = new Bundle();
                bundle.putString("phoneNumber", value);
                ResetPasswordFragment newFragment = ResetPasswordFragment.newInstance(bundle);
                newFragment.setListener(this);
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_out, R.anim.push_right_in);
                ft.add(R.id.frag_container, newFragment, ResetPasswordFragment.class.getSimpleName());
                ft.addToBackStack(null);
                ft.commitAllowingStateLoss();

                count++;
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        } else if (fragment instanceof ResetPasswordFragment) {
            EventCenter.fireEvent(new TokenExpiredEvent());
            ToastUtils.showToast("重置密码成功");
            FragmentManager fm = getSupportFragmentManager();
            int size = fm.getBackStackEntryCount();
            for (int i = 0; i < size; i++) {
                fm.popBackStack();
                count--;
            }
        }
    }

    @Override
    public void handleLoginButtonClicked(Fragment fragment, String value) {
        if (isFinishing()) {
            return;
        }

        hideSoftKeyboard(getCurrentFocus());

        if (fragment instanceof InitFragment) {
            try {
                Bundle bundle = new Bundle();
                bundle.putInt(Constants.KEY_FROM_TYPE, 1);
                NewLoginFragment newLoginFragment = NewLoginFragment.newInstance(bundle);
                newLoginFragment.setListener(this);
                FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                ft.setCustomAnimations(R.anim.push_left_in, R.anim.push_left_out, R.anim.push_right_out, R.anim.push_right_in);
                ft.add(R.id.frag_container, newLoginFragment, NewLoginFragment.class.getSimpleName());
                ft.addToBackStack(null);
                ft.commitAllowingStateLoss();
                count++;
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    @Override
    public void handleRegisterButtonClicked2(Fragment fragment, String value) {
        hideSoftKeyboard(getCurrentFocus());
        if (fragment instanceof FindPasswordFragment) {
            //找回密码验证手机号不存在时，点击注册回到手机登录之验证码登录页面
            FragmentManager fm = getSupportFragmentManager();
            fm.popBackStack();
            Fragment fragmentByTag = fm.findFragmentByTag(NewLoginFragment.class.getSimpleName());
            if (fragmentByTag != null && fragmentByTag instanceof NewLoginFragment) {
                final NewLoginFragment loginFragment = (NewLoginFragment) fragmentByTag;
                getHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        loginFragment.switchLoginType(true);
                    }
                }, 100);
            }
        }
    }

    @Override
    public void handleBackButtonClicked(Fragment fragment) {
        processPageBack();
    }

    private void processPageBack() {
        hideSoftKeyboard(getCurrentFocus());
        FragmentManager fm = getSupportFragmentManager();
        int size = fm.getBackStackEntryCount();
        if (size > 0) {
            fm.popBackStack();
            count--;
            // 登录注册选择页，登录 注册相关fragment都是add加入，切换fragment时不好监听显示状态，故在返回的时候判断当前显示fragment并打点
            List<Fragment> fragmentList = fm.getFragments();
            if (fragmentList != null && fragmentList.size() >= size) {
                Fragment topFragment = fragmentList.get(size - 1);
                String habitName = "";
                if (topFragment instanceof InitFragment) {
                    habitName = "register_or_login_select_view";
                } else if (topFragment instanceof NewLoginFragment) {
                    NewLoginFragment fragment = (NewLoginFragment) topFragment;
                    fragment.trackPageHabit();
                    return;
                }
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
            }
        } else {
            EventCenter.fireEvent(new LoginStatusForJsBridgeEvent(-1));
            finish();
        }
    }

    @Override
    public void showLoading() {
        if (isFinishing()) {
            return;
        }

        if (catLoadingView == null) {
            catLoadingView = new CatLoadingView();
        }
        if (!catLoadingView.isAdded() && !catLoadingView.isRemoving() && !catLoadingView.isVisible()) {
            catLoadingView.show(getSupportFragmentManager().beginTransaction(), "");
        }
    }


    @Override
    public void hideLoading() {
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing() && catLoadingView != null) {
                    catLoadingView.dismissAllowingStateLoss();
                }
            }
        }, 500);
    }

    @Override
    public void loginSuccess(String loginName) {
        UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "loginsuccess", TimeUtil.currentTime()));

        UserService.getInstance().setIsLogining(true);
        ((AuthService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.AUTH_SERVICE)).setAuthorized(true);
        hideSoftKeyboard(getCurrentFocus());
        DatabaseManager.getInstance().loadUserDatabase(loginName);
        UserService.getInstance().login(loginName, false);
        EventCenter.fireEvent(new LoginEvent(type));
        EventCenter.fireEvent(new LoginStatusForJsBridgeEvent(1));
        if (!ActivityUtil.isMainActivityLaunch()) {
            ActivityUtil.next(this, MainActivity.class);
        }
        if (!TextUtils.isEmpty(redirectUrl)) {
            RedirectActivity.startActivity(LoginOrRegisterActivity.this, redirectUrl);
        }

        if (isNeedCommit) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "general_app_user_register_and_login_succeed", TimeUtil.currentTime()));
        }

        finish();
    }

    @Override
    public void thirdLoginSuccess(int thirdType, String userName, boolean isInfoCompleted, boolean isToast, boolean firstLogin) {
        UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "loginsuccess", TimeUtil.currentTime()));

        UserService.getInstance().setIsLogining(true);
        ((AuthService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.AUTH_SERVICE)).setAuthorized(true);
        hideSoftKeyboard(getCurrentFocus());
        DatabaseManager.getInstance().loadUserDatabase(userName);
        UserService.getInstance().login(userName, false);
        EventCenter.fireEvent(new LoginEvent(type));
        EventCenter.fireEvent(new LoginStatusForJsBridgeEvent(1));

        if (isNeedCommit) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "general_app_user_register_and_login_succeed", TimeUtil.currentTime()));
        }

        if (TextUtils.isEmpty(type)) {
            // 若非微信第一次登录，作已完善资料处理
            if (isInfoCompleted || !firstLogin) {
                //若已完善信息，则必然进入过推荐流程或回到过首页(回到首页请求书架订阅内容后，若未推荐，服务端会内置推荐内容，算作已推荐)
                if (!ActivityUtil.isMainActivityLaunch()) {
                    ActivityUtil.next(this, MainActivity.class);
                }
                if(!TextUtils.isEmpty(redirectUrl)) {
                    RedirectActivity.startActivity(LoginOrRegisterActivity.this, redirectUrl);
                }
                finish();
            } else {
                //若进入推荐完善资料页面，即便通过协议进入登录，不做处理 推荐完善资料页面处理时需要判断MainActivity是否存在，不存在启动
                getUserRecommendInfo(isToast);
            }
        } else {
            //如果是通过订阅进入登录，成功后直接关闭当前页面回到之前页面或订阅或直接创建订单
            finish();
        }
        hideLoading();
    }

    //注册
    @Override
    public void registerSuccess(String phoneNumber, boolean isInfoCompleted, boolean isToast) {
        UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "registersuccess", TimeUtil.currentTime()));

        UserService.getInstance().setIsLogining(true);
        ((AuthService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.AUTH_SERVICE)).setAuthorized(true);
        hideSoftKeyboard(getCurrentFocus());
        DatabaseManager.getInstance().loadUserDatabase(phoneNumber);
        UserService.getInstance().login(phoneNumber, true);

        EventCenter.fireEvent(new LoginEvent(type));
        EventCenter.fireEvent(new LoginStatusForJsBridgeEvent(1));

        if (isNeedCommit) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "general_app_user_register_and_login_succeed", TimeUtil.currentTime()));
        }

        if (TextUtils.isEmpty(type)) {
            if (isInfoCompleted) {
                //若已完善信息，则必然进入过推荐流程或回到过首页(回到首页请求书架订阅内容后，若未推荐，服务端会内置推荐内容，算作已推荐)
                if (!ActivityUtil.isMainActivityLaunch()) {
                    ActivityUtil.next(this, MainActivity.class);
                }
                if(!TextUtils.isEmpty(redirectUrl)) {
                    RedirectActivity.startActivity(LoginOrRegisterActivity.this, redirectUrl);
                }
                finish();
            } else {
                //若进入推荐完善资料页面，即便通过协议进入登录，不做处理 推荐完善资料页面处理时需要判断MainActivity是否存在，不存在启动
                getUserRecommendInfo(isToast);
            }
        } else {
            //如果是通过订阅进入登录，成功后直接关闭当前页面回到之前页面或订阅或直接创建订单
            finish();
        }
    }

    private List<DimensionInfo> recommendDimensionList;

    /**
     * 获取推荐维度信息
     */
    private void getUserRecommendInfo(final boolean isToast) {
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this);
        DefaultCallback<List<DimensionInfo>> callback = new DefaultCallback<List<DimensionInfo>>() {
            @Override
            public void onDataReceived(List<DimensionInfo> responseData) {
                customDialogManager.dismissDialog(LoginOrRegisterActivity.this);
                if (responseData != null) {
                    recommendDimensionList = responseData;
                    ActivityUtil.nextRecommendSettingActivity(LoginOrRegisterActivity.this, recommendDimensionList, isToast);
                } else if (!ActivityUtil.isMainActivityLaunch()) {
                    ActivityUtil.next(LoginOrRegisterActivity.this, MainActivity.class);
                }
                finish();
            }

            @Override
            public void onException(String reason) {
                customDialogManager.dismissDialog(LoginOrRegisterActivity.this);
                if (!ActivityUtil.isMainActivityLaunch()) {
                    ActivityUtil.next(LoginOrRegisterActivity.this, MainActivity.class);
                }
                finish();
            }
        };
        if (dimensInfoCallbackRef == null) {
            dimensInfoCallbackRef = new StrongReference<>();
        }
        dimensInfoCallbackRef.set(callback);
        TalentPlanAPI.getDimensionInfo(dimensInfoCallbackRef);
    }


    @Override
    public void userLogin(String tag, String loginName, boolean isInfoCompleted, boolean isToast) {
        loginSuccess(loginName);
        hideLoading();
    }

    @Override
    public void onBackPressed() {
        processPageBack();
    }

    private Intent onHomeIntent; // home键退出后通过intent启动程序

    @Override
    protected void onNewIntent(Intent intent) {
        // 拦截Intent，保存Intent，在onResume中进行处理
        onHomeIntent = intent;
    }

    void hideSoftKeyboard(View view) {
        InputMethodManager im = (InputMethodManager) KaDaApplication.getInstance().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (view != null && view.getWindowToken() != null) {
            im.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    protected void onDestroy() {
        HWSDKUtil.clearLoginReference();
        DialogFactory.dismissAllDialog(this);
        if (strongReference != null) {
            strongReference.clear();
            strongReference = null;
        }
        if (dimensInfoCallbackRef != null) {
            dimensInfoCallbackRef.clear();
            dimensInfoCallbackRef = null;
        }
        if (catLoadingView != null) {
            catLoadingView.dismissAllowingStateLoss();
        }
        getHandler().removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
