package com.hhdd.kada.main.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.hhdd.core.model.BaseVO;
import com.hhdd.core.model.HomeVO;
import com.hhdd.core.model.RecommendVO;
import com.hhdd.core.model.StoryInfo;
import com.hhdd.core.service.StoryService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.main.model.ShareInfo;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.ui.adapter.AlbumAdapter;
import com.hhdd.kada.main.ui.dialog.ContentIsDeletedDialog;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.views.DataLoadingBuilder;
import com.hhdd.kada.share.ShareProvider;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;


/**
 * Created by zhengkaituo on 15/12/24.
 */
public class StoryCollectionActivity extends BaseActivity {

//    private View headview;
    private PullToRefreshListView mListView;
    private TextView mBookName;
    private FrameLayout container;
//    private NetworkBitmap bitmap;
    private AlbumAdapter mAdapter;
    private int mCollectionId;
    private boolean isNew;

    StoryCollectionDetail storyCollectionDetail;

    private DataLoadingBuilder mLoadingBuilder = null;
    private SimpleDraweeView background;

    public static final void startActivity(Context context, int collectionId) {
        Intent intent = new Intent(context, StoryCollectionActivity.class);
        intent.putExtra("collectionId", collectionId);
        context.startActivity(intent);
    }

    public static final void startActivity(Context context, int collectionId, boolean isNew) {
        Intent intent = new Intent(context, StoryCollectionActivity.class);
        intent.putExtra("collectionId", collectionId);
        intent.putExtra("isNew", isNew);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen_collection);
        getWindow().getDecorView().setBackgroundDrawable(null);

        EventBus.getDefault().register(this);
        mCollectionId = getIntent().getIntExtra("collectionId", 0);
        UserHabitService.getInstance().track(UserHabitService.newUserHabit(mCollectionId + "", "clickstorycollection", TimeUtil.currentTime()));
        isNew = getIntent().getBooleanExtra("isNew", false);
        initView();
        loadData();
    }

    void initView() {

        View titleView = findViewById(R.id.titleView);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleViewLayoutParams = titleView.getLayoutParams();
            if (titleViewLayoutParams==null){
                titleViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleViewLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height)+LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleView.setLayoutParams(titleViewLayoutParams);
            titleView.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }

        mListView = (PullToRefreshListView) findViewById(R.id.listview);
//        mListView.getRefreshableView().addHeaderView(headview);
        background = (SimpleDraweeView) findViewById(R.id.background);
        View back = (ImageView) findViewById(R.id.back);
        mBookName = (TextView) findViewById(R.id.tv_name);
        container = (FrameLayout) findViewById(R.id.main_container);
        back.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                finish();
            }
        });

        mAdapter = new AlbumAdapter(this);
        mListView.setAdapter(mAdapter);
        mListView.setMode(PullToRefreshBase.Mode.DISABLED);

        mLoadingBuilder = new DataLoadingBuilder(this, mListView);
        View view = mLoadingBuilder.showLoading();
        view.setBackgroundColor(getResources().getColor(R.color.transparent));
        mLoadingBuilder.setOnRetryClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        findViewById(R.id.share).setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                if(storyCollectionDetail != null){
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(""+storyCollectionDetail.getCollectId(), "click_storycollection_playpage_share", TimeUtil.currentTime()));
                    ShareInfo shareInfo = new ShareInfo();
                    shareInfo.setTitle(AppUtils.getString(R.string.share_default_title));
                    shareInfo.setContent(" " + storyCollectionDetail.getName());
                    shareInfo.setImageUrl(storyCollectionDetail.getCoverUrl());
                    shareInfo.setTargetUrl(API.STORY_SINGLE_SHARE_URL + storyCollectionDetail.getCollectId());
                    ShareProvider.share(StoryCollectionActivity.this, shareInfo, new ShareProvider.Listener() {
                        @Override
                        public void onComplete(boolean success, SHARE_MEDIA share_media) {
                            if(success){
                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(storyCollectionDetail.getCollectId() + ","+share_media.toString()+",yes", "story_collection_page_share", TimeUtil.currentTime()));
                            }else{
                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(storyCollectionDetail.getCollectId() + ","+share_media.toString()+",no", "story_collection_page_share", TimeUtil.currentTime()));
                            }
                        }
                    });
                }
            }
        });
    }

    void loadData() {
        storyCollectionDetail = StoryService.loadCollectionFromCache(mCollectionId);
        if (storyCollectionDetail == null || isNew){
            if(storyCollectionDetail != null){
                refreshView();
            }
            if(NetworkUtils.isReachable()){
                getOldStoryCollection();
            }else{
                if(storyCollectionDetail == null){
                    ToastUtils.showToast("网络异常，请检查网络");
                }
            }
        } else{
            refreshView();
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();

        dismissLoadingDialog();

        EventBus.getDefault().unregister(this);
        mAdapter.recycle();
    }


    public void refreshView() {
        mAdapter.clear();
        if (storyCollectionDetail != null) {
            List<BaseVO> recommendList = new ArrayList<BaseVO>();
            RecommendVO vo = new RecommendVO();
            vo.setBannerUrl(storyCollectionDetail.getBannerUrl());
            recommendList.add(vo);
            vo = new RecommendVO();
            vo.setContent(storyCollectionDetail.getIntroduction());
            vo.setName(storyCollectionDetail.getName());
            vo.setCoverUrl(storyCollectionDetail.getCoverUrl());
            recommendList.add(vo);

            HomeVO homeVO = new HomeVO();
            homeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_ALBUM_STORY_BANNER);
            homeVO.setItemList(recommendList);
            mAdapter.add(homeVO);

            HomeVO seqHomeVO = new HomeVO();
            seqHomeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_SEP2);
            mAdapter.add(seqHomeVO);

//            String backImg = CdnUtils.getImgCdnUrl(storyCollectionDetail.getBannerUrl(), CdnUtils.SIZE_700x435, true);
//            FrescoUtils.showImg(background, new IterativeBoxBlurPostProcessor(30), backImg, 0, 0);
            String backImg = CdnUtils.getImgCdnBlurUrl(storyCollectionDetail.getBannerUrl(), 30, 30, true);
            FrescoUtils.showImg(background, backImg);

            mBookName.setText(storyCollectionDetail.getName());
            List<BaseVO> infoList = new ArrayList<BaseVO>();
            List<com.hhdd.kada.main.model.StoryInfo> storyList = storyCollectionDetail.getItems();
            if(storyList == null || storyList.size()==0){

            }else{
                for (int i = 0; i < storyList.size(); i++) {
                    StoryInfo info = StoryInfo.createInfoByStoryInfo(storyList.get(i), mCollectionId,storyCollectionDetail.getCoverUrl(),storyCollectionDetail.getType());
                    infoList.add(info);
                    if ((i + 1) % 3 == 0) {
                        HomeVO storyListHomeVO = new HomeVO();
                        storyListHomeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_STORY_LIST);
                        storyListHomeVO.setItemList(infoList);
                        mAdapter.add(storyListHomeVO);
                        infoList.clear();
                    }
                }

                if (infoList.size() > 0) {
                    HomeVO storyListHomeVO = new HomeVO();
                    storyListHomeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_STORY_LIST);
                    storyListHomeVO.setItemList(infoList);
                    mAdapter.add(storyListHomeVO);
                }

                seqHomeVO = new HomeVO();
                seqHomeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_SEP2);
                mAdapter.add(seqHomeVO);
            }
        }
        mAdapter.notifyDataSetChanged();

        dismissLoadingDialog();
    }

    private void dismissLoadingDialog() {
        if (mLoadingBuilder != null) {
            mLoadingBuilder.dismiss();
            mLoadingBuilder.onDestroy();
            mLoadingBuilder = null;
        }
    }

    public void reload() {
        storyCollectionDetail =StoryService.loadCollectionFromCache(mCollectionId);
        refreshView();

    }

    public void onEvent(OnRefreshDoneEvent event) {
        reload();
    }


    public static class OnRefreshDoneEvent {

    }

    private void getOldStoryCollection() {
        StoryAPI.getOldStoryCollectionDetail(mCollectionId, new API.ResponseHandler<StoryCollectionDetail>() {
            @Override
            public void onSuccess(StoryCollectionDetail responseData) {
                if (responseData == null) {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            showContentDialog(2, 1, mCollectionId);

                            dismissLoadingDialog();
                        }
                    });

                    return;
                }

                Gson gson = new Gson();
                String json = gson.toJson(responseData, new TypeToken<StoryCollectionDetail>() {
                }.getType());
                FileUtils.saveStringToFile(json, StoryService.cateCollectionItemFilePath(responseData.getCollectId()));

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        dismissLoadingDialog();

                        EventBus.getDefault().post(new OnRefreshDoneEvent());
                    }
                });
            }

            @Override
            public void onFailure(int code, String message) {
                dismissLoadingDialog();
            }
        });
    }
    private void showContentDialog(int kind, int type, int id){
        if(isFinishing()){
            return;
        }
        ContentIsDeletedDialog dialog = new ContentIsDeletedDialog(this);
        dialog.setCallback(new ContentIsDeletedDialog.ContentDialogCallback() {
            @Override
            public void doYes() {
                finish();
            }
        });
        dialog.setData(kind, type, id);
        dialog.show();
    }
}
