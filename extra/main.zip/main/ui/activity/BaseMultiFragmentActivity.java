package com.hhdd.kada.main.ui.activity;

import android.support.annotation.IdRes;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import com.hhdd.kada.base.BaseFragmentActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.ui.activity
 */
public abstract class BaseMultiFragmentActivity extends  BaseFragmentActivity{

    protected FragmentManager fragmentManager;
    protected int selectIndex = -1;
    protected List<Fragment> fragments = new ArrayList<Fragment>();

    @IdRes
    @Override
    public abstract int getFragmentContainerId();

    public abstract void createFragmentsToBackStack();

    @Override
    public void doInitView() {
        super.doInitView();
        fragmentManager = getSupportFragmentManager();
        createFragmentsToBackStack();
    }

    public void pushFragmentToBackStack(int selectIndex) {
        try {
            FragmentTransaction addTransaction = fragmentManager.beginTransaction();
            if (fragmentManager.getFragments() == null || (fragments.size() > selectIndex && !fragmentManager.getFragments().contains(fragments.get(selectIndex)))) {
                addTransaction.add(getFragmentContainerId(), fragments.get(selectIndex), String.format("fragment_%s", selectIndex));
                addTransaction.commitAllowingStateLoss();
            }
            showFragmentIndex(selectIndex);
        }catch (Exception e){

        }
    }

    private void showFragmentIndex(int selectIndex) {
        if (fragments != null && fragments.size() > selectIndex) {
            if (this.selectIndex != selectIndex) {
                this.selectIndex = selectIndex;
                FragmentTransaction showTransaction = fragmentManager.beginTransaction();
                for (int i = 0; i < fragments.size(); i++){
                    Fragment fragment = fragments.get(i);
                    if(i == selectIndex){
                        showTransaction.show(fragment);
                        fragment.setUserVisibleHint(true);
                    } else {
                        showTransaction.hide(fragment);
                        fragment.setUserVisibleHint(false);
                    }
                }
                showTransaction.commitAllowingStateLoss();
            }
        }
    }
}
