package com.hhdd.kada.main.ui.activity;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.net.Uri;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.main.playback.SoundPlayback;
import com.hhdd.kada.main.ui.dialog.ChildrenLockDialog;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.record.callback.ChildrenDialogCallback;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/4
 * @describe : com.hhdd.kada.main.ui.activity
 */
public abstract class BaseRestActivity extends BaseActivity {

    @BindView(R.id.layout)
    View layout;
    @BindView(R.id.timeTextView)
    TextView timeTextView;
    @BindView(R.id.motherUnlockImageView)
    ImageView motherUnlockImageView;
    @BindView(R.id.modifyTimeLayout)
    View modifyTimeLayout;
    protected ValueAnimator rotationAnimator;
    protected SoundPlayback soundPlayback;
    private ChildrenLockDialog lockDialog;
    private ValueAnimator animator;

    @Override
    public void doInitView() {
        super.doInitView();
        initListener();
        animator = ObjectAnimator.ofFloat(layout, "translationY",
                -LocalDisplay.SCREEN_WIDTH_PIXELS, 0, -40, 0, -20, 0);
        animator.setDuration(1000);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                initAnimation();
                soundPlayback = new SoundPlayback();
                soundPlayback.prepare(KaDaApplication.getInstance(), Uri.parse("android.resource://"
                        + KaDaApplication.getInstance().getPackageName() + "/" + getRawId()));
                soundPlayback.setListener(new SoundPlayback.Listener() {
                    @Override
                    public void handlePrepared(SoundPlayback playback) {
                        if (playback != null) {
                            playback.playFromBegin();
                        }
                    }

                    @Override
                    public void handleCompletion(SoundPlayback playback) {

                    }
                });
            }
        });
        animator.start();
    }

    /**
     * 获取音频id
     *
     * @return
     */
    protected abstract int getRawId();

    /**
     * 妈妈解锁操作
     */
    protected abstract void doMotherUnLock();

    /**
     * 设置使用时长操作
     */
    protected abstract void doModifyTime();

    /**
     * 点击妈妈解锁打点
     */
    protected abstract void doMotherUnLockHabit();

    /**
     * 点击修改时间打点
     */
    protected abstract void doModifyTimeHabit();

    protected void initListener() {
        motherUnlockImageView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                doMotherUnLockHabit();
                showLockDialog(new LockDialogCallBack() {
                    @Override
                    public void back() {
                        doMotherUnLock();
                        animFinish();
                    }
                });
            }
        });
        modifyTimeLayout.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                doModifyTimeHabit();
                showLockDialog(new LockDialogCallBack() {
                    @Override
                    public void back() {
                        doModifyTime();
                        ActivityHelper.unregisterActivity(BaseRestActivity.this);
                        ActivityUtil.nextSettingActivity(BaseRestActivity.this, false);
                        animFinish();
                    }
                });
            }
        });
    }

    protected void animFinish() {
        dismissLockDialog();
        cancelEnterAnim();
        releaseMediaPlayer();
        finish();
        overridePendingTransition(R.anim.alpha_in, R.anim.translate_out);
    }

    /**
     * 关闭儿童锁弹窗
     */
    private void dismissLockDialog() {
        if(lockDialog != null && lockDialog.isShowing()) {
            lockDialog.dismiss();
        }
    }

    /**
     * 显示儿童锁
     * @param callBack
     */
    private void showLockDialog(final LockDialogCallBack callBack) {
        dismissLockDialog();
        lockDialog = new ChildrenLockDialog(BaseRestActivity.this, true);
        lockDialog.setCallback(new ChildrenDialogCallback() {
            @Override
            public void onAnswerRight() {
                getHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        callBack.back();
                    }
                }, 300);
            }

            @Override
            public void onDirectDismiss() {

            }
        });
        lockDialog.show();
    }

    protected void initAnimation() {

    }

    @Override
    public void onResume() {
        super.onResume();
        if(rotationAnimator != null && !rotationAnimator.isRunning()) {
            rotationAnimator.start();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (rotationAnimator != null && rotationAnimator.isRunning()) {
            rotationAnimator.cancel();
        }
        releaseMediaPlayer();
    }

    /**
     * 取消进入动画
     */
    protected void cancelEnterAnim() {
        if(animator != null) {
            if(animator.isRunning()) {
                animator.cancel();
            }
            animator = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (rotationAnimator != null) {
            if(rotationAnimator.isRunning()) {
                rotationAnimator.cancel();
            }
            rotationAnimator = null;
        }
        cancelEnterAnim();
        releaseMediaPlayer();
        super.onDestroy();
    }

    /**
     * 关闭音频播放
     */
    protected void releaseMediaPlayer() {
        if (soundPlayback != null) {
            soundPlayback.releaseMediaPlayer();
            soundPlayback = null;
        }
    }

    @Override
    public void onBackPressed() {

    }

    public interface LockDialogCallBack {
        void back();
    }
}
