package com.hhdd.kada.main.ui.activity;

import android.view.View;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.ui.fragment.collectdownload.BaseCollectFragment;
import com.hhdd.kada.main.ui.fragment.collectdownload.CollectBookFragment;
import com.hhdd.kada.main.ui.fragment.collectdownload.CollectStoryFragment;
import com.hhdd.kada.main.utils.TimeUtil;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/26
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class CollectActivity extends CollectDownloadActivity {

    @Override
    protected void initFragments() {
        fragments.add(new CollectBookFragment());
        fragments.add(new CollectStoryFragment());
    }

    @Override
    public void doInitView() {
        super.doInitView();
        titleBarView.setTitle("收藏");
    }

    @Override
    protected void doTabClick(View view) {
        String name = view.getId() == R.id.bookTabTextView ? "collect_center_book_tab_click" : "collect_center_story_tab_click";
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", name, TimeUtil.currentTime()));
    }

    @Override
    protected void doEdit() {
        if(fragments.get(viewPager.getCurrentItem()) instanceof BaseCollectFragment){
            BaseCollectFragment collectFragment = (BaseCollectFragment) fragments.get(viewPager.getCurrentItem());
            editTextView.setText(collectFragment.isEdit() ? R.string.manage : R.string.done);
            collectFragment.doEdit(!collectFragment.isEdit());
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "collect_center_edit_click", TimeUtil.currentTime()));
    }

    @Override
    protected void updateEditTextView(int position) {
        if(fragments.get(position) instanceof BaseCollectFragment) {
            BaseCollectFragment collectFragment = (BaseCollectFragment) fragments.get(position);
            editTextView.setText(collectFragment.isEdit() ? R.string.done : R.string.manage);
        }
    }
}
