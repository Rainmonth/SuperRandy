package com.hhdd.kada.main.ui.activity;

import com.hhdd.kada.api.API;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.umeng.socialize.bean.SHARE_MEDIA;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/21
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class SubmissionActivity extends BaseTitleWebViewActivity {

    @Override
    public void doInitView() {
        super.doInitView();
        loadUrl();
    }

    @Override
    protected void loadUrl() {
        if (!NetworkUtils.isReachable()) {
            showError();
            return;
        }
        if(contentWebView != null) {
            contentWebView.loadUrl(API.SUBMISSION_URL());
        }
    }

    @Override
    protected void doShareHabit() {

    }

    @Override
    protected void doShareHabitSuccess(SHARE_MEDIA share_media) {

    }
}
