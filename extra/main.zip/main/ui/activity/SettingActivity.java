package com.hhdd.kada.main.ui.activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.android.thread.IThread;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.BuildConfig;
import com.hhdd.kada.Constants;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.base.BaseFragmentActivity;
import com.hhdd.kada.dialog.ConfirmDialogManager;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.event.CheckTimeEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.LogoutEvent;
import com.hhdd.kada.main.event.OtherAccountUnifySuccessEvent;
import com.hhdd.kada.main.event.SameAccountUnifySuccessEvent;
import com.hhdd.kada.main.event.UpdateAppStartTimeEvent;
import com.hhdd.kada.main.event.WeiXinLoginEvent;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.manager.WChatManager;
import com.hhdd.kada.main.mediaserver.MediaServer2;
import com.hhdd.kada.main.model.AccountUnifyInfo;
import com.hhdd.kada.main.model.ShareInfo;
import com.hhdd.kada.main.model.UserAccountInfo;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.settings.UserSettings;
import com.hhdd.kada.main.ui.dialog.ChildrenLockDialog;
import com.hhdd.kada.main.ui.dialog.ClearCacheDialog2;
import com.hhdd.kada.main.ui.dialog.ConfirmDialog;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.ui.fragment.BindingPhoneFragment;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.HWSDKUtil;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.views.CatLoadingView;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.record.callback.ChildrenDialogCallback;
import com.hhdd.kada.share.ShareProvider;
import com.hhdd.kada.widget.SettingAccountView;
import com.hhdd.kada.widget.SettingCheckView;
import com.hhdd.kada.widget.SettingMoreView;
import com.hhdd.kada.widget.SettingProgressView;
import com.hhdd.kada.widget.SleepTimeProgressView;
import com.hhdd.logger.LogHelper;
import com.tencent.bugly.beta.Beta;
import com.tencent.mm.opensdk.modelmsg.SendAuth;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/1
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class SettingActivity extends BaseFragmentActivity {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.useTimeProgressView)
    SettingProgressView useTimeProgressView;
    @BindView(R.id.restProgressView)
    SettingProgressView restProgressView;
    @BindView(R.id.sleepTimeProgressView)
    SleepTimeProgressView sleepTimeProgressView;
    @BindView(R.id.unEnabledView)
    SettingCheckView unEnabledView;
    @BindView(R.id.showTalentPlanCheckView)
    SettingCheckView showTalentPlanCheckView;
    //    @BindView(R.id.bookPlayCheckView)
//    SettingCheckView bookPlayCheckView;
    @BindView(R.id.bookShowQuestionCheckView)
    SettingCheckView bookShowQuestionCheckView;
    @BindView(R.id.clearCacheMoreView)
    SettingMoreView clearCacheMoreView;
    @BindView(R.id.shareMoreView)
    SettingMoreView shareMoreView;
    @BindView(R.id.feedbackMoreView)
    SettingMoreView feedbackMoreView;
    @BindView(R.id.aboutMoreView)
    SettingMoreView aboutMoreView;
    @BindView(R.id.submissionMoreView)
    SettingMoreView submissionMoreView;
    @BindView(R.id.exchangeCenterMoreView)
    SettingMoreView exchangeCenterMoreView;
    @BindView(R.id.lastLineView)
    View lastLineView;
    @BindView(R.id.logoutTextView)
    TextView logoutTextView;
    @BindView(R.id.userIdTextView)
    TextView userIdTextView;
    @BindView(R.id.agreementTextView)
    TextView agreementTextView;
    @BindView(R.id.loginTextView)
    TextView loginTextView;
    @BindView(R.id.accountSpaceView)
    View accountSpaceView;
    @BindView(R.id.accountLayout)
    View accountLayout;
    @BindView(R.id.hwAccountView)
    SettingAccountView hwAccountView;
    @BindView(R.id.accountLineView)
    View accountLineView;
    @BindView(R.id.weixinAccountView)
    SettingAccountView weixinAccountView;
    @BindView(R.id.phoneAccountView)
    SettingAccountView phoneAccountView;

    /*
     * Created by Xiaoyu on 2018/6/26 上午9:43
     * debug模式下的两个View
     */
    @BindView(R.id.debugView)
    View debugView;
    @BindView(R.id.debugLineView)
    View debugLineView;
    @BindView(R.id.check_update)
    View checkUpdateView;
    @BindView(R.id.check_update_line)
    View checkUpdateLineView;

    private ClearCacheDialog2 mClearCacheDialog;
    private CatLoadingView catLoadingView;
    private Settings settings;
    private StrongReference<DefaultCallback> strongReference;
    private StrongReference<DefaultCallback> userAllAccountReference;
    private StrongReference<DefaultCallback> validateWeixinReference;
    private ChildrenLockDialog lockDialog;

    private static final String[] userTimeTextArr = {"30分钟", "45分钟", "60分钟", "无限制"};
    private static final int[] useTimeArr = {30 * 60, 45 * 60, 60 * 60, -1}; //分钟
    //    private static final int[] useTimeArr = {15, 30, 45, -1}; //秒
    private static final String[] restTextArr = {"5分钟", "10分钟", "15分钟"};
    private static final int[] restTimeArr = {5 * 60, 10 * 60, 15 * 60}; //分钟
//    private static final int[] restTimeArr = {10, 20, 30}; //秒

    @Override
    public int getLayoutId() {
        return R.layout.activity_setting;
    }

    @Override
    protected int getFragmentContainerId() {
        return 0;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        EventBus.getDefault().register(this);
        if(BuildConfig.DEBUG_MODE){
            debugView.setVisibility(View.VISIBLE);
            debugLineView.setVisibility(View.VISIBLE);
            debugView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    DebugActivity.start(SettingActivity.this);
                }
            });

            checkUpdateView.setVisibility(View.VISIBLE);
            checkUpdateLineView.setVisibility(View.VISIBLE);
            checkUpdateView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(View v) {
                    Beta.checkUpgrade();
                }
            });
        }

        titleBarView.setTitle(getResources().getString(R.string.setting_text));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            titleBarView.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }
        titleBarView.setLeftOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                finish();
            }
        });

        init(getIntent());
    }

    /**
     * 初始化数据
     *
     * @param intent
     */
    private void init(Intent intent) {
        settings = Settings.getInstance();
        int useTime = settings.getUseTime();
        int useTimeIndex = getProgressInitIndex(useTime, useTimeArr);
        if (useTimeIndex < 0) {
            useTimeIndex = 3;
        }

        int restTime = settings.getRestTime();
        int restTimeIndex = getProgressInitIndex(restTime, restTimeArr);
        if (restTimeIndex < 0) {
            restTimeIndex = 0;
        }
        useTimeProgressView.update(userTimeTextArr, useTimeIndex);
        restProgressView.update(restTextArr, restTimeIndex);

        ViewGroup.LayoutParams params = sleepTimeProgressView.getLayoutParams();
        params.height = (int) sleepTimeProgressView.getViewHeight();
        int moonTime = settings.getSleepTime();
        int sunTime = settings.getWakeUpTime();
        if (moonTime == 0) {
            moonTime = SleepTimeProgressView.DEFAULT_MOON_TIME;
        }
        if (sunTime == 0) {
            sunTime = SleepTimeProgressView.DEFAULT_SUN_TIME;
        }
        sleepTimeProgressView.updateProgress(moonTime, sunTime);

        PrefsManager prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
        unEnabledView.setChecked(prefsManager.getBoolean(Constants.KEY_SLEEP_TIME_UNENABLED, true));
        unEnabledView.setTextViewWidth(ViewGroup.LayoutParams.WRAP_CONTENT);

        showTalentPlanCheckView.setChecked(UserSettings.getInstance().isBookFragmentShowTalentPlan());
//        bookPlayCheckView.setChecked(settings.isBookContinuePlay());
        bookShowQuestionCheckView.setChecked(settings.isShowQuestion());
        initCacheSize();
        String userId = UserService.getInstance().getCurrentUserId();
        if (!TextUtils.isEmpty(userId)) {
            userIdTextView.setText(String.format(getResources().getString(R.string.setting_user_id_text), userId));
        }
        agreementTextView.setText(getClickableSpan());
        agreementTextView.setMovementMethod(LinkMovementMethod.getInstance());
        showLoginView(UserService.getInstance().isLogining());

        boolean showLockDialog = intent.getBooleanExtra(Constants.INTENT_KEY_SETTING_SHOWLOCKDIALOG, true);
        if (!showLockDialog) {
            return;
        }
        lockDialog = new ChildrenLockDialog(this);
        lockDialog.setCallback(new ChildrenDialogCallback() {
            @Override
            public void onAnswerRight() {

            }

            @Override
            public void onDirectDismiss() {
                finish();
            }
        });
        lockDialog.show();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        init(intent);
    }

    /**
     * 获取进度条索引
     *
     * @param progressTime
     * @param progressArr
     * @return
     */
    private int getProgressInitIndex(int progressTime, int[] progressArr) {
        for (int i = 0; i < progressArr.length; i++) {
            if (progressTime == progressArr[i]) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 初始化缓存大小
     */
    private void initCacheSize() {
        ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE))
                .postDaemonTask(getCacheSizeRunnable, "GetCacheSizeJob");
    }

    private Runnable getCacheSizeRunnable = new Runnable() {
        @Override
        public void run() {
            try {
                final Long cacheSize =
                        FileUtils.getFolderSize(Dirs.getImageCachePath()) +
                                FileUtils.getFolderSize(Dirs.getBooksCachePath())
                                + FileUtils.getFolderSize(Dirs.getTmpCachePath())
                                + FileUtils.getFolderSize(MediaServer2.getRootPath())
                                + FileUtils.getFolderSize(Dirs.getListenCachePath())
                                + FileUtils.getFolderSize(Dirs.getRequestCachePath())
                                + FileUtils.getFolderSize(Dirs.getVideoCacheDir());
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        if (!isFinishing()) {
                            clearCacheMoreView.setRightText(FileUtils.getFormatSize(cacheSize));
                        }
                    }
                });
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        }
    };

    /**
     * 获取协议条款click span
     *
     * @return
     */
    private SpannableString getClickableSpan() {
        View.OnClickListener l = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                        "", "setting_user_protocol_click", TimeUtil.currentTime()));
                WebViewActivity.startActivity(SettingActivity.this, API.USER_PROTOCOL_URL);
            }
        };

        SpannableString spannableInfo = new SpannableString(
                getResources().getString(R.string.setting_agreement_text));
        int start = 11;
        int end = spannableInfo.length() - 1;
        spannableInfo.setSpan(new Clickable(l), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannableInfo.setSpan(new ForegroundColorSpan(Color.WHITE), start, end,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        return spannableInfo;
    }

    class Clickable extends ClickableSpan implements View.OnClickListener {
        private final View.OnClickListener mListener;

        public Clickable(View.OnClickListener l) {
            mListener = l;
        }

        @Override
        public void onClick(View v) {
            mListener.onClick(v);
        }
    }

    /**
     * 根据登录状态显示登录登出view
     *
     * @param isLogin
     */
    private void showLoginView(boolean isLogin) {
        loginTextView.setVisibility(isLogin ? View.GONE : View.VISIBLE);
        lastLineView.setVisibility(isLogin ? View.VISIBLE : View.GONE);
        logoutTextView.setVisibility(isLogin ? View.VISIBLE : View.GONE);

        accountSpaceView.setVisibility(View.GONE);
        accountLayout.setVisibility(View.GONE);
        if (isLogin) {
            getUserAllAccountInfo();
        }
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        useTimeProgressView.setCallBack(new SettingProgressView.SettingProgressCallBack() {
            @Override
            public void getProgressIndex(int index) {
                if (index < userTimeTextArr.length) {
                    int time = 0;
                    if (index != useTimeArr.length - 1) {
                        time = useTimeArr[index] / 60;
                    } else {
                        time = 9999;
                    }
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(time), StaCtrName.setting_once_timing, TimeUtil.currentTime()));

                    settings.setUseTime(useTimeArr[index]);
                    settings.refreshToCache();
                    EventBus.getDefault().post(new UpdateAppStartTimeEvent());
                }
            }
        });
        restProgressView.setCallBack(new SettingProgressView.SettingProgressCallBack() {
            @Override
            public void getProgressIndex(int index) {
                if (index < restTextArr.length) {
                    int time = restTimeArr[index] / 60;
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(time), StaCtrName.setting_rest_timing, TimeUtil.currentTime()));

                    settings.setRestTime(restTimeArr[index]);
                    settings.refreshToCache();
                    EventBus.getDefault().post(new UpdateAppStartTimeEvent());
                }
            }
        });
        sleepTimeProgressView.setCallBack(new SleepTimeProgressView.SleepTimeProgressCallBack() {
            @Override
            public void getProgressIndex(int moveType, int moonTime, int sunTime) {
                String habitName = "";
                int time = 0;
                if (moveType == SleepTimeProgressView.TYPE_MOVE_MOON) {
                    habitName = "setting_sleep_begin_timing";
                    if (moonTime < 24) {
                        time = moonTime;
                    }
                } else if (moveType == SleepTimeProgressView.TYPE_MOVE_SUN) {
                    habitName = "setting_sleep_end_timing";
                    time = sunTime;
                }
                if (!TextUtils.isEmpty(habitName)) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(time),
                            habitName, TimeUtil.currentTime()));
                }

                settings.setSleepTime(moonTime);
                settings.setWakeUpTime(sunTime);
                settings.refreshToCache();
                EventBus.getDefault().post(new UpdateAppStartTimeEvent());
            }
        });
        KaDaApplication.NoDoubleClickListener onClickListener = new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                doCheckViewClick(v);
            }
        };

        unEnabledView.setOnChildClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View view) {
                boolean isChecked = !unEnabledView.isChecked();
                unEnabledView.setChecked(isChecked);

                if (isChecked) {
                    ToastUtils.showToast(R.string.sleep_mode_disable);

                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.setting_sleep_clock_disable, TimeUtil.currentTime()));
                } else {
                    ToastUtils.showToast(R.string.sleep_mode_enable);

                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.setting_sleep_clock_enable, TimeUtil.currentTime()));
                }

                PrefsManager prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
                prefsManager.putBoolean(Constants.KEY_SLEEP_TIME_UNENABLED, isChecked);
                EventBus.getDefault().post(new CheckTimeEvent());
            }
        });

        showTalentPlanCheckView.setOnClickListener(onClickListener);
//        bookPlayCheckView.setOnClickListener(onClickListener);
        bookShowQuestionCheckView.setOnClickListener(onClickListener);
        clearCacheMoreView.setOnClickListener(onClickListener);
        shareMoreView.setOnClickListener(onClickListener);
        feedbackMoreView.setOnClickListener(onClickListener);
        aboutMoreView.setOnClickListener(onClickListener);
        submissionMoreView.setOnClickListener(onClickListener);
        exchangeCenterMoreView.setOnClickListener(onClickListener);
        logoutTextView.setOnClickListener(onClickListener);
        loginTextView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                if (!UserService.getInstance().isLogining()) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                            "clickloginbutton", TimeUtil.currentTime()));
                    LoginOrRegisterActivity.startActivity(SettingActivity.this);
                }
            }
        });
        OnChildViewClickListener listener = new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View parentView, int action, Object obj) {
                switch (parentView.getId()) {
                    case R.id.hwAccountView:
                        if (!checkAccountTypeBeforeBind()) {
                            return;
                        }
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.setting_binding_huawei, TimeUtil.currentTime()));
                        doHWAccountBindingClick();
                        break;
                    case R.id.weixinAccountView:
                        if (!checkAccountTypeBeforeBind()) {
                            return;
                        }
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.setting_binding_weixin, TimeUtil.currentTime()));
                        WChatManager wChatManager = ((WChatManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.W_CHAT_MANAGER));
                        wChatManager.setTag(SettingActivity.this.getClass().getSimpleName());
                        wChatManager.requestOauthCode(new WChatManager.IWXListener() {
                            @Override
                            public void wxUnInstall() {
                                ToastUtils.showToast(R.string.uninstall_wx);
                            }
                        }, Constants.LOGIN_WX_TRANSACTION);
                        break;
                    case R.id.phoneAccountView:
                        if (!checkAccountTypeBeforeBind()) {
                            return;
                        }
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.setting_binding_phone, TimeUtil.currentTime()));
                        FragmentUtil.pushFragment(BindingPhoneFragment.class, null, true);
                        break;
                    default:
                        break;
                }
            }
        };
        hwAccountView.setOnChildViewClickListener(listener);
        weixinAccountView.setOnChildViewClickListener(listener);
        phoneAccountView.setOnChildViewClickListener(listener);
    }

    /**
     * 绑定前检查本地是否存储帐号类型，若无，弹框提示用户退出重新登录
     * @return
     */
    private boolean checkAccountTypeBeforeBind() {
        int userAccountType = UserService.getInstance().getUserAccountType();
        if (userAccountType > 0) {
            return true;
        }
        Dialog dialog = new AlertDialog.Builder(this)
                .setMessage(AppUtils.getString(R.string.dialog_check_account_type_conflict))
                .setPositiveButton(getResources().getString(R.string.dialog_check_account_type_conflict_yes),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int whichButton) {
                                dialog.dismiss();
                                try {
                                    /**
                                     * DatabaseManager.getInstance().localDatabase(); 偶现database is locked异常，暂时捕获异常防止崩溃，后期数据库更改时统一处理并行访问问题
                                     */
                                    UserService.getInstance().setIsLogining(false);
                                    UserService.getInstance().logout();
                                    DatabaseManager.getInstance().localDatabase();
                                    UserSettings.getInstance().resetUserSetting();
                                    EventBus.getDefault().post(new LogoutEvent());
                                    LoginOrRegisterActivity.startActivity(SettingActivity.this, "", true);
                                } catch (Exception e) {
                                    LogHelper.printStackTrace(e);
                                }
                            }
                        })
                .setNegativeButton(getResources().getString(R.string.dialog_check_account_type_conflict_no),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int whichButton) {
                                dialog.dismiss();
                            }
                        })
                .create();
        if (isFinishing()) {
            return false;
        }
        dialog.show();
        return false;
    }

    /**
     * 处理华为帐号绑定点击操作
     */
    private void doHWAccountBindingClick() {
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                HWSDKUtil.clearValidateHWReference();
            }
        });
        HWSDKUtil.bindHWAccount(new HWSDKUtil.HWLoginHandler<List<AccountUnifyInfo>>() {
            @Override
            public void onSuccess(final List<AccountUnifyInfo> accountUnifyInfoList) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(SettingActivity.this);
                        if (accountUnifyInfoList != null && accountUnifyInfoList.size() > 0) {
                            ActivityUtil.nextBindingConflictActivity(SettingActivity.this, (ArrayList<AccountUnifyInfo>) accountUnifyInfoList);
                        } else {
                            // 要求服务端不能返回404，要不然按照客户端当前版本(v3.7.5)逻辑404也会回调成功的话，无法区分是绑定失败还是绑定成功
                            ActivityUtil.nextBindingSuccessActivity(SettingActivity.this, false);
                        }
                    }
                });
            }

            @Override
            public void onFail(int errorCode, String message) {
                customDialogManager.dismissDialog(SettingActivity.this);
                String errorStr = KaDaApplication.applicationContext().getResources().getString(R.string.html_error);
                if(!TextUtils.isEmpty(message) && !message.contains(errorStr)) {
                    ToastUtils.showToast(message);
                }
            }
        });
    }

    /**
     * checkView点击处理
     *
     * @param view
     */
    private void doCheckViewClick(View view) {
        boolean isChecked = true;
        if (view instanceof SettingCheckView) {
            SettingCheckView checkView = (SettingCheckView) view;
            isChecked = !checkView.isChecked();
            checkView.setChecked(isChecked);
        }
        String habitName = "";
        switch (view.getId()) {
            case R.id.showTalentPlanCheckView:
                habitName = isChecked ? "setting_youcai_plan_open" : "setting_youcai_plan_close";
                UserDetail.UserInfo userInfo = UserService.getInstance().getUserInfo();
                int isPaid = 0;
                if (userInfo != null) {
                    isPaid = userInfo.isSubscribePlan() ? 1 : 0;
                }
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(isPaid), habitName, TimeUtil.currentTime()));
                UserSettings.getInstance().setBookFragmentShowTalentPlan(isChecked);
                EventCenter.fireEvent(new UserSettings.TalentPlanShowPositionChangeEvent());
                break;
//            case R.id.bookPlayCheckView:
//                habitName = isChecked ? "setting_allow_book_auto_play" : "setting_disallow_book_auto_play";
//                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
//                settings.setBookContinuePlay(isChecked);
//                settings.refreshToCache();
//                break;
            case R.id.bookShowQuestionCheckView:
                habitName = isChecked ? "setting_allow_question_after_finish_reading" : "setting_disallow_question_after_finish_reading";
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
                settings.setShowQuestion(isChecked);
                settings.refreshToCache();
                break;
            case R.id.clearCacheMoreView:
                habitName = "click_setting_clear_buffer";
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
                doClearCacheClick();
                break;
            case R.id.shareMoreView:
                habitName = "setting_page_share";
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
                doShareClick();
                break;
            case R.id.feedbackMoreView:
                habitName = "setting_feedback";
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
                WebViewActivity.startActivity(this, API.FEEDBACK_WEB);
                break;
            case R.id.aboutMoreView:
                habitName = "setting_about_us";
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
                AboutActivity.startActivity(this, KaDaApplication.APP_VERSION);
                break;
            case R.id.submissionMoreView:
                habitName = "setting_upload_click";
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
                ActivityUtil.next(this, SubmissionActivity.class);
                break;

            case R.id.exchangeCenterMoreView:
                habitName = StaCtrName.setting_exchange_center_click;
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
                WebViewActivity.startActivity(this, API.EXCHANGE_CENTER_URL());
                break;

            case R.id.logoutTextView:
                doLogoutClick();
                break;
            default:
                break;
        }
    }

    /**
     * 获取用户帐号绑定信息
     */
    private void getUserAllAccountInfo() {
        int userAccountType = UserService.getInstance().getUserAccountType();
        if (userAccountType == 0) {
            return;
        }
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                clearApiReference(userAllAccountReference);
            }
        });
        DefaultCallback<List<UserAccountInfo>> callback = new DefaultCallback<List<UserAccountInfo>>() {
            @Override
            public void onDataReceived(final List<UserAccountInfo> data) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(SettingActivity.this);
                        hwAccountView.setVisibility(View.GONE);
                        accountLineView.setVisibility(View.GONE);
                        if (data != null && data.size() > 0) {
                            for (UserAccountInfo info : data) {
                                if (info.getType() == UserAccountInfo.TYPE_PHONE) {
                                    phoneAccountView.update(info);
                                } else if (info.getType() == UserAccountInfo.TYPE_WEIXIN) {
                                    weixinAccountView.update(info);
                                } else if (info.getType() == UserAccountInfo.TYPE_HUAWEI) {
                                    hwAccountView.update(info);
                                    hwAccountView.setVisibility(View.VISIBLE);
                                    accountLineView.setVisibility(View.VISIBLE);
                                }
                            }
                            // 如果非华为帐号登录并且未绑定过华为帐号，满足华为展示条件，仍然展示华为(立即绑定)
                            if (hwAccountView.getVisibility() == View.GONE && HWSDKUtil.isShowHuaWeiInfo()) {
                                UserAccountInfo info = new UserAccountInfo();
                                info.setStatus(UserAccountInfo.STATUS_ACCOUNT_NONE);
                                hwAccountView.update(info);
                                hwAccountView.setVisibility(View.VISIBLE);
                                accountLineView.setVisibility(View.VISIBLE);
                            }
                            if (UserService.getInstance().isLogining()) {
                                accountSpaceView.setVisibility(View.VISIBLE);
                                accountLayout.setVisibility(View.VISIBLE);
                            }
                        }
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                customDialogManager.dismissDialog(SettingActivity.this);
            }
        };
        if(userAllAccountReference == null) {
            userAllAccountReference = new StrongReference<>();
        }
        userAllAccountReference.set(callback);
        UserAPI.getUserAllAccountInfo(userAllAccountReference);
    }

    /**
     * 点击分享
     */
    private void doShareClick() {
        ShareInfo shareInfo = new ShareInfo();
        shareInfo.setTitle(AppUtils.getString(R.string.app_name));
        shareInfo.setContent(AppUtils.getString(R.string.setting_share_content));
        shareInfo.setTargetUrl(API.URL_APP);
        ShareProvider.share(this, shareInfo, null);
    }

    /**
     * 点击清除缓存
     */
    private void doClearCacheClick() {
        dismissClearCacheDialog();
        mClearCacheDialog = new ClearCacheDialog2(this, new ClearCacheDialog2.Callback() {
            @Override
            public void refresh() {
                clearCacheMoreView.setRightText(getResources().getString(R.string.setting_cache_zero));
            }
        });
        if (((DownloadManager) ServiceProxyFactory.getProxy().
                getService(ServiceProxyName.DOWNLOAD_MANAGER)).hasDownloadingItems()) {
            mClearCacheDialog.setText(getResources().getString(R.string.setting_clear_cache_text));
        } else {
            mClearCacheDialog.setText(getResources().getString(R.string.clear_cache_all));
        }
        mClearCacheDialog.show();
    }

    /**
     * 点击退出登录
     */
    private void doLogoutClick() {
        if (UserService.getInstance().isLogining()) {
            if (!NetworkUtils.isNetworkAvailable(this)) {
                ToastUtils.showToast(getResources().getString(R.string.setting_logout_no_network), Gravity.CENTER);
                return;
            }
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                    "clicklogoutbutton", TimeUtil.currentTime()));
            final boolean hasDownloadingItems = ((DownloadManager) ServiceProxyFactory.getProxy().
                    getService(ServiceProxyName.DOWNLOAD_MANAGER)).hasDownloadingItems();
            String dialogContent = hasDownloadingItems ? getResources().getString(R.string.setting_logout_dialog_content_1) :
                    getResources().getString(R.string.setting_logout_dialog_content_2);

            final ConfirmDialogManager confirmDialogManager = DialogFactory.getConfirmDialogManager();
            confirmDialogManager.showDialog(this, dialogContent, R.string.setting_logout_dialog_no,
                    R.string.setting_logout_dialog_yes, false, new ConfirmDialog.OnConfirmDialogListener() {
                @Override
                public void onCancel() {
                    confirmDialogManager.dismissDialog(SettingActivity.this);
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("0", StaCtrName.clicklogoutbuttonselect, TimeUtil.currentTime()));
                }

                @Override
                public void onConfirm() {
                    confirmDialogManager.dismissDialog(SettingActivity.this);
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1", StaCtrName.clicklogoutbuttonselect, TimeUtil.currentTime()));
                    doExit();
                }
            });
        }
    }

    /**
     * 确认退出
     */
    private void doExit() {
        ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER))
                .removeAllPendingTasks(false);
        KaDaApplication.getInstance().cancelPendingRequests(0);

        if (NetworkUtils.isReachable()) {
            if (isFinishing()) {
                return;
            }
            String phoneNumber = UserService.getInstance().getUserLoginName();
            if (!TextUtils.isEmpty(phoneNumber)) {
                if (catLoadingView == null) {
                    catLoadingView = new CatLoadingView();
                }
                catLoadingView.show(this.getSupportFragmentManager(), "");
                catLoadingView.setCancelable(false);
                doLogout(phoneNumber);
            } else {
                ToastUtils.showToast(R.string.logout_param_error);
            }
        } else {
            ToastUtils.showToast(getResources().getString(R.string.network_error));
        }
    }

    /**
     * 退出登录
     *
     * @param phoneNumber
     */
    private void doLogout(String phoneNumber) {
        DefaultCallback callback = new DefaultCallback() {
            @Override
            public void onDataReceived(Object data) {
//                ((StoreConfigUtil) ServiceProxyFactory.getProxy().
//                        getService(ServiceProxyName.STORE_CONFIG_UTIL)).clearSession();

                UserService.getInstance().setIsLogining(false);
                UserService.getInstance().logout();
                DatabaseManager.getInstance().localDatabase();

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        ToastUtils.showToast(getResources().getString(R.string.setting_logout_success));
                        showLoginView(false);
                        if (catLoadingView != null) {
                            catLoadingView.dismissAllowingStateLoss();
                        }
                        EventBus.getDefault().post(new LogoutEvent());
                        LoginOrRegisterActivity.startActivity(ActivityHelper.getTopActivity(), "", true);
                        finish();
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        "logout_failure", TimeUtil.currentTime()));
                if (code == 400 && TextUtils.equals(reason, getResources().
                        getString(R.string.setting_logout_error))) {
//                    ((StoreConfigUtil) ServiceProxyFactory.getProxy().
//                            getService(ServiceProxyName.STORE_CONFIG_UTIL)).clearSession();

                    ToastUtils.showToast(getResources().getString(R.string.setting_logout_success));
                    UserService.getInstance().setIsLogining(false);
                    UserService.getInstance().logout();
                    DatabaseManager.getInstance().localDatabase();
                    EventBus.getDefault().post(new LogoutEvent());
                    showLoginView(false);
                    if (catLoadingView != null) {
                        catLoadingView.dismissAllowingStateLoss();
                    }
                    LoginOrRegisterActivity.startActivity(ActivityHelper.getTopActivity(), "", true);
                } else {
                    ToastUtils.showToast(getResources().getString(R.string.setting_logout_failed));
                    if (catLoadingView != null) {
                        catLoadingView.dismissAllowingStateLoss();
                    }
                }
            }
        };
        if (strongReference == null) {
            strongReference = new StrongReference<>();
        }
        strongReference.set(callback);
        UserAPI.doLoginOut(phoneNumber, strongReference);
    }

    public void onEvent(UserService.UserInfoChangeEvent event) {
        userIdTextView.setText(String.format(getResources().getString(R.string.setting_user_id_text),
                UserService.getInstance().getCurrentUserId()));
    }

    public void onEventMainThread(LoginEvent event) {
        showLoginView(true);
    }

    public void onEventMainThread(LogoutEvent event) {
        showLoginView(false);
    }

    public void onEventMainThread(SameAccountUnifySuccessEvent event) {
        getUserAllAccountInfo();
    }

    public void onEvent(OtherAccountUnifySuccessEvent event) {
        finish();
    }

    public void onEvent(WeiXinLoginEvent event) {
        final SendAuth.Resp response = event.getResp();
        if (event.isSuccess() && response != null && TextUtils.equals(getClass().getSimpleName(), event.getTag())) {
            int userAccountType = UserService.getInstance().getUserAccountType();
            if (userAccountType == 0) {
                return;
            }
            final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
            customDialogManager.showDialog(this, new CustomProgressDialog.Listener() {
                @Override
                public void onClosed() {
                    clearApiReference(validateWeixinReference);
                }
            });
            if (validateWeixinReference == null) {
                validateWeixinReference = new StrongReference<>();
            }
            DefaultCallback callback = new DefaultCallback<List<AccountUnifyInfo>>() {
                @Override
                public void onDataReceived(final List<AccountUnifyInfo> data) {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            customDialogManager.dismissDialog(SettingActivity.this);
                            if (data != null && data.size() > 0) {
                                ActivityUtil.nextBindingConflictActivity(SettingActivity.this, (ArrayList<AccountUnifyInfo>) data);
                            } else {
                                // 要求服务端不能返回404，要不然按照客户端当前版本(v3.6.5)逻辑404也会回调成功的话，无法区分是绑定失败还是绑定成功
                                ActivityUtil.nextBindingSuccessActivity(SettingActivity.this, false);
                            }
                        }
                    });
                }

                @Override
                public void onException(int code, String reason) {
                    super.onException(reason);
                    customDialogManager.dismissDialog(SettingActivity.this);
                }
            };
            validateWeixinReference.set(callback);
            UserAPI.validateWechat(userAccountType, response.code, validateWeixinReference);
        }
    }

    /**
     * 关闭销毁清除缓存弹框
     */
    private void dismissClearCacheDialog() {
        if (mClearCacheDialog != null) {
            if (mClearCacheDialog.isShowing()) {
                mClearCacheDialog.dismiss();
            }
            mClearCacheDialog = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "setting_page_view", TimeUtil.currentTime()));
    }

    /**
     * 清除指定接口回调资源
     * @param reference
     */
    private void clearApiReference(StrongReference reference) {
        if (reference != null) {
            reference.clear();
            reference = null;
        }
    }

    @Override
    protected void onDestroy() {
        getHandler().removeCallbacksAndMessages(null);
        if (catLoadingView != null) {
            catLoadingView.dismissAllowingStateLoss();
        }
        if (lockDialog != null) {
            lockDialog.clearCallback();
            if (lockDialog.isShowing()) {
                lockDialog.dismiss();
            }
            lockDialog = null;
        }
        dismissClearCacheDialog();
        HWSDKUtil.clearValidateHWReference();

        clearApiReference(strongReference);
        clearApiReference(userAllAccountReference);
        clearApiReference(validateWeixinReference);

        if(useTimeProgressView != null) {
            useTimeProgressView.recycle();
        }
        if (restProgressView != null) {
            restProgressView.recycle();
        }
        if (sleepTimeProgressView != null) {
            sleepTimeProgressView.recycle();
        }
        EventBus.getDefault().unregister(this);
        DialogFactory.dismissAllDialog(this);
        super.onDestroy();
    }
}
