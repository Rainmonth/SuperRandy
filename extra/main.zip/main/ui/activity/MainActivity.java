package com.hhdd.kada.main.ui.activity;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.os.PowerManager;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.CoinService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Client;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.coin.model.DailyTaskInfo;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.download.DownloadService;
import com.hhdd.kada.main.controller.MainActivityController;
import com.hhdd.kada.main.event.AppStateEvent;
import com.hhdd.kada.main.event.CheckTimeEvent;
import com.hhdd.kada.main.event.CloseRestEvent;
import com.hhdd.kada.main.event.CloseSleepEvent;
import com.hhdd.kada.main.event.LogoutEvent;
import com.hhdd.kada.main.event.PauseEvent;
import com.hhdd.kada.main.event.UnLockEvent;
import com.hhdd.kada.main.event.UpdateAppStartTimeEvent;
import com.hhdd.kada.main.event.UpdateMainTabEvent;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.listen.ListenService2;
import com.hhdd.kada.main.manager.TimeOutManager;
import com.hhdd.kada.main.mediaserver.MediaServer2;
import com.hhdd.kada.main.playback.PlaybackServiceMediaPlayer;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.ui.book.BookFragment;
import com.hhdd.kada.main.ui.fragment.MotherFragment;
import com.hhdd.kada.main.ui.story.StoryFragment;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.ConnectivityUtil;
import com.hhdd.kada.main.utils.HWSDKUtil;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.views.MainTabItemView;
import com.hhdd.kada.medal.MedalManager;
import com.hhdd.kada.medal.UserTrack;
import com.hhdd.kada.module.exposure.ExposureTracker;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.pay.PayManager;
import com.hhdd.logger.LogHelper;
import com.huawei.android.hms.agent.HMSAgent;
import com.huawei.android.hms.agent.common.handler.CheckUpdateHandler;
import com.huawei.android.hms.agent.common.handler.ConnectHandler;

import java.util.Calendar;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class MainActivity extends BaseMultiFragmentActivity {

    @BindView(R.id.main_layout)
    RelativeLayout mainLayout;
    @BindView(R.id.tabLayout)
    LinearLayout tabLayout;
    @BindView(R.id.frag_container)
    View frag_container;
    @BindView(R.id.motherTabView)
    MainTabItemView motherTabView;
    @BindView(R.id.bookTabView)
    MainTabItemView bookTabView;
    @BindView(R.id.storyTabView)
    MainTabItemView storyTabView;

    private long useAppDuration;
    private int mBackCount = 0;
    private MainActivityController controller;
    private boolean isFirstStart = true;//判断是否点击过妈妈tab 点过false
    private int currentIndex;
    private boolean isUnLockSleepPage = false;
    private long appStartTime;
    private ScheduledExecutorService service;
    private boolean isBackground; //app 是否处于后台
    private boolean isAutoUnLockRestPage; //是否时间到自动解锁休息页面
    private PowerManager pm;
    private PowerManager.WakeLock mWakeLock;

    private final int MESSAGE_START_TAB_ANIM = 100;
    private final int MESSAGE_STOP_TAB_ANIM = 200;

    private final int DELAY_TIME = 60; //单位分钟，则延迟60秒
    //                private final int DELAY_TIME = 1; //单位秒，则延迟1秒
    private static final String IS_FIRST_START = "is_first_start";//app是否首次安装
    private static final String IS_A_WEEK_TIME = "is_a_week_time";//存储一周时间起点标记位，精选页被点击时触发
    private static final String[] TRACK_TAB_TEXT_ARR = {"main_page_tabbar_mom", "main_page_tabbar_book",
            "main_page_tabbar_story"};

    @Override
    public int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    public int getFragmentContainerId() {
        return R.id.frag_container;
    }

    @Override
    public void createFragmentsToBackStack() {
        fragments.add(new MotherFragment());
        fragments.add(new BookFragment());
        fragments.add(new StoryFragment());
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //儿童锁计时归零
        final PrefsManager prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
        prefsManager.putLong("children_dialog_time", 0);
        //版本号记录
        Settings.getInstance().setVerName(KaDaApplication.getAppVersion());
        Settings.getInstance().setNoLimitUsing(true);
        Settings.getInstance().refreshToCache();

        pm = (PowerManager) getSystemService(POWER_SERVICE);
        acquireWakeLock();

        if (HWSDKUtil.isShowHuaWeiInfo()) {
            final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
            customDialogManager.showDialog(this);
            HMSAgent.connect(this, new ConnectHandler() {
                @Override
                public void onConnect(int rst) {
                    customDialogManager.dismissDialog(MainActivity.this);
                    HMSAgent.checkUpdate(MainActivity.this, new CheckUpdateHandler() {
                        @Override
                        public void onResult(int rst) {
                        }
                    });
                }
            });
        }

        Intent intent = getIntent();
        if (intent != null) {
            //闪屏点击跳转协议地址
            String redirectUrl = intent.getStringExtra(Constants.INTENT_KEY_SPLASH_REDIRECT_INFO);
            if (!TextUtils.isEmpty(redirectUrl)) {
                RedirectActivity.startActivity(MainActivity.this, redirectUrl);
            }

            //启动类型及启动跳转协议地址（如推送）
            int launchFromType = intent.getIntExtra(Constants.INTENT_KEY_LAUNCH_FROM_TYPE, 0);
            String launchRedirectUrl = intent.getStringExtra(Constants.INTENT_KEY_LAUNCH_REDIRECT_INFO);
            if (launchFromType > 0 && !TextUtils.isEmpty(launchRedirectUrl)) {
                RedirectActivity.startActivity(MainActivity.this, launchRedirectUrl);
            }
            isUnLockSleepPage = intent.getBooleanExtra(Constants.INTENT_KEY_UNLOCK_SLEEP_INFO, false);
        }

        //延迟100毫秒，优化休息睡眠页面进入卡顿
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                initCheckTime(prefsManager);
            }
        }, 100);
    }

    /**
     * 保持唤醒cpu
     */
    private void acquireWakeLock() {
        if (mWakeLock == null) {
            mWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, getClass().getSimpleName());
        }

        if (!mWakeLock.isHeld()) {
            mWakeLock.acquire();
        }
    }

    /**
     * 进入MainActivity时间检测
     *
     * @param prefsManager
     */
    private void initCheckTime(PrefsManager prefsManager) {
        boolean unEnabledSleepTime = prefsManager.getBoolean(Constants.KEY_SLEEP_TIME_UNENABLED, true);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        Settings settings = Settings.getInstance();
        int sleepTime = settings.getSleepTime();
        int wakeUpTime = settings.getWakeUpTime();
        boolean showSleepPage = !unEnabledSleepTime && !isUnLockSleepPage && (hour >= sleepTime || hour < wakeUpTime);
        if (showSleepPage) {
            //睡眠时间进入睡眠页面
            prefsManager.putLong(Constants.REST_TIME_START, 0);
            ActivityUtil.nextSleepActivity(MainActivity.this);
        } else {
            long restTimeStart = prefsManager.getLong(Constants.REST_TIME_START);
            if (restTimeStart <= 0) {
                //未处于休息时间内，开始记录app开始使用时间
                appStartTime = System.currentTimeMillis();
            } else {
                //处于休息时间内
                int restTimeSecond = settings.getRestTime();
                boolean inRestTime = (System.currentTimeMillis() - restTimeStart) / 1000 < restTimeSecond;
                if (inRestTime) {
                    //仍在休息时间内，进入休息页面，继续剩下时间倒计时
                    ActivityUtil.nextRestActivity(this);
                } else {
                    //超过休息时间，开始记录app开始使用时间
                    prefsManager.putLong(Constants.REST_TIME_START, 0);
                    appStartTime = System.currentTimeMillis();
                }
            }
        }

        startTime(DELAY_TIME);
    }

    /**
     * 开始计时
     *
     * @param delaySecond 延迟时间 单位：秒
     * @return
     */
    private boolean startTime(int delaySecond) {
        if (service != null) {
            return false;
        }
        acquireWakeLock();
        appStartTime = System.currentTimeMillis();
        service = new ScheduledThreadPoolExecutor(1);
        service.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        checkTime();
                    }
                });
            }
        }, delaySecond, DELAY_TIME, TimeUnit.SECONDS);
        return true;
    }


    @Override
    public void doInitView() {
        super.doInitView();
        int padding = ScreenUtil.dip2px(this, 50);
        frag_container.setPadding(0, 0, 0, padding);
        controller = new MainActivityController(this);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(
                ScreenUtil.getScreenWidth(this) / 4, ScreenUtil.getScreenWidth(this) / 3);
        ImageView floatImageView = controller.initFloatView();
        mainLayout.addView(floatImageView, layoutParams);
        ((RelativeLayout.LayoutParams) (floatImageView.getLayoutParams())).setMargins(10,
                ScreenUtil.getScreenHeight() - ScreenUtil.getScreenWidth(this) / 3 - 200, 0, 0);
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        controller.setCallBack(new MainActivityController.CallBack() {
            @Override
            public void showRedDot() {
                MainActivity.this.showExploreRedDot();
            }
        });
        motherTabView.setOnClickListener(new OnTabClickListener());
        bookTabView.setOnClickListener(new OnTabClickListener());
        storyTabView.setOnClickListener(new OnTabClickListener());
    }

    //////////
    /**
     * 精选tab  是否是一周时间
     * */
    private boolean isAWeekTimeOut(long currentTime) {
        long timeStep = 7 * 24 * 60 * 60 * 1000;//7天
        PrefsManager shared = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
        long storeTime = shared.getLong(IS_A_WEEK_TIME, currentTime);

        return currentTime - storeTime > timeStep;
    }

    @Override
    public void doInitData() {
        super.doInitData();
        EventBus.getDefault().register(this);
        controller.initData();

        PrefsManager shared = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
        isFirstStart = shared.getBoolean(IS_FIRST_START, true);

        if (isFirstStart) {
            shared.putLong(IS_A_WEEK_TIME, System.currentTimeMillis());//首次启动时，存储一周时间计时标记点
        }

        showRedDot();

        useAppDuration = System.currentTimeMillis();

        UserTrack.track(UserTrack.oac);

        tabLayout.getChildAt(1).setSelected(true);
        pushFragmentToBackStack(1);
        currentIndex = 1;
    }

    Runnable tabAnimRunable = new Runnable() {
        @Override
        public void run() {

        }
    };

    @Override
    public boolean handleMessage(Message message) {
        if (message.what == MESSAGE_START_TAB_ANIM) {
            motherTabView.startAnim(MainTabItemView.MOTHER_TYPE, currentIndex==0);
            bookTabView.startAnim(MainTabItemView.BOOK_TYPE, currentIndex==1);
            storyTabView.startAnim(MainTabItemView.STORY_TYPE, currentIndex==2);
            getHandler().sendEmptyMessageDelayed(MESSAGE_START_TAB_ANIM,6000);
        } else if (message.what == MESSAGE_STOP_TAB_ANIM) {
            motherTabView.stopAnim();
            bookTabView.stopAnim();
            storyTabView.stopAnim();
        }
        return super.handleMessage(message);
    }

    private void toggleTabAnim(boolean isOpen) {
        getHandler().removeCallbacksAndMessages(null);
        if (isOpen) {
            getHandler().sendEmptyMessage(MESSAGE_START_TAB_ANIM);
        } else {
            getHandler().sendEmptyMessage(MESSAGE_STOP_TAB_ANIM);
        }
    }

    private void showRedDot() {
        View motherRedDotView = getMainTabItemRedDotView(0);
        if (motherRedDotView != null && isFirstStart) {
            motherRedDotView.setVisibility(View.VISIBLE);
        }

        if (motherRedDotView != null && isAWeekTimeOut(System.currentTimeMillis())) {//最超过7天一定显示精选小红点
            motherRedDotView.setVisibility(View.VISIBLE);
        }

        showExploreRedDot();
    }

    private void showExploreRedDot() {
        View exploreRedDotView = getMainTabItemRedDotView(3);
        if (exploreRedDotView == null) {
            return;
        }

        CoinService coinService = (CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE);
        List<DailyTaskInfo> dailyTaskInfos = coinService.getDaliyTaskList();
        if (dailyTaskInfos != null) {
            int size = dailyTaskInfos.size();
            boolean needShow = false;
            for (int i = 0; i < size; i++) {
                if (!dailyTaskInfos.get(i).isFinished()) {
                    needShow = true;
                    break;
                }
            }
            exploreRedDotView.setVisibility(needShow && !isFirstStart ? View.VISIBLE : View.GONE);
        } else {
            exploreRedDotView.setVisibility(View.GONE);
        }
    }

    @Nullable
    private View getMainTabItemRedDotView(int position) {
        if (tabLayout.getChildCount() > position && tabLayout.getChildAt(position) instanceof MainTabItemView) {
            MainTabItemView exploreTabItemView = (MainTabItemView) tabLayout.getChildAt(position);
            return exploreTabItemView.getTabRedPointView();
        }
        return null;
    }

    class OnTabClickListener extends KaDaApplication.OnClickWithAnimListener {

        OnTabClickListener() {
            super(300);
        }

        @Override
        public void OnClickWithAnim(View v) {
            int index = tabLayout.indexOfChild(v);
            if (index != currentIndex) {
                updateTab(index, -1, index == 0);
            }
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", TRACK_TAB_TEXT_ARR[index], TimeUtil.currentTime()));
        }
    }

    public void onEvent(UpdateMainTabEvent event) {
        if (event != null && event.getIndex() < fragments.size()) {
            updateTab(event.getIndex(), event.getChildIndex(), event.isShowLockDialog());
        }
    }

    public void onEvent(LogoutEvent event) {
        if (!event.isCookieExpired()) {
            updateTab(1, 0, false);
        }
    }

    /**
     * 休息睡眠页面解锁
     *
     * @param event
     */
    public void onEvent(UnLockEvent event) {
        appStartTime = System.currentTimeMillis();
        int type = event.getType();
        if (type == UnLockEvent.TYPE_SLEEP_AUTO || type == UnLockEvent.TYPE_SLEEP_PUSH) {
            //自动解锁打点，非用户操作都算作自动解锁
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                    "sleep_timing_lock_auto_unlock", TimeUtil.currentTime()));
        }
        if (type == UnLockEvent.TYPE_SLEEP_USER || type == UnLockEvent.TYPE_SLEEP_PUSH) {
            isUnLockSleepPage = true;
        } else if (type == UnLockEvent.TYPE_REST_AUTO || type == UnLockEvent.TYPE_REST_USER) {
            if (type == UnLockEvent.TYPE_REST_AUTO) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        "once_timing_lock_auto_unlock", TimeUtil.currentTime()));
            }
            if (isBackground) {
                isAutoUnLockRestPage = true;
                shutdownTime();
            }
        }
    }

    public void onEvent(UpdateAppStartTimeEvent event) {
        appStartTime = System.currentTimeMillis();
        checkTime();
    }

    public void onEvent(CheckTimeEvent event) {
        checkTime();
    }

    /**
     * 休息或睡眠页面自动关闭也会触发该方法且状态为前台，故增加亮屏条件
     *
     * @param event
     */
    public void onEvent(AppStateEvent event) {
        isBackground = event.isBackground();
        if (!isBackground && pm.isScreenOn()) {
            if (isAutoUnLockRestPage) {
                isAutoUnLockRestPage = false;
            }
            boolean startTime = startTime(0);
            if (!startTime) {
                checkTime();
            }
        } else {
            Activity activity = ActivityHelper.getTopActivity();
            if (activity instanceof SleepActivity) {
                shutdownTime();
            }
            int useTime = Settings.getInstance().getUseTime();
            if (useTime < 0) {
                //使用时长设置为无限制，进入后台停止计时
                shutdownTime();
            }
        }
    }

    /**
     * 更新tab状态及切换fragment
     *
     * @param index
     */
    private void updateTab(final int index, final int childIndex, final boolean isShowLockDialog) {
        for (int i = 0; i < tabLayout.getChildCount(); i++) {
            tabLayout.getChildAt(i).setSelected(i == index);
            if (i == index) {
                View redDotView = getMainTabItemRedDotView(i);
                if (redDotView != null) {
                    redDotView.setVisibility(View.GONE);
                }
            }
        }
        pushFragmentToBackStack(index);
        if (index == 0) {

            if (isFirstStart) {
                isFirstStart = false;
                ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).putBoolean(IS_FIRST_START, false);
            }
                ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).putLong(IS_A_WEEK_TIME, System.currentTimeMillis());

            MotherFragment motherFragment = (MotherFragment) fragments.get(index);
//            if (isShowLockDialog) {
//                motherFragment.showChildLockDialog(currentIndex);
//            }
            motherFragment.setCurrentItem(childIndex);
        }
        currentIndex = index;
        toggleTabAnim(true);

        // tab切换 连续2次返回退出程序计数重置为0；
        mBackCount = 0;
    }

    @Override
    public void onBackPressed() {
        if (mBackCount >= 1) {
            long seconds = (System.currentTimeMillis() - useAppDuration) / 1000;
            UserTrack.track(UserTrack.oal, seconds);
            UserTrack.saveToFileInMainThread();
            useAppDuration = 0;
            //清除所有通知
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancelAll();
            finish();
            return;
        }
        mBackCount++;
        if (mBackCount == 1) {
            ToastUtils.showToast("再按一次退出" + getString(R.string.app_name));
        }
        getHandler().removeCallbacks(mRunnable);
        getHandler().postDelayed(mRunnable, 2000);
    }

    private Runnable mRunnable = new Runnable() {
        @Override
        public void run() {
            mBackCount = 0;
        }
    };


    @Override
    public void onDestroy() {
        super.onDestroy();
//        LogHelper.getInstance().stop();

        shutdownTime();

        releaseWakeLock();

        if (controller != null) {
            controller.onDestroy();
        }

        EventBus.getDefault().unregister(this);

        UserHabitService.getInstance().track(UserHabitService.newUserHabit("app退出", "appexit", TimeUtil.currentTime()));
//        Settings.getInstance().setVerName(KaDaApplication.getAppVersion());
//        Settings.getInstance().refreshToCache();


        PayManager.destroy();
        DialogFactory.destroyDialogManager();
        KaDaApplication.getInstance().cancelPendingRequests(0);

        if (MediaServer2.getMediaServer() != null) {
            MediaServer2.getMediaServer().stop();
        }
        PlaybackServiceMediaPlayer.stopService();
        ListenService2.stopService();
        DownloadService.stopService();
        ListenManager.getInstance().onDestory();
        ((TimeOutManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.TIME_OUT_MANAGER)).onDestory();
        ((Client) ServiceProxyFactory.getProxy().getService(ServiceProxyName.CLIENT)).cleanup();
        ((ConnectivityUtil) ServiceProxyFactory.getProxy().getService(ServiceProxyName.CONNECTIVITY_UTIL)).cleanup();
        ((MedalManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.MEDAL_MANAGER)).cleanup();
        ((UserTrack) ServiceProxyFactory.getProxy().getService(ServiceProxyName.USER_TRACK)).cleanup();
        ((IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER)).release();
        HWSDKUtil.destroy();

        ActivityHelper.finishAllActivities();
        ExposureTracker.getInstance().destroy();//序列化曝光量到本地。放倒这里是因为下面两行导致initHelper的onDestroy()不会触发。将来注释掉下面两行代码，也注释掉这里。
        android.os.Process.killProcess(android.os.Process.myPid());    //获取PID
        System.exit(0);   //常规java、c#的标准退出法，返回值为0代表正常退出
    }

    /**
     * 取消保持唤醒cpu
     */
    private void releaseWakeLock() {
        if (mWakeLock != null && mWakeLock.isHeld()) {
            try {
                mWakeLock.release();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    /**
     * 取消计时
     */
    private void shutdownTime() {
        if (service != null) {
            if (!service.isShutdown()) {
                service.shutdownNow();
            }
            service = null;
        }
        releaseWakeLock();
    }

    @Override
    public void onResume() {
        super.onResume();
        controller.onResume();
        toggleTabAnim(true);
        mBackCount = 0;
    }

    @Override
    public void onPause() {
        super.onPause();
        controller.onPause();
        toggleTabAnim(false);
    }

    @Override
    public void onStop() {
        super.onStop();
        UserTrack.saveToFileInMainThread();
    }

    /**
     * 每分钟检查一次时间
     * 判断是否到达设置使用时长及睡眠时间
     */
    private void checkTime() {
        Activity activity = ActivityHelper.getTopActivity();
        EventBus eventBus = EventBus.getDefault();
        PrefsManager prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
        boolean unEnabledSleepTime = prefsManager.getBoolean(Constants.KEY_SLEEP_TIME_UNENABLED, true);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        Settings settings = Settings.getInstance();
        int sleepTime = settings.getSleepTime();
        int wakeUpTime = settings.getWakeUpTime();
        boolean showSleepPage = !unEnabledSleepTime && !isUnLockSleepPage && (hour >= sleepTime || hour < wakeUpTime);
        if (showSleepPage) {
            //处于睡眠时间段内
            if (activity != null && activity instanceof SleepActivity) {
                return;
            }
            prefsManager.putLong(Constants.REST_TIME_START, 0);
            //休息页面存在，关闭
            eventBus.post(new CloseRestEvent());
            //暂停音频播放
            pauseMedia(activity, eventBus);
            if (!isBackground) {
                //不在后台，直接进入睡眠页面
                ActivityUtil.nextSleepActivity(MainActivity.this);
            } else {
                //后台，关闭计时，重新回到前台会重新检测当前状态
                shutdownTime();
            }
        } else {
            if (isAutoUnLockRestPage) {
                return;
            }
            if (activity != null && activity instanceof RestActivity) {
                return;
            }
            if (activity != null && activity instanceof SleepActivity) {
                eventBus.post(new CloseSleepEvent());
                eventBus.post(new UnLockEvent(UnLockEvent.TYPE_SLEEP_AUTO));
                return;
            }
            int useTime = settings.getUseTime();
            if (useTime > 0) {
                //使用时长非无限制
                long useTimeMillSec = useTime * 1000;
                boolean showRestPage = System.currentTimeMillis() - appStartTime >= useTimeMillSec;
                if (showRestPage) {
                    //到达使用时长，进入休息时间，暂停音频播放
                    pauseMedia(activity, eventBus);
                    if (!isBackground) {
                        //若在前台，直接进入休息页面
                        ActivityUtil.nextRestActivity(MainActivity.this);
                    } else {
                        //后台
                        long restTimeStart = prefsManager.getLong(Constants.REST_TIME_START);
                        if (restTimeStart <= 0) {
                            //记录当前休息时间点
                            prefsManager.putLong(Constants.REST_TIME_START, System.currentTimeMillis());
                        } else {
                            int restTimeSecond = settings.getRestTime();
                            boolean inRestTime = (System.currentTimeMillis() - restTimeStart) / 1000 < restTimeSecond;
                            if (!inRestTime) {
                                //超过休息时间，自动解锁
                                EventBus.getDefault().post(new UnLockEvent(UnLockEvent.TYPE_REST_AUTO));
                                prefsManager.putLong(Constants.REST_TIME_START, 0);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 暂停音频播放
     *
     * @param eventBus
     */
    private void pauseMedia(final Activity activity, final EventBus eventBus) {
        eventBus.post(new MainActivityController.OnHideFloatingWindowEvent());
        EventBus.getDefault().post(new PauseEvent(true));
        if (activity instanceof ListenActivity) {
            return;
        }
//        ListenManager.getInstance().pause(true);

        try {
            Intent listenIntent = new Intent(KaDaApplication.getInstance(), ListenService2.class);
            listenIntent.setAction(ListenService2.INTENT_ACTION);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_TYPE, ListenService2.Types.PAUSE);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_NEED_COMMIT, true);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_REMOVE_NOTIFICATION, true);
            KaDaApplication.getInstance().startService(listenIntent);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }
}
