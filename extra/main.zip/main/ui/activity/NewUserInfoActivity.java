package com.hhdd.kada.main.ui.activity;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.event.CapabilityMediaPlayerStopEvent;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.LogoutEvent;
import com.hhdd.kada.main.event.OtherAccountUnifySuccessEvent;
import com.hhdd.kada.main.manager.PermissionManager;
import com.hhdd.kada.main.model.CapabilityModelInfo;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.ui.dialog.TakePhotoSelectDialog;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.BitmapUtils;
import com.hhdd.kada.main.utils.CameraUtils;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.views.CommonHeaderView;
import com.hhdd.kada.medal.UserTrack;
import com.hhdd.kada.widget.UserInfoTreeView;
import com.makeramen.roundedimageview.RoundedImageView;

import java.io.File;
import java.util.List;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

import static com.hhdd.kada.medal.UserTrack.fmh;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/13
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class NewUserInfoActivity extends BaseActivity {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.headImageView)
    RoundedImageView headImageView;
    @BindView(R.id.nameLayout)
    View nameLayout;
    @BindView(R.id.nameTextView)
    TextView nameTextView;
    @BindView(R.id.genderAgeTextView)
    TextView genderAgeTextView;
    @BindView(R.id.loginTextView)
    View loginTextView;
    @BindView(R.id.customTextView)
    View customTextView;
    @BindView(R.id.capabilityIntroduceImageView)
    View capabilityIntroduceImageView;
    @BindView(R.id.userInfoTreeView)
    UserInfoTreeView userInfoTreeView;
    @BindView(R.id.bookCountTextView)
    TextView bookCountTextView;
    @BindView(R.id.bookReadTimeTextView)
    TextView bookReadTimeTextView;
    @BindView(R.id.storyCountTextView)
    TextView storyCountTextView;
    @BindView(R.id.storyReadTimeTextView)
    TextView storyReadTimeTextView;
    @BindView(R.id.collectLayout)
    View collectLayout;
    @BindView(R.id.reportLayout)
    View reportLayout;

    @BindView(R.id.topBgImageView)
    View topBgImageView;
    @BindView(R.id.contentLayout)
    View contentLayout;
    @BindView(R.id.bookLayout)
    View bookLayout;
    @BindView(R.id.bottomLayout)
    View bottomLayout;

    private Uri mPictureUri;
    private String mPicturePath;
    private StrongReference<DefaultCallback> strongReference;

    private final String IMAGE_DIR = Dirs.getTmpCachePath() + File.separator + "headImage";//头像路径

    @Override
    public int getLayoutId() {
        return R.layout.activity_userinfo_new;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        titleBarView.setTitle(getResources().getString(R.string.user_center_title));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            titleBarView.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }

        View view = titleBarView.getRightViewContainer();
        RelativeLayout.LayoutParams rightLayoutParams = (RelativeLayout.LayoutParams) view.getLayoutParams();
        rightLayoutParams.width = LocalDisplay.dp2px(60);
        view.setLayoutParams(rightLayoutParams);
        ImageView rightImageView = titleBarView.getRightImageView();
        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) rightImageView.getLayoutParams();
        if (params != null) {
            int size = LocalDisplay.dp2px(31);
            params.width = size;
            params.height = size;
            params.addRule(RelativeLayout.CENTER_IN_PARENT);
            rightImageView.setLayoutParams(params);
        }
        rightImageView.setImageResource(R.drawable.icon_setting);

        LinearLayout.LayoutParams topBgImageLayoutParams = (LinearLayout.LayoutParams) topBgImageView.getLayoutParams();
        topBgImageLayoutParams.height = LocalDisplay.isHighScreen ? LocalDisplay.dp2px(224) : LocalDisplay.dp2px(214);
        FrameLayout.LayoutParams contentLayoutParams = (FrameLayout.LayoutParams) contentLayout.getLayoutParams();
        contentLayoutParams.topMargin = LocalDisplay.isHighScreen ? LocalDisplay.dp2px(63) : LocalDisplay.dp2px(53);
        LinearLayout.LayoutParams bookLayoutParams = (LinearLayout.LayoutParams) bookLayout.getLayoutParams();
        bookLayoutParams.topMargin = LocalDisplay.isHighScreen ? LocalDisplay.dp2px(62) : LocalDisplay.dp2px(22);
        LinearLayout.LayoutParams bottomLayoutParams = (LinearLayout.LayoutParams) bottomLayout.getLayoutParams();
        bottomLayoutParams.topMargin = LocalDisplay.isHighScreen ? LocalDisplay.dp2px(40) : LocalDisplay.dp2px(10);
    }

    private KaDaApplication.OnClickWithAnimListener onClickListener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            switch (v.getId()) {
                case R.id.rl_title_bar_left:
                    finish();
                    break;
                case R.id.rl_title_bar_right:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "personal_center_setting_click", TimeUtil.currentTime()));
                    ActivityUtil.next(NewUserInfoActivity.this, SettingActivity.class);
                    break;
                case R.id.headImageView:
                    String habitName = UserService.getInstance().isLogining() ? "personal_center_avatar_click" : "personal_center_visitor_avatar_click";
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", habitName, TimeUtil.currentTime()));
                    doHeadImageClick(v);
                    break;
                case R.id.loginTextView:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "my_login_btn_new", TimeUtil.currentTime()));
                    LoginOrRegisterActivity.startActivity(NewUserInfoActivity.this, null, null, false);
                    break;
                case R.id.nameLayout:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "personal_center_edit_click", TimeUtil.currentTime()));
                    BabyInfoSettingActivity.startActivity(NewUserInfoActivity.this);
                    break;
                case R.id.customTextView:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "personal_center_custom_service_click", TimeUtil.currentTime()));
                    WebViewActivity.startActivity(NewUserInfoActivity.this, API.URL_CUSTOM());
                    break;
                case R.id.capabilityIntroduceImageView:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "personal_center_mode_info_click", TimeUtil.currentTime()));
                    ActivityUtil.next(NewUserInfoActivity.this, ReadingModelIntroduceActivity.class);
                    break;
                case R.id.collectLayout:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "personal_center_my_favorite_click", TimeUtil.currentTime()));
                    ActivityUtil.nextCollectActivity(NewUserInfoActivity.this, CommonHeaderView.TYPE_BOOK);
                    break;
                case R.id.reportLayout:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "personal_center_reading_report_click", TimeUtil.currentTime()));
                    WebViewActivity.startActivity(NewUserInfoActivity.this, API.READING_BILL);
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void doInitListener() {
        super.doInitListener();
        titleBarView.setLeftOnClickListener(onClickListener);
        titleBarView.setRightOnClickListener(onClickListener);
        headImageView.setOnClickListener(onClickListener);
        loginTextView.setOnClickListener(onClickListener);
        nameLayout.setOnClickListener(onClickListener);
        customTextView.setOnClickListener(onClickListener);
        capabilityIntroduceImageView.setOnClickListener(onClickListener);
        collectLayout.setOnClickListener(onClickListener);
        reportLayout.setOnClickListener(onClickListener);
        EventBus.getDefault().register(this);
    }

    private StrongReference<DefaultCallback<UserDetail>> mLoadUserDetailCallbackRef;

    @Override
    public void doInitData() {
        super.doInitData();
        loadUserInfo(null);
        DialogFactory.getCustomDialogManager().showDialog(this);

        DefaultCallback<UserDetail> callback = new DefaultCallback<UserDetail>() {
            @Override
            public void onDataReceived(UserDetail data) {
                if (data != null) {
                    loadUserInfo(data.getReadInfo());
                }
            }
        };

        if (mLoadUserDetailCallbackRef == null) {
            mLoadUserDetailCallbackRef = new StrongReference<>();
        }
        mLoadUserDetailCallbackRef.set(callback);
        UserService.getInstance().loadUserDetail(mLoadUserDetailCallbackRef, false);

        getUserReadingModel();
    }

    /**
     * 获取启蒙阅读模型信息
     */
    private void getUserReadingModel() {
        DefaultCallback callback = new DefaultCallback<List<CapabilityModelInfo>>() {
            @Override
            public void onDataReceived(final List<CapabilityModelInfo> data) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        DialogFactory.getCustomDialogManager().dismissDialog(NewUserInfoActivity.this);
                        if (data != null) {
                            if (isFinishing()) {
                                return;
                            }
                            userInfoTreeView.update(data);
                        }
                    }
                });
            }

            @Override
            public void onException(String reason) {
                super.onException(reason);
                DialogFactory.getCustomDialogManager().dismissDialog(NewUserInfoActivity.this);
            }
        };
        if(strongReference == null) {
            strongReference = new StrongReference<>();
        }
        strongReference.set(callback);
        UserAPI.getUserReadingModel("", strongReference);
    }

    /**
     * 加载用户信息
     */
    private void loadUserInfo(UserDetail.ReadInfo info) {
        boolean isLogin = UserService.getInstance().isLogining();
        nameLayout.setVisibility(isLogin ? View.VISIBLE : View.GONE);
        loginTextView.setVisibility(isLogin ? View.GONE : View.VISIBLE);
        updateHeadImage(isLogin);
        if (isLogin) {
            updateUserInfo();
        }
        updateBookStoryInfo(info);
    }

    /**
     * 更新头像
     */
    private void updateHeadImage(boolean isLogin) {
        if (isLogin) {
            float borderWidth = LocalDisplay.dp2px(3);
            headImageView.setBorderWidth(borderWidth);
            Bitmap bitmap = UserService.getInstance().currentUserAvatar();
            if (bitmap != null) {
                headImageView.setImageBitmap(bitmap);
            } else {
                headImageView.setImageResource(R.drawable.cemara);
            }
        } else {
            headImageView.setBorderWidth(0f);
            headImageView.setImageResource(R.drawable.icon_user_center_unlogin);
        }
    }

    /**
     * 更新用户昵称 性别 年龄
     */
    private void updateUserInfo() {
        String nick = UserService.getInstance().currentUserNickName();
        if (TextUtils.isEmpty(nick)) {
            nick = "";
        }
        nameTextView.setText(nick);
        String genderTmp = UserService.getInstance().currentUserGender();
        if (genderTmp != null && genderTmp.trim().length() > 0) {
            genderTmp = genderTmp.equalsIgnoreCase("f") ? "女 " : "男 ";
        }
        String age = UserService.getInstance().getAgeString();
        genderAgeTextView.setText(genderTmp + age);
    }


    /**
     * 更新绘本听书数据
     *
     * @param info
     */
    private void updateBookStoryInfo(UserDetail.ReadInfo info) {
        bookCountTextView.setText(null == info ? String.valueOf(UserService.getInstance().currentUserReadNumber()) : String.valueOf(info.getTotalCount()));
        bookReadTimeTextView.setText(null == info ? TimeUtil.formatUserInfoTime(UserService.getInstance().currentUserReadTimes()) : TimeUtil.formatUserInfoTime(info.getReadTimes()));
        storyCountTextView.setText(null == info ? String.valueOf(UserService.getInstance().currentUserListenNumber()) : String.valueOf(info.getStoryCount()));
        storyReadTimeTextView.setText(null == info ? TimeUtil.formatUserInfoTime(UserService.getInstance().currentUserListenTimes() / 1000) : TimeUtil.formatUserInfoTime(info.getStoryTime() / 1000));
    }

    /**
     * 点击头像
     *
     * @param view
     */
    private void doHeadImageClick(View view) {
        if (UserService.getInstance().isLogining()) {
            final TakePhotoSelectDialog mSelectorDialog = new TakePhotoSelectDialog(this);
            mSelectorDialog.show(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (i == 0) {
                        UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "clickheadcarmera", TimeUtil.currentTime()));
                        if (ContextCompat.checkSelfPermission(NewUserInfoActivity.this, Manifest.permission.CAMERA)
                                != PackageManager.PERMISSION_GRANTED) {
                            ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).requestPermission(NewUserInfoActivity.this, PermissionManager.PERMISSION_CAMERA);
                        } else {
                            mPictureUri = CameraUtils.showCamera(NewUserInfoActivity.this, IMAGE_DIR);
                        }
                    } else {
                        if (ContextCompat.checkSelfPermission(NewUserInfoActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                                != PackageManager.PERMISSION_GRANTED) {
                            ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).requestPermission(NewUserInfoActivity.this, PermissionManager.PERMISSION_READ_EXTERNAL_STORAGE);
                        } else {
                            CameraUtils.openPhotoLibrary(NewUserInfoActivity.this);
                        }
                    }
                    mSelectorDialog.dismiss();
                }
            });
        } else {
            LoginOrRegisterActivity.startActivity(NewUserInfoActivity.this, null, null, false);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            if (requestCode == PermissionManager.PERMISSION_CAMERA) {
                mPictureUri = CameraUtils.showCamera(NewUserInfoActivity.this, IMAGE_DIR);
            } else if (requestCode == PermissionManager.PERMISSION_READ_EXTERNAL_STORAGE) {
                CameraUtils.openPhotoLibrary(NewUserInfoActivity.this);
            }
        } else {
            // Permission Denied
            if (requestCode == PermissionManager.PERMISSION_CAMERA) {
                ToastUtils.showToast(R.string.no_permission_open_camera);
            } else if (requestCode == PermissionManager.PERMISSION_READ_EXTERNAL_STORAGE) {
                ToastUtils.showToast(R.string.no_permission_open_photo_library);
            }
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            switch (requestCode) {
                case CameraUtils.REQUEST_IMAGE_CAPTURE:
                    if (mPictureUri != null) {
                        CameraUtils.startCropImageActivityForCamera(this, mPictureUri, mPictureUri);
                    } else {
                        File file = new File(IMAGE_DIR);
                        if (file.length() > 0) {
                            File[] files = file.listFiles();
                            mPictureUri = CameraUtils.getUriForFile(getApplicationContext(), files[0]);
                        } else {
                            Toast.makeText(this, "拍摄失败", Toast.LENGTH_LONG).show();
                        }

                        if (mPictureUri != null) {
                            CameraUtils.startCropImageActivityForCamera(this, mPictureUri, mPictureUri);
                        }
                    }
                    break;

                case CameraUtils.REQUEST_PHOTO_LIBRARY:
                    Uri uri = data.getData();
                    if (uri != null) {
                        mPictureUri = CameraUtils.startCropImageActivityForPicture(this, uri);
                    }
                    break;

                case CameraUtils.REQUEST_CODE_IMAGE_CROP:
                    if (mPictureUri != null) {
                        doImageCrop();
                    } else {
                        File file = new File(IMAGE_DIR);
                        if (file.length() > 0) {
                            File[] files = file.listFiles();
                            mPictureUri = Uri.fromFile(files[0]);
                        } else {
                            Toast.makeText(this, "拍摄失败", Toast.LENGTH_LONG).show();
                        }
                        doImageCrop();
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 处理图片裁剪
     */
    private void doImageCrop() {
        File avatar = BitmapUtils
                .compressAndRotateToBitmapThumbFile(this,
                        mPictureUri, Constants.kAvatarSize, Constants.kAvatarSize);
        mPictureUri = null;
        if (avatar != null) {
            mPicturePath = avatar.getAbsolutePath();
            if (FileUtils.fileExist(mPicturePath)) {
                Settings.addChangeAvatarTimes();
                UserService.getInstance().updateAvatar(mPicturePath);

                UserTrack.track(fmh);
                EventBus.getDefault().post(new UserService.AvatarChangedEvent());
            }
        }
    }

    public void onEvent(UserService.AvatarFetchedEvent event) {
        updateHeadImage(UserService.getInstance().isLogining());
    }

    public void onEvent(UserService.AvatarChangedEvent event) {
        updateHeadImage(UserService.getInstance().isLogining());
    }

    public void onEvent(UserService.UserInfoChangeEvent event) {
        loadUserInfo(null);
    }

    public void onEvent(LoginEvent event) {
        DialogFactory.getCustomDialogManager().showDialog(NewUserInfoActivity.this);
        loadUserInfo(null);
        getUserReadingModel();
    }

    public void onEvent(LogoutEvent event) {
        if (!event.isCookieExpired()) {
            finish();
        } else {
            DialogFactory.getCustomDialogManager().showDialog(NewUserInfoActivity.this);
            loadUserInfo(null);
            getUserReadingModel();
        }
    }

    public void onEvent(OtherAccountUnifySuccessEvent event) {
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "personal_center_view", TimeUtil.currentTime()));
        userInfoTreeView.startAnim();
    }

    @Override
    public void onPause() {
        super.onPause();
        userInfoTreeView.cancelAnim();
        EventBus.getDefault().post(new CapabilityMediaPlayerStopEvent());
    }

    @Override
    protected void onDestroy() {
        if (userInfoTreeView != null) {
            userInfoTreeView.recycle();
        }
        EventBus.getDefault().unregister(this);
        if(strongReference != null) {
            strongReference.clear();
            strongReference = null;
        }
        super.onDestroy();

        if (mLoadUserDetailCallbackRef != null) {
            mLoadUserDetailCallbackRef.clear();
            mLoadUserDetailCallbackRef = null;
        }
        DialogFactory.dismissAllDialog(this);
    }
}
