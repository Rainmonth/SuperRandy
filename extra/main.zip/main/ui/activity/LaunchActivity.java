package com.hhdd.kada.main.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.kada.Constants;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.RestSleepUtil;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/29
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class LaunchActivity extends Activity {

    private PrefsManager prefsManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActivityHelper.registerActivity(this);
        prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
        Intent intent = getIntent();
        int inRest = RestSleepUtil.checkTimeInRestSleep();
        if (intent != null) {
            int launchFromType = intent.getIntExtra(Constants.INTENT_KEY_LAUNCH_FROM_TYPE, 0);
            switch (launchFromType) {
                case Constants.LAUNCH_FROM_TYPE_PUSH:
                    prefsManager.putLong(Constants.REST_TIME_START, 0);
                    if(inRest == RestSleepUtil.IN_SLEEP_TIME) {
                        //处于睡眠时间，解锁
                        intent.putExtra(Constants.INTENT_KEY_UNLOCK_SLEEP_INFO, true);
                    }
                    //如果由推送启动，均直接进入MainActivity，不经过SplashActivity，避免SplashActivity可以点击跳转
                    intent.setClass(this, MainActivity.class);
                    break;
                case Constants.LAUNCH_FROM_TYPE_DEFAULT:
                default:
                    intent = normalLaunch(inRest);
                    break;
            }
        } else {
            intent = normalLaunch(inRest);
        }
        startActivity(intent);
        finish();
    }

    /**
     * 正常启动
     * @param inRest
     * @return
     */
    private Intent normalLaunch(int inRest) {
        //正常启动
        Intent intent = new Intent();
        if (inRest > RestSleepUtil.NOT_IN_REST) {
            //如果处于休息或睡眠时间，直接进入MainActivity，避免SplashActivity可以点击跳转
            intent.setClass(this, MainActivity.class);
        } else {
            //如果正常时间段内，走SplashActivity正常流程
            intent.setClass(this, SplashActivity.class);
        }
        return intent;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ActivityHelper.unregisterActivity(this, false);
    }
}
