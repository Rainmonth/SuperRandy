package com.hhdd.kada.main.ui.activity;

import android.animation.ObjectAnimator;
import android.os.Build;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.event.CloseSleepEvent;
import com.hhdd.kada.main.event.UnLockEvent;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.utils.TimeUtil;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/4
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class SleepActivity extends BaseRestActivity {

    @BindView(R.id.moonBoyImageView)
    ImageView moonBoyImageView;
    @BindView(R.id.sleepLayout)
    LinearLayout sleepLayout;

    @Override
    public int getLayoutId() {
        return R.layout.activity_sleep;
    }

    @Override
    protected int getRawId() {
        return R.raw.good_night;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        EventBus.getDefault().register(this);
        Settings settings = Settings.getInstance();
        int sleepTime = settings.getSleepTime();
        if (sleepTime == 24) {
            sleepTime = 0;
        }
        int wakeUpTime = settings.getWakeUpTime();
        timeTextView.setText(String.format(getResources().getString(R.string.setting_sleep_time),
                String.valueOf(sleepTime), String.valueOf(wakeUpTime)));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            sleepLayout.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
        }
    }

    @Override
    protected void initAnimation() {
        rotationAnimator = ObjectAnimator.ofFloat(moonBoyImageView, "rotation", 0, -20, 0, 20, 40, 20, 0);
        rotationAnimator.setDuration(6000);
        rotationAnimator.setInterpolator(new LinearInterpolator());
        rotationAnimator.setRepeatCount(-1);
        rotationAnimator.start();
    }

    @Override
    protected void doMotherUnLock() {
        EventBus.getDefault().post(new UnLockEvent(UnLockEvent.TYPE_SLEEP_USER));
    }

    @Override
    protected void doModifyTime() {
        EventBus.getDefault().post(new UnLockEvent(UnLockEvent.TYPE_SLEEP_USER));
    }

    @Override
    protected void doMotherUnLockHabit() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "sleep_timing_mom_unlock_click", TimeUtil.currentTime()));
    }

    @Override
    protected void doModifyTimeHabit() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "sleep_timing_modify_setting_click", TimeUtil.currentTime()));
    }

    public void onEvent(CloseSleepEvent event) {
        animFinish();
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "sleep_timing_lock_view", TimeUtil.currentTime()));
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }

}
