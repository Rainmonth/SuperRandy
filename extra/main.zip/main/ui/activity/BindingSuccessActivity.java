package com.hhdd.kada.main.ui.activity;

import android.content.Intent;

import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.event.LogoutEvent;
import com.hhdd.kada.main.event.OtherAccountUnifySuccessEvent;
import com.hhdd.kada.main.event.SameAccountUnifySuccessEvent;
import com.hhdd.kada.main.settings.UserSettings;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.logger.LogHelper;

import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/5
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class BindingSuccessActivity extends BindingResultActivity {

    private boolean isNeedLoginAgain;

    @Override
    public void doInitView() {
        super.doInitView();
        int size = LocalDisplay.dp2px(55);
        bindingResultIconView.getLayoutParams().width = size;
        bindingResultIconView.getLayoutParams().height = size;
        bindingResultIconView.setImageResource(R.drawable.icon_binding_success);
    }

    @Override
    public void doInitData() {
        super.doInitData();
        Intent intent = getIntent();
        if (intent != null) {
            isNeedLoginAgain = intent.getBooleanExtra(Constants.INTENT_KEY_UNIFY_RESULT_NEED_LOGIN, false);
            bindingResultDescriptionView.setText(isNeedLoginAgain ? R.string.unify_account_success_text_2 : R.string.unify_account_success_text_1);
            bindingResultButtonView.setText(isNeedLoginAgain ? R.string.binding_button_success_login : R.string.binding_button_success);
        }
    }

    @Override
    protected int getBindingResultTitleId() {
        return R.string.binding_success_text;
    }

    @Override
    protected void doBindingResultButtonClick() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                StaCtrName.binding_success_ok_click, TimeUtil.currentTime()));
        doFinish();
        finish();
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(isNeedLoginAgain ? "1" : "0",
                StaPageName.binding_success_view, TimeUtil.currentTime()));
    }

    @Override
    public void onBackPressed() {
        doFinish();
        super.onBackPressed();
    }

    /**
     * 退出当前页面
     */
    private void doFinish() {
        if (isNeedLoginAgain) {
            try {
                /**
                 * DatabaseManager.getInstance().localDatabase(); 偶现database is locked异常，暂时捕获异常防止崩溃，后期数据库更改时统一处理并行访问问题
                 */
                UserService.getInstance().setIsLogining(false);
                UserService.getInstance().logout();
                DatabaseManager.getInstance().localDatabase();
                EventBus.getDefault().post(new LogoutEvent());
                EventBus.getDefault().post(new OtherAccountUnifySuccessEvent());
                LoginOrRegisterActivity.startActivity(ActivityHelper.getTopActivity(), "", true);
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        } else {
            EventBus.getDefault().post(new SameAccountUnifySuccessEvent());
        }
    }
}
