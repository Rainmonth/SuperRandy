package com.hhdd.kada.main.ui.activity;

import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.ui.dialog.ClearCacheDialog2;
import com.hhdd.kada.main.ui.fragment.collectdownload.BaseDownloadFragment;
import com.hhdd.kada.main.ui.fragment.collectdownload.DownloadBookFragment;
import com.hhdd.kada.main.ui.fragment.collectdownload.DownloadStoryFragment;
import com.hhdd.kada.main.utils.TimeUtil;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/26
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class DownloadActivity extends CollectDownloadActivity {

    private ClearCacheDialog2 clearCacheDialog;

    @Override
    protected void initFragments() {
        fragments.add(new DownloadBookFragment());
        fragments.add(new DownloadStoryFragment());
    }

    @Override
    public void doInitView() {
        super.doInitView();
        titleBarView.setTitle("下载");
    }

    @Override
    protected void doTabClick(View view) {
        String name = view.getId() == R.id.bookTabTextView ? "download_center_book_tab_click" : "download_center_story_tab_click";
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", name, TimeUtil.currentTime()));
    }

    @Override
    protected void addClearImageView() {
        ImageView imageView = new ImageView(this);
        imageView.setImageResource(R.drawable.icon_clear);
        imageView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                doDownloadCacheClear();
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "download_center_delete_click", TimeUtil.currentTime()));
            }
        });
        LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        imgParams.gravity = Gravity.CENTER;
        container.addView(imageView, imgParams);
    }

    private void doDownloadCacheClear() {
        //避免点击清除按钮后出现多个提示dialog
        if (clearCacheDialog != null && clearCacheDialog.isShowing()) {
            return;
        }
        String title = getResources().getString(R.string.clear_cache_all);
        int type = ClearCacheDialog2.TYPE_ALL;
        if (viewPager.getCurrentItem() == 0) {
            title = getResources().getString(R.string.clear_cache_book);
            type = ClearCacheDialog2.TYPE_BOOK;
        } else if (viewPager.getCurrentItem() == 1) {
            title = getResources().getString(R.string.clear_cache_story);
            type = ClearCacheDialog2.TYPE_STORY;
        }
        clearCacheDialog = new ClearCacheDialog2(DownloadActivity.this, new ClearCacheDialog2.Callback() {
            @Override
            public void refresh() {
                String name = viewPager.getCurrentItem() == 0 ? "user_downloaded_page_delete_all_book" : "user_downloaded_page_delete_all_story";
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", name, TimeUtil.currentTime()));
                if (fragments.get(viewPager.getCurrentItem()) instanceof BaseDownloadFragment) {
                    BaseDownloadFragment downloadFragment = (BaseDownloadFragment) fragments.get(viewPager.getCurrentItem());
                    downloadFragment.handleLoadedData(null);
                }
            }
        }, type);
        clearCacheDialog.setText(title);
        clearCacheDialog.show();
    }

    @Override
    protected void doEdit() {
        if (fragments.get(viewPager.getCurrentItem()) instanceof BaseDownloadFragment) {
            BaseDownloadFragment downloadFragment = (BaseDownloadFragment) fragments.get(viewPager.getCurrentItem());
            editTextView.setText(downloadFragment.isEdit() ? R.string.manage : R.string.done);
            downloadFragment.doEdit(!downloadFragment.isEdit());
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "download_center_edit_click", TimeUtil.currentTime()));
    }

    @Override
    protected void updateEditTextView(int position) {
        if (fragments.get(position) instanceof BaseDownloadFragment) {
            BaseDownloadFragment downloadFragment = (BaseDownloadFragment) fragments.get(position);
            editTextView.setText(downloadFragment.isEdit() ? R.string.done : R.string.manage);
        }
    }
}
