package com.hhdd.kada.main.ui.activity;

import android.content.Intent;
import android.text.TextUtils;

import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;

import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/5
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class BindingFailActivity extends BindingResultActivity {

    @Override
    public void doInitView() {
        super.doInitView();
        bindingResultIconView.getLayoutParams().width = LocalDisplay.dp2px(68);
        bindingResultIconView.getLayoutParams().height = LocalDisplay.dp2px(50);
        bindingResultIconView.setImageResource(R.drawable.icon_binding_failed);
        bindingResultDescriptionView.setText("绑定出现异常\n请联系客服，我们会帮您解决");
        bindingResultButtonView.setText(R.string.binding_button_fail);
    }

    @Override
    public void doInitData() {
        super.doInitData();
        EventBus.getDefault().register(this);
        Intent intent = getIntent();
        if (intent != null) {
            String resultText = intent.getStringExtra(Constants.INTENT_KEY_UNIFY_RESULT_TEXT);
            if (!TextUtils.isEmpty(resultText)) {
                bindingResultDescriptionView.setText(resultText);
            }
        }
    }

    @Override
    protected int getBindingResultTitleId() {
        return R.string.binding_fail_text;
    }

    @Override
    protected void doBindingResultButtonClick() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                StaCtrName.binding_failure_contact_click, TimeUtil.currentTime()));
        WebViewActivity.startActivity(this, API.URL_CUSTOM());
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                StaPageName.binding_failure_view, TimeUtil.currentTime()));
    }

    public void onEvent(AuthService.CookieExpiredEvent event) {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }
}
