package com.hhdd.kada.main.ui.activity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.TalentPlanAPI;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.dialog.ConfirmDialogManager;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.event.CloseRecommendSettingPageEvent;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.DimensionInfo;
import com.hhdd.kada.main.model.RecommendContentInfo;
import com.hhdd.kada.main.ui.dialog.ConfirmDialog;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.HHTimeUtil;
import com.hhdd.kada.main.utils.TextLengthFilter;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.widget.RecommendSettingTreeView;
import com.hhdd.logger.LogHelper;

import java.io.UnsupportedEncodingException;
import java.util.List;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/22
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class RecommendSubscribeSettingActivity extends BaseActivity {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.nameEditText)
    EditText nameEditText;
    @BindView(R.id.ageTextView)
    TextView ageTextView;
    @BindView(R.id.boyView)
    TextView boyView;
    @BindView(R.id.girlView)
    TextView girlView;
    @BindView(R.id.boyCheckImageView)
    ImageView boyCheckImageView;
    @BindView(R.id.girlCheckImageView)
    ImageView girlCheckImageView;
    @BindView(R.id.recommendIntroduceImageView)
    ImageView recommendIntroduceImageView;
    @BindView(R.id.recommendSettingTreeView)
    RecommendSettingTreeView recommendSettingTreeView;
    @BindView(R.id.skipLayout)
    View skipLayout;

    private int babyYear;
    private int babyMonth;
    private int babyDay;
    private StrongReference<DefaultCallback> strongReference;
    private Dialog exitConfirmDialog;

    private final String REGEX = "-";

    @Override
    public int getLayoutId() {
        return R.layout.activity_recommend_subscribe_setting;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        EventBus.getDefault().register(this);
        titleBarView.setTitle(getResources().getString(R.string.recommend_user_info_title));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleViewLayoutParams = titleBarView.getLayoutParams();
            if (titleViewLayoutParams == null) {
                titleViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleViewLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height) + LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleBarView.setLayoutParams(titleViewLayoutParams);
            titleBarView.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
        }

//        String nick = UserService.getInstance().currentUserNickName();
//        if (TextUtils.isEmpty(nick)) {
//            nick = "";
//        }
//        nameEditText.setText(nick);
//        nameEditText.setSelection(nameEditText.getText().length());
//        String userBirthday = UserService.getInstance().currentUserBirthday();
//        if (!TextUtils.isEmpty(userBirthday) && HHTimeUtil.isInRange(userBirthday, Constants.USER_BEGIN_DATE, HHTimeUtil.currentDate())) {
//            babyYear = HHTimeUtil.getYear(userBirthday);
//            babyMonth = HHTimeUtil.getMonth(userBirthday);
//            babyDay = HHTimeUtil.getDay(userBirthday);
//            ageTextView.setText(userBirthday);
//        }
//        String genderTmp = UserService.getInstance().currentUserGender();
//        boolean isBoy = true;
//        if (genderTmp != null && genderTmp.trim().length() > 0) {
//            isBoy = !genderTmp.equalsIgnoreCase("f");
//        }
        updateGender(true);

        nameEditText.setFilters(new InputFilter[]{new TextLengthFilter(Constants.NAME_LENGHT)});
        nameEditText.addTextChangedListener(new NameTextWatcher());
    }

    private KaDaApplication.NoDoubleClickListener onClickListener = new KaDaApplication.NoDoubleClickListener() {
        @Override
        public void onNoDoubleClick(View v) {
            switch (v.getId()) {
                case R.id.boyView:
                case R.id.boyCheckImageView:
                    updateGender(true);
                    break;
                case R.id.girlView:
                case R.id.girlCheckImageView:
                    updateGender(false);
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    public void doInitListener() {
        super.doInitListener();
        KaDaApplication.NoDoubleClickListener noDoubleClickListener = new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                switch (v.getId()) {
                    case R.id.rl_title_bar_left:
                        showExitConfirmDialog();
                        break;
                    case R.id.skipLayout:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                "new_user_recommend_setting_info_skip", TimeUtil.currentTime()));
                        checkMainActivityForFinish();
                        break;
                    case R.id.ageTextView:
                        chooseAge();
                        break;
                    default:
                        break;
                }
            }
        };
        titleBarView.setLeftOnClickListener(noDoubleClickListener);
        skipLayout.setOnClickListener(noDoubleClickListener);
        ageTextView.setOnClickListener(noDoubleClickListener);
        boyView.setOnClickListener(onClickListener);
        boyCheckImageView.setOnClickListener(onClickListener);
        girlView.setOnClickListener(onClickListener);
        girlCheckImageView.setOnClickListener(onClickListener);
        recommendIntroduceImageView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        "new_user_recommend_setting_info_introduction_click", TimeUtil.currentTime()));
                ActivityUtil.next(RecommendSubscribeSettingActivity.this, ReadingModelIntroduceActivity.class);
            }
        });

        recommendSettingTreeView.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        "new_user_recommend_setting_info_submit_click", TimeUtil.currentTime()));
                String dimensionIds = (String) obj;
                postDimensionInfo(dimensionIds);
            }
        });
    }

    /**
     * 显示退出二次确认框
     */
    private void showExitConfirmDialog() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "new_user_recommend_setting_info_tip", TimeUtil.currentTime()));
        final ConfirmDialogManager confirmDialogManager = DialogFactory.getConfirmDialogManager();
        confirmDialogManager.showDialog(this, R.string.recommend_exit_confirm_dialog_content,
                R.string.recommend_exit_confirm_dialog_cancel, R.string.recommend_exit_confirm_dialog_confirm,
                false, new ConfirmDialog.OnConfirmDialogListener() {
                    @Override
                    public void onCancel() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                "new_user_recommend_setting_info_tip_no", TimeUtil.currentTime()));
                        confirmDialogManager.dismissDialog(RecommendSubscribeSettingActivity.this);
                    }

                    @Override
                    public void onConfirm() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                "new_user_recommend_setting_info_tip_yes", TimeUtil.currentTime()));
                        confirmDialogManager.dismissDialog(RecommendSubscribeSettingActivity.this);
                        checkMainActivityForFinish();
                    }
                });
    }

    @Override
    public void doInitData() {
        super.doInitData();
        Intent intent = getIntent();
        if (intent != null) {
            boolean isToast = intent.getBooleanExtra(Constants.INTENT_KEY_RECOMMEND_TOAST, false);
            recommendSettingTreeView.updateRecommendImage(isToast ? R.drawable.button_baby_info_setting_go_app : R.drawable.button_baby_info_setting_recommend);
            String dimensionInfo = intent.getStringExtra(Constants.INTENT_KEY_RECOMMEND_DIMENSION_INFO);
            List<DimensionInfo> dimensionInfoList = new Gson().fromJson(dimensionInfo, new TypeToken<List<DimensionInfo>>() {
            }.getType());
            recommendSettingTreeView.update(dimensionInfoList);
        }
    }

    /**
     * 提交选中的推荐分类信息
     */
    private void postDimensionInfo(final String dimensionIds) {
        String nick = nameEditText.getText().toString();
        String birthday = ageTextView.getText().toString();
        final String gender = boyCheckImageView.isSelected() ? "M" : "F";
        if (!TextUtils.isEmpty(nick)) {
            nick = nick.trim();
        }
        if (!TextUtils.isEmpty(birthday)) {
            birthday = birthday.trim();
        }
        if (TextUtils.isEmpty(nick)) {
            nameEditText.setText("");
            ToastUtils.showToast(getResources().getString(R.string.recommend_setting_nick_not_null));
            return;
        }
        if (TextUtils.isEmpty(birthday)) {
            ToastUtils.showToast(getResources().getString(R.string.recommend_setting_birthday_not_null));
            return;
        }

        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this);
        final String finalNick = nick;
        final String finalBirthday = birthday;
        DefaultCallback callback = new DefaultCallback<RecommendContentInfo>() {
            @Override
            public void onDataReceived(final RecommendContentInfo data) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(RecommendSubscribeSettingActivity.this);

                        UserDetail.UserInfo userInfo = UserService.getInstance().getUserInfo();
                        if (userInfo != null) {
                            userInfo.setNick(finalNick);
                            userInfo.setBirthday(finalBirthday);
                            userInfo.setGender(gender);
                            UserService.getInstance().save();
                            EventBus.getDefault().post(new UserService.UserInfoChangeEvent());
                        }

                        boolean haveData = false;
                        if (data != null) {
                            boolean haveBookData = data.getBookList() != null && data.getBookList().size() > 0;
                            boolean haveStoryData = data.getStoryList() != null && data.getStoryList().size() > 0;
                            if (haveBookData || haveStoryData) {
                                haveData = true;
                            }
                        }
                        if (haveData) {
                            ActivityUtil.nextRecommendContentActivity(RecommendSubscribeSettingActivity.this, data, dimensionIds);
                        } else {
                            checkMainActivityForFinish();
                        }
                    }
                });
            }

            @Override
            public void onException(String reason) {
                super.onException(reason);
                customDialogManager.dismissDialog(RecommendSubscribeSettingActivity.this);
                checkMainActivityForFinish();
            }
        };
        if (strongReference == null) {
            strongReference = new StrongReference<>();
        }
        strongReference.set(callback);
        TalentPlanAPI.postDimensionInfo(nick, gender, birthday, dimensionIds, strongReference);
    }

    /**
     * 更新性别
     *
     * @param isBoy
     */
    private void updateGender(boolean isBoy) {
        boyCheckImageView.setSelected(isBoy);
        girlCheckImageView.setSelected(!isBoy);
    }

    /**
     * 选择年龄
     */
    private void chooseAge() {
        if (babyYear == 0 || babyMonth == 0 || babyDay == 0) {
            babyYear = HHTimeUtil.getCurrentYear();
            babyMonth = 1;
            babyDay = 1;
        }
        DatePickerDialog dialog = new DatePickerDialog(this, AlertDialog.THEME_HOLO_LIGHT, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                babyYear = year;
                babyMonth = monthOfYear + 1;
                babyDay = dayOfMonth;
                String date = HHTimeUtil.getFormatDate(babyYear, babyMonth, babyDay);
                ageTextView.setText(date);
            }
        }, babyYear, babyMonth - 1, babyDay);

        // 如果手机系统时间小于{@link Constants.USER_BEGIN_DATE}，则minTime使用(systemCurrentTime - 1秒)
        long minTime = HHTimeUtil.milliTimeFromDate2(Constants.USER_BEGIN_DATE);
        long systemCurrentTime = System.currentTimeMillis();
        if (systemCurrentTime <= minTime) {
            minTime = systemCurrentTime - 1000;
        }

        dialog.getDatePicker().setMinDate(minTime);// 设置可选择最小日期
        dialog.getDatePicker().setMaxDate(systemCurrentTime); // 设置可选择最大日期

        if (isFinishing()) {
            return;
        }
        dialog.show();
    }

    class NameTextWatcher implements TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void afterTextChanged(Editable editable) {
            String string = editable.toString();
            try {
                if (string.getBytes(TextLengthFilter.CHARSET_NAME).length > Constants.NAME_LENGHT) {
                    ToastUtils.showToast("昵称最长支持6个汉字、12个英文或数字");
                }
            } catch (UnsupportedEncodingException e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "new_user_recommend_setting_info_view", TimeUtil.currentTime()));
    }

    public void onEvent(CloseRecommendSettingPageEvent event) {
        finish();
    }

    /**
     * 检查MainActivity是否启动，若未启动，则启动在关闭当前页面
     */
    private void checkMainActivityForFinish() {
        if (!ActivityUtil.isMainActivityLaunch()) {
            ActivityUtil.next(RecommendSubscribeSettingActivity.this, MainActivity.class);
        }
        finish();
    }

    @Override
    public void onBackPressed() {
        showExitConfirmDialog();
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        if (recommendSettingTreeView != null) {
            recommendSettingTreeView.recycle();
        }
        super.onDestroy();
        if (strongReference != null) {
            strongReference.clear();
            strongReference = null;
        }
        DialogFactory.dismissAllDialog(this);
    }
}
