package com.hhdd.kada.main.ui.activity;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.main.common.TitleBar;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/5
 * @describe : com.hhdd.kada.main.ui.activity
 */
public abstract class BindingResultActivity extends BaseActivity {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.bindingResultIconView)
    ImageView bindingResultIconView;
    @BindView(R.id.bindingResultDescriptionView)
    TextView bindingResultDescriptionView;
    @BindView(R.id.bindingResultButtonView)
    TextView bindingResultButtonView;

    @Override
    public int getLayoutId() {
        return R.layout.activity_binding_result;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        ViewGroup.LayoutParams titleBarLayoutParams = titleBarView.getLayoutParams();
        if (titleBarLayoutParams==null){
            titleBarLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        titleBarLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height)+ LocalDisplay.SCREEN_STATUS_HEIGHT);
        titleBarView.setLayoutParams(titleBarLayoutParams);
        titleBarView.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        titleBarView.setTitle(getResources().getString(getBindingResultTitleId()));
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        titleBarView.setLeftOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                onBackPressed();
            }
        });
        bindingResultButtonView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                doBindingResultButtonClick();
            }
        });
    }

    /**
     * 获取绑定结果页标题 id
     * @return
     */
    protected abstract int getBindingResultTitleId();

    /**
     * 绑定结果页按钮点击事件处理
     */
    protected abstract void doBindingResultButtonClick();


}
