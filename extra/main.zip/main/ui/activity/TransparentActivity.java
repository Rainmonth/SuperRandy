package com.hhdd.kada.main.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.UpdateManager;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.base.BaseActivity;

/**
 * Created by lj on 16/7/26.
 */
public class TransparentActivity extends BaseActivity {

    public static void startActivity(Context context){
        Intent intent = new Intent(context,TransparentActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        boolean isRunning = ((UpdateManager)(ServiceProxyFactory.getProxy().getService(ServiceProxyName.UPDATE_MANAGER))).showNoticeDialog(this,"需要更新最新版本才能播放哟^_^",true);
        if(!isRunning){
            finish();
        }
    }
}
