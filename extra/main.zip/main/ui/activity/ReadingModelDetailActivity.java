package com.hhdd.kada.main.ui.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.genius.GeniusConfig;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.model.CapabilityModelInfo;
import com.hhdd.kada.main.model.GeniusModelInfo;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.audio.AudioName;
import com.hhdd.kada.module.player.AudioInfo;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;
import com.hhdd.kada.widget.FruitHorizontalProgressView;
import com.hhdd.kada.widget.UserInfoTreeView;

import java.util.List;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/1/11
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class ReadingModelDetailActivity extends BaseActivity {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.dimensionTextView)
    TextView dimensionTextView;
    @BindView(R.id.bookStoryCountTextView)
    TextView bookStoryCountTextView;
    @BindView(R.id.labelLayout)
    LinearLayout labelLayout;
    @BindView(R.id.dimensionDetailTextView)
    TextView dimensionDetailTextView;
    @BindView(R.id.levelTextView)
    TextView levelTextView;
    @BindView(R.id.bookLayout)
    View bookLayout;
    @BindView(R.id.geniusImageView)
    ImageView geniusImageView;
    @BindView(R.id.geniusHorizontalProgressView)
    FruitHorizontalProgressView geniusHorizontalProgressView;
    @BindView(R.id.geniusLayout)
    LinearLayout geniusLayout;
    @BindView(R.id.geniusTextView)
    TextView geniusTextView;
    @BindView(R.id.geniusDetailTextView)
    TextView geniusDetailTextView;
    @BindView(R.id.tv_genius_amount)
    TextView tvGeniusAmount;

    private CapabilityModelInfo info;
    private int dimensionIndex;

    private int LEVEL_COUNT = 4; //精灵等级数量

    private IMediaPlayer mShortMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);

    private boolean isNeedContinuePlayListen = false;

    @Override
    public int getLayoutId() {
        return R.layout.activity_reading_model_detail;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mShortMediaPlayer.addOnPlayListener(mOnPlayListener);
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        titleBarView.setLeftOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                finish();
            }
        });
//        for (int i = 0; i < geniusLayout.getChildCount(); i++) {
//            ImageView geniusImageView = (ImageView) geniusLayout.getChildAt(i);
//            geniusImageView.setTag(i);
//            geniusImageView.setOnClickListener(onClickListener);
//        }
    }

//    /**
//     * 精灵等级列表点击事件 点击切换大精灵展示
//     */
//    private KaDaApplication.NoDoubleClickListener onClickListener = new KaDaApplication.NoDoubleClickListener() {
//        @Override
//        public void onNoDoubleClick(View v) {
//            Object tag = v.getTag();
//            int index = -1;
//            if(tag != null && tag instanceof Integer) {
//                index = (int) tag;
//            }
//            if(index >= 0 && dimensionIndex < GeniusConfig.GENIUS_IMAGE_ID_NAME.length) {
//                showGeniusImage(index);
////                playGeniusRaw(index);
//            }
//        }
//    };


    @Override
    public void doInitView() {
        super.doInitView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            titleBarView.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }
    }

    /**
     * 展示精灵大图
     *
     * @param index
     */
    private void showGeniusImage(int index) {
        int padding = 0;
        int geniusProgressViewHeightAndMargin = LocalDisplay.dp2px(24);
        int verticalMargin = 0;
        int leftMargin = 0;
        if (index < LEVEL_COUNT - 1) {
            padding = LocalDisplay.dp2px(20);
            geniusHorizontalProgressView.setVisibility(View.VISIBLE);
            tvGeniusAmount.setVisibility(View.VISIBLE);
        } else {
            //如果是A级芭蕉，由于图片原因，也给padding
            if (dimensionIndex == 1) {
                padding = LocalDisplay.dp2px(8);
                leftMargin = -LocalDisplay.dp2px(6);
            }
            verticalMargin = geniusProgressViewHeightAndMargin / 2;
            geniusHorizontalProgressView.setVisibility(View.GONE);
            tvGeniusAmount.setVisibility(View.GONE);
        }
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) geniusImageView.getLayoutParams();
        params.setMargins(params.leftMargin + leftMargin, params.topMargin + verticalMargin, params.rightMargin, params.bottomMargin + verticalMargin);
        geniusImageView.setPadding(padding, padding, padding, padding);
        int geniusImageId = getGeniusImageId(index);
        geniusImageView.setImageResource(geniusImageId);
    }

    @Override
    public void doInitData() {
        super.doInitData();

//        if(ListenManager.getInstance().isPlaying()) {
//            EventBus.getDefault().post(new MainActivityController.OnHideFloatingWindowEvent());
//            ListenManager.getInstance().pause(true);
//        }
        int levelIndex = 0;
        Intent intent = getIntent();
        if (intent != null) {
            dimensionIndex = intent.getIntExtra(Constants.INTENT_KEY_DIMENSION_INDEX, 0);
            levelIndex = intent.getIntExtra(Constants.INTENT_KEY_LEVEL_INDEX, 0);
            info = (CapabilityModelInfo) intent.getSerializableExtra(Constants.INTENT_KEY_CAPABILITY_MODEL_INFO);
        }
        if (info != null) {
            String dimensionName = info.getDimensionName();
            titleBarView.setTitle(dimensionName);
            dimensionTextView.setText(dimensionName);
            dimensionDetailTextView.setText(info.getDimensionDetail());
            String abilityName = info.getAbilityName();
            if (!TextUtils.isEmpty(abilityName) && abilityName.length() > 3) {
                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) levelTextView.getLayoutParams();
                params.width = LocalDisplay.dp2px(57);
                params.height = LocalDisplay.dp2px(36);
            }
            levelTextView.setText(abilityName);
            Resources resources = KaDaApplication.instance.getResources();
            String[] labelArr = null;
            if (dimensionIndex < GeniusConfig.DIMENSION_LABEL_ID.length) {
                labelArr = resources.getStringArray(GeniusConfig.DIMENSION_LABEL_ID[dimensionIndex]);
            }
            if (labelArr != null && labelArr.length > 0) {
                for (int i = 0; i < labelLayout.getChildCount(); i++) {
                    TextView labelTextView = (TextView) labelLayout.getChildAt(i);
                    if (i < labelArr.length) {
                        labelTextView.setVisibility(View.VISIBLE);
                        labelTextView.setText(labelArr[i]);
                    } else {
                        labelTextView.setVisibility(View.GONE);
                    }
                }
            }
            bookStoryCountTextView.setText(String.format(resources.getString(R.string.book_story_count),
                    String.valueOf(info.getBookCount()), String.valueOf(info.getStoryCount())));
            showGeniusImage(levelIndex);
            GeniusModelInfo geniusInfo = null;
            List<GeniusModelInfo> geniusModelInfoList = info.getGenius();
            if (geniusModelInfoList != null && geniusModelInfoList.size() > 0) {
                geniusInfo = geniusModelInfoList.get(0);
            }
            if (geniusInfo != null) {
                geniusTextView.setText(geniusInfo.getGeniusName());
                geniusDetailTextView.setText(geniusInfo.getGeniusDetail());
            }
            if (levelIndex < LEVEL_COUNT - 1 && geniusInfo != null) {
                if (dimensionIndex < GeniusConfig.GENIUS_PROGRESS_COLOR.length && geniusInfo.getGeniusValue() > 0) {
                    final GeniusModelInfo finalGeniusInfo = geniusInfo;
                    getHandler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            geniusHorizontalProgressView.update(GeniusConfig.GENIUS_PROGRESS_COLOR[dimensionIndex],
                                    finalGeniusInfo.getConsumeValue() / finalGeniusInfo.getGeniusValue());
                        }
                    }, 300);
                    tvGeniusAmount.setText(KaDaApplication.getInstance().getResources().getString(R.string.genius_amount,(int)finalGeniusInfo.getConsumeValue(),(int)finalGeniusInfo.getGeniusValue()));
                }
            }
            for (int i = 0; i < geniusLayout.getChildCount(); i++) {
                ImageView geniusImageView = (ImageView) geniusLayout.getChildAt(i);
                int geniusImageId = getGeniusImageId(i);
                if (dimensionIndex == 1 && i == geniusLayout.getChildCount() - 1) {
                    int padding = LocalDisplay.dp2px(2);
                    geniusImageView.setPadding(padding, padding, padding, padding);
                }
                geniusImageView.setImageResource(geniusImageId);
            }
        }
        playGeniusRaw(levelIndex);
    }

    /**
     * 获取精灵图片id
     *
     * @param levelIndex
     * @return
     */
    private int getGeniusImageId(int levelIndex) {
        int geniusImageId = KaDaApplication.instance.getResources().getIdentifier(
                GeniusConfig.GENIUS_IMAGE_ID_NAME[dimensionIndex] + levelIndex,
                "drawable", KaDaApplication.instance.getPackageName());
        return geniusImageId;
    }

    /**
     * 获取音频id
     *
     * @return
     */
    private int getGeniusRawId(CapabilityModelInfo info, int levelIndex) {
        if (info == null) {
            return 0;
        }
        int rawId = 0;
        switch (info.getDimensionId()) {
            case UserInfoTreeView.DIMENSION_ID_0:
                rawId = GeniusConfig.APPLE_VIDEO_ARR[levelIndex];
                break;
            case UserInfoTreeView.DIMENSION_ID_1:
                rawId = GeniusConfig.BANANA_VIDEO_ARR[levelIndex];
                break;
            case UserInfoTreeView.DIMENSION_ID_2:
                rawId = GeniusConfig.PITAYA_VIDEO_ARR[levelIndex];
                break;
            case UserInfoTreeView.DIMENSION_ID_3:
                rawId = GeniusConfig.CARAMBOLA_VIDEO_ARR[levelIndex];
                break;
            case UserInfoTreeView.DIMENSION_ID_4:
                rawId = GeniusConfig.PEACH_VIDEO_ARR[levelIndex];
                break;
            default:
                break;
        }
        return rawId;
    }

    /**
     * 播放指定等级精灵音频
     *
     * @param levelIndex
     */
    private void playGeniusRaw(int levelIndex) {

        int geniusRawId = getGeniusRawId(info, levelIndex);
        if (geniusRawId > 0) {

            isNeedContinuePlayListen = ListenManager.getInstance().isPlayingOrPromptAudioPlaying();
            if (isNeedContinuePlayListen) {
                ListenManager.getInstance().setPausedByShortAudio(true);
                ListenManager.getInstance().pause(false);
            }

            mShortMediaPlayer.addPlayQueue(geniusRawId, PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.GENIUS_AUDIO);
        }
    }

    /**
     * 取消音频播放
     */
    private void releaseMediaPlayer() {
        if (mShortMediaPlayer != null) {

            List<AudioInfo> audioInfos = mShortMediaPlayer.getCurrentPlayAudio();
            if (!audioInfos.isEmpty()) {
                for (AudioInfo audioInfo : audioInfos) {
                    mShortMediaPlayer.stop(audioInfo.mPlayMode, audioInfo.mAudioTag);
                }
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (info != null) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getDimensionId()),
                    "dimension_detail_view", TimeUtil.currentTime()));
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        releaseMediaPlayer();
    }

    @Override
    protected void onDestroy() {
        getHandler().removeCallbacksAndMessages(null);
        super.onDestroy();

        releaseMediaPlayer();

        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.removeOnPlayListener(mOnPlayListener);
        }
    }

    private OnPlayListener mOnPlayListener = new OnPlayListener() {
        @Override
        public void onPrepared(String audioTag, int playMode) {

        }

        @Override
        public void onCompletion(String audioTag, int playMode) {
            if (AudioName.GENIUS_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onError(String audioTag, int playMode) {
            if (AudioName.GENIUS_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onStop(String audioTag, int playMode) {
            if (AudioName.GENIUS_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }
    };

    private void continuePlayListen() {
        if (isNeedContinuePlayListen || ListenManager.getInstance().isPausedByShortAudio()) {
            isNeedContinuePlayListen = false;

            ListenManager.getInstance().setPause(false);
            ListenManager.getInstance().play();
        }
    }

}
