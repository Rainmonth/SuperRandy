//package com.hhdd.kada.main.ui.activity;
//
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//import android.support.v4.app.Fragment;
//import android.support.v4.app.FragmentManager;
//import android.support.v4.app.FragmentPagerAdapter;
//import android.support.v4.view.ViewPager;
//import android.text.Editable;
//import android.text.TextUtils;
//import android.text.TextWatcher;
//import android.view.KeyEvent;
//import android.view.MotionEvent;
//import android.view.View;
//import android.view.ViewGroup;
//import android.view.inputmethod.EditorInfo;
//import android.widget.AdapterView;
//import android.widget.EditText;
//import android.widget.FrameLayout;
//import android.widget.ImageView;
//import android.widget.ListView;
//import android.widget.TextView;
//
//import com.hhdd.android.common.ServiceProxyFactory;
//import com.hhdd.android.ref.StrongReference;
//import com.hhdd.android.thread.IThread;
//import com.hhdd.core.service.DefaultCallback;
//import com.hhdd.core.service.UserHabitService;
//import com.hhdd.kada.KaDaApplication;
//import com.hhdd.kada.R;
//import com.hhdd.kada.android.library.utils.LocalDisplay;
//import com.hhdd.kada.api.PaginationData;
//import com.hhdd.kada.api.SearchAPI;
//import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
//import com.hhdd.kada.base.BaseFragmentActivity;
//import com.hhdd.kada.main.model.OrganizationInfo;
//import com.hhdd.kada.main.model.SearchBookResultInfo;
//import com.hhdd.kada.main.model.SearchStoryResultInfo;
//import com.hhdd.kada.main.ui.adapter.MyBaseAdapter;
//import com.hhdd.kada.main.ui.search.SearchDirs;
//import com.hhdd.kada.main.ui.search.SearchPageFragment;
//import com.hhdd.kada.main.ui.search.SearchResultActivity;
//import com.hhdd.kada.main.ui.viewholder.BaseViewHolder;
//import com.hhdd.kada.main.utils.FileUtils;
//import com.hhdd.kada.main.utils.StringUtil;
//import com.hhdd.kada.main.utils.TimeUtil;
//import com.hhdd.kada.main.views.magicindicator.ScaleTransitionPagerTitleView;
//import com.hhdd.kada.main.vo.BaseModelVO;
//
//import net.lucode.hackware.magicindicator.MagicIndicator;
//import net.lucode.hackware.magicindicator.ViewPagerHelper;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
//import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;
//
//import butterknife.BindView;
//import butterknife.OnClick;
//
//
///**
// * Created by sxh on 2017/7/24.
// * 最新的搜索activity
// */
//
//public class SearchActivity extends BaseFragmentActivity {
//
//    public static final int SEARCH_STORY = 1;    //搜索听书
//    public static final int SEARCH_BOOK = 2;    //搜索绘本
//    public static final int SEARCH_ALL = 3;    //搜索全部（包括绘本、听书）
//
//    public static final String[] tabTitles = {"绘本", "听书"};
//    public static final List<String> titleList = Arrays.asList(tabTitles);
//
//
//    private boolean isUserEdit = true;  //是否用户手动输入
//
//    @BindView(R.id.back)
//    ImageView back;
//    @BindView(R.id.search_text)
//    EditText mSearchText;
//    @BindView(R.id.explore_titlebar_search_icon)
//    ImageView exploreTitlebarSearchIcon;
//    @BindView(R.id.clear_text)
//    ImageView btnClearText;
//    @BindView(R.id.search_btn)
//    TextView searchBtn;
//    @BindView(R.id.vp_search)
//    ViewPager vpSearch;
//    @BindView(R.id.listview)
//    ListView listview;
//    @BindView(R.id.associate_container)
//    FrameLayout mListViewContainer;
//    @BindView(R.id.indicator_search)
//    MagicIndicator indicatorSearch;
//    @BindView(R.id.statusView)
//    View statusView;
//
//    public static final String SEARCH_TYPR = "searchFromType";
//    private SearchPageFragment mBookFg, mStoryFg;
//    private int mSearchType;
//    private List<SearchBookResultInfo> bookResultInfoList;
//    private List<SearchStoryResultInfo> storyResultInfoList;
//
//    private List<SearchPageFragment> mFragmentList = new ArrayList<>();
//    private HintListAdapter hintListAdapter;
//    private List<String> stringList;
//
//    private StrongReference<DefaultCallback> bookStrongReference;
//    private StrongReference<DefaultCallback> storyStrongReference;
//    private StrongReference<DefaultCallback> cpStrongReference;
//
//    private boolean mRelatedSearch = true;  //是否需要触发关联搜索
//
//
//    public static void startActivity(Context context, int type) {
//        if (context == null) {
//            return;
//        }
//
//        Intent intent = new Intent(context, SearchActivity.class);
//        intent.putExtra(SEARCH_TYPR, type);
//        context.startActivity(intent);
//    }
//
//    public void setUserEdit(boolean userEdit) {
//        isUserEdit = userEdit;
//    }
//
//    @OnClick(R.id.back)
//    public void back() {
//        hideKeyBoard();
//        finish();
//    }
//
//    @Override
//    public int getLayoutId() {
//        return R.layout.layout_search_activity;
//    }
//
//    @Override
//    protected int getFragmentContainerId() {
//        return 0;
//    }
//
//    @Override
//    public void doInitView() {
//
//        this.mSearchType = getIntent().getIntExtra(SEARCH_TYPR, SEARCH_ALL);
//        mBookFg = new SearchPageFragment();
//        Bundle bundle1 = new Bundle();
//        bundle1.putInt(SEARCH_TYPR, SEARCH_BOOK);
//        mBookFg.setArguments(bundle1);
//
//        mStoryFg = new SearchPageFragment();
//        Bundle bundle2 = new Bundle();
//        bundle2.putInt(SEARCH_TYPR, SEARCH_STORY);
//        mStoryFg.setArguments(bundle2);
//
//        mFragmentList.add(mBookFg);
//        mFragmentList.add(mStoryFg);
//
//        initMagicIndicator();
//        vpSearch.setOffscreenPageLimit(mFragmentList.size() - 1);
//        vpSearch.setAdapter(new FragmentAdapter(getSupportFragmentManager(), mFragmentList));
//
//        ViewGroup.LayoutParams statusViewLayoutParams = statusView.getLayoutParams();
//        if (statusViewLayoutParams == null) {
//            statusViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        }
//        statusViewLayoutParams.height = LocalDisplay.SCREEN_STATUS_HEIGHT;
//        statusView.setLayoutParams(statusViewLayoutParams);
//    }
//
//    @Override
//    public void doInitData() {
//        loadCPListData();
//        hintListAdapter = new HintListAdapter(this);
//        listview.setAdapter(hintListAdapter);
//        switch (mSearchType) {
//            case SEARCH_BOOK:
//                vpSearch.setCurrentItem(0);
//                break;
//            case SEARCH_STORY:
//                vpSearch.setCurrentItem(1);
//                break;
//        }
//    }
//
//    @Override
//    public void doInitListener() {
//        mSearchText.addTextChangedListener(textWatcher);
//
//        mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
//                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
//                    if (!mSearchText.getText().toString().trim().equals("")) {
//                        doSearch(mSearchText.getText().toString().trim(), false);
//                    }
//                }
//                return false;
//            }
//        });
//
//        searchBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                switch (mSearchType) {
//                    case SEARCH_BOOK:
//                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mSearchText.getText().toString(), "search_page_book_search_click", TimeUtil.currentTime()));
//                        break;
//                    case SEARCH_STORY:
//                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mSearchText.getText().toString(), "search_page_story_search_click", TimeUtil.currentTime()));
//                        break;
//                }
//                if (!mSearchText.getText().toString().trim().equals("")) {
//                    doSearch(mSearchText.getText().toString().trim(), false);
//                }
//            }
//        });
//
//        listview.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View v, MotionEvent event) {
//                hideKeyBoard();
//                return false;
//            }
//        });
//
//        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                if (stringList == null || stringList.isEmpty()) {
//                    return;
//                }
//
//                if (position >= stringList.size()) {
//                    return;
//                }
//
//                String key = stringList.get(position);
//
//                if (!TextUtils.isEmpty(key)) {
//                    switch (mSearchType) {
//                        case SEARCH_BOOK:
//                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(key, "search_page_book_popular_recommended", TimeUtil.currentTime()));
//                            break;
//                        case SEARCH_STORY:
//                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(key, "search_page_story_popular_recommended", TimeUtil.currentTime()));
//                            break;
//                    }
//                    doSearch(key, false);
//                }
//            }
//        });
//
//        btnClearText.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
//            @Override
//            public void onNoDoubleClick(View v) {
//                mSearchText.setText("");
//            }
//        });
//        vpSearch.addOnPageChangeListener(pageChangeListener);
//    }
//
//    private ViewPager.OnPageChangeListener pageChangeListener = new ViewPager.OnPageChangeListener() {
//        @Override
//        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//        }
//
//        @Override
//        public void onPageSelected(int position) {
//            switch (position) {
//                case 0:
//                    mSearchType = SEARCH_BOOK;
//                    break;
//                case 1:
//                    mSearchType = SEARCH_STORY;
//                    break;
//            }
//        }
//
//        @Override
//        public void onPageScrollStateChanged(int state) {
//
//        }
//    };
//
//    private TextWatcher textWatcher = new TextWatcher() {
//        @Override
//        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//
//        }
//
//        @Override
//        public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
//            if (charSequence.length() > 0 && mRelatedSearch) {
//                if (isUserEdit) {
//                    if (mSearchText.getText().toString().trim().equals("") || mSearchText.getText().length() == 0) {
//                        mListViewContainer.setVisibility(View.GONE);
//                        btnClearText.setVisibility(View.GONE);
//                        hintListAdapter.clear();
//                        hintListAdapter.notifyDataSetChanged();
//                    } else {
//                        mListViewContainer.setVisibility(View.VISIBLE);
//                        btnClearText.setVisibility(View.VISIBLE);
//                        switch (mSearchType) {
//                            case SEARCH_ALL:
//                                loadBookData(charSequence.toString().trim());
//                                loadStoryData(charSequence.toString().trim());
//                                break;
//                            case SEARCH_BOOK:
//                                loadBookData(charSequence.toString().trim());
//                                break;
//                            case SEARCH_STORY:
//                                loadStoryData(charSequence.toString().trim());
//                                break;
//                        }
//                    }
//                }
//            }
//            mRelatedSearch = true;
//        }
//
//        @Override
//        public void afterTextChanged(Editable s) {
//
//        }
//    };
//
//    private void initMagicIndicator() {
//        CommonNavigator commonNavigator = new CommonNavigator(this);
//        commonNavigator.setAdjustMode(true);
//        commonNavigator.setAdapter(new CommonNavigatorAdapter() {
//            @Override
//            public int getCount() {
//                return titleList == null ? 0 : titleList.size();
//            }
//
//            @Override
//            public IPagerTitleView getTitleView(Context context, final int index) {
//                SimplePagerTitleView simplePagerTitleView = new ScaleTransitionPagerTitleView(context);
//                simplePagerTitleView.setText(titleList.get(index));
//                simplePagerTitleView.setTextSize(16);
//                simplePagerTitleView.setNormalColor(getResources().getColor(R.color.book_info_title));
//                simplePagerTitleView.setSelectedColor(getResources().getColor(R.color.mother_tab_text_selected_color));
//                simplePagerTitleView.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        if (index == 0) {
//                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "search_page_book_tab_click", TimeUtil.currentTime()));
//                        } else if (index == 1) {
//                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "search_page_story_tab_click", TimeUtil.currentTime()));
//                        } else if (index == 2) {
//                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "search_page_goods_tab_click", TimeUtil.currentTime()));
//                        }
//                        vpSearch.setCurrentItem(index);
//                    }
//                });
//                return simplePagerTitleView;
//            }
//
//            @Override
//            public IPagerIndicator getIndicator(Context context) {
//                LinePagerIndicator indicator = new LinePagerIndicator(context);
//                indicator.setColors(KaDaApplication.getInstance().getResources().getColor(R.color.mother_tab_text_selected_color));
//                return indicator;
//            }
//        });
//        indicatorSearch.setNavigator(commonNavigator);
//        ViewPagerHelper.bind(indicatorSearch, vpSearch);
//    }
//
//    void loadBookData(final String searchText) {
//        if (searchText.equals("")) {
//            return;
//        }
//        if (bookStrongReference == null) {
//            bookStrongReference = new StrongReference<>();
//        }
//        DefaultCallback bookCallback = new DefaultCallback<List<SearchBookResultInfo>>() {
//            @Override
//            public void onDataReceived(List<SearchBookResultInfo> data) {
//                if (data != null && data.size() > 0) {
//                    bookResultInfoList = new ArrayList<>();
//                    bookResultInfoList.addAll(data);
//                } else {
//                    bookResultInfoList = null;
//                }
//                loadSuccess();
//            }
//
//            @Override
//            public void onException(int code, String reason) {
//                super.onException(code, reason);
//                loadSuccess();
//            }
//        };
//        bookStrongReference.set(bookCallback);
//        SearchAPI.bookAPI_search(searchText, 0, 3, 0, bookStrongReference);
//    }
//
//    void loadStoryData(String searchText) {
//        if (searchText.equals("")) {
//            return;
//        }
//        if (storyStrongReference == null) {
//            storyStrongReference = new StrongReference<>();
//        }
//        DefaultCallback<List<SearchStoryResultInfo>> storyCallback = new DefaultCallback<List<SearchStoryResultInfo>>() {
//            @Override
//            public void onDataReceived(List<SearchStoryResultInfo> data) {
//                if (data != null && data.size() > 0) {
//                    storyResultInfoList = new ArrayList<>();
//                    storyResultInfoList.addAll(data);
//                } else {
//                    storyResultInfoList = null;
//                }
//                loadSuccess();
//            }
//
//            @Override
//            public void onException(int code, String reason) {
//                super.onException(code, reason);
//                loadSuccess();
//            }
//        };
//        storyStrongReference.set(storyCallback);
//        SearchAPI.storyAPI_search(searchText, 0, 3, 0, storyStrongReference);
//    }
//
//
//    void loadSuccess() {
//        stringList = new ArrayList<String>();
//        if (mSearchType == SEARCH_BOOK) {
//            if (bookResultInfoList != null && bookResultInfoList.size() > 0) {
//                for (int i = 0; i < bookResultInfoList.size(); i++) {
//                    if (bookResultInfoList.get(i) != null) {
//                        stringList.add(bookResultInfoList.get(i).getName());
//                    }
//                }
//            }
//        } else if (mSearchType == SEARCH_STORY) {
//            if (storyResultInfoList != null && storyResultInfoList.size() > 0) {
//                for (int i = 0; i < storyResultInfoList.size(); i++) {
//                    if (storyResultInfoList.get(i) != null) {
//                        stringList.add(storyResultInfoList.get(i).getName());
//                    }
//                }
//            }
//        }
//        runOnUiThread(new Runnable() {
//            @Override
//            public void run() {
//                hintListAdapter.clear();
//                hintListAdapter.addAll(stringList);
//                hintListAdapter.notifyDataSetChanged();
//            }
//        });
//
//    }
//
//    /**
//     * 搜索
//     *
//     * @param searchText    搜索关键字
//     * @param relatedSearch 是否需要关联搜索
//     */
//    public void doSearch(final String searchText, boolean relatedSearch) {
//        mRelatedSearch = relatedSearch;
//        mSearchText.setText(searchText);
//        if (!StringUtil.isEmpty(searchText)) {
//            mSearchText.setSelection(searchText.length());
//        }
//        SearchResultActivity.startActivity(this, mSearchType, searchText);
//        isUserEdit = true;
//
//        Runnable runnable = new Runnable() {
//            @Override
//            public void run() {
//                //历史搜索数据存储
//                if (FileUtils.fileExist(SearchDirs.searchHistoryFilePath(mSearchType))) {
//                    String text = FileUtils.readStringFromFile(SearchDirs.searchHistoryFilePath(mSearchType));
//                    if (!text.contains(searchText)) {
//                        if (text.length() > 0) {
//                            text = searchText + "," + text;
//                        } else {
//                            text = searchText;
//                        }
//                        if (text.split(",").length > 10) {
//                            text = text.substring(0, text.lastIndexOf(","));
//                        }
//                        FileUtils.saveStringToFile(text, SearchDirs.searchHistoryFilePath(mSearchType));
//                    } else {
//                        StringBuffer sb = new StringBuffer();
//                        List<String> list = new ArrayList<String>();
//                        String[] array = text.split(",");
//                        for (String str : array) {
//                            list.add(str);
//                        }
//                        list.remove(searchText);
//                        list.add(0, searchText);
//                        for (int i = 0; i < list.size(); i++) {
//                            if (i != 0) {
//                                sb.append(",");
//                            }
//                            sb.append(list.get(i));
//                        }
//                        FileUtils.saveStringToFile(sb.toString(), SearchDirs.searchHistoryFilePath(mSearchType));
//                    }
//                } else {
//                    FileUtils.saveStringToFile(searchText, SearchDirs.searchHistoryFilePath(mSearchType));
//                }
//                //UI更新
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        switch (mSearchType) {
//                            case SEARCH_BOOK:
//                                if (mBookFg.getActivity() != null) {
//                                    mBookFg.refreshHistoryList(searchText);
//                                }
//                                break;
//                            case SEARCH_STORY:
//                                if (mStoryFg.getActivity() != null) {
//                                    mStoryFg.refreshHistoryList(searchText);
//                                }
//                                break;
//                        }
//                    }
//                });
//            }
//        };
//        ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE)).postDaemonTask(runnable, "saveSearchHistory");
//    }
//
//    //咔哒伙伴
//    void loadCPListData() {
//        if (cpStrongReference == null) {
//            cpStrongReference = new StrongReference<>();
//        }
//        DefaultCallback cpDefaultCallback = new DefaultCallback<PaginationData<OrganizationInfo>>() {
//
//            @Override
//            public void onLoadFromCache(PaginationData<OrganizationInfo> cacheData) {
//                super.onLoadFromCache(cacheData);
//                if (cacheData != null && cacheData.getList() != null && cacheData.getList().size() > 0) {
//                    handlerSuccess(cacheData);
//                }
//            }
//
//            @Override
//            public void onDataReceived(PaginationData<OrganizationInfo> data) {
//                if (data != null && data.getList() != null && data.getList().size() > 0) {
//                    handlerSuccess(data);
//                }
//            }
//
//            @Override
//            public void onException(int code, String reason) {
//                super.onException(code, reason);
//            }
//        };
//        cpStrongReference.set(cpDefaultCallback);
//        SearchAPI.getCPListData(cpStrongReference);
//    }
//
//    private void handlerSuccess(PaginationData<OrganizationInfo> cachedData) {
//        final List<BaseModelVO> cpDataList = new ArrayList<>();
//        int cachedDataSize = cachedData.getList().size();
//        for (int i = 0; i < cachedDataSize; i++) {
//            OrganizationInfo info = cachedData.getList().get(i);
//            BaseModelVO vo = new BaseModelVO();
//            vo.setModel(info);
//            cpDataList.add(vo);
//        }
//
//        getHandler().post(new Runnable() {
//            @Override
//            public void run() {
//                int size = mFragmentList.size();
//                for (int i = 0; i < size; i++) {
//                    mFragmentList.get(i).refreshCP(cpDataList);
//                }
//            }
//        });
//    }
//
//    public static class FragmentAdapter extends FragmentPagerAdapter {
//
//        private List<SearchPageFragment> fragmentList;
//
//        public FragmentAdapter(FragmentManager fm, List<SearchPageFragment> fragmentList) {
//            super(fm);
//            this.fragmentList = fragmentList;
//        }
//
//        @Override
//        public Fragment getItem(int position) {
//            return fragmentList.get(position);
//        }
//
//        @Override
//        public int getCount() {
//            return fragmentList.size();
//        }
//    }
//
//    public static class HintListAdapter extends MyBaseAdapter<String> {
//
//
//        public HintListAdapter(Context context) {
//            super(context);
//        }
//
//        @Override
//        public View getView(int position, View convertView, ViewGroup parent) {
//            if (convertView == null) {
//                convertView = View.inflate(mContext, R.layout.hint_list_item_layout, null);
//            }
//
//            TextView hint = BaseViewHolder.getChildView(convertView, R.id.hint_text);
//            if (hint != null) {
//                hint.setText(mItems.get(position));
//            }
//            return convertView;
//        }
//    }
//
//    @Override
//    protected void onDestroy() {
//        if (textWatcher != null && mSearchText != null) {
//            mSearchText.removeTextChangedListener(textWatcher);
//        }
//
//        if (pageChangeListener != null && vpSearch != null) {
//            vpSearch.removeOnPageChangeListener(pageChangeListener);
//        }
//
//        if (bookStrongReference != null) {
//            bookStrongReference.clear();
//            bookStrongReference = null;
//        }
//        if (storyStrongReference != null) {
//            storyStrongReference.clear();
//            storyStrongReference = null;
//        }
//        if (cpStrongReference != null) {
//            cpStrongReference.clear();
//            cpStrongReference = null;
//        }
//
//        super.onDestroy();
//    }
//}
