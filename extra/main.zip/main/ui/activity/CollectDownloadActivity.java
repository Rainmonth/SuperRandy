package com.hhdd.kada.main.ui.activity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.base.BaseFragmentActivity;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.ui.adapter.FragmentAdapter;
import com.hhdd.kada.main.views.CommonHeaderView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/26
 * @describe : com.hhdd.kada.main.ui.activity
 */
public abstract class CollectDownloadActivity extends BaseFragmentActivity {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.tabLayout)
    LinearLayout tabLayout;
    @BindView(R.id.viewPager)
    ViewPager viewPager;
    protected LinearLayout container;
    protected TextView editTextView;
    protected List<Fragment> fragments = new ArrayList<>();
    @BindView(R.id.statusView)
    View mStatusView;

    @Override
    public int getLayoutId() {
        return R.layout.activity_collect_download;
    }

    @Override
    protected int getFragmentContainerId() {
        return 0;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        initTitleBar();
        initFragments();
        viewPager.setAdapter(new FragmentAdapter(getSupportFragmentManager(), fragments));

        int type = getIntent().getIntExtra("type", CommonHeaderView.TYPE_BOOK);
        if (type >= 2) {
            type = 0;
        }
        doPageSelected(type);
        viewPager.setCurrentItem(type);
    }

    protected void initTitleBar() {
        container = new LinearLayout(this);
        container.setOrientation(LinearLayout.HORIZONTAL);
        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
        params.addRule(RelativeLayout.CENTER_VERTICAL);
        container.setLayoutParams(params);

        addClearImageView();

        editTextView = new TextView(this);
        editTextView.setText(R.string.manage);
        editTextView.setGravity(Gravity.CENTER);
        editTextView.setBackgroundResource(R.drawable.bg_collect_manage);
        editTextView.setPadding(LocalDisplay.dp2px(10), LocalDisplay.dp2px(3), LocalDisplay.dp2px(10), LocalDisplay.dp2px(3));
        editTextView.setTextColor(Color.WHITE);
        editTextView.setTextSize(TypedValue.COMPLEX_UNIT_PX, LocalDisplay.dp2px(14));
        LinearLayout.LayoutParams tbParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tbParams.gravity = Gravity.CENTER;
        tbParams.rightMargin = LocalDisplay.dp2px(8);
        tbParams.leftMargin = LocalDisplay.dp2px(8);
        container.addView(editTextView, tbParams);
        editTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doEdit();
            }
        });

        titleBarView.addView(container);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams statusViewLayoutParams = mStatusView.getLayoutParams();
            if (statusViewLayoutParams == null) {
                statusViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            statusViewLayoutParams.height = LocalDisplay.SCREEN_STATUS_HEIGHT;
            mStatusView.setLayoutParams(statusViewLayoutParams);
        }else {
            mStatusView.setVisibility(View.GONE);
        }

    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                updateEditTextView(position);
                doPageSelected(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        titleBarView.setLeftOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                finish();
            }
        });
    }

    @OnClick({R.id.bookTabTextView, R.id.storyTabTextView})
    void onClick(View view) {
        viewPager.setCurrentItem(tabLayout.indexOfChild(view));
        doTabClick(view);
    }

    private void doPageSelected(int position) {
        for (int i = 0; i < tabLayout.getChildCount(); i++) {
            tabLayout.getChildAt(i).setSelected(i == position);
        }
    }

    protected void addClearImageView() {

    }

    protected abstract void initFragments();

    protected abstract void doEdit();

    protected abstract void updateEditTextView(int position);

    protected abstract void doTabClick(View view);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // TODO: add setContentView(...) invocation
        ButterKnife.bind(this);
    }
}
