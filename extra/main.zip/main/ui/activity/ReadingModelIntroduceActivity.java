package com.hhdd.kada.main.ui.activity;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.api.API;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.umeng.socialize.bean.SHARE_MEDIA;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/21
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class ReadingModelIntroduceActivity extends BaseTitleWebViewActivity {

    @Override
    public void doInitView() {
        super.doInitView();
        loadUrl();
    }

    @Override
    protected void loadUrl() {
        if (!NetworkUtils.isReachable()) {
            showError();
            return;
        }
        if(contentWebView != null) {
            contentWebView.loadUrl(API.READING_MODEL_URL());
        }
    }

    @Override
    protected void doShareHabit() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "education_mode_introduction_share_click", TimeUtil.currentTime()));
    }

    @Override
    protected void doShareHabitSuccess(SHARE_MEDIA share_media) {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "education_mode_introduction_share_success", TimeUtil.currentTime()));
    }
}
