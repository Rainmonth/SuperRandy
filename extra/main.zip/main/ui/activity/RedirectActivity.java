package com.hhdd.kada.main.ui.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.CoinService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.R;
import com.hhdd.kada.URLScheme;
import com.hhdd.kada.api.API;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.coin.CoinMedalFragment;
import com.hhdd.kada.coin.TaskFragment;
import com.hhdd.kada.jsbridge.LoginModel;
import com.hhdd.kada.main.common.FragParamData;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.UpdateMainTabEvent;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.ui.book.BookCollectionCategoryFragment;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.ui.book.BookCollectionListFragment;
import com.hhdd.kada.main.ui.book.BookCollectionPayListFragment;
import com.hhdd.kada.main.ui.book.CartoonListFragment;
import com.hhdd.kada.main.ui.dialog.FunctionDescribeDialog;
import com.hhdd.kada.main.ui.fragment.BindingPhoneFragment;
import com.hhdd.kada.main.ui.fragment.MotherBookFragment;
import com.hhdd.kada.main.ui.fragment.PayExcellentMoreFragment;
import com.hhdd.kada.main.ui.fragment.ServiceConfigFragment;
import com.hhdd.kada.main.ui.story.MotherStoryFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionCategoryFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionListFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionPayListFragment;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.talentplan.TalentPlanUtils;
import com.hhdd.kada.module.talentplan.playback.TalentPlanPlaybackActivity;
import com.hhdd.kada.organization.AnchorListFragment;
import com.hhdd.kada.organization.BookIPHomeFragment;
import com.hhdd.kada.organization.BookIPListFragment;
import com.hhdd.kada.organization.OrgHomeFragment;
import com.hhdd.kada.record.RecordFragment;
import com.hhdd.kada.video.CategoryInfo;
import com.hhdd.kada.video.VideoCateListFragment;
import com.hhdd.kada.video.VideoFragment;
import com.hhdd.kada.video.VideoPlayActivity;
import com.hhdd.logger.LogHelper;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import com.hhdd.kada.store.ui.StoreListFragment;

/**
 * Created by simon on 16/6/15.
 */
public class RedirectActivity extends BaseActivity {

    public static final String KEY_SCHEME_HTTP = "http";
    public static final String KEY_SCHEME_KADA = "kada";

    private static final String KEY_REDIRECT_INFO = "redirectInfo";
    private static final String KEY_NOW_URL = "nowUrl";
    private static final String KEY_HTML5 = "html5";
    private static final String KEY_URL = "url";
    private static final String KEY_BOOK = "book";
    private static final String KEY_STORY = "story";
    private static final String KEY_MARK = "?";

    public static final void startActivity(Context context, String uri) {
        Intent intent = new Intent(context, RedirectActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (uri != null) {
            intent.setData(Uri.parse(uri));
            context.startActivity(intent);
        }
    }

    public static final void startActivity(Context context, RedirectInfo redirectInfo) {
        /**
         * v3.7.0 与产品确定逻辑如下：
         * 1、打点信息不为空，就执行打点
         * 2、由跳转协议是否为空来决定是否要跳转到redirectActivity
         */
        if (redirectInfo != null) {
            if (redirectInfo.getSourceKey() != null
                    && redirectInfo.getSourceKey().length() > 0) {
                RedirectInfo.SourceKeyStatInfo statInfo = RedirectInfo.SourceKeyStatInfo.parse(redirectInfo.getSourceKey());
                if (statInfo != null) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(statInfo.getContent(), statInfo.getName(), TimeUtil.currentTime()));
                }
            }

            if (!TextUtils.isEmpty(redirectInfo.getRedirectUri())) {
                Intent intent = new Intent(context, RedirectActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra(KEY_REDIRECT_INFO, redirectInfo);
                context.startActivity(intent);
            }
        }
    }

    public static final void startActivity(Context context, String uri, String nowUrl) {
        Intent intent = new Intent(context, RedirectActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (uri != null) {
            intent.setData(Uri.parse(uri));
            intent.putExtra(KEY_NOW_URL, nowUrl);
            context.startActivity(intent);
        }
    }

    String nowUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        RedirectInfo redirectInfo = null;
        if (getIntent().getSerializableExtra(KEY_REDIRECT_INFO) != null) {
            redirectInfo = (RedirectInfo) getIntent().getSerializableExtra(KEY_REDIRECT_INFO);
        }

        Uri uri = null;
        Intent intent = getIntent();
        if (intent != null) {
            uri = intent.getData();
            nowUrl = intent.getStringExtra(KEY_NOW_URL);
        }

        if (uri == null) {
            if (redirectInfo != null) {
                String redirectUri = redirectInfo.getRedirectUri();
                String html5 = redirectInfo.getHtml5();
                if (redirectUri != null
                        && redirectUri.length() > 0) {
                    uri = Uri.parse(redirectUri);
                } else if (html5 != null
                        && html5.length() > 0
                        && html5.startsWith(KEY_SCHEME_HTTP)) {
                    uri = Uri.parse(html5);
                }
            }
        }

        if (uri == null) {
            finish();
            return;
        }

        String schema = uri.getScheme();
        if (schema != null && schema.startsWith(KEY_SCHEME_HTTP)) {
            WebViewActivity.startActivity(this, uri.toString());
            finish();
        } else if (schema != null && schema.trim().startsWith(KEY_SCHEME_KADA)) {
            if (!handleRedirectUri(uri)) {
                if (redirectInfo != null) {
                    String html5 = redirectInfo.getHtml5();
                    if (html5 != null && html5.length() > 0 && html5.startsWith(KEY_SCHEME_HTTP)) {
                        WebViewActivity.startActivity(this, redirectInfo.getHtml5());
                        finish();
                    }
                } else if (!TextUtils.isEmpty(uri.getQueryParameter(KEY_HTML5))) {
                    String query = getUriQuery(uri);
                    Map<String, String> map = getQueryMap(query);

                    try {
                        if (map.get(KEY_HTML5) != null) {
                            startUrl(URLDecoder.decode(map.get(KEY_HTML5).trim(), "utf-8"));
                        }
                    } catch (UnsupportedEncodingException e) {
                        LogHelper.printStackTrace(e);
                    }
                    finish();
                } else {
                    if (schema.equals(URLScheme.SCHEMA)) {
                        showRemindUpgradeDialog();
                    } else {
                        finish();
                    }
                }
            } else {
                finish();
            }
        } else {
            finish();
        }
    }

    /**
     * 解决uri.getQuery中含#问题
     *
     * @param uri
     * @return
     */
    @NonNull
    private String getUriQuery(Uri uri) {
        String query = "";
        if (uri.toString().contains(KEY_MARK)) {
            int index = uri.toString().indexOf(KEY_MARK) + 1;
            if (uri.toString().length() > index) {
                query = uri.toString().substring(index);
            }
        }
        return query;
    }

    /**
     * 判断String是否全为数字
     *
     * @param str
     * @return
     */

    static boolean isNumeric(String str) {
        if (str != null && str.length() > 0) {
            for (int i = str.length(); --i >= 0; ) {
                if (!Character.isDigit(str.charAt(i))) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    private boolean handleRedirectUri(Uri uri) {

        boolean handled = false;
        String schema = uri.getScheme();
        if (!TextUtils.isEmpty(schema) && URLScheme.SCHEMA.equals(schema.trim())) {
            String host = uri.getHost();
            String path = uri.getPath();
            String query = getUriQuery(uri);
            if (!TextUtils.isEmpty(host)) {
                host = host.trim();
                //绘本跳转
                if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENBOOK) == 0) {
                    String bookId = uri.getQueryParameter("bookId");
                    String from = uri.getQueryParameter("from");
                    int fromFlag = 0;
                    try {
                        if (!TextUtils.isEmpty(from)) {
                            from = from.trim();
                            fromFlag = Integer.parseInt(from);
                        }
                        if (!TextUtils.isEmpty(bookId)) {
                            bookId = bookId.trim();
                            Integer nBookId = Integer.valueOf(bookId);
                            if (nBookId != null) {
                                startBook(nBookId, fromFlag);
                            }
                        }
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                }
                //绘本分类跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENCATEGORY) == 0 || host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENBOOKCATEGORY) == 0) {
                    String categoryId = uri.getQueryParameter("categoryId");
                    String categoryName = "";
                    //处理title含+问题
                    List<String> titleList = uri.getQueryParameters("title");
                    if (titleList != null && titleList.size() > 0 && !TextUtils.isEmpty(titleList.get(0))) {
                        categoryName = titleList.get(0);
                    }
                    String limitAge = uri.getQueryParameter("limitAge");
                    //分类id为空则为跳转分类列表页
                    if (TextUtils.isEmpty(categoryId)) {
                        FragmentUtil.pushFragment(BookCollectionCategoryFragment.class, null, true);
                    } else if (!TextUtils.isEmpty(limitAge)) {
                        limitAge = limitAge.trim();
                        categoryId = categoryId.trim();
                        if (categoryName == null || categoryName.length() == 0) {
                            categoryName = "";
                        }
                        try {
                            startBookCategory(Integer.parseInt(categoryId), categoryName, limitAge);
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                    handled = true;

                }
                //打开老绘本合辑详情
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENBOOKCOLLECTION) == 0) {
                    String collectionId = uri.getQueryParameter("collectionId");
                    if (!TextUtils.isEmpty(collectionId)) {
                        collectionId = collectionId.trim();
                    }
                    if (isNumeric(collectionId)) {
                        startOldBookCollection(Integer.parseInt(collectionId));
                    }
                    handled = true;
                }
                //打开新绘本合辑
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENBOOKCOLLECTION2) == 0) { // 打开绘本合辑
                    String collectionId = uri.getQueryParameter("collectionId");
                    String model = uri.getQueryParameter("model");
                    try {
                        boolean isFromUser = false;
                        if (!TextUtils.isEmpty(model)) {
                            model = model.trim();
                            if (model.equals("2")) {
                                isFromUser = true;
                            } else if (model.equals("1")) {
                                isFromUser = false;
                            }
                        }
                        if (!TextUtils.isEmpty(collectionId)) {
                            collectionId = collectionId.trim();
                        }
                        if (isNumeric(collectionId)) {
                            startBookCollection(Integer.parseInt(collectionId), isFromUser);
                        }
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                }
                //老听书跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSTORY) == 0) {
                    String storyId = uri.getQueryParameter("storyId");
                    if (storyId != null && storyId.length() > 0) {
                        try {
                            storyId = storyId.trim();
                            Integer nStoryId = Integer.valueOf(storyId);
                            if (nStoryId != 0) {
                                startStory(nStoryId);
                            }
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                    handled = true;
                }
                //新听书跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSTORY2) == 0) {
                    String storyId = uri.getQueryParameter("storyId");
                    if (storyId != null && storyId.length() > 0) {
                        try {
                            storyId = storyId.trim();
                            Integer nStoryId = Integer.valueOf(storyId);
                            if (nStoryId != 0) {
                                startStory(nStoryId);
                            }
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                    handled = true;
                }
                //老听书合辑跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSTORYCOLLECTION) == 0) {
                    String collectionId = uri.getQueryParameter("collectionId");
                    if (collectionId != null && collectionId.length() > 0) {
                        try {
                            collectionId = collectionId.trim();
                            startStoryCollection(Integer.valueOf(collectionId));
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                    handled = true;
                }
                //新听书合辑跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSTORYCOLLECTION2) == 0) { // 打开听书合辑
                    String collectionId = uri.getQueryParameter("collectionId");
                    String model = uri.getQueryParameter("model");
                    if (collectionId != null) {
                        collectionId = collectionId.trim();
                        if (isNumeric(collectionId)) {
                            if (StringUtil.isEmpty(model) || model.equals("1")) { // 普通样式
                                try {
                                    FragmentUtil.presentFragment(StoryCollectionFragment.class, Integer.parseInt(collectionId), true);
                                } catch (NumberFormatException e) {
                                    LogHelper.printStackTrace(e);
                                }
                            } else if (model.equals("2")) { // 内置合辑样式
                                try {
                                    FragmentUtil.presentFragment(StoryCollectionFragment.class, new BaseCollectionFragment.CollectionModel(Integer.parseInt(collectionId), true), true);
                                } catch (NumberFormatException e) {
                                    LogHelper.printStackTrace(e);
                                }
                            }
                        }
                    }
                    handled = true;
                }
                //视频播放跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENVIDEO) == 0) {

                    String videoId = uri.getQueryParameter("videoId");
                    if (!TextUtils.isEmpty(videoId)) {
                        videoId = videoId.trim();
                    }
                    try {
                        if (isNumeric(videoId)) {
                            startVideo(Integer.parseInt(videoId));
                        }
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                }
                //视频列表跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENVIDEOLIST) == 0) {
                    startVideoList();
                    handled = true;
                }
                //视频分类跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENVIDEOCATEGORY) == 0) {
                    String categoryId = uri.getQueryParameter("categoryId");
                    String categoryName = uri.getQueryParameter("title");
                    if (!TextUtils.isEmpty(categoryId) && !TextUtils.isEmpty(categoryName)) {
                        categoryId = categoryName.trim();
                        categoryName = categoryId.trim();
                    }
                    try {
                        if (isNumeric(categoryId)) {
                            startVideoCategory(Integer.parseInt(categoryId), categoryName);
                        }
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                }
                //主播详情页跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENORGHOME) == 0) {
                    String orgId = uri.getQueryParameter("orgId");
                    if (!TextUtils.isEmpty(orgId)) {
                        orgId = orgId.trim();
                    }
                    try {
                        if (isNumeric(orgId)) {
                            startOrgHome(Integer.parseInt(orgId));
                        }
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                }
                //主播列表页跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENORGLIST) == 0) {
                    startOrgList();
                    handled = true;
                }
                //绘本ip详情页跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENBOOKIPHOME) == 0) {
                    String orgId = uri.getQueryParameter("orgId");
                    if (TextUtils.isEmpty(orgId)) {
                        orgId = orgId.trim();
                    }
                    try {
                        if (isNumeric(orgId)) {
                            startBookIPHome(Integer.parseInt(orgId));
                        }
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                }
                //绘本ip列表跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENBOOKIPLIST) == 0) {
                    String orgType = uri.getQueryParameter("orgType");
                    String title = uri.getQueryParameter("title");
                    if (TextUtils.isEmpty(orgType)) {
                        startBookIPList();
                    } else {
                        try {
                            orgType = orgType.trim();
                            FragParamData fragParamData = new FragParamData(0, title, Integer.parseInt(orgType));
                            FragmentUtil.pushFragment(CartoonListFragment.class, fragParamData, true);
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                    handled = true;
                }
                //H5页面跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENURL) == 0) {
                    Map<String, String> map = getQueryMap(query);
                    try {
                        if (map.get(KEY_URL) != null) {
                            startUrl(URLDecoder.decode(map.get(KEY_URL).trim(), "utf-8"));
                            handled = true;
                        }
                    } catch (UnsupportedEncodingException e) {
                        LogHelper.printStackTrace(e);
                    }
                }
                //登录页面跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENLOGIN) == 0) {
                    //如果已登录则不做任何操作
                    if (!UserService.getInstance().isLogining()) {
                        String json = uri.getQueryParameter("json");
                        if (json != null && json.length() > 0) {
                            json = json.trim();
                            Gson gson = new Gson();
                            LoginModel loginModel = gson.fromJson(json, new TypeToken<LoginModel>() {
                            }.getType());
                            if (loginModel != null) {
                                //跳转url对比当前webview url 一致则不跳转
                                String redirectURL = loginModel.getRedirectURL();
                                String message = loginModel.getMessage();
                                if (nowUrl != null && redirectURL != null) {
                                    LoginOrRegisterActivity.startActivity(this, message, "");
                                } else {
                                    LoginOrRegisterActivity.startActivity(this, message, redirectURL);
                                }

                            }
                        } else {
                            LoginOrRegisterActivity.startActivity(this);
                        }
                        overridePendingTransition(R.anim.login_activity_enter, R.anim.login_activity_exit);
                    }
                    handled = true;
                }
                //设置页面跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSETTING) == 0) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "clicknewsetting", TimeUtil.currentTime()));
                    ActivityUtil.next(this, SettingActivity.class);
                    handled = true;
                }
                //订单列表页跳转
//                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENORDERLIST) == 0) {
//                    String index = uri.getQueryParameter("index");
//                    if (!TextUtils.isEmpty(index)) {
//                        index = index.trim();
//                    }
//                    if (isNumeric(index)) {
//                        try {
//                            int i = Integer.parseInt(index);
//                            FragmentUtil.pushFragment(StoreOrderListFragment.class, i, true);
//                        } catch (NumberFormatException e) {
//                            LogHelper.printStackTrace(e);
//                        }
//                    } else {
//                        FragmentUtil.pushFragment(StoreOrderListFragment.class, null, true);
//                    }
//                    handled = true;
//                }
                //地址管理列表页跳转
//                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENMYADDRESS) == 0) {
//                    FragmentUtil.pushFragment(StoreAddressListFragment.class, null, true);
//                    handled = true;
//                }
                //商品详情页跳转
//                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENGOODSDETAIL) == 0) {
//                    String productId = uri.getQueryParameter("productId");
//                    if (!TextUtils.isEmpty(productId)) {
//                        productId = productId.trim();
//                    }
//                    FragmentUtil.pushFragment(StoreDetailFragment.class, productId, true);
//
//                    handled = true;
//                }
                //原发现页跳转（咔哒币页面）
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_DATALIST) == 0) {
                    startDataList(uri.toString());
                    handled = true;
                }
                //商品列表页跳转
//                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENPRODUCTLIST) == 0) {
//                    String tag = uri.getQueryParameter("tag");
//                    String title = uri.getQueryParameter("title");
//                    String key = uri.getQueryParameter("key");
//                    if (!TextUtils.isEmpty(tag)) {
//                        tag = tag.trim();
//                    }
//                    if (!TextUtils.isEmpty(title)) {
//                        title = title.trim();
//                    }
//                    if (!TextUtils.isEmpty(key)) {
//                        key = key.trim();
//                    }
//                    StoreListFragment.ProductListTag productListTag = new StoreListFragment.ProductListTag(tag, title, key);
//                    FragmentUtil.pushFragment(StoreListFragment.class, productListTag, true);
//
//                    handled = true;
//
//                }
                //每日任务跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENTASKLIST) == 0) {
                    FragmentUtil.presentFragment(TaskFragment.class, null, true);
                    handled = true;
                }
                //lost my name 跳转
//                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENLOSTHOME) == 0) {
//                    if (UserService.getInstance().isLogining()) {
//                        FragmentUtil.presentFragment(LostUserInfoFragment.class, null, true);
//                    } else {
//                        LoginOrRegisterActivity.startActivity(this, "", "kada://openlostmynamehome");
//                    }
//                    handled = true;
//                }
                //咔哒币勋章页面跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENCOINHOME) == 0) {
                    FragmentUtil.presentFragment(CoinMedalFragment.class, null, true);
                    handled = true;
                }
                //录音活动页面跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENRECORD) == 0) {
                    String id = uri.getQueryParameter("id");
                    if (UserService.getInstance().isLogining()) {
                        if (!TextUtils.isEmpty(id)) {
                            id = id.trim();
                        }
                        try {
                            if (isNumeric(id)) {
                                FragmentUtil.presentFragment(RecordFragment.class, Integer.parseInt(id), true);
                            }
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    } else {
                        LoginOrRegisterActivity.startActivity(this, "", "kada://openrecord");
                    }
                    handled = true;
                }
                //lost my name 绘本页面跳转
//                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENLOSTBOOK) == 0) {
//                    String bookId = uri.getQueryParameter("bookId");
//                    String productId = uri.getQueryParameter("productId");
//                    String bookDetail = uri.getQueryParameter("bookdetail");
//                    if (!TextUtils.isEmpty(bookId) && !TextUtils.isEmpty(productId) && !TextUtils.isEmpty(bookDetail)) {
//                        bookId = bookId.trim();
//                        productId = productId.trim();
//                        bookDetail = bookDetail.trim();
//                    }
//                    if (isNumeric(bookId) && isNumeric(productId)) {
//                        try {
//                            PlaybackActivity.startActivity(this, Integer.parseInt(bookId), Integer.parseInt(productId), bookDetail);
//                            ((StoreConfigUtil) ServiceProxyFactory.getProxy().getService(ServiceProxyName.STORE_CONFIG_UTIL)).setBookId(Integer.parseInt(bookId));
//                        } catch (NumberFormatException e) {
//                            LogHelper.printStackTrace(e);
//                        }
//                    }
//                    handled = true;
//                }
                //lost my name 购买页跳转
//                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENLOSTBOOKSTORE) == 0) {
//                    String bookId = uri.getQueryParameter("bookId");
//                    String productId = uri.getQueryParameter("productId");
//                    if (!TextUtils.isEmpty(bookId) && !TextUtils.isEmpty(productId)) {
//                        bookId = bookId.trim();
//                        productId = productId.trim();
//                    }
//                    if (isNumeric(bookId) && isNumeric(productId)) {
//                        try {
//                            FragmentUtil.presentFragment(StoreDetailFragment.class, new StoreDetailFragment.LostBabyInfo(productId, true), true);
//                            ((StoreConfigUtil) ServiceProxyFactory.getProxy().getService(ServiceProxyName.STORE_CONFIG_UTIL)).setBookId(Integer.parseInt(bookId));
//                        } catch (NumberFormatException e) {
//                            LogHelper.printStackTrace(e);
//                        }
//                    }
//                    handled = true;
//                }
                //vip充值页面跳转
//                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENVIP) == 0) {
//                    FragmentUtil.presentFragment(VipFragment.class, null, true);
//                    handled = true;
//                }
                //听书分类页跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSTORYCATEGORY) == 0 || host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSTORYCOLLECTIONCATEGORY) == 0) {
                    String categoryId = uri.getQueryParameter("categoryId");
                    String title = uri.getQueryParameter("title");
                    if (!TextUtils.isEmpty(categoryId)) {
                        categoryId = categoryId.trim();
                    }
                    if (isNumeric(categoryId)) {
                        try {
                            StoryCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(StoryCollectionListFragment.COLLECTION_TYPE_CATEGORY, title, Integer.parseInt(categoryId), 0, 0));
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                    handled = true;
                }
                //听书通用列表跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSTORYCOLLECTIONCOMMON) == 0) {
                    String extFlag = uri.getQueryParameter("extFlag");
                    String sortFlag = uri.getQueryParameter("sortFlag");
                    String title = uri.getQueryParameter("title");
                    try {
                        if (!TextUtils.isEmpty(extFlag) && !TextUtils.isEmpty(sortFlag)) {
                            extFlag = extFlag.trim();
                            sortFlag = sortFlag.trim();
                            StoryCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(StoryCollectionListFragment.COLLECTION_TYPE_EXTFLAG_SORTFLAG, title, 0, Integer.parseInt(extFlag), Integer.parseInt(sortFlag)));
                        } else if (!TextUtils.isEmpty(extFlag)) {
                            extFlag = extFlag.trim();
                            StoryCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(StoryCollectionListFragment.COLLECTION_TYPE_EXTFLAG, title, 0, Integer.parseInt(extFlag), 0));
                        } else if (!TextUtils.isEmpty(sortFlag)) {
                            sortFlag = sortFlag.trim();
                            StoryCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(StoryCollectionListFragment.COLLECTION_TYPE_SORTFLAG, title, 0, 0, Integer.parseInt(sortFlag)));
                        }
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                }
                //听书分类页跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENSTORYCATEGORYHOME) == 0) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_home_all_kind_more_click", TimeUtil.currentTime()));
                    FragmentUtil.pushFragment(StoryCollectionCategoryFragment.class, null, true);
                    handled = true;
                }
                //听书付费精品跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENPAYSTORYCOLLECTION) == 0) {
                    String extFlag = uri.getQueryParameter("extFlag");
                    String mTitle = uri.getQueryParameter("title");
                    if (!TextUtils.isEmpty(extFlag)) {
                        extFlag = extFlag.trim();
                    }
                    if (isNumeric(extFlag)) {
                        try {
                            FragParamData fragParamData = new FragParamData(0, mTitle, Integer.parseInt(extFlag));
                            FragmentUtil.pushFragment(StoryCollectionPayListFragment.class, fragParamData, true);
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                    handled = true;
                }
                //妈妈精选更多内容页面跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENEXCELLENTSUBJECT) == 0) {
                    FragmentUtil.pushFragment(PayExcellentMoreFragment.class, uri.toString(), true);
                    handled = true;
                }
                //妈妈精选 功能入口 - 跳转到选绘本
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENEXCELLENTSELECTBOOK) == 0) {
                    FragmentUtil.pushFragment(MotherBookFragment.class, null, true);
                    handled = true;
                }
                //妈妈精选 功能入口 - 跳转到选听书
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENEXCELLENTSELECTSTORY) == 0) {
                    FragmentUtil.pushFragment(MotherStoryFragment.class, null, true);
                    handled = true;
                }

                //绘本通用列表页跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENBOOKCOLLECTIONCOMMON) == 0) {
                    String extFlag = uri.getQueryParameter("extFlag");
                    String sortFlag = uri.getQueryParameter("sortFlag");
                    String title = uri.getQueryParameter("title");

                    try {
                        if (!TextUtils.isEmpty(extFlag) && !TextUtils.isEmpty(sortFlag)) {
                            extFlag = extFlag.trim();
                            sortFlag = sortFlag.trim();
                            BookCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(BookCollectionListFragment.COLLECTION_TYPE_EXTFLAG_SORTFLAG, title, 0, Integer.parseInt(extFlag), Integer.parseInt(sortFlag)));
                        } else if (!TextUtils.isEmpty(extFlag)) {
                            extFlag = extFlag.trim();
                            BookCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(BookCollectionListFragment.COLLECTION_TYPE_EXTFLAG, title, 0, Integer.parseInt(extFlag), 0));
                        } else if (!TextUtils.isEmpty(sortFlag)) {
                            sortFlag = sortFlag.trim();
                            BookCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(BookCollectionListFragment.COLLECTION_TYPE_SORTFLAG, title, 0, 0, Integer.parseInt(sortFlag)));
                        }
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                }
                //绘本付费精品列表页跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENPAYBOOKCOLLECTION) == 0) {
                    String extFlag = uri.getQueryParameter("extFlag");
                    String mTitle = uri.getQueryParameter("title");
                    if (!TextUtils.isEmpty(extFlag)) {
                        extFlag = extFlag.trim();
                    }
                    if (isNumeric(extFlag)) {
                        try {
                            FragParamData fragParamData = new FragParamData(0, mTitle, Integer.parseInt(extFlag));
                            FragmentUtil.pushFragment(BookCollectionPayListFragment.class, fragParamData, true);
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                    handled = true;
                }
                //一级或二级tab跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENCONTROLLER) == 0) {
                    String site = uri.getQueryParameter("site");
                    String seq = uri.getQueryParameter("seq");
                    String[] siteArr = {"mom", "book", "story", "discovery"};
                    String[] seqArr = {"populer", "mombook", "momstory", "mommall"};
                    List<String> siteList = Arrays.asList(siteArr);
                    List<String> seqList = Arrays.asList(seqArr);
                    if (siteList.contains(site)) {
                        int index = siteList.indexOf(site);
                        int childIndex = -1;
                        if (seqList.contains(seq)) {
                            childIndex = seqList.indexOf(seq);
                        }
                        EventCenter.fireEvent(new UpdateMainTabEvent(index, true, childIndex));
                    }
                    handled = true;
                }
                //每日任务内容跳转
                else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENDAILYTASK) == 0) {
                    String type = uri.getQueryParameter("type");
                    String taskId = uri.getQueryParameter("taskId");
                    String sourceId = uri.getQueryParameter("sourceId");
                    if (!TextUtils.isEmpty(type)) {
                        type = type.trim();
                        if (TextUtils.equals(type, KEY_BOOK)) {
                            if (!TextUtils.isEmpty(sourceId)) {
                                sourceId = sourceId.trim();
                                Integer nBookId = Integer.valueOf(sourceId);
                                if (nBookId != null) {
                                    startBook(nBookId, 1);
                                }
                            }
                        } else if (TextUtils.equals(type, KEY_STORY)) {
                            if (!TextUtils.isEmpty(sourceId)) {
                                sourceId = sourceId.trim();
                                Integer nStoryId = Integer.valueOf(sourceId);
                                if (nStoryId != null) {
                                    startStory(nStoryId);
                                }
                            }
                        }
                    }
                    if (!TextUtils.isEmpty(taskId) && !TextUtils.isEmpty(sourceId)) {
                        taskId = taskId.trim();
                        sourceId = sourceId.trim();
                    }
                    if (isNumeric(taskId) && isNumeric(sourceId)) {
                        try {
                            ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).startTask(Integer.valueOf(taskId), Integer.parseInt(sourceId));
                        } catch (NumberFormatException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }

                    handled = true;
                } else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENTALENTPLANBOOK) == 0) {
                    String bookIdStr = uri.getQueryParameter("bookId");
                    String versionStr = uri.getQueryParameter("version");
                    try {
                        int bookId = Integer.parseInt(bookIdStr);
                        int version = Integer.parseInt(versionStr);
                        TalentPlanPlaybackActivity.startActivity(this, bookId, version);
                    } catch (NumberFormatException e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                } else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENTALENTPLAN) == 0) {
                    String showWeek = uri.getQueryParameter("week");
                    ActivityUtil.nextTalentPlanContentActivity(this, showWeek);
                    handled = true;
                } else if (host.compareToIgnoreCase(URLScheme.REDIRECT_OPEN_WEB_URL) == 0) {
                    // 打开外部浏览器
                    try {
                        String url = uri.getQueryParameter("url");
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                        startActivity(intent);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    handled = true;
                } else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPEN_TALENTPLAN_OR_INTRODUCTION) == 0) {
                    TalentPlanUtils.openTalentPlanOrIntroduction();

                    handled = true;
                } else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPEN_COMPLETE_BABY_INFO) == 0) {
                    BabyInfoSettingActivity.startActivity(RedirectActivity.this);
                    handled = true;
                } else if (host.compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPEN_BIND_PHONE) == 0) {
                    FragmentUtil.pushFragment(BindingPhoneFragment.class, null, true);
                    handled = true;
                }
            }
        }
        return handled;

    }

    @NonNull
    private Map<String, String> getQueryMap(String query) {
        String[] querys = query.split("&");
        Map<String, String> map = new HashMap();
        for (int i = 0; i < querys.length; i++) {
            String[] keyValues = querys[i].split("=");
            if (!TextUtils.isEmpty(keyValues[0])) {
                String value = querys[i].substring(keyValues[0].length() + 1, querys[i].length());
                if (!TextUtils.isEmpty(value)) {
                    map.put(keyValues[0], value.trim());
                }
            }
        }
        return map;
    }

    private void showRemindUpgradeDialog() {
        FunctionDescribeDialog updateDialog = new FunctionDescribeDialog.Build()
                .setContext(this)
                .setTitle("升级版本")
                .setContent("需要升级版本才能打开")
                .setButtonImage(R.drawable.icon_update_now)
                .setCallback(new FunctionDescribeDialog.Callback() {
                    @Override
                    public void refresh() {
                        Intent intent = new Intent(Intent.ACTION_VIEW,
                                Uri.parse(API.URL_APP));
                        startActivity(intent);
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "protocol_need_update_software_yes_click", TimeUtil.currentTime()));
                    }
                })
                .create();
        if (!isFinishing()) {
            updateDialog.show();
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "protocol_need_update_software_view", TimeUtil.currentTime()));
        }
        updateDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                finish();
            }
        });
    }

    void startBook(int bookId, int fromFlag) {
        PlaybackActivity.startActivity(this, bookId, fromFlag);
    }

    /**
     * @param collectionId
     * @param isFromUser   表示是否内置合辑样式
     */
    void startBookCollection(int collectionId, boolean isFromUser) {
        FragmentUtil.pushFragment(BookCollectionFragment.class, new BaseCollectionFragment.CollectionModel(collectionId, isFromUser), true);
    }

    void startOldBookCollection(int collectionId) {
        BookCollectionActivity.startActivity(this, collectionId);
    }

    void startBookCategory(int categoryId, String categoryName, String limitAge) {
        if (!TextUtils.isEmpty(limitAge)) {
            if (Integer.parseInt(limitAge) == -1) {
                BookCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(
                        BookCollectionListFragment.COLLECTION_TYPE_CATEGORY, categoryName, categoryId, 0, 0));
            } else {
                try {
                    BookCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(
                            BookCollectionListFragment.COLLECTION_TYPE_LIMITAGE, categoryName, categoryId, 0, 0, limitAge));
                } catch (NumberFormatException e) {
                    LogHelper.printStackTrace(e);
                }
            }
        }
    }

    void startStory(int storyId) {
        ListenActivity.startActivity(this, storyId);
    }

    void startStoryCollection(int id) {
        StoryCollectionActivity.startActivity(this, id);
    }


    void startStoryCategory(int categoryId, String categoryName) {
        //离线下载跳转
//        if (categoryId == -1) {
//            DownloadListFragment.DownloadListVO vo = new DownloadListFragment.DownloadListVO(DownloadListFragment.STORY_TYPE, null);
//            FragmentUtil.pushFragment(DownloadListFragment.class, vo, true);
//        } else {
//            FragmentUtil.pushFragment(CateStoryListFragment.class, new Category(categoryId, categoryName), true);
//        }
    }

    void startVideo(int videoId) {
        VideoPlayActivity.present(videoId);
    }

    void startVideoList() {
        VideoFragment.pushFragment();
    }

    void startVideoCategory(int categoryId, String categoryName) {
        VideoCateListFragment.pushFragment(new CategoryInfo(categoryId, categoryName));
    }

    void startOrgHome(int orgId) {
        OrgHomeFragment.present(orgId);
    }

    void startOrgList() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_home_all_host_more_click", TimeUtil.currentTime()));
        FragmentUtil.presentFragment(AnchorListFragment.class, null, true);
    }

    void startBookIPList() {
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "book_homepage_organization_more_click", TimeUtil.currentTime()));
        FragmentUtil.pushFragment(BookIPListFragment.class, null, true);
    }

    void startBookIPHome(int orgId) {
        BookIPHomeFragment.present(orgId);
    }

    void startUrl(String url) {
        WebViewActivity.startActivity(this, url);
    }

    void startDataList(String url) {
        FragmentUtil.pushFragment(ServiceConfigFragment.class, url, true);
    }
}
