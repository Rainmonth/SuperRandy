package com.hhdd.kada.main.ui.activity;

import android.os.Build;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.TalentPlanAPI;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.event.CloseRecommendSettingPageEvent;
import com.hhdd.kada.main.event.UserSubscribeChangeEvent;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RecommendBookInfo;
import com.hhdd.kada.main.model.RecommendContentInfo;
import com.hhdd.kada.main.model.RecommendStoryInfo;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.adapter.RecommendSubscribeContentAdapter;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.recommend.RecommendBookViewHolder;
import com.hhdd.kada.main.viewholders.recommend.RecommendStoryViewHolder;
import com.hhdd.kada.main.viewholders.recommend.RecommendSubTitleViewHolder;
import com.hhdd.kada.main.viewholders.recommend.RecommendTitleViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.widget.support.KdLinearLayoutManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/23
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class RecommendSubscribeContentActivity extends BaseActivity {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.recyclerView)
    RecyclerView recyclerView;
    @BindView(R.id.addToShelfLayout)
    View addToShelfLayout;
    @BindView(R.id.skipLayout)
    View skipLayout;
    private RecommendSubscribeContentAdapter adapter;
    private List<BaseModel> contentList;
    private StrongReference<DefaultCallback> strongReference;
    private String dimensionIds;

    private static final int VIEW_TYPE_TITLE = 100;
    private static final int VIEW_TYPE_SUB_TITLE = VIEW_TYPE_TITLE + 1;
    private static final int VIEW_TYPE_BOOK = VIEW_TYPE_SUB_TITLE + 1;
    private static final int VIEW_TYPE_STORY = VIEW_TYPE_BOOK + 1;

    @Override
    public int getLayoutId() {
        return R.layout.activity_recommend_subscribe_content;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleBarViewLayoutParams = titleBarView.getLayoutParams();
            if (titleBarViewLayoutParams==null){
                titleBarViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleBarViewLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height)+ LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleBarView.setLayoutParams(titleBarViewLayoutParams);
            titleBarView.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        KaDaApplication.OnClickWithAnimListener onClickListener = new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                        "new_user_recommend_select_collection_submit_click", TimeUtil.currentTime()));
                StringBuilder bookStringBuilder = new StringBuilder();
                StringBuilder storyStringBuilder = new StringBuilder();
                if(contentList != null && contentList.size() > 0) {
                    for (int i = 0; i < contentList.size(); i++) {
                        BaseModel model = contentList.get(i);
                        if(model instanceof RecommendBookInfo) {
                            RecommendBookInfo info = (RecommendBookInfo) model;
                            if(info.isCheck()) {
                                if(bookStringBuilder.length() > 0) {
                                    bookStringBuilder.append(",");
                                }
                                bookStringBuilder.append(info.getSourceId());
                            }
                        } else if(model instanceof RecommendStoryInfo) {
                            RecommendStoryInfo info = (RecommendStoryInfo) model;
                            if(info.isCheck()) {
                                if(storyStringBuilder.length() > 0) {
                                    storyStringBuilder.append(",");
                                }
                                storyStringBuilder.append(info.getSourceId());
                            }
                        }
                    }
                }
                recommendSubscribe(bookStringBuilder.toString(), storyStringBuilder.toString());
            }
        };
        addToShelfLayout.setOnClickListener(onClickListener);
        KaDaApplication.NoDoubleClickListener listener = new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                switch (v.getId()) {
                    case R.id.rl_title_bar_left:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                "new_user_recommend_select_collection_back", TimeUtil.currentTime()));
                        finish();
                        break;
                    case R.id.skipLayout:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                "new_user_recommend_select_collection_skip", TimeUtil.currentTime()));
                        recommendSubscribe("", "");
                        break;
                    default:
                        break;
                }
            }
        };
        titleBarView.setLeftOnClickListener(listener);
        skipLayout.setOnClickListener(listener);
    }

    /**
     * 将推荐订阅加入书架，若点击跳过，则保持所选维度信息。若绘本听书合集均未选择，作跳过处理
     * @param bookIds
     * @param storyIds
     */
    private void recommendSubscribe(final String bookIds, final String storyIds) {
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this);
        DefaultCallback callback = new DefaultCallback<String>() {
            @Override
            public void onDataReceived(String data) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(RecommendSubscribeContentActivity.this);
                        if (!TextUtils.isEmpty(bookIds) || !TextUtils.isEmpty(storyIds)) {
                            EventBus.getDefault().post(new UserSubscribeChangeEvent());
                        }
                        if (!ActivityUtil.isMainActivityLaunch()) {
                            ActivityUtil.next(RecommendSubscribeContentActivity.this, MainActivity.class);
                        }
                        EventBus.getDefault().post(new CloseRecommendSettingPageEvent());
                        finish();
                    }
                });
            }

            @Override
            public void onException(String reason) {
                super.onException(reason);
                customDialogManager.dismissDialog(RecommendSubscribeContentActivity.this);
                if (!ActivityUtil.isMainActivityLaunch()) {
                    ActivityUtil.next(RecommendSubscribeContentActivity.this, MainActivity.class);
                }
                EventBus.getDefault().post(new CloseRecommendSettingPageEvent());
                finish();
            }
        };
        if(strongReference == null) {
            strongReference = new StrongReference<>();
        }
        strongReference.set(callback);
        if (TextUtils.isEmpty(bookIds) && TextUtils.isEmpty(storyIds)) {
            TalentPlanAPI.recommendSubscribeSkip(dimensionIds, strongReference);
        } else {
            TalentPlanAPI.recommendSubscribe(bookIds, storyIds, dimensionIds, strongReference);
        }
    }

    @Override
    public void doInitData() {
        super.doInitData();
        titleBarView.setTitle(getResources().getString(R.string.recommend_content_title));
        contentList = new ArrayList<>();
        adapter = new RecommendSubscribeContentAdapter();
        recyclerView.setLayoutManager(new KdLinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(adapter);
        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(VIEW_TYPE_TITLE, RecommendTitleViewHolder.class);
        viewTypeMaps.put(VIEW_TYPE_SUB_TITLE, RecommendSubTitleViewHolder.class);
        viewTypeMaps.put(VIEW_TYPE_BOOK, RecommendBookViewHolder.class);
        viewTypeMaps.put(VIEW_TYPE_STORY, RecommendStoryViewHolder.class);
        BaseViewHolderCreator viewHolderCreator = new BaseViewHolderCreator(null, viewTypeMaps);
        adapter.setViewHolderCreator(viewHolderCreator);

        dimensionIds = getIntent().getStringExtra(Constants.INTENT_KEY_RECOMMEND_DIMENSION_ID);
        RecommendContentInfo info = (RecommendContentInfo) getIntent().getSerializableExtra(Constants.INTENT_KEY_RECOMMEND_CONTENT_INFO);
        if(info != null) {
            updateList(info);
        }
    }

    /**
     * 更新列表
     * @param info
     */
    private void updateList(RecommendContentInfo info) {
        List<RecommendBookInfo> recommendBookInfoList = info.getBookList();
        List<RecommendStoryInfo> recommendStoryInfoList = info.getStoryList();
        if(recommendBookInfoList != null) {
            contentList.addAll(recommendBookInfoList);
        }
        if(recommendStoryInfoList != null) {
            contentList.addAll(recommendStoryInfoList);
        }

        List<BaseVO> dataList = new ArrayList<>();
        dataList.add(new BaseModelVO(null, VIEW_TYPE_TITLE));
        if(recommendBookInfoList != null && recommendBookInfoList.size() > 0) {
            dataList.add(getSubTitleMode(getResources().getString(R.string.recommend_book_title), R.drawable.icon_book_shelf_title));
            List<BaseVO> dataListTmp = new ArrayList<>();
            List<BaseModel> singleLineTmp = new ArrayList<>();
            for (int i = 0; i < recommendBookInfoList.size(); i++) {
                RecommendBookInfo bookInfo = recommendBookInfoList.get(i);
                bookInfo.setCheck(true);
                bookInfo.setIndex(i);
                singleLineTmp.add(bookInfo);
                if (singleLineTmp.size() >= 3) {
                    addItemModel(dataListTmp, singleLineTmp, VIEW_TYPE_BOOK);
                }
            }

            if(singleLineTmp.size() > 0) {
                addItemModel(dataListTmp, singleLineTmp, VIEW_TYPE_BOOK);
            }
            dataList.addAll(dataListTmp);
        }

        if(recommendStoryInfoList != null && recommendStoryInfoList.size() > 0) {
            dataList.add(getSubTitleMode(getResources().getString(R.string.recommend_story_title), R.drawable.icon_story_collect));
            List<BaseVO> dataListTmp = new ArrayList<>();
            List<BaseModel> singleLineTmp = new ArrayList<>();
            for (int i = 0; i < recommendStoryInfoList.size(); i++) {
                RecommendStoryInfo storyInfo = recommendStoryInfoList.get(i);
                storyInfo.setCheck(true);
                storyInfo.setIndex(i);
                singleLineTmp.add(storyInfo);
                if (singleLineTmp.size() >= 3) {
                    addItemModel(dataListTmp, singleLineTmp, VIEW_TYPE_STORY);
                }
            }

            if(singleLineTmp.size() > 0) {
                addItemModel(dataListTmp, singleLineTmp, VIEW_TYPE_STORY);
            }
            dataList.addAll(dataListTmp);
        }

        adapter.setContentList(dataList);
        adapter.notifyDataSetChanged();
    }

    private BaseModelVO getSubTitleMode(String name, int iconId) {
        BaseModelVO baseVO = new BaseModelVO();
        baseVO.setViewType(VIEW_TYPE_SUB_TITLE);
        RedirectInfo redirectInfo = new RedirectInfo();
        redirectInfo.setTitle(name);
        redirectInfo.setImageUrl("res://" + KaDaApplication.getInstance().getPackageName() + "/" + iconId);
        baseVO.setModel(redirectInfo);
        return baseVO;
    }

    private void addItemModel(List<BaseVO> dataListTmp, List<BaseModel> singleLineTmp, int type) {
        BaseModelListVO vo = new BaseModelListVO(type);
        vo.setItemList(singleLineTmp);
        dataListTmp.add(vo);
        singleLineTmp.clear();
    }

    @Override
    public void onResume() {
        super.onResume();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "new_user_recommend_select_collection_view", TimeUtil.currentTime()));
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                "new_user_recommend_select_collection_back", TimeUtil.currentTime()));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(strongReference != null) {
            strongReference.clear();
            strongReference = null;
        }
        DialogFactory.dismissAllDialog(this);
    }
}
