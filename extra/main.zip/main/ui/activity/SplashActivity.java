package com.hhdd.kada.main.ui.activity;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.DailyUpdateService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.manager.PermissionManager;
import com.hhdd.kada.main.ui.dialog.PermissionDialog;
import com.hhdd.kada.main.ui.fragment.InitFragment;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.SafeHandler;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.audio.AudioName;
import com.hhdd.kada.module.player.AudioFocusLossProcessMode;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnKdAudioFocusChangeListener;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.logger.LogHelper;

import java.io.File;

/**
 * Created by simon on 10/6/15.
 */
public class SplashActivity extends Activity implements ActivityCompat.OnRequestPermissionsResultCallback {

    SafeHandler mHandler;

    private boolean isRequestPermission = false;

    private boolean isSkipToMain = false; //是否跳转到MainActivity
    private boolean isAudioLoss = false;

    private String imageUrl;

    private boolean mPlayCompletionTrackHabit = false;

    private IMediaPlayer mMediaPlayer;

    private OnKdAudioFocusChangeListener mOnKdAudioFocusChangeListener = new OnKdAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            switch (focusChange) {
                case AudioManager.AUDIOFOCUS_LOSS:
                case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                    isAudioLoss = true;
                    break;

                case AudioManager.AUDIOFOCUS_GAIN:
                    isAudioLoss = false;

                    startMain(0);
                    break;

                default:
            }
        }
    };

    private OnPlayListener mOnPlayListener = new OnPlayListener() {
        @Override
        public void onPrepared(String audioTag, int playMode) {

        }

        @Override
        public void onCompletion(String audioTag, int playMode) {
            if (AudioName.APP_START_AUDIO.equals(audioTag)) {
                if (mMediaPlayer != null) {
                    mMediaPlayer.removeOnPlayListener(mOnPlayListener);
                }

                if (mPlayCompletionTrackHabit) {
                    trackSplashHabit(1);
                }

                startMain(0);

            }
        }

        @Override
        public void onError(String audioTag, int playMode) {
            if (AudioName.APP_START_AUDIO.equals(audioTag)) {
                if (mMediaPlayer != null) {
                    mMediaPlayer.removeOnPlayListener(mOnPlayListener);
                }

                if (mPlayCompletionTrackHabit) {
                    trackSplashHabit(1);
                }

                startMain(0);
            }
        }

        @Override
        public void onStop(String audioTag, int playMode) {
            if (AudioName.APP_START_AUDIO.equals(audioTag)) {
                if (mMediaPlayer != null) {
                    mMediaPlayer.removeOnPlayListener(mOnPlayListener);
                }

                if (mPlayCompletionTrackHabit) {
                    trackSplashHabit(1);
                }

                startMain(0);
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);

        ActivityHelper.registerActivity(this);

        mHandler = new SafeHandler();

        mMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
        mMediaPlayer.addOnPlayListener(mOnPlayListener);
        mMediaPlayer.addOnKdAudioFocusChangeListener(mOnKdAudioFocusChangeListener);

        showSplash();
    }


    // 显示闪屏
    private void showSplash() {
        final String adFilePath = DailyUpdateService.getAdFilePath();
        final String dailyFilePath = DailyUpdateService.dailyFilePath();
        if (!FileUtils.fileExist(adFilePath) || !FileUtils.fileExist(dailyFilePath)) {
            playStartMusic();
            return;
        }

        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {

                mPlayCompletionTrackHabit = true;

                ImageView splashImgIv = (ImageView) findViewById(R.id.splash_img);

                try {
                    splashImgIv.setImageURI(Uri.fromFile(new File(adFilePath)));
                } catch (Throwable e) {
                    LogHelper.printStackTrace(e);
                }

                splashImgIv.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
                    @Override
                    public void onNoDoubleClick(View v) {
                        processSplashClicked();
                    }
                });

                playStartMusic();
            }
        }, 500);
    }

    private void processSplashClicked() {
        String redirectUrl = ((DailyUpdateService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DAILY_UPDATE_SERVICE)).getRedirectUrl();

        AuthService authService = (AuthService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.AUTH_SERVICE);
        boolean isAuthorized = authService.isAuthorized();
        // 1、配置了咔哒协议  2、认证成功
        if (!TextUtils.isEmpty(redirectUrl) && isAuthorized && !isSkipToMain) {
            isSkipToMain = true;
            trackSplashHabit(2);
            Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra(Constants.INTENT_KEY_SPLASH_REDIRECT_INFO, redirectUrl);
            ActivityUtil.next(this, intent);
            finish();
        }
    }

    /**
     * 处理splash配置的展示和点击打点
     */
    private void trackSplashHabit(int type) {
        imageUrl = ((DailyUpdateService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DAILY_UPDATE_SERVICE)).getSplashImageUrl();
        if (!TextUtils.isEmpty(imageUrl)) {
            String[] temStr = imageUrl.split("/");
            imageUrl = temStr[temStr.length - 1];
            if (type == 1) {
                //splash展示打点
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(imageUrl, StaPageName.app_splash_view, TimeUtil.currentTime()));
            } else if (type == 2) {
                //splash点击打点
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(imageUrl, StaCtrName.app_splash_click, TimeUtil.currentTime()));
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PermissionManager.PERMISSION_READ_WRITE_EXTERNAL_STORAGE) {
            startMainActivity();
        }
    }

    void playStartMusic() {
        mMediaPlayer.addPlayQueue(R.raw.appstart, PlayMode.IMMEDIATELY_PLAY_MODE, AudioFocusLossProcessMode.RELEASE, AudioName.APP_START_AUDIO);
    }

    private void startMain(int delay) {
        if (delay <= 0) {
            mStartMainRunnable.run();
            return;
        }

        mHandler.postDelayed(mStartMainRunnable, delay);
    }

    private Runnable mStartMainRunnable = new Runnable() {
        @Override
        public void run() {

            File file = null;
            if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
                file = getExternalCacheDir();
            }
            if (file == null || !file.exists() || TextUtils.isEmpty(file.getAbsolutePath())) {//Android/data/package 缓存目录不需要权限申请
                //检查文件读写权限
                if ((ContextCompat.checkSelfPermission(SplashActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) ||
                        (ContextCompat.checkSelfPermission(SplashActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE)
                                != PackageManager.PERMISSION_GRANTED)) {
                    //申请权限
                    ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).requestPermission(SplashActivity.this, PermissionManager.PERMISSION_READ_WRITE_EXTERNAL_STORAGE);
                    ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).setCallBack(new PermissionManager.PermissionDialogCallBack() {
                        @Override
                        public void onRequestPermission() {
                            isRequestPermission = true;
                        }
                    });

                    // 线上环境出现一次dialog为空
                    // https://bugly.qq.com/v2/crash-reporting/crashes/3c90f7f868/18090?pid=1
                    // 这里判断dialog如果是空 则直接 startMainActivity
                    PermissionDialog dialog = ((PermissionManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PERMISSION_MANAGER)).getDialog();
                    if (dialog != null) {
                        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                if (!isRequestPermission) {
                                    startMainActivity();
                                }
                            }
                        });
                    } else {
                        startMainActivity();
                    }
                } else {
                    startMainActivity();
                }
            } else {
                startMainActivity();
            }
        }
    };

    private void startMainActivity() {
        if (isSkipToMain || isAudioLoss) {
            return;
        }
        isSkipToMain = true;

        if (UserService.getInstance().isLogining()
                || ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).getInt(Constants.LAST_LOGIN_WAY) == InitFragment.LAST_LOGIN_WAY_IS_TOURIST
                || !KaDaApplication.IS_NEW_USER) {
            ActivityUtil.next(this, new Intent(this, MainActivity.class));
        } else {
            //增加打点排查register_or_login_select_view打点异常问题
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(KaDaApplication.unique_identifier + "," + System.currentTimeMillis(),
                    "test_SplashActivity", TimeUtil.currentTime()));
            LoginOrRegisterActivity.startActivity(SplashActivity.this, "", true);
        }
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //由于偶现音频不播放导致卡在闪屏页问题，这里5秒后强制跳转
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                startMain(0);
            }
        }, 5000);
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    protected void onDestroy() {

        mHandler.removeCallbacksAndMessages(null);
        mHandler.destroy();
        super.onDestroy();

        // 如果关闭的activity是SplashActivity，就不发action_last_activity_destroyed广播了
        // 因为这个activity是不允许主动关闭的，后续会有MainActivity创建
        // 并且有一个场景：在SplashActivity 页面点击home键切到后台，Activity生命周期会先执行SplashActivity#onDestroy，后执行MainActivity#onCreate方法，
        // 这样InitHelper类就会收到最后一个Activity被销毁的消息，执行回收工作，导致之后的功能不能正常使用（比如微信支付等）；
        ActivityHelper.unregisterActivity(this, false);

        if (mMediaPlayer != null && mOnKdAudioFocusChangeListener != null) {
            mMediaPlayer.removeOnKdAudioFocusChangeListener(mOnKdAudioFocusChangeListener);
        }
    }

}
