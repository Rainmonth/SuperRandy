package com.hhdd.kada.main.ui.activity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.tracking.TrackingHelper;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.lifecycle.IComponentContainer;
import com.hhdd.kada.android.library.app.lifecycle.LifeCycleComponent;
import com.hhdd.kada.android.library.app.lifecycle.LifeCycleComponentManager;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.jsbridge.JsBridgeController;
import com.hhdd.kada.jsbridge.JsBridgeWebView;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.event.JsBridgeShareInfoEvent;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.share.ShareProvider;
import com.hhdd.logger.LogHelper;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.List;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/21
 * @describe : com.hhdd.kada.main.ui.activity
 */
public abstract class BaseTitleWebViewActivity extends BaseActivity implements IComponentContainer {

    @Nullable
    @BindView(R.id.titleBarView)
    protected TitleBar titleBarView;
    @Nullable
    @BindView(R.id.contentWebView)
    protected JsBridgeWebView contentWebView;
    @Nullable
    @BindView(R.id.loadingView)
    protected ProgressBar loadingView;
    @Nullable
    @BindView(R.id.errorTextView)
    protected View errorTextView;

    protected LifeCycleComponentManager componentManager = new LifeCycleComponentManager();
    protected WebSettings settings;
    protected JsBridgeController mController;
    protected WebChromeClient.CustomViewCallback myCallback;
    protected View myView;
    protected RelativeLayout.LayoutParams centerViewParams;
    protected ShareProvider.JsBridgeShareVO shareInfo;
    protected final String KADA = "kada";


    @Override
    public int getLayoutId() {
        return R.layout.activity_title_webview;
    }

    @Override
    public void doInitView() {
        super.doInitView();

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED, WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);

        EventBus.getDefault().register(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            titleBarView.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }
        titleBarView.getRightImageView().setVisibility(View.INVISIBLE);
        titleBarView.getRightImageView().setImageResource(R.drawable.icon_share);
        initWebView();

        centerViewParams = (RelativeLayout.LayoutParams) titleBarView.getCenterViewContainer().getLayoutParams();
        centerViewParams.leftMargin = LocalDisplay.dp2px(50);
        centerViewParams.rightMargin = LocalDisplay.dp2px(50);
        titleBarView.getTitleTextView().setEllipsize(TextUtils.TruncateAt.END);
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        titleBarView.setLeftOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (contentWebView != null && contentWebView.canGoBack()) {
                    contentWebView.goBack();// 返回前一个页面
                } else {
                    finish();
                }
            }
        });
        titleBarView.setRightOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                doShareHabit();
                doShare();
            }
        });
        errorTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (NetworkUtils.isReachable()) {
                    loadUrl();
                } else {
                    ToastUtils.showToast("网络异常，请检查网络");
                }
            }
        });
    }

    protected abstract void loadUrl();

    /**
     * 异常展示
     */
    protected void showError() {
        contentWebView.setVisibility(View.GONE);
        errorTextView.setVisibility(View.VISIBLE);
        loadingView.setVisibility(View.GONE);
    }

    /**
     * 分享
     */
    private void doShare() {
        if (isFinishing() || shareInfo == null) {
            return;
        }
        ShareProvider.share(this, shareInfo, new ShareProvider.Listener() {
            @Override
            public void onComplete(boolean success, SHARE_MEDIA share_media) {
                if (success) {
                    doShareHabitSuccess(share_media);
                }
            }
        });
    }

    /**
     * js回调分享信息
     *
     * @param event
     */
    public void onEventMainThread(JsBridgeShareInfoEvent event) {
        ShareProvider.JsBridgeShareVO shareVO = event.getShareVO();
        if (shareVO != null) {
            titleBarView.getRightImageView().setVisibility(View.VISIBLE);
            shareInfo = shareVO;
        }
    }

    @SuppressLint("NewApi")
    private void initWebView() {
        //音频自动播放
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            contentWebView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        }
        contentWebView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        contentWebView.setWebViewClient(mWebClient);

        contentWebView.setHorizontalScrollBarEnabled(false);// 水平不显示
        contentWebView.setVerticalScrollBarEnabled(false);
        contentWebView.setWebChromeClient(new MyWebChromeClient());
        contentWebView.removeJavascriptInterface("searchBoxJavaBridge_");

        settings = contentWebView.getSettings();

        settings.setDomStorageEnabled(true);
        // Open Cache manifest
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptEnabled(true);
        settings.setAppCacheEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAppCacheMaxSize(1024 * 1024 * 8);
        //根据cache-control决定是否从网络上取数据

        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        String appCacheDir = getDir("cache", Context.MODE_PRIVATE).getPath();
        settings.setAppCachePath(appCacheDir);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        settings.setAllowFileAccess(true);
        settings.setUseWideViewPort(true);
        settings.setDefaultTextEncodingName("utf-8");
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);// 提高渲染优先级

        settings.setBuiltInZoomControls(false);
        settings.setSupportZoom(false);

        mController = new JsBridgeController(this, contentWebView);
        contentWebView.setEnableJsBridge(true);
        contentWebView.setJs2JavaObjName("WebViewJavascriptBridge");// "WebViewJavascriptBridge_kada_hhdd_com";//WebViewJavascriptBridge
        contentWebView.setDefaultController(mController);

        contentWebView.setDownloadListener(new DownloadListener() {

            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                Intent intent = null;
                if (mimetype.startsWith("video")
                        || mimetype.startsWith("audio")) {
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.parse(url), mimetype);
                } else {
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                }
                try {
                    if (hasIntentHandler(BaseTitleWebViewActivity.this, intent)) {
                        startActivity(intent);
                    }
                } catch (ActivityNotFoundException e) {
                    LogHelper.printStackTrace(e);
                } catch (Exception e) {
                    LogHelper.printStackTrace(e);
                }

            }
        });
    }

    private boolean hasIntentHandler(Context context, Intent intent) {
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> list = pm.queryIntentActivities(intent, 0);
        return list.size() > 0;
    }

    private WebViewClient mWebClient = new WebViewClient() {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);

            loadingView.setVisibility(View.VISIBLE);
            errorTextView.setVisibility(View.GONE);
            contentWebView.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);

            if (errorTextView.getVisibility() == View.GONE) {
                contentWebView.setVisibility(View.VISIBLE);
            }
            loadingView.setVisibility(View.GONE);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, final String url) {
            if (url == null) {
                return true;
            }

            if (url.startsWith("tel:")) { // 拨打电话
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Throwable e) {
                    LogHelper.printStackTrace(e);
                }
                return true;
            } else if (url.startsWith("mqqwpa")) { // 启动QQ
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Throwable e) {
                    LogHelper.printStackTrace(e);
                }

                return true;
            }
            if (!TextUtils.isEmpty(url) && url.startsWith(KADA)) {
                RedirectActivity.startActivity(BaseTitleWebViewActivity.this, url);
            } else {
                return super.shouldOverrideUrlLoading(view, url);
            }
            return true;
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            showError();
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.proceed();//接受证书
        }

        @SuppressLint("NewApi")
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            String url = request.getUrl().toString();
            contentWebView.synCookies(BaseTitleWebViewActivity.this, url);
            return super.shouldInterceptRequest(view, request);
        }
    };

    @Override
    public void addComponent(LifeCycleComponent component) {
        componentManager.addComponent(component);
    }

    class MyWebChromeClient extends WebChromeClient {

        @Override
        public void onReceivedTitle(WebView view, String title) {
            super.onReceivedTitle(view, title);
            // 回调标题如果是url地址，则不显示
            if (!TextUtils.isEmpty(title) && !TextUtils.equals(view.getUrl(), title)) {
                titleBarView.setTitle(title);
            }
        }

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            if (newProgress == 100) {
                loadingView.setVisibility(View.GONE);
            } else {
                loadingView.setVisibility(View.VISIBLE);
                loadingView.setProgress(newProgress);
            }
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (myCallback != null) {
                myCallback.onCustomViewHidden();
                myCallback = null;
                return;
            }

            ViewGroup parent = (ViewGroup) contentWebView.getParent();
            parent.removeView(contentWebView);

            ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            view.setLayoutParams(params);
            view.setBackgroundColor(Color.BLACK);
            parent.addView(view);
            myView = view;
            myCallback = callback;
            BaseTitleWebViewActivity.this.onShowCustomView();
        }

        @Override
        public void onHideCustomView() {
            if (myView != null) {
                if (myCallback != null) {
                    myCallback.onCustomViewHidden();
                    myCallback = null;
                }

                ViewGroup parent = (ViewGroup) myView.getParent();
                parent.removeView(myView);
                parent.addView(contentWebView);
                myView = null;
                BaseTitleWebViewActivity.this.onHideCustomView();
            }
        }
    }

    protected void onShowCustomView() {

    }

    protected void onHideCustomView() {

    }

    protected abstract void doShareHabit();

    protected abstract void doShareHabitSuccess(SHARE_MEDIA share_media);

    @Override
    public void onBackPressed() {
        if (contentWebView != null && contentWebView.canGoBack()) {
            contentWebView.goBack();// 返回前一个页面
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        EventBus.getDefault().unregister(this);
        hideKeyBoard();
        if (mController != null) {
            mController.destroy();
        }
        super.onDestroy();
        try {
            if (contentWebView != null) {
                /**
                 * 若仍存在TextToSpeech$Connnection相应内存泄漏，参考https://my.oschina.net/huqiji/blog/864551试试，
                 * 即通过获取webView的父控件将webview移除试试
                 */
                contentWebView.stopLoading();
                contentWebView.releaseWebViewResouce(new Handler());
                //修复oppo a37快速进入该页面黑屏崩溃问题
//                contentWebView = null;
            }
        } catch (Throwable tr) {
            LogHelper.printStackTrace(tr);
        }
    }

    protected void trackHabit(TrackingHelper.UserHabitInfo event) {
        if (event == null) {
            return;
        }

        UserHabitService.getInstance().trackHabit(event);
    }
}
