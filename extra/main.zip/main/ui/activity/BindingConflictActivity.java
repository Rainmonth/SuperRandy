package com.hhdd.kada.main.ui.activity;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.dialog.ConfirmDialogManager;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.common.TitleBar;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.AccountUnifyContentInfo;
import com.hhdd.kada.main.model.AccountUnifyInfo;
import com.hhdd.kada.main.model.UserAccountInfo;
import com.hhdd.kada.main.ui.dialog.ConfirmDialog;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.kada.widget.BindingConflictCellView;
import com.hhdd.kada.widget.BindingConflictChooseLayout;
import com.hhdd.kada.widget.BindingResultCellView;

import java.util.List;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/5
 * @describe : com.hhdd.kada.main.ui.activity
 */
public class BindingConflictActivity extends BaseActivity {

    @BindView(R.id.titleBarView)
    TitleBar titleBarView;
    @BindView(R.id.accountLayout)
    View accountLayout;
    @BindView(R.id.accountDataLayout)
    View accountDataLayout;
    @BindView(R.id.account1IconView)
    ImageView account1IconView;
    @BindView(R.id.account1TitleView)
    TextView account1TitleView;
    @BindView(R.id.account2IconView)
    ImageView account2IconView;
    @BindView(R.id.account2TitleView)
    TextView account2TitleView;
    @BindView(R.id.account1DataLayout)
    LinearLayout account1DataLayout;
    @BindView(R.id.account2DataLayout)
    LinearLayout account2DataLayout;
    @BindView(R.id.conflictChooseLayout)
    BindingConflictChooseLayout conflictChooseLayout;
    @BindView(R.id.conflictLayout)
    LinearLayout conflictLayout;
    @BindView(R.id.bindingButtonLayout)
    View bindingButtonLayout;
    @BindView(R.id.bindingButtonChooseLayout)
    View bindingButtonChooseLayout;
    @BindView(R.id.conflictTextView)
    View conflictTextView;
    @BindView(R.id.cancelBindingTextView)
    View cancelBindingTextView;
    @BindView(R.id.confirmBindingTextView)
    View confirmBindingTextView;
    private AccountUnifyInfo currentLoginAccountInfo;
    private AccountUnifyInfo otherAccountInfo;
    private AccountUnifyInfo selectedAccountInfo;
    private StrongReference<DefaultCallback> accountUnifyReference;

    private int type;
    private final int TYPE_CAN_UNIFY = 1; // 可以合并
    private final int TYPE_CAN_NOT_UNIFY = 2; //不可以合并

    @Override
    public int getLayoutId() {
        return R.layout.activity_binding_conflict;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        titleBarView.setTitle(getResources().getString(R.string.binding_conflict_title));
        ViewGroup.LayoutParams titleBarLayoutParams = titleBarView.getLayoutParams();
        if (titleBarLayoutParams==null){
            titleBarLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            titleBarLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height)+ LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleBarView.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }else {
            titleBarLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height));
            titleBarView.setPadding(0, 0,0,0);
        }
        titleBarView.setLayoutParams(titleBarLayoutParams);
        adapterHighScreenPhone();
    }

    /**
     * 适配高屏手机
     */
    private void adapterHighScreenPhone() {
        int highTopMarin = LocalDisplay.dp2px(10);
        int topMarin = LocalDisplay.dp2px(5);
        LinearLayout.LayoutParams accountLayoutParams = (LinearLayout.LayoutParams) accountLayout.getLayoutParams();
        accountLayoutParams.topMargin = LocalDisplay.isHighScreen ? highTopMarin : topMarin;
        accountLayout.setLayoutParams(accountLayoutParams);

        LinearLayout.LayoutParams accountDataLayoutParams = (LinearLayout.LayoutParams) accountDataLayout.getLayoutParams();
        accountDataLayoutParams.topMargin = LocalDisplay.isHighScreen ? highTopMarin : topMarin;
        accountDataLayout.setLayoutParams(accountDataLayoutParams);

        LinearLayout.LayoutParams conflictChooseLayoutParams = (LinearLayout.LayoutParams) conflictChooseLayout.getLayoutParams();
        conflictChooseLayoutParams.topMargin = LocalDisplay.isHighScreen ? LocalDisplay.dp2px(15) : topMarin;
        conflictChooseLayout.setLayoutParams(conflictChooseLayoutParams);

        LinearLayout.LayoutParams bindingButtonLayoutParams = (LinearLayout.LayoutParams) bindingButtonLayout.getLayoutParams();
        bindingButtonLayoutParams.topMargin = LocalDisplay.isHighScreen ? LocalDisplay.dp2px(25) : LocalDisplay.dp2px(10);
        bindingButtonLayout.setLayoutParams(bindingButtonLayoutParams);
    }

    @Override
    public void doInitData() {
        super.doInitData();
        Intent intent = getIntent();
        if (intent != null) {
            List<AccountUnifyInfo> accountUnifyInfoList = (List<AccountUnifyInfo>) intent.getSerializableExtra(Constants.INTENT_KEY_ACCOUNT_UNIFY_INFO);
            if (accountUnifyInfoList == null || accountUnifyInfoList.size() < 2) {
                finish();
                return;
            }
            updateConflictCellLayout(accountUnifyInfoList);
        }
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        EventBus.getDefault().register(this);
        titleBarView.setLeftOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                finish();
            }
        });
        conflictChooseLayout.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                switch (action) {
                    // 与产品确认，默认进入页面选中推荐不需要打该点，故仅在按钮切换合并帐号时打点
                    case BindingConflictChooseLayout.ACTION_ACCOUNT_1:
                        if (selectedAccountInfo == currentLoginAccountInfo) {
                            break;
                        }
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                                currentLoginAccountInfo.getIsRecommend() == 1 ? "2" : "1",
                                StaCtrName.binding_conflict_solve_switch, TimeUtil.currentTime()));
                        updateConflictLayout(true);
                        break;
                    case BindingConflictChooseLayout.ACTION_ACCOUNT_2:
                        if (selectedAccountInfo == otherAccountInfo) {
                            break;
                        }
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                                currentLoginAccountInfo.getIsRecommend() == 1 ? "1" : "2",
                                StaCtrName.binding_conflict_solve_switch, TimeUtil.currentTime()));
                        updateConflictLayout(false);
                        break;
                    default:
                        break;
                }
            }
        });
        KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                switch (v.getId()) {
                    case R.id.cancelBindingTextView:
                        // 与产品确认 物理返回键和左上角返回按钮均不打该点
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.binding_conflict_solve_giveup, TimeUtil.currentTime()));
                        finish();
                        break;
                    case R.id.confirmBindingTextView:
                        doConfirmBinding();
                        break;
                    case R.id.conflictTextView:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.binding_conflict_solve_contact, TimeUtil.currentTime()));
                        WebViewActivity.startActivity(BindingConflictActivity.this, API.URL_CUSTOM());
                        break;
                    default:
                        break;
                }
            }
        };
        cancelBindingTextView.setOnClickListener(listener);
        confirmBindingTextView.setOnClickListener(listener);
        conflictTextView.setOnClickListener(listener);
    }

    /**
     * 点击立即绑定
     */
    private void doConfirmBinding() {
        if (selectedAccountInfo == null) {
            return;
        }
        Resources resources = getResources();
        String selectText = getTipDialogText(selectedAccountInfo.getAccountType());
        String otherText = getTipDialogText(selectedAccountInfo == currentLoginAccountInfo ?
                otherAccountInfo.getAccountType() : currentLoginAccountInfo.getAccountType());
        String dialogContent = String.format(resources.getString(R.string.binding_conflict_dialog_text), selectText, otherText);
        final ConfirmDialogManager confirmDialogManager = DialogFactory.getConfirmDialogManager();
        confirmDialogManager.showDialog(this, dialogContent,
                R.string.binding_conflict_dialog_nb_text, R.string.binding_conflict_dialog_pb_text,
                false, Gravity.LEFT|Gravity.CENTER_VERTICAL, new ConfirmDialog.OnConfirmDialogListener() {
                    @Override
                    public void onCancel() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.binding_conflict_confirm_cancel, TimeUtil.currentTime()));
                        confirmDialogManager.dismissDialog(BindingConflictActivity.this);
                    }

                    @Override
                    public void onConfirm() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                                StaCtrName.binding_conflict_confirm_sure, TimeUtil.currentTime()));
                        confirmDialogManager.dismissDialog(BindingConflictActivity.this);
                        doAccountUnify();
                    }
                });
    }

    /**
     * 帐号绑定
     */
    private void doAccountUnify() {
        if (selectedAccountInfo == null) {
            return;
        }
        if (otherAccountInfo == null) {
            return;
        }
        int selectUserAccountType = selectedAccountInfo.getAccountType();
        int otherUserAccountType = selectedAccountInfo == currentLoginAccountInfo ?
                otherAccountInfo.getAccountType() : currentLoginAccountInfo.getAccountType();
        long selectUserId = selectedAccountInfo.getUserId();
        long otherUserId = selectedAccountInfo == currentLoginAccountInfo ? otherAccountInfo.getUserId()
                : currentLoginAccountInfo.getUserId();
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                StaCtrName.binding_conflict_solve_submit, TimeUtil.currentTime()));
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this, R.string.unify_dialog_text, false,
                false, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                clearAccountUnifyReference();
            }
        });
        DefaultCallback<List<UserAccountInfo>> callback = new DefaultCallback<List<UserAccountInfo>>() {
            @Override
            public void onDataReceived(final List<UserAccountInfo> data) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(BindingConflictActivity.this);
                        boolean isNeedLoginAgain = currentLoginAccountInfo == null || currentLoginAccountInfo.getUserId() != selectedAccountInfo.getUserId();
                        ActivityUtil.nextBindingSuccessActivity(BindingConflictActivity.this, isNeedLoginAgain);
                        finish();
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                customDialogManager.dismissDialog(BindingConflictActivity.this);
                ActivityUtil.nextBindingFailActivity(BindingConflictActivity.this, reason);
            }
        };
        if(accountUnifyReference == null) {
            accountUnifyReference = new StrongReference<>();
        }
        accountUnifyReference.set(callback);
        UserAPI.doAccountUnify(String.valueOf(selectUserId), selectUserAccountType, String.valueOf(otherUserId), otherUserAccountType, accountUnifyReference);
    }

    /**
     * 更新两个帐号icon和标题
     * @param accountIconView
     * @param accountTitleView
     * @param accountType
     */
    private void updateAccountTitleView(ImageView accountIconView, TextView accountTitleView, int accountType) {
        switch (accountType) {
            case UserAccountInfo.TYPE_PHONE:
                accountIconView.setImageResource(R.drawable.icon_binding_conflict_phone);
                accountTitleView.setText(R.string.binding_title_phone);
                break;
            case UserAccountInfo.TYPE_WEIXIN:
                accountIconView.setImageResource(R.drawable.icon_binding_conflict_weixin);
                accountTitleView.setText(R.string.binding_title_wx);
                break;
            case UserAccountInfo.TYPE_HUAWEI:
                accountIconView.setImageResource(R.drawable.icon_binding_conflict_hw);
                accountTitleView.setText(R.string.binding_title_hw);
                break;
            default:
                break;
        }
    }

    /**
     * 获取合并帐号选项标题id
     * @param accountType
     * @return
     */
    private int getConflictChooseTitleResId(int accountType) {
        int titleResId = 0;
        switch (accountType) {
            case UserAccountInfo.TYPE_PHONE:
                titleResId = R.string.binding_conflict_to_phone;
                break;
            case UserAccountInfo.TYPE_WEIXIN:
                titleResId = R.string.binding_conflict_to_wx;
                break;
            case UserAccountInfo.TYPE_HUAWEI:
                titleResId = R.string.binding_conflict_to_hw;
                break;
            default:
                break;
        }
        return titleResId;
    }

    /**
     * 获取确认弹窗对应帐号文案
     * @param accountType
     * @return
     */
    private String getTipDialogText(int accountType) {
        String tipDialogText = "";
        switch (accountType) {
            case UserAccountInfo.TYPE_PHONE:
                tipDialogText = getResources().getString(R.string.binding_conflict_phone_text);
                break;
            case UserAccountInfo.TYPE_WEIXIN:
                tipDialogText = getResources().getString(R.string.binding_conflict_wx_text);
                break;
            case UserAccountInfo.TYPE_HUAWEI:
                tipDialogText = getResources().getString(R.string.binding_conflict_hw_text);
                break;
            default:
                break;
        }
        return tipDialogText;
    }

    /**
     * 更新当前登录帐号与被绑定帐号信息
     */
    private void updateConflictCellLayout(List<AccountUnifyInfo> accountUnifyInfoList) {
        if (accountUnifyInfoList.size() > 2) {
            accountUnifyInfoList = accountUnifyInfoList.subList(0, 2);
        }
        boolean haveUnifyDataNone = false; // 是否存在某个帐号返回合并数据为空
        for (AccountUnifyInfo info : accountUnifyInfoList) {
            int type = info.getType();
            if (type == 1) {
                currentLoginAccountInfo = info;
            } else if (type == 2) {
                otherAccountInfo = info;
            }
            List<AccountUnifyContentInfo> contentInfoList = info.getAccountList();
            if (contentInfoList != null && contentInfoList.size() > 0) {
                for (AccountUnifyContentInfo contentInfo : contentInfoList) {
                    BindingConflictCellView cellView = new BindingConflictCellView(this);
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    cellView.update(contentInfo.getTypeName(), contentInfo.getValue());
                    if (type == 1) {
                        //当前登录用户
                        account1DataLayout.addView(cellView, params);
                    } else if (type == 2) {
                        //被绑定用户
                        account2DataLayout.addView(cellView, params);
                    }
                }
            }
            List<AccountUnifyContentInfo> unifyList = info.getUnifyList();
            if (unifyList == null || unifyList.size() == 0) {
                haveUnifyDataNone = true;
            }
        }
        if (currentLoginAccountInfo != null && otherAccountInfo != null) {
            int currentAccountType = currentLoginAccountInfo.getAccountType();
            int otherAccountType = otherAccountInfo.getAccountType();
            updateAccountTitleView(account1IconView, account1TitleView, currentAccountType);
            updateAccountTitleView(account2IconView, account2TitleView, otherAccountType);
            conflictChooseLayout.init(getConflictChooseTitleResId(currentAccountType),
                    getConflictChooseTitleResId(otherAccountType), currentLoginAccountInfo.getIsRecommend() == 1);
        }
        if (!haveUnifyDataNone) {
            conflictChooseLayout.setVisibility(View.VISIBLE);
            updateConflictLayout(currentLoginAccountInfo != null && currentLoginAccountInfo.getIsRecommend() == 1);
            bindingButtonLayout.setVisibility(View.VISIBLE);
        }
    }

    /**
     * 选择帐号时更新合并后数据展示背景
     * @param isLeftSelected
     */
    private void updateConflictLayout(boolean isLeftSelected) {
        int radius = LocalDisplay.dp2px(5);
        GradientDrawable drawable = new GradientDrawable();
        float[] radiusArr = null;
        if (isLeftSelected) {
            radiusArr = new float[] {0, 0, radius, radius, radius, radius, radius, radius};
        } else {
            radiusArr = new float[] {radius, radius, 0, 0, radius, radius, radius, radius};
        }
        drawable.setCornerRadii(radiusArr);
        drawable.setColor(getResources().getColor(R.color.color_1cc2ff));
        conflictLayout.setBackgroundDrawable(drawable);
        selectedAccountInfo = isLeftSelected ? currentLoginAccountInfo : otherAccountInfo;
        if (selectedAccountInfo != null) {
            updateConflictResultContent(selectedAccountInfo.getAccountType() == UserAccountInfo.TYPE_PHONE, selectedAccountInfo.getUnifyList());
        }
    }

    /**
     * 更新模拟合并后的数据展示
     * @param isPhoneAccountSelected
     * @param contentInfoList
     */
    private void updateConflictResultContent(boolean isPhoneAccountSelected, List<AccountUnifyContentInfo> contentInfoList) {
        if (contentInfoList != null && contentInfoList.size() > 0) {
            conflictLayout.removeAllViews();
            boolean haveDataConflict = false; // 是否存在数据冲突
            for (AccountUnifyContentInfo contentInfo : contentInfoList) {
                BindingResultCellView cellView = new BindingResultCellView(this);
                int isMerge = contentInfo.getIsMerge();
                if (isMerge == 2) {
                    haveDataConflict = true;
                }
                cellView.update(contentInfo.getTypeName(), contentInfo.getValue(), isMerge, isPhoneAccountSelected);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                conflictLayout.addView(cellView, params);
            }
            type = haveDataConflict ? TYPE_CAN_NOT_UNIFY : TYPE_CAN_UNIFY;
            bindingButtonChooseLayout.setVisibility(haveDataConflict ? View.GONE : View.VISIBLE);
            conflictTextView.setVisibility(haveDataConflict ? View.VISIBLE : View.GONE);
        }
    }

    /**
     * 回收帐号合并接口回调强引用资源
     */
    private void clearAccountUnifyReference() {
        if (accountUnifyReference != null) {
            accountUnifyReference.clear();
            accountUnifyReference = null;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (type > 0) {
            String habitName = type == TYPE_CAN_UNIFY ? StaPageName.binding_conflict_can_solve_view
                    : StaPageName.binding_conflict_cannot_solve_view;
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("",
                    habitName, TimeUtil.currentTime()));
        }
    }

    public void onEvent(AuthService.CookieExpiredEvent event) {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
        clearAccountUnifyReference();
        DialogFactory.dismissAllDialog(this);
    }
}
