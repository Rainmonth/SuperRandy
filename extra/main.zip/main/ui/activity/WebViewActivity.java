package com.hhdd.kada.main.ui.activity;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.app.lifecycle.IComponentContainer;
import com.hhdd.kada.android.library.app.lifecycle.LifeCycleComponent;
import com.hhdd.kada.android.library.app.lifecycle.LifeCycleComponentManager;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.jsbridge.JsBridgeController;
import com.hhdd.kada.jsbridge.JsBridgeWebView;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.LogoutEvent;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.logger.LogHelper;

import java.util.List;

/**
 * Created by simon on 16/6/15.
 */
public class WebViewActivity extends BaseActivity implements IComponentContainer {

    private LifeCycleComponentManager componentManager = new LifeCycleComponentManager();
    private WebSettings settings;
    private String appCacheDir;

    public static final void startActivity(Context context, String url) {
        Intent intent = new Intent(context, WebViewActivity.class);
        intent.setData(Uri.parse(url));
        context.startActivity(intent);
    }

    private boolean isCache = true;

    private JsBridgeWebView mWebView;
    private View mBackView;
    private View myView;
    private ProgressBar progressBar;
    private View errorContainer;
    private WebChromeClient.CustomViewCallback myCallback;

    private JsBridgeController mController;
    String mUrl;
    private SimpleEventHandler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        if (initUrl(intent)) return;

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,   WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        setContentView(R.layout.activity_webview);

        progressBar = (ProgressBar) findViewById(R.id.webview_loading);
        mWebView = (JsBridgeWebView) findViewById(R.id.webview);
        mBackView = findViewById(R.id.back);
        errorContainer = findViewById(R.id.error_container);
        mBackView.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (mWebView != null && mWebView.canGoBack()) {
                    mWebView.goBack();// 返回前一个页面
                } else {
                    hideKeyBoard();
                    finish();
                }
            }
        });

        //音频自动播放
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            mWebView.getSettings().setMediaPlaybackRequiresUserGesture(false);
        }

        EventCenter.bindContainerAndHandler(this, handler = new SimpleEventHandler() {

            public void onEvent(LoginEvent event) {
                initWebView(mUrl);
            }

            public void onEvent(LogoutEvent event) {
                initWebView(mUrl);
            }
        }).tryToRegisterIfNot();

        initWebView(mUrl);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (initUrl(intent)) return;
        mWebView.loadUrl(mUrl);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && mWebView != null && mWebView.canGoBack()) {
            mWebView.goBack();// 返回前一个页面
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        if (mController != null) {
            mController.destroy();
        }
        if (handler != null) {
            handler.tryToUnregister();
            handler = null;
        }
        super.onDestroy();
        try {
            if (mWebView != null) {
                mWebView.stopLoading();
                mUrl = null;
                mWebView.releaseWebViewResouce(new Handler());
            }

        } catch (Throwable tr) {

        }
    }

    @SuppressLint("NewApi")
    private void initWebView(String url) {
        mWebView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        mWebView.setWebViewClient(mWebClient);

        mWebView.setHorizontalScrollBarEnabled(false);// 水平不显示
        mWebView.setVerticalScrollBarEnabled(false);
        mWebView.setWebChromeClient(new MyWebChromeClient());

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            mWebView.removeJavascriptInterface("searchBoxJavaBridge_");
        }

        settings = mWebView.getSettings();

        settings.setDomStorageEnabled(true);
        // Open Cache manifest
        settings.setDatabaseEnabled(true);
        settings.setJavaScriptEnabled(true);
        settings.setAppCacheEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAppCacheMaxSize(1024 * 1024 * 8);
        //根据cache-control决定是否从网络上取数据

        settings.setCacheMode(isCache ? WebSettings.LOAD_DEFAULT : WebSettings.LOAD_NO_CACHE);

        appCacheDir = getDir("cache", Context.MODE_PRIVATE).getPath();
        settings.setAppCachePath(appCacheDir);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        settings.setAllowFileAccess(true);
        settings.setUseWideViewPort(true);
        settings.setDefaultTextEncodingName("utf-8");
        settings.setLoadWithOverviewMode(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);// 提高渲染优先级

        settings.setBuiltInZoomControls(false);
        settings.setSupportZoom(false);

        mController = new JsBridgeController(this, mWebView);
        mWebView.setEnableJsBridge(true);
        mWebView.setJs2JavaObjName("WebViewJavascriptBridge");// "WebViewJavascriptBridge_kada_hhdd_com";//WebViewJavascriptBridge
        mWebView.setDefaultController(mController);

        mWebView.setDownloadListener(new DownloadListener() {

            @Override
            public void onDownloadStart(String url, String userAgent,
                                        String contentDisposition, String mimetype,
                                        long contentLength) {
                Intent intent = null;
                if (mimetype.startsWith("video")
                        || mimetype.startsWith("audio")) {
                    intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.parse(url), mimetype);
                } else {
                    intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                }
                try {
                    if (hasIntentHandler(WebViewActivity.this, intent)) {
                        startActivity(intent);
                    }
                } catch (ActivityNotFoundException e) {
                    LogHelper.printStackTrace(e);
                } catch (Exception e) {
                    LogHelper.printStackTrace(e);
                }

            }
        });
        mWebView.loadUrl(url);
    }

    private boolean hasIntentHandler(Context context, Intent intent) {
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> list = pm.queryIntentActivities(intent, 0);
        return list.size() > 0;
    }

    private boolean initUrl(Intent intent) {
        if (null != intent) {
            Uri data = intent.getData();
            if (null != data) {
                mUrl = data.toString();
            }
            if (TextUtils.isEmpty(mUrl)) {
                mUrl = intent.getStringExtra("url");
            }
        }
        if (TextUtils.isEmpty(mUrl)) {
            Toast.makeText(this, "url不能为空", Toast.LENGTH_SHORT).show();
            finish();
            return true;
        }
        return false;
    }

    private WebViewClient mWebClient = new WebViewClient() {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (errorContainer.getVisibility() == View.VISIBLE) {

            } else {
//                mLoadingProgress.setVisibility(View.GONE);
                mWebView.setVisibility(View.VISIBLE);
                errorContainer.setVisibility(View.GONE);
            }
            progressBar.setVisibility(View.GONE);
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, final String url) {
//            view.loadUrl(url);
            if (url == null) {
                return true;
            }

            if (url.startsWith("tel:")) { // 拨打电话
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Throwable e) {
                }
                return true;
            } else if (url.startsWith("mqqwpa")) { // 启动QQ
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(intent);
                } catch (Throwable e) {
                }

                return true;
            }

            RedirectActivity.startActivity(WebViewActivity.this, url);
            return true;
        }

        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
//            super.onReceivedError(view, errorCode, description, failingUrl);
            mWebView.setVisibility(View.GONE);
            errorContainer.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.proceed();//接受证书
        }

        //        /**
//         * 5.0以下
//         * @param view
//         * @param url
//         * @return
//         */
//        @Override
//        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
//            mWebView.synCookies(WebViewActivity.this, url);
//            return super.shouldInterceptRequest(view, url);
//        }

        @SuppressLint("NewApi")
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            String url = request.getUrl().toString();
            mWebView.synCookies(WebViewActivity.this, url);
            return super.shouldInterceptRequest(view, request);
        }
    };

    @Override
    public void addComponent(LifeCycleComponent component) {
        componentManager.addComponent(component);
    }

    class MyWebChromeClient extends WebChromeClient {

        @Override
        public void onReceivedTitle(WebView view, String title) {
//            mTitleView.setText(title);
            super.onReceivedTitle(view, title);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (myCallback != null) {
                myCallback.onCustomViewHidden();
                myCallback = null;
                return;
            }

            ViewGroup parent = (ViewGroup) mWebView.getParent();
            parent.removeView(mWebView);

            ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            view.setLayoutParams(params);
            view.setBackgroundColor(Color.BLACK);
            parent.addView(view);
            myView = view;
            myCallback = callback;
//            mTitleLayout.setVisibility(View.GONE);
        }

        @Override
        public void onHideCustomView() {
            if (myView != null) {

                if (myCallback != null) {
                    myCallback.onCustomViewHidden();
                    myCallback = null;
                }

                ViewGroup parent = (ViewGroup) myView.getParent();
                parent.removeView(myView);
                parent.addView(mWebView);
                myView = null;
//                mTitleLayout.setVisibility(View.VISIBLE);
            }
        }

    }


}
