package com.hhdd.kada.main.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.record.utils.KadaOSSClient;

/**
 * Created by simon on 18/6/15.
 */
public class AboutActivity extends BaseActivity {

    public static final void startActivity(Context context,String version) {
        if (context == null) {
            return;
        }

        Intent intent = new Intent(context, AboutActivity.class);
        intent.putExtra("version",version);
        context.startActivity(intent);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        String version =  getIntent().getStringExtra("version");
        TextView tv_version = (TextView) findViewById(R.id.version);
        tv_version.setText("咔哒故事"+version);

        //设置间隔时长 应用在后台多久时间后 算新session
//        MobclickAgent.setSessionContinueMillis(15 * 60 * 1000);
//        //禁止默认的统计
//        MobclickAgent.openActivityDurationTrack(false);
        /** 设置是否对日志信息进行加密, 默认false(不加密). */
//        AnalyticsConfig.enableEncrypt(true);


        findViewById(R.id.back).setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                finish();
            }
        });

        View statusView = findViewById(R.id.statusView);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            statusView.getLayoutParams().height = LocalDisplay.SCREEN_STATUS_HEIGHT;
        }else {
            statusView.setVisibility(View.GONE);
        }

    }

}
