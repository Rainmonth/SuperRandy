package com.hhdd.kada.main.ui.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshListView;
import com.hhdd.core.model.BaseVO;
import com.hhdd.core.model.BookCollectionVO;
import com.hhdd.core.model.BookInfo;
import com.hhdd.core.model.BookVO;
import com.hhdd.core.model.HomeVO;
import com.hhdd.core.model.RecommendVO;
import com.hhdd.core.service.BookService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BookAPI;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.main.model.ShareInfo;
import com.hhdd.kada.main.ui.adapter.AlbumAdapter;
import com.hhdd.kada.main.ui.dialog.ContentIsDeletedDialog;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.views.DataLoadingBuilder;
import com.hhdd.kada.share.ShareProvider;
import com.hhdd.kada.share.ShareUtils;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;


/**
 * Created by zhengkaituo on 15/12/24.
 */
public class BookCollectionActivity extends BaseActivity {

//    private View headview;
    private PullToRefreshListView mListview;
    private TextView mBookName;
    private FrameLayout container;
//    private NetworkBitmap bitmap;
    private AlbumAdapter adapter;
    private int mCollectionId;
    private boolean isNew;

    BookCollectionVO collectionVO;
    private DataLoadingBuilder mLoadingBuilder = null;
    private SimpleDraweeView background;

    public static final void startActivity(Context context, int collectionId) {
        if (context == null) {
            return;
        }

        Intent intent = new Intent(context, BookCollectionActivity.class);
        intent.putExtra("collectionId", collectionId);
        context.startActivity(intent);
    }

    public static final void startActivity(Context context, int collectionId, boolean isNew) {
        if (context == null) {
            return;
        }

        Intent intent = new Intent(context, BookCollectionActivity.class);
        intent.putExtra("collectionId", collectionId);
        intent.putExtra("isNew", isNew);
        context.startActivity(intent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listen_collection);
        getWindow().getDecorView().setBackgroundDrawable(null);
//        LayoutInflater inflater = LayoutInflater.from(this);
//        headview = inflater.inflate(R.layout.head_view_collection, null);

        EventBus.getDefault().register(this);
        mCollectionId = getIntent().getIntExtra("collectionId", 0);
        UserHabitService.getInstance().track(UserHabitService.newUserHabit("" + mCollectionId, "clickbookcollection", TimeUtil.currentMiliTime()));
        isNew = getIntent().getBooleanExtra("isNew", false);
        initView();
        loadData();
    }

    void initView() {

        View titleView = findViewById(R.id.titleView);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            ViewGroup.LayoutParams titleViewLayoutParams = titleView.getLayoutParams();
            if (titleViewLayoutParams==null){
                titleViewLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleViewLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height)+LocalDisplay.SCREEN_STATUS_HEIGHT);
            titleView.setLayoutParams(titleViewLayoutParams);
            titleView.setPadding(0,LocalDisplay.SCREEN_STATUS_HEIGHT,0,0);
        }


        mListview = (PullToRefreshListView) findViewById(R.id.listview);
//        mListview.getRefreshableView().addHeaderView(headview);
        View back = findViewById(R.id.back);
        background = (SimpleDraweeView) findViewById(R.id.background);
        mBookName = (TextView) findViewById(R.id.tv_name);
        container = (FrameLayout) findViewById(R.id.main_container);
        back.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                finish();
            }
        });
//        bitmap = new NetworkBitmap();
//
//        bitmap.setImageListener(new Listener<Bitmap>() {
//            @Override
//            public void onResponse(Bitmap response) {
//                super.onResponse(response);
//                if (response != null) {
////                    linearLayout.setBackground(new BitmapDrawable(getResources(),response));
//                    applyBlur(response);
////                    Log.d("responseget", "asd");
//                }
//
//
//            }
//        });

        adapter = new AlbumAdapter(this);
        mListview.setAdapter(adapter);
        mListview.setMode(PullToRefreshBase.Mode.DISABLED);

        mLoadingBuilder = new DataLoadingBuilder(this, mListview);
        View view = mLoadingBuilder.showLoading();
        view.setBackgroundColor(getResources().getColor(R.color.transparent));
        mLoadingBuilder.setOnRetryClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            }
        });

        findViewById(R.id.share).setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                if(collectionVO != null){
                    int collectionId = collectionVO.getCollectId();
                    ShareInfo shareInfo = new ShareInfo();
                    shareInfo.setTitle(AppUtils.getString(R.string.share_default_title));
                    shareInfo.setContent(collectionVO.getName() + " ");
                    shareInfo.setImageUrl(collectionVO.getCoverUrl());
                    shareInfo.setTargetUrl(API.BOOK_SINGLE_SHARE_URL + collectionId);
                    shareInfo.setWxMinPath(ShareUtils.getWxMinBookPagePath(String.valueOf(collectionId)));
                    ShareProvider.share(BookCollectionActivity.this, shareInfo, new ShareProvider.Listener() {
                        @Override
                        public void onComplete(boolean success, SHARE_MEDIA share_media) {
                            if(success){
                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectionVO.getCollectId() + ","+share_media.toString()+",yes", "book_collection_page_share", TimeUtil.currentTime()));
                            }else{
                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectionVO.getCollectId() + ","+share_media.toString()+",no", "book_collection_page_share", TimeUtil.currentTime()));
                            }
                        }
                    });
                }
            }
        });
    }

    void loadData() {
        collectionVO = BookService.loadCollectionFromCache(mCollectionId);
        if (collectionVO == null || isNew) {
            if (collectionVO != null) {
                refreshView();

            }
            if(NetworkUtils.isReachable()){
                getOldBookCollectionDetail();
            }else{
                if(collectionVO == null){
                    ToastUtils.showToast("网络异常，请检查网络");
                }
            }
        } else {
            refreshView();
            if(NetworkUtils.isReachableViaWiFi()){
                getOldBookCollectionDetail();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        dismissLoadingDialog();

        EventBus.getDefault().unregister(this);

        if (adapter != null) {
            adapter.recycle();
        }

//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                if (collectionVO != null) {
//                    Gson gson = new Gson();
//                    String json = gson.toJson(collectionVO, new TypeToken<BookCollectionVO>() {
//                    }.getType());
//                    FileUtils.saveStringToFile(json, StoryService.cateCollectionItemFilePath(collectionVO.getSourceId()));
//                }
//            }
//        }).start();
    }


    public void refreshView() {
        adapter.clear();
        if (collectionVO != null) {
            List<BaseVO> recommendList = new ArrayList<BaseVO>();
            RecommendVO vo = new RecommendVO();
            vo.setBannerUrl(collectionVO.getBannerUrl());
            recommendList.add(vo);
            vo = new RecommendVO();
            vo.setContent(collectionVO.getIntroduction());
            vo.setName(collectionVO.getName());
            vo.setCoverUrl(collectionVO.getCoverUrl());
            recommendList.add(vo);

            HomeVO homeVO = new HomeVO();
            homeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_ALBUM_BOOK_BANNER);
            homeVO.setItemList(recommendList);
            adapter.add(homeVO);

            HomeVO seqHomeVO = new HomeVO();
            seqHomeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_SEP2);
            adapter.add(seqHomeVO);

//            String backImg = CdnUtils.getImgCdnUrl(collectionVO.getBannerUrl(), CdnUtils.SIZE_700x435, true);
//            FrescoUtils.showImg(background, new IterativeBoxBlurPostProcessor(30), backImg, 0, 0);
            String backImg = CdnUtils.getImgCdnBlurUrl(collectionVO.getBannerUrl(), 30, 30, true);
            FrescoUtils.showImg(background, backImg);

            mBookName.setText(collectionVO.getName());
            List<BaseVO> infoList = new ArrayList<BaseVO>();
            List<BookVO.Book> bookList = collectionVO.getItems();
            if (bookList == null || bookList.size() == 0) {

            } else {
//                int collectionId = mCollectionId;
//                if(collectionVO.getType() == BookInfo.COLLECTION_TYPE_NORMAL){
//                    collectionId = 0;
//                }
                for (int i = 0; i < bookList.size(); i++) {
                    BookInfo info = BookInfo.createInfoByBook(bookList.get(i), 0);
                    infoList.add(info);
                    if ((i + 1) % 3 == 0) {
                        HomeVO storyListHomeVO = new HomeVO();
                        storyListHomeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_BOOK_LIST);
                        storyListHomeVO.setItemList(infoList);
                        adapter.add(storyListHomeVO);
                        infoList.clear();
                    }
                }

                if (infoList.size() > 0) {
                    HomeVO storyListHomeVO = new HomeVO();
                    storyListHomeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_BOOK_LIST);
                    storyListHomeVO.setItemList(infoList);
                    adapter.add(storyListHomeVO);
                }

                seqHomeVO = new HomeVO();
                seqHomeVO.setItemType(AlbumAdapter.ITEM_VIEW_TYPE_SEP2);
                adapter.add(seqHomeVO);
            }
        }
        adapter.notifyDataSetChanged();

        dismissLoadingDialog();
    }

    private void dismissLoadingDialog() {
        if (mLoadingBuilder != null) {
            mLoadingBuilder.dismiss();
            mLoadingBuilder.onDestroy();
            mLoadingBuilder = null;
        }
    }

    public void reload() {
        collectionVO = BookService.loadCollectionFromCache(mCollectionId);
        refreshView();
    }




    public void onEvent(OnRefreshDoneEvent event) {
        reload();
    }


    public static class OnRefreshDoneEvent {

    }

    public void getOldBookCollectionDetail(){
        API.UrlAPI bookAPI = BookAPI.getOldBookCollectionItem(mCollectionId);
        bookAPI.get(new API.ResponseHandler<BookCollectionVO>(){
            @Override
            public void onSuccess(BookCollectionVO responseData) {
                if (responseData == null) {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            showContentDialog();

                            dismissLoadingDialog();
                        }
                    });

                    return;
                }

                Gson gson = new Gson();
                String json = gson.toJson(responseData, new TypeToken<BookCollectionVO>() {
                }.getType());
                FileUtils.saveStringToFile(json, BookService.cateCollectionItemFilePath(responseData.getCollectId()));

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        dismissLoadingDialog();

                        EventBus.getDefault().post(new OnRefreshDoneEvent());
                    }
                });
            }

            @Override
            public void onFailure(int code, String message) {
                dismissLoadingDialog();
            }
        });
    }
    private void showContentDialog(){
        if (isFinishing()){
            return;
        }
        ContentIsDeletedDialog dialog = new ContentIsDeletedDialog(this);
        dialog.setCallback(new ContentIsDeletedDialog.ContentDialogCallback() {
            @Override
            public void doYes() {
                finish();
            }
        });
        dialog.setData(1, 1, mCollectionId);
        dialog.show();
    }
}
