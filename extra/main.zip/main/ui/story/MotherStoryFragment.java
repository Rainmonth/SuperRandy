package com.hhdd.kada.main.ui.story;

import android.os.Bundle;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BannerAPI;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.AutoLayoutViewHolder;
import com.hhdd.kada.main.viewholders.BannerViewHolder;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.MotherStoryBannerViewHolder;
import com.hhdd.kada.main.viewholders.OrgSlideViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorMiddleViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorViewHolder;
import com.hhdd.kada.main.viewholders.Story1x3ViewHolder;
import com.hhdd.kada.main.viewholders.Story2x2ViewHolder;
import com.hhdd.kada.main.viewholders.StoryCateViewHolder;
import com.hhdd.kada.main.viewholders.StoryListViewHolder;
import com.hhdd.kada.main.viewholders.TitleViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.ViewTypes;
import com.hhdd.kada.module.userhabit.StaPageName;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by lj on 17/4/17.
 */

public class MotherStoryFragment extends RecyclerDataListFragment2 {

    private StrongReference<DefaultCallback> configStrongReference;

    public static MotherStoryFragment newInstance(Bundle bundle) {
        MotherStoryFragment fragment = new MotherStoryFragment();
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        return fragment;
    }

    public MotherStoryFragment() {
        super(LIST_MODE_PULL_DOWN_TO_REFRESH, "", null);
    }

    //    API.PaginationUrlAPI listAPI;
    static final int View_Type_DataList_Old_Banner = 101;
    private static final int View_Type_Separator = View_Type_DataList_Old_Banner + 1;
    List<BaseModel> bannerInfoList = new ArrayList<>();
    List<BaseModel> models = new ArrayList<>();

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        useTitleBar("选听书");//by lazy for v3.7 title字段可以通过咔哒协议传过来 在onEnter方法中获取

        setBackgroundColor(KaDaApplication.instance.getResources().getColor(R.color.white));
        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(ViewTypes.View_Type_Separator.getId(), SeparatorViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_Banner.getId(), BannerViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_StoryCate.getId(), StoryCateViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_Title.getId(), TitleViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_OrgSlide.getId(), OrgSlideViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_StoryCollect2X2.getId(), Story2x2ViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_StoryCollect1X3.getId(), Story1x3ViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_AutoLayout.getId(), AutoLayoutViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_DataList_StoryList.getId(), StoryListViewHolder.class);
        viewTypeMaps.put(View_Type_DataList_Old_Banner, MotherStoryBannerViewHolder.class);
        viewTypeMaps.put(View_Type_Separator, SeparatorMiddleViewHolder.class);
        BaseViewHolderCreator viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        setViewHolderCreator(viewHolderCreator);

        showLoadingView();
        doRefresh();
    }

    void loadBannerData() {
        getBannerInfo();
    }

    private void getBannerInfo() {
        BannerAPI.getMotherStoryBanner(new API.CachedResponseHandler<List<BannerInfo>>() {
            @Override
            public void onFirstLoadFromCache(List<BannerInfo> cachedData) {
                if (cachedData != null) {
                    bannerInfoList.clear();
                    bannerInfoList.addAll(cachedData);
                }
            }

            @Override
            public void onSuccess(List<BannerInfo> responseData) {
                if (responseData != null && responseData.size() > 0) {
                    bannerInfoList.clear();
                    bannerInfoList.addAll(responseData);

                    final List<BaseModel> data = new ArrayList<BaseModel>();
                    if (models.size() > 0) {
                        BaseModelListVO vo = new BaseModelListVO();
                        vo.setViewType(View_Type_DataList_Old_Banner);
                        vo.setItemList(bannerInfoList);
                        data.add(vo);
                        data.addAll(models);
//                        data.add(getBaseV0());

                        getHandler().post(new Runnable() {
                            @Override
                            public void run() {
                                reloadData(data);
                            }
                        });
                    }
                }
            }

            @Override
            public void onFailure(int code, String message) {
            }
        });
    }

    @Override
    protected void doRefresh() {

        loadBannerData();

        if (configStrongReference == null) {
            configStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<BaseModelListVO>> defaultCallback = new DefaultCallback<List<BaseModelListVO>>() {
            @Override
            public void onDataReceived(List<BaseModelListVO> responseData) {
                if (responseData != null && responseData.size() > 0) {
                    models.clear();
                    models.addAll(responseData);

                    final List<BaseModel> data = new ArrayList<BaseModel>();
                    if (bannerInfoList.size() > 0) {
                        BaseModelListVO vo = new BaseModelListVO();
                        vo.setViewType(View_Type_DataList_Old_Banner);
                        vo.setItemList(bannerInfoList);
                        data.add(vo);
                        data.addAll(models);
                    } else {
                        data.addAll(models);
                    }
//                        data.add(getBaseV0());

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            reloadData(data);
                            handleLoadComplete(false);
                        }
                    });
                } else {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            handleErrorOccurred(true, 0, "加载错误");
                        }
                    });
                }
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(reason);
                handleErrorOccurred(true, code, reason);
            }
        };
        configStrongReference.set(defaultCallback);
        StoryAPI.getStoryConfig2(configStrongReference);

    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.mom_home_story_view, TimeUtil.currentTime()));
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (configStrongReference != null) {
            configStrongReference.clear();
            configStrongReference = null;
        }
    }
}
