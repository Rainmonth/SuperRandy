package com.hhdd.kada.main.ui.story;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.widget.ProgressBar;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.utils.BitmapUtils;

/**
 * Created by MCX on 2017/5/4.
 */

public class FishProgressBar extends ProgressBar {

    private TextPaint mTextPaint;
    private Paint mPaint,mRectPaint;

    public FishProgressBar(Context context) {
        this(context,null);
    }

    public FishProgressBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);

        mTextPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        mTextPaint.density = getResources().getDisplayMetrics().density;

        mTextPaint.setColor(Color.parseColor("#2aa8e3"));
        mTextPaint.setTextSize(80);
        mTextPaint.setTextAlign(Paint.Align.CENTER);
        mTextPaint.setAntiAlias(true);
        mTextPaint.setFakeBoldText(true);

        mPaint = new Paint();
        mPaint.setAntiAlias(true);

        mRectPaint = new Paint();
        mRectPaint.setAntiAlias(true);
        mRectPaint.setColor(Color.parseColor("#78d2fe"));

    }

    public FishProgressBar(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected synchronized void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        final int width = getMeasuredWidth();
        final int height = getMeasuredHeight();
        setMeasuredDimension(width,height);
    }
    private void updateProgressBar(){
        Drawable progressDrawble = getProgressDrawable();
        if (progressDrawble != null && progressDrawble instanceof LayerDrawable){
            LayerDrawable layerDrawable = (LayerDrawable) progressDrawble;
            final float scale = getScale(getProgress());
            //获取进度条，更新它的大小
            Drawable progressBar = layerDrawable.findDrawableByLayerId(R.id.fish_progress);
            final int width = layerDrawable.getBounds().right+layerDrawable.getBounds().left;

            if (progressBar != null){
                Rect progressBarBounds = progressBar.getBounds();
                progressBarBounds.right = progressBarBounds.left + (int) (width * scale + 0.5f);
                progressBar.setBounds(progressBarBounds);
            }
        }
    }
    private float getScale(int progress) {
        float scale = getMax() > 0 ? (float) progress / (float) getMax() : 0;

        return scale;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        updateProgressBar();
        Drawable progressDrawable = getProgressDrawable();
        Bitmap bitmap = BitmapUtils.resourceToBitmap(getContext(), R.drawable.fish);
        canvas.save();

        int dx = 0;

        if (progressDrawable != null
                && progressDrawable instanceof LayerDrawable) {
            LayerDrawable d = (LayerDrawable) progressDrawable;
            Drawable progressBar = d.findDrawableByLayerId(R.id.fish_progress);
            dx = progressBar.getBounds().right;
        } else if (progressDrawable != null) {
            dx = progressDrawable.getBounds().right;
        }

        dx = dx - bitmap.getWidth() / 2 + getPaddingLeft();

        //矩形
        int width = dx+bitmap.getWidth()/2 ;
        int height = getHeight();
        Rect rect = new Rect(0,0,width,height);
        canvas.drawRect(rect,mRectPaint);

        //鱼
        float marginTop = (getHeight() - bitmap.getHeight()) / 2;
        canvas.drawBitmap(bitmap, dx, marginTop, mPaint);

        //进度
        String progress = "" + getProgress() + "%";
        float textHeight = getHeight();
        canvas.drawText(progress, 150, LocalDisplay.dp2px(35), mTextPaint);

        canvas.restore();
    }
}
