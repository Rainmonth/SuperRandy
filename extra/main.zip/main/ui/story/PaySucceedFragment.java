package com.hhdd.kada.main.ui.story;

import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.PayAPI;
import com.hhdd.kada.base.BaseFragment;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.event.BookSubscribeStatusEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SubscribeSuccessEvent;
import com.hhdd.kada.main.event.TalentPaySucceedEvent;
import com.hhdd.kada.main.event.UpdateMainTabEvent;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.model.TalentPlanCollectInfo;
import com.hhdd.kada.main.settings.UserSettings;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.talentplan.fragment.TalentPlanSetBabyDateFragment;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.kada.store.event.OrderStatusChangedEvent;
import com.hhdd.kada.store.model.OrderFragParamData;
import com.hhdd.kada.store.model.VirtualOrderListInfo;

import butterknife.BindView;

/**
 * Created by MCX on 2017/5/3.
 */

public class PaySucceedFragment extends BaseFragment {

    @BindView(R.id.paySuccessImageBgView)
    ImageView paySuccessImageBgView;
    @BindView(R.id.titleTextView)
    TextView titleTextView;
    @BindView(R.id.paySuccessImageView)
    ImageView paySuccessImageView;
    @BindView(R.id.countDownTextView)
    TextView countDownTextView;
    @BindView(R.id.descriptionTextView)
    TextView descriptionTextView;

    int mCollectionId;
    private OrderFragParamData fragParamData;
    private VirtualOrderListInfo.OrderItemInfo orderItemInfo;
    private int orderId;
    private int delayCount;
    private int payChannel; // 支付渠道  1 支付宝 2 微信  4 华为

    // 倒计时时长 单位秒
    private static final int TIME = 3;

    @Override
    public void onEnter(Object data) {
        if (data != null && data instanceof OrderFragParamData) {
            fragParamData = (OrderFragParamData) data;
            orderId = ((OrderFragParamData) data).getOrderId();
            mCollectionId = fragParamData.getCollectId();
            payChannel = fragParamData.getPayChannel();
        }
        if (data != null && data instanceof VirtualOrderListInfo.OrderItemInfo) {
            orderItemInfo = (VirtualOrderListInfo.OrderItemInfo) data;
            mCollectionId = orderItemInfo.getCollectId();
            orderId = ((VirtualOrderListInfo.OrderItemInfo) data).getId();
            payChannel = orderItemInfo.getPayChannel();
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_pay_result_succeed;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        RelativeLayout.LayoutParams bgImageParams = (RelativeLayout.LayoutParams) paySuccessImageBgView.getLayoutParams();
        bgImageParams.width = LocalDisplay.SCREEN_WIDTH_PIXELS;
        bgImageParams.height = bgImageParams.width * 332 / 375;
    }

    @Override
    public void doInitData() {
        super.doInitData();
        delay();
    }

    /**
     * 延迟操作 3s后关闭当前页面
     */
    private void delay() {
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                delayCount++;
                if (delayCount == TIME) {
                    doPaySuccessOperate();
                } else {
                    countDownTextView.setText(String.format(KaDaApplication.instance.getResources().
                            getString(R.string.pay_success_countdown_text), String.valueOf(TIME - delayCount)));
                    descriptionTextView.setText(String.format(KaDaApplication.instance.getResources().
                            getString(R.string.pay_success_countdown_text_2), String.valueOf(TIME - delayCount)));
                    delay();
                }
            }
        }, 1000);
    }

    /**
     * 支付成功相关操作
     */
    private void doPaySuccessOperate() {
        //如果是从详情页跳转至支付页面 则直接返回
        //若是从订单页面跳转至支付页面 这跳转至详情页

        EventCenter.fireEvent(new OrderStatusChangedEvent(VirtualOrderListInfo.ORDER_STATUS_PAID));

        int orderType = getType();
        switch (orderType) {
            case PayAPI.TYPE_ORDER_BOOK:
                EventCenter.fireEvent(new BookSubscribeStatusEvent(mCollectionId, 1));
                if (orderItemInfo != null) {
                    FragmentUtil.pushFragment(BookCollectionFragment.class, new BaseCollectionFragment.CollectionModel(mCollectionId, false), true);
                }
                break;
            case PayAPI.TYPE_ORDER_STORY:
                EventCenter.fireEvent(new SubscribeSuccessEvent(mCollectionId));
                if (orderItemInfo != null) {
                    FragmentUtil.pushFragment(StoryCollectionFragment.class, mCollectionId, true);
                }
                break;
            case PayAPI.TYPE_ORDER_TALENT_PLAN:
                UserDetail.UserInfo userInfo = UserService.getInstance().getUserInfo();
                if (userInfo != null) {
                    userInfo.setSubscribePlan(true);
                }
                EventCenter.fireEvent(new TalentPaySucceedEvent());
                UserSettings.getInstance().setBookFragmentShowTalentPlan(true);
                EventCenter.fireEvent(new UserSettings.UserSettingsChangedEvent());
                EventCenter.fireEvent(new UpdateMainTabEvent(1,false,0));

                FragmentUtil.pushFragment(TalentPlanSetBabyDateFragment.class, null, true);
                break;
            default:
                break;
        }
        finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getHandler().removeCallbacksAndMessages(null);

    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(orderId +
                    "," + getType() + "," + mCollectionId + "," + payChannel, StaPageName.payment_result_success_view, TimeUtil.currentTime()));
            UserHabitService.getInstance().immediatelyUpload();
        }
    }

    /**
     * 获取订单类型 绘本 听书 优才计划
     * @return
     */
    private int getType() {
        int type = 0;
        if (fragParamData != null && fragParamData.getOrderDetail() != null) {
            if (fragParamData.getOrderDetail() instanceof BookCollectionDetailInfo) {
                type = PayAPI.TYPE_ORDER_BOOK;
            } else if (fragParamData.getOrderDetail() instanceof StoryCollectionDetail) {
                type = PayAPI.TYPE_ORDER_STORY;
            } else if (fragParamData.getOrderDetail() instanceof TalentPlanCollectInfo) {
                type = PayAPI.TYPE_ORDER_TALENT_PLAN;
            }
        } else if (orderItemInfo != null) {
            if (orderItemInfo.getCollectType() == VirtualOrderListInfo.BOOK_ORDER) {
                type = PayAPI.TYPE_ORDER_BOOK;
            } else if (orderItemInfo.getCollectType() == VirtualOrderListInfo.STORY_ORDER) {
                type = PayAPI.TYPE_ORDER_STORY;
            } else if (orderItemInfo.getCollectType() == VirtualOrderListInfo.TALENT_PLAN_ORDER) {
                type = PayAPI.TYPE_ORDER_TALENT_PLAN;
            }
        }
        return type;
    }

    private void finish() {
        if (getContext() != null && !getContext().isFinishing()) {
            getContext().finish();
        }
    }

    @Override
    public boolean processBackPressed() {
        return true;
    }
}
