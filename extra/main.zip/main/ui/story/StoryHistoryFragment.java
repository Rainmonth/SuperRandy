package com.hhdd.kada.main.ui.story;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.StoryService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.db.main.entities.ListenHistory;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.RequestStoryHistoryListEvent;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.event.StoryHistoryUpdateEvent;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryHistoryInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.StoryHistoryViewHolder;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.views.NoDoubleClickListener;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.widget.support.KdGridLayoutManager;
import com.hhdd.logger.LogHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static com.hhdd.kada.Constants.PAUSE_MODE;
import static com.hhdd.kada.Constants.PLAY_MODE;
import static com.hhdd.kada.Constants.STOP_MODE;

/**
 * Created by lj on 17/2/7.
 */

public class StoryHistoryFragment extends RecyclerDataListFragment2 {

    static final int View_Type_Item = 100;

    List<BaseModel> dataList = new ArrayList<>();
    List<com.hhdd.core.model.StoryInfo> oldHistoryList = new ArrayList<>();

    BaseViewHolderCreator viewHolderCreator;
    private ImageView btnBack;
    private TextView historyNum;
    private TextView historyTime;

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case StoryHistoryViewHolder.TYPE_STORY_HISTORY_ITEM_CLICKED:
                    try {
                        StoryHistoryInfo storyHistoryInfo = (StoryHistoryInfo) args[0];
                        processStoryHistoryItemClicked(storyHistoryInfo);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    return true;
            }
            return false;
        }
    };

    public StoryHistoryFragment() {
        super(LIST_MODE_NONE, "", null);
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }

        initView();

        showLoadingView();
        reloadData();

        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {

            public void onEvent(StoryService.StartReadingEvent event) {
                resetPlayList(event.getStoryInfo(), PLAY_MODE);
            }

            public void onEvent(StoryService.PauseReadingEvent event) {
                resetPlayList(event.getStoryInfo(), PAUSE_MODE);
            }

            public void onEvent(StoryService.StopReadingEvent event) {
                resetPlayList(event.getStoryInfo(), STOP_MODE);
            }

            public void onEvent(StoryHistoryUpdateEvent event) {
                reloadHistoryData();
            }

        }).tryToRegisterIfNot();
    }

    private StrongReference<DefaultCallback<UserDetail>> mLoadUserDetailCallbackRef;

    private void reloadData() {

        historyNum.setText(KaDaApplication.getInstance().getResources().getString(R.string.story_history_title_count, UserService.getInstance().currentUserListenNumber()));
        long time = UserService.getInstance().currentUserListenTimes();
        historyTime.setText(KaDaApplication.getInstance().getResources().getString(R.string.story_history_title_time, TimeUtil.formatListenTime(time / 1000)));


        DefaultCallback<UserDetail> callback = new DefaultCallback<UserDetail>() {
            @Override
            public void onDataReceived(UserDetail data) {
                if (data != null) {
                    UserService.getInstance().setUserDetail(data);
                    historyNum.setText(KaDaApplication.getInstance().getResources().getString(R.string.story_history_title_count, data.getReadInfo().getStoryCount()));
                    long time = data.getReadInfo().getStoryTime();
                    historyTime.setText(KaDaApplication.getInstance().getResources().getString(R.string.story_history_title_time, TimeUtil.formatListenTime(time / 1000)));
                }
            }

            @Override
            public void onException(String reason) {
                super.onException(reason);
            }
        };
        if (mLoadUserDetailCallbackRef == null) {
            mLoadUserDetailCallbackRef = new StrongReference<>();
        }
        mLoadUserDetailCallbackRef.set(callback);

        UserService.getInstance().loadUserDetail(mLoadUserDetailCallbackRef, false);

        // 先加载本地数据库数据
        reloadHistoryData();

        // 延时200ms 提交听书历史记录和同步服务端数据
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                EventCenter.fireEvent(new RequestStoryHistoryListEvent());
            }
        }, 200);
    }


    void initView() {
        initTitleBar();

        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(View_Type_Item, StoryHistoryViewHolder.class);
        viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(viewHolderCreator);

        getmListView().setLayoutManager(new KdGridLayoutManager(getContext(), 3));
        getmListView().setPadding(LocalDisplay.dp2px(3), 0, LocalDisplay.dp2px(3), 0);
    }

    protected void initTitleBar() {
        View headview = inflater.inflate(R.layout.activitiy_history_headview, null);
        btnBack = (ImageView) headview.findViewById(R.id.back);
        historyNum = (TextView) headview.findViewById(R.id.listen_num);
        historyTime = (TextView) headview.findViewById(R.id.listen_time);
        btnBack.setOnClickListener(new NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                onBackPressed();
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            headview.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
            ViewGroup.LayoutParams layoutParams = headview.getLayoutParams();
            if (layoutParams==null){
                layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            layoutParams.height = LocalDisplay.dp2px(80)+LocalDisplay.SCREEN_STATUS_HEIGHT;
            headview.setLayoutParams(layoutParams);
            setInnerViewPadding(0, LocalDisplay.dp2px(80) + LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
        }else {
            setInnerViewPadding(0, LocalDisplay.dp2px(80) , 0, 0);
        }
        getInnerContainer().addView(headview);
    }

    private static class LoadHistoryDataFlowableOnSubscribe implements FlowableOnSubscribe<List<StoryHistoryInfo>> {

        @Override
        public void subscribe(FlowableEmitter<List<StoryHistoryInfo>> e) throws Exception {
            List<ListenHistory> historyVOList = DatabaseManager.getInstance().listenhistoryDB().query(-1);
            if (historyVOList != null && historyVOList.size() > 0) {
                List<StoryHistoryInfo> listenHistoryInfos = StoryHistoryInfo.createByHistory(historyVOList);
                e.onNext(listenHistoryInfos);
            } else {
                e.onNext(new ArrayList<StoryHistoryInfo>());
            }
            e.onComplete();
        }
    }

    void reloadHistoryData() {

        //========历史听书=========
        Flowable.create(new LoadHistoryDataFlowableOnSubscribe(), BackpressureStrategy.BUFFER)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<StoryHistoryInfo>>() {
                    @Override
                    public void accept(List<StoryHistoryInfo> tmphistoryList) throws Exception {
                        dataList.clear();
                        if (tmphistoryList != null && tmphistoryList.size() > 0) {
                            List<BaseModel> historyList = new ArrayList<>();
                            for (int i = 0; i < tmphistoryList.size(); i++) {
                                tmphistoryList.get(i).setIndex(i);
                                StoryListItem item = new StoryListItem(tmphistoryList.get(i).getType(), tmphistoryList.get(i));
                                BaseModelVO vo = new BaseModelVO(item, View_Type_Item);
                                historyList.add(vo);
                            }
                            dataList.addAll(historyList);
                            reloadData(historyList);

                            if (ListenManager.getInstance().isPlaying() || !ListenManager.getInstance().isPause()) {
                                resetPlayList(ListenManager.getInstance().getCurrentStoryInfo(), PLAY_MODE);
                            }

                            oldHistoryList.clear();
                            for (int i = 0; i < tmphistoryList.size(); i++) {
                                oldHistoryList.add(com.hhdd.core.model.StoryInfo.createInfoByHistory(tmphistoryList.get(i)));
                            }
                        }
                    }
                });
    }

    private void processStoryHistoryItemClicked(StoryHistoryInfo storyHistoryInfo) {
        if (storyHistoryInfo == null) {
            return;
        }

        Activity activity = getContext();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (storyHistoryInfo.getType() == Constants.TYPE_STORY_COLLECT) {
            UserHabitService.getInstance().track(UserHabitService.newUserHabit("2," + storyHistoryInfo.getCollectId() + "", "child_story_history_list_click_" + storyHistoryInfo.getIndex(), TimeUtil.currentTime()));
            FragmentUtil.presentFragment(StoryCollectionFragment.class, new BaseCollectionFragment.CollectionModel(storyHistoryInfo.getCollectId(), true), true);
        } else {
            UserHabitService.getInstance().track(UserHabitService.newUserHabit("1," + storyHistoryInfo.getStoryId() + "", "child_story_history_list_click_" + storyHistoryInfo.getIndex(), TimeUtil.currentTime()));
            if (oldHistoryList != null) {
                //数据量太大 取200本
                if (oldHistoryList.size() > 210) {
                    com.hhdd.core.model.StoryInfo oldStoryInfo = com.hhdd.core.model.StoryInfo.createInfoByHistory(storyHistoryInfo);
                    List<com.hhdd.core.model.StoryInfo> tmpList = new ArrayList<>();
                    int index = oldHistoryList.indexOf(oldStoryInfo);
                    if (index < 100) {
                        tmpList.addAll(oldHistoryList.subList(0, 200));
                    } else if (oldHistoryList.size() - index < 100) {
                        tmpList.addAll(oldHistoryList.subList(oldHistoryList.size() - 200, oldHistoryList.size()));
                    } else {
                        tmpList.addAll(oldHistoryList.subList(index - 100, index + 100));
                    }
                    ListenActivity.startActivity(activity, storyHistoryInfo.getStoryId(), storyHistoryInfo.getReadCurrentTime(), tmpList);
                } else {
                    ListenActivity.startActivity(activity, storyHistoryInfo.getStoryId(), storyHistoryInfo.getReadCurrentTime(), oldHistoryList);
                }
            }
        }
    }

    void resetPlayList(com.hhdd.core.model.StoryInfo playStoryInfo, int mode) {
        if (playStoryInfo != null) {
            List reassembledList = getDataListDisplayed().getDataList();
            if (reassembledList != null && reassembledList.size() > 0) {
                for (int i = 0; i < reassembledList.size(); i++) {
                    if (reassembledList.get(i) instanceof BaseModelVO) {
                        BaseModelVO modelVO = (BaseModelVO) reassembledList.get(i);
                        if (modelVO.getModel() != null && modelVO.getModel() instanceof StoryListItem) {
                            StoryListItem item = (StoryListItem) modelVO.getModel();
                            if (mode == STOP_MODE) {
                                item.setPlayMode(mode);
                            } else {
                                if (item.getData() != null && item.getData() instanceof StoryHistoryInfo) {
                                    StoryHistoryInfo info = (StoryHistoryInfo) item.getData();
                                    if (info.getStoryId() == playStoryInfo.getId()) {
                                        item.setPlayMode(mode);
                                    } else if (playStoryInfo.getCollectionId() != 0 && info.getCollectId() == playStoryInfo.getCollectionId()) {
                                        item.setPlayMode(mode);
                                    } else {
                                        item.setPlayMode(STOP_MODE);
                                    }
                                }
                            }
                        }
                    }
                }

                notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_story_history_list_view", TimeUtil.currentTime()));
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if (mLoadUserDetailCallbackRef != null) {
            mLoadUserDetailCallbackRef.clear();
            mLoadUserDetailCallbackRef = null;
        }
    }
}
