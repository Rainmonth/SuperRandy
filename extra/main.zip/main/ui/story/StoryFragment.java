package com.hhdd.kada.main.ui.story;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.StoryService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.URLScheme;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.android.library.views.list.RecyclerPagedListDataAdapter;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.BannerAPI;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.db.main.entities.CollectionCountInfo;
import com.hhdd.kada.db.main.entities.ListenHistory;
import com.hhdd.kada.main.common.DataListModel;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.event.CancelSubscribeEvent;
import com.hhdd.kada.main.event.ConnectivityChangedEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LimitFreeEndedEvent;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.SameAccountUnifySuccessEvent;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.event.StoryHistoryUpdateEvent;
import com.hhdd.kada.main.event.SubscribeSuccessEvent;
import com.hhdd.kada.main.event.UserSubscribeChangeEvent;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.RedirectPositionSubjectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryHistoryInfo;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.model.SubscribeStoryInfo;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.settings.UserSettings;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.ui.dialog.ChildrenLockDialog;
import com.hhdd.kada.main.ui.viewholder.ShelfTitleViewHolder;
import com.hhdd.kada.main.utils.LocalSubscribeUtil;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.MotherExcellentSubjectViewHolder;
import com.hhdd.kada.main.viewholders.OldBannerViewHolder;
import com.hhdd.kada.main.viewholders.StoryCircleCateViewHolder;
import com.hhdd.kada.main.viewholders.StoryCollectionOneColViewHolder;
import com.hhdd.kada.main.viewholders.StoryCollectionTwoColViewHolder;
import com.hhdd.kada.main.viewholders.StoryConfigPositionViewHolder;
import com.hhdd.kada.main.viewholders.StoryHomeHistoryViewHolder;
import com.hhdd.kada.main.viewholders.StoryListViewHolder;
import com.hhdd.kada.main.viewholders.StorySchemaTwoColViewHolder;
import com.hhdd.kada.main.viewholders.SubscribeListViewHolder;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.views.CommonHeaderView;
import com.hhdd.kada.main.views.FastScrollLinearLayoutManager;
import com.hhdd.kada.main.views.SubscribeLoadingMoreFooter;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.main.vo.ViewTypes;
import com.hhdd.kada.medal.UserTrack;
import com.hhdd.kada.module.exposure.ExposureTracker;
import com.hhdd.kada.module.exposure.OldBannerShownOnScreenEvent;
import com.hhdd.kada.module.shelf.ShelfActivity;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.kada.record.callback.ChildrenDialogCallback;
import com.hhdd.logger.LogHelper;
import com.jcodecraeer.xrecyclerview.XRecyclerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.greenrobot.event.EventBus;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static com.hhdd.kada.Constants.PAUSE_MODE;
import static com.hhdd.kada.Constants.PLAY_MODE;
import static com.hhdd.kada.Constants.STOP_MODE;
import static com.hhdd.kada.main.vo.ViewTypes.View_Type_DataList_StoryList;

/**
 * Created by lj on 17/4/17.
 */

public class StoryFragment extends RecyclerDataListFragment2 {
    private StrongReference<DefaultCallback> configStrongReference;
    private CommonHeaderView commonHeaderView;
    List<BaseVO> bannerInfoList = new ArrayList<>();
    private ImageView floatIcon;
    private View floatLayout;

    //    private ChildrenLockDialog mChildrenLockDialog;
    private boolean needPlayTipAinm = true;

    private static final int FIXED_HOLDER_COUNT = 1;   //页面固定的holder数目

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case ShelfTitleViewHolder.TYPE_MANAGE_CLICKED:
                    processShelfManageClick(true);
                    return true;
                case SubscribeListViewHolder.TYPE_STORY_SHELF_CLICKED:
                    processShelfManageClick(false);
                    return true;
                case SubscribeListViewHolder.TYPE_STORY_SUBSCRIBE_LIST_ITEM_CLICKED:
                    if (args != null && args.length > 0) {
                        if (args[0] instanceof StoryListItem) {
                            processSubscribeListItemClick((StoryListItem) args[0]);
                        }
                    }
                    return true;
                case StoryListViewHolder.TYPE_STORY_LIST_ITEM_CLICKED:
                    try {
                        processStoryItemClicked((StoryListItem) args[0]);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    return true;

                case StoryHomeHistoryViewHolder.TYPE_STORY_HOME_HISTORY_ITEM_CLICKED:
                    try {
                        processHistoryItemClicked((int) args[0], (StoryListItem) args[1]);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    return true;
            }

            return false;
        }
    };

    public static StoryFragment newInstance(Bundle bundle) {
        StoryFragment fragment = new StoryFragment();
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        return fragment;
    }

    public StoryFragment() {
        super(LIST_MODE_BOTH, "", null);
    }

    DataListModel dataListModel;
    API.PaginationUrlAPI listAPI;
    API.UrlAPI subscribeApi;

    List<com.hhdd.core.model.StoryInfo> oldStoryInfoList = new ArrayList<com.hhdd.core.model.StoryInfo>();
    List<com.hhdd.core.model.StoryInfo> oldHistoryList = new ArrayList<>();

    List<BaseVO> reassembledList = new ArrayList<>();
    List<BaseModel> subscribeList = new ArrayList<>();
    List<BaseModel> historyList = new ArrayList<>();
    View tipView;
    ObjectAnimator animator;

    public static final int View_Type_Story_Reading_History = 101;      // 阅读历史ViewHolder
    public static final int View_Type_Story_Shelf_Title = 102;          // 左标题有按钮ViewHolder
    public static final int View_Type_DataList_Old_Banner = 104;        // Banner列表ViewHolder
    public static final int View_Type_Story_Circle_Cate = 105;          // 听书分类ViewHolder
    public static final int View_Type_Story_My_Book_Shelf = 103;        // 我的书架ViewHolder
    //    static final int View_Type_Story_Ad = 106;
    public static final int View_Type_Story_Collection_One_Col = 107;   // 故事合集-单列ViewHolder
    public static final int View_Type_Story_Collection_Two_Col = 108;   // 故事合集-两列ViewHolder

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }

        Map<Integer, Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
        viewTypeMaps.put(ViewTypes.View_Type_DataList_StoryList.getId(), StoryListViewHolder.class);
        viewTypeMaps.put(View_Type_DataList_Old_Banner, OldBannerViewHolder.class);
        viewTypeMaps.put(View_Type_Story_Circle_Cate, StoryCircleCateViewHolder.class);
        viewTypeMaps.put(View_Type_Story_Shelf_Title, ShelfTitleViewHolder.class);
        viewTypeMaps.put(View_Type_Story_My_Book_Shelf, SubscribeListViewHolder.class);
        viewTypeMaps.put(View_Type_Story_Reading_History, StoryHomeHistoryViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_Story_Simple_Image_Title.getId(), MotherExcellentSubjectViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_Story_Config_Position_Title.getId(), StoryConfigPositionViewHolder.class);
        viewTypeMaps.put(View_Type_Story_Collection_One_Col, StoryCollectionOneColViewHolder.class);
        viewTypeMaps.put(View_Type_Story_Collection_Two_Col, StoryCollectionTwoColViewHolder.class);
        viewTypeMaps.put(ViewTypes.View_Type_Story_Schema_Two_Col.getId(), StorySchemaTwoColViewHolder.class);

        BaseViewHolderCreator viewHolderCreator = new BaseViewHolderCreator(this, viewTypeMaps);
        viewHolderCreator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(viewHolderCreator);

        FastScrollLinearLayoutManager manager = new FastScrollLinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false);
        getmListView().setLayoutManager(manager);

        initFloatLayout();
        loadTitleBarData();

        showLoadingView();
        loadLookAroundData();

        if (!NetworkUtils.isReachable() && tipView.getVisibility() == View.GONE) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.network_not_connect, TimeUtil.currentTime()));
            startShowTipViewAnim();
        } else if (NetworkUtils.isReachable() && tipView.getVisibility() == View.VISIBLE) {
            startGoneTipViewAnim();
        }

        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {

            public void onEvent(ConnectivityChangedEvent event) {
                if (event.isConnected) {
                    if (getmListView().getAdapter().getItemCount() == 0) {
                        doRefresh();
                    }
                    if (tipView.getVisibility() == View.VISIBLE) {
                        startGoneTipViewAnim();
                    }
                } else if (tipView.getVisibility() == View.GONE) {
                    //执行tip弹出动画
                    startShowTipViewAnim();
                }
            }

            public void onEvent(StoryService.StartReadingEvent event) {
                resetPlayList(event.getStoryInfo(), PLAY_MODE);
            }

            public void onEvent(StoryService.PauseReadingEvent event) {
                resetPlayList(event.getStoryInfo(), PAUSE_MODE);
            }

            public void onEvent(UserSettings.SubscribedCollectionIdChangedEvent event) {
                if (event.type == 2) {
                    notifyDataSetChanged();
                }
            }

            public void onEvent(StoryService.StopReadingEvent event) {
                resetPlayList(event.getStoryInfo(), STOP_MODE);
            }

            public void onEvent(StoryHistoryUpdateEvent event) {
                reloadHistoryData();
            }

            public void onEvent(LoginEvent event) {
                loadLookAroundData();
            }

            public void onEvent(AuthService.AuthorizedSuccessEvent event) {
                loadLookAroundData();
            }

            public void onEvent(SubscribeSuccessEvent event) {
                if (event.collectId > 0) {
                    LocalSubscribeUtil.addStorySubscribeId(event.collectId);
                }
                loadSubscribeList();
            }

            public void onEvent(CancelSubscribeEvent event) {
                LocalSubscribeUtil.removeBookSubscribeId(event.getCollectId());
                loadSubscribeList();
            }

            public void onEvent(UserSubscribeChangeEvent event) {
                loadSubscribeList();
            }

            public void onEvent(SameAccountUnifySuccessEvent event) {
                loadSubscribeList();
            }

            public void onEvent(LimitFreeEndedEvent event) {
                // 更新列表
                LogHelper.d("Randy", "StoryFragment接受到事件LimitFreeEndedEvent，限免结束");
                doRefresh();
            }

        }).tryToRegisterIfNot();

    }

    private void initFloatLayout() {
        //浮动icon
        floatLayout = LayoutInflater.from(getContext()).inflate(R.layout.list_float_layout, null);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.BOTTOM;
        getInnerContainer().addView(floatLayout, lp);
        floatIcon = (ImageView) floatLayout.findViewById(R.id.float_icon);
        floatIcon.setVisibility(View.VISIBLE);
        floatIcon.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                isTouched = true;
                floatIcon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.youyu_move));
                getmListView().smoothScrollToPosition(0);
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_story_home_back_top_click", TimeUtil.currentTime()));
            }
        });
        floatLayout.setVisibility(View.GONE);
    }


    @Override
    protected void initListViewFooter(XRecyclerView listView) {
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }
        final SubscribeLoadingMoreFooter footer = new SubscribeLoadingMoreFooter(getContext());
        footer.setType(SubscribeLoadingMoreFooter.TYPE_STORY);

        footerView = footer;
        listView.setFootView(footer);
    }

    protected void loadTitleBarData() {

        tipView = LayoutInflater.from(getContext()).inflate(R.layout.view_holder_without_net, null, false);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LocalDisplay.dp2px(30));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            layoutParams.topMargin = LocalDisplay.dp2px(35) + LocalDisplay.SCREEN_STATUS_HEIGHT;
        } else {
            layoutParams.topMargin = LocalDisplay.dp2px(35);
        }
        tipView.setLayoutParams(layoutParams);

        TextView btnSet = (TextView) tipView.findViewById(R.id.btn_set);
        btnSet.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.network_not_connect_click, TimeUtil.currentTime()));
                Intent intent = new Intent(android.provider.Settings.ACTION_SETTINGS);
                getContext().startActivity(intent);
            }
        });

        tipView.setVisibility(View.GONE);
        getInnerContainer().addView(tipView);

        getTitleBar().removeAllViews();
        getTitleBar().setVisibility(View.GONE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            View statusView = new View(getActivity());
            statusView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LocalDisplay.SCREEN_STATUS_HEIGHT));
            statusView.setBackgroundColor(KaDaApplication.getInstance().getResources().getColor(R.color.color_4abbf6));
            getInnerContainer().addView(statusView);
            getInnerContainer().addView(commonHeaderView = new CommonHeaderView(getActivity()));
            commonHeaderView.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
            commonHeaderView.setType(CommonHeaderView.TYPE_STORY);
            setInnerViewPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT + KaDaApplication.getInstance().getResources().getDimensionPixelOffset(R.dimen.tab_activity_bottom_small_height), 0, 0);

        } else {
            getInnerContainer().addView(commonHeaderView = new CommonHeaderView(getActivity()));
            commonHeaderView.setType(CommonHeaderView.TYPE_STORY);
            setInnerViewPadding(0, KaDaApplication.getInstance().getResources().getDimensionPixelOffset(R.dimen.tab_activity_bottom_small_height), 0, 0);
        }
    }

    /**
     * 获取banner数据
     */
    void loadBannerData() {
        BannerAPI.getStoryBanner(new API.CachedResponseHandler<List<BannerInfo>>() {
            @Override
            public void onFirstLoadFromCache(List<BannerInfo> cachedData) {
                updateBannerInfo(cachedData);
            }

            @Override
            public void onSuccess(List<BannerInfo> responseData) {
                updateBannerInfo(responseData);
            }

            @Override
            public void onFailure(int code, String message) {
            }
        });
    }

    /**
     * 更新banner数据
     *
     * @param data
     */
    private synchronized void updateBannerInfo(List<BannerInfo> data) {
        bannerInfoList.clear();
        if (data != null && data.size() > 0) {
            BaseModelListVO modelListVO = new BaseModelListVO();
            modelListVO.setViewType(View_Type_DataList_Old_Banner);
            modelListVO.getItemList().addAll(data);
            bannerInfoList.add(modelListVO);
        }
        getHandler().post(new Runnable() {
            @Override
            public void run() {
                reloadDataImpl();
            }
        });
    }

    private List<BaseVO> configList = new ArrayList<>();

    /**
     * 加载听书配置数据
     * 可能的配置项包括如下内容：
     * 1. 复杂标题，对应Type为View_Type_Story_Complex_Title
     * 2. 单个大图，对应Type为View_Type_Story_Collection_One_Col
     * 3. 2*2方形，对应Type为View_Type_Story_Collection_Two_Col
     * 4. 2*2协议，对应Type为View_Type_Story_Schema_Two_Col
     */
    private void loadStoryConfigData() {
        if (configStrongReference == null) {
            configStrongReference = new StrongReference<>();
        }
        DefaultCallback<List<BaseModelListVO>> configDefaultCallback = new DefaultCallback<List<BaseModelListVO>>() {

            @Override
            public void onLoadFromCache(final List<BaseModelListVO> cacheData) {
                super.onLoadFromCache(cacheData);
                if (null != cacheData) {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            assembleConfigStoryList(cacheData);
                        }
                    });
                }
            }

            @Override
            public void onDataReceived(final List<BaseModelListVO> data) {
                if (data == null || data.isEmpty()) {
                    return;
                }

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        assembleConfigStoryList(data);
                        handleLoadComplete(false);
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(code, reason);
                handleErrorOccurred(true, 0, "加载失败");
            }
        };
        configStrongReference.set(configDefaultCallback);
        StoryAPI.getStoryHomeConfig(configStrongReference);
    }

    private synchronized void assembleConfigStoryList(List<BaseModelListVO> list) {
        if (list != null && list.size() > 0) {
            configList.clear();
            for (BaseModelListVO modelListVO : list) {
                int type = modelListVO.getViewType();
                switch (type) {
                    case View_Type_Story_Circle_Cate:
                    case View_Type_Story_Collection_One_Col:
                    case View_Type_Story_Collection_Two_Col:
                        configList.add(modelListVO);
                        break;
                    default:
                        break;
                }
                if (type == ViewTypes.View_Type_Story_Simple_Image_Title.getId()) {
                    configList.add(modelListVO);
                } else if (type == ViewTypes.View_Type_Story_Schema_Two_Col.getId()) {
                    configList.add(modelListVO);
                } else if (type == ViewTypes.View_Type_Story_Config_Position_Title.getId()) {
                    configList.add(modelListVO);
                }

            }
            reloadDataImpl();
        }
    }

    /**
     * 这里加载随便听听的数据
     */
    void loadLookAroundData() {
        listAPI = new StoryAPI.RecommendPaginationListAPI("story2", "getStoryList.json", Settings.getInstance().getStoryAgeType());
        dataListModel = new DataListModel(listAPI, 60);
        reloadData(dataListModel);
    }

    @Override
    public void handleErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg) {
        super.handleErrorOccurred(isFirstPage, errorCode, errorMsg);
        if (getDataListDisplayed().getDataList().size() > FIXED_HOLDER_COUNT) {
            mLoadingView.hide();
        }
        if (isFirstPage) {
            getmListView().setPullRefreshEnabled(true);
        }
    }

    @Override
    protected void doRefresh() {
        super.doRefresh();
        if (!((AuthService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.AUTH_SERVICE)).isAuthorized()) {
            return;
        }
        commonHeaderView.upDateCoinCount();
        loadBannerData();
        loadSubscribeList();
        reloadHistoryData();
        loadStoryConfigData();
    }

    void loadSubscribeList() {
        subscribeApi = StoryAPI.storyAPI_subscribeList();
        subscribeApi.get(new API.CachedResponseHandler<SubscribeStoryInfo>() {
            @Override
            public void onFirstLoadFromCache(SubscribeStoryInfo cachedData) {
                updateSubscribeInfo(cachedData);
            }

            @Override
            public void onSuccess(SubscribeStoryInfo responseData) {
                updateSubscribeInfo(responseData);
            }

            @Override
            public void onFailure(int code, String message) {
                reloadDataImpl();
            }
        });
    }

    /**
     * 更新书架订阅数据
     *
     * @param data
     */
    private synchronized void updateSubscribeInfo(SubscribeStoryInfo data) {
        subscribeList.clear();
        if (data != null) {
            List<StoryListItem> chargeList = data.getChargeList();
            if (chargeList != null && chargeList.size() > 0) {
                subscribeList.addAll(chargeList);
            }
            List<StoryListItem> freeList = data.getFreesList();
            if (freeList != null && freeList.size() > 0) {
                subscribeList.addAll(freeList);
            }
        }
        getHandler().post(new Runnable() {
            @Override
            public void run() {
                reloadDataImpl();
            }
        });
    }

    private static class LoadHistoryDataFlowableOnSubscribe implements FlowableOnSubscribe<List<StoryHistoryInfo>> {
        @Override
        public void subscribe(FlowableEmitter<List<StoryHistoryInfo>> e) throws Exception {
            List<ListenHistory> historyVOList = DatabaseManager.getInstance().listenhistoryDB().query(-1);
            if (historyVOList != null && historyVOList.size() > 0) {
                List<StoryHistoryInfo> listenHistoryInfos = StoryHistoryInfo.createByHistory(historyVOList);
                e.onNext(listenHistoryInfos);
            } else {
                e.onNext(new ArrayList<StoryHistoryInfo>());
            }
            e.onComplete();
        }
    }

    void reloadHistoryData() {
        //========历史听书=========
        Flowable.create(new LoadHistoryDataFlowableOnSubscribe(), BackpressureStrategy.BUFFER)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new Consumer<List<StoryHistoryInfo>>() {
                    @Override
                    public void accept(List<StoryHistoryInfo> tmphistoryList) throws Exception {
                        historyList.clear();
                        if (tmphistoryList != null && tmphistoryList.size() > 0) {
                            for (int i = 0; i < tmphistoryList.size(); i++) {
                                StoryListItem item = new StoryListItem(tmphistoryList.get(i).getType(), tmphistoryList.get(i));
                                historyList.add(item);
                            }
                            oldHistoryList.clear();
                            for (int i = 0; i < tmphistoryList.size(); i++) {
                                oldHistoryList.add(com.hhdd.core.model.StoryInfo.createInfoByHistory(tmphistoryList.get(i)));
                            }
                        }
                        reloadDataImpl();
                    }
                });
    }

    synchronized void reloadDataImpl() {
        List<BaseVO> dataList = getDataListDisplayed().getDataList();
        dataList.clear();

        updateList(dataList);

        dataList.addAll(reassembledList);

        //这里如果只有View_Type_Story_Title一个holder，则证明无数据，就不展示
        if (dataList.size() > FIXED_HOLDER_COUNT) {
            notifyDataSetChanged();
        } else {
            handleErrorOccurred(true, 0, "加载数据为空");
        }

        if (ListenManager.getInstance().isPlaying() || !ListenManager.getInstance().isPause()) {
            resetPlayList(ListenManager.getInstance().getCurrentStoryInfo(), PLAY_MODE);
        }
    }

    /**
     * 更新列表数据
     *
     * @param dataList
     */
    private void updateList(List<BaseVO> dataList) {
        if (bannerInfoList != null && bannerInfoList.size() > 0) {
            dataList.addAll(bannerInfoList);
        }

        if (subscribeList != null && !subscribeList.isEmpty()) {
            BaseModelVO baseVO = new BaseModelVO();
            baseVO.setViewType(View_Type_Story_Shelf_Title);
            RedirectInfo redirectInfo = new RedirectInfo();
            redirectInfo.setTitle("我的书架");
            redirectInfo.setImageUrl("res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.icon_story_collect);
            redirectInfo.setRedirectUri("toStoryShelf");//只要不为空就行
            baseVO.setModel(redirectInfo);
            dataList.add(baseVO);

            List<BaseVO> dataListTmp = new ArrayList<BaseVO>();
            List<BaseModel> singleLineTmp = new ArrayList<BaseModel>();
            for (int i = 0; i < Math.min(subscribeList.size(), 8); i++) {//最多显示8个，再多就显示“更多”-跳转书架
                subscribeList.get(i).setIndex(i);
                singleLineTmp.add(subscribeList.get(i));
                if (singleLineTmp.size() >= 3) {
                    BaseModelListVO vo = new BaseModelListVO(View_Type_Story_My_Book_Shelf, singleLineTmp);
                    dataListTmp.add(vo);
                    singleLineTmp.clear();
                }
            }

            if (subscribeList.size() > 8) {
                RedirectInfo info = new RedirectInfo();
                info.setRedirectUri(URLScheme.SCHEMA + "://" + URLScheme.REDIRECT_URI_FORMAT_OPENSTORYSHELF);
                info.setImageUrl("res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.story_shelf_more);
                singleLineTmp.add(info);
            }

            // 对不足3条的添加list
            if (!singleLineTmp.isEmpty()) {
                BaseModelListVO modelListVO = new BaseModelListVO(View_Type_Story_My_Book_Shelf, singleLineTmp);
                singleLineTmp.clear();
                dataListTmp.add(modelListVO);
            }

            dataList.addAll(dataListTmp);
        }

        if (historyList.size() > 0) {
            BaseModelListVO vo = new BaseModelListVO(View_Type_Story_Reading_History, historyList);
            dataList.add(vo);
        }
        int cateViewHolderCount = 0;
        if (configList != null && configList.size() > 0
                && bannerInfoList != null && bannerInfoList.size() > 0) {// 加上这个判断是为了防止banner没获取到但配置数据先难道的情况
            for (BaseVO baseModelListVO : configList) {
                if (baseModelListVO.getViewType() == View_Type_Story_Circle_Cate) {
                    cateViewHolderCount++;
                    dataList.add(cateViewHolderCount, baseModelListVO);
                } else {
                    dataList.add(baseModelListVO);
                }
            }
        }

        RedirectPositionSubjectInfo redirectInfo = new RedirectPositionSubjectInfo();
        redirectInfo.setPosition(0);
        redirectInfo.setTitle("随便听听");
        redirectInfo.setSubTitle("海量有趣有内容的故事单本");
        List<BaseModel> baseModelList = new ArrayList<>();
        baseModelList.add(redirectInfo);
//        redirectInfo.setImageUrl("res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.icon_story_recommend);
        BaseModelListVO baseVO = new BaseModelListVO(ViewTypes.View_Type_Story_Config_Position_Title.getId(), baseModelList);
        dataList.add(baseVO);
    }


    @Override
    protected void reassembleDisplayedDataList(final List<BaseVO> reassembledListTemp,
                                               List<BaseModel> itemsAdded, boolean isFirstPage) {
        int index = 0;

        if (isFirstPage) {
            reassembledList.clear();
            updateList(reassembledListTemp);
        }
        // 如果一页加载完成后，最后一排不足3个，用新加的数据填补上
        if (reassembledListTemp.size() > 0) {
            BaseVO baseVO = reassembledListTemp.get(reassembledListTemp.size() - 1);
            if (baseVO instanceof BaseModelListVO) {
                BaseModelListVO modelListVO = (BaseModelListVO) baseVO;
                if (modelListVO.getItemList().size() < 3) {
                    for (int i = 0; i < itemsAdded.size(); i++) {
                        modelListVO.getItemList().add(itemsAdded.get(i));
                        if (modelListVO.getItemList().size() >= 3) {
                            index = i + 1;
                            break;
                        }

                    }
                }
            }
        }

        List<BaseVO> dataListTmp = new ArrayList<BaseVO>();
        List<BaseModel> singleLineTmp = new ArrayList<BaseModel>();
        for (int i = index; i < itemsAdded.size(); i++) {
            BaseModel model = itemsAdded.get(i);
            model.setIndex(i);
            singleLineTmp.add(model);
            if (singleLineTmp.size() >= 3) {
                addStoryLookAroundModel(dataListTmp, singleLineTmp);
            }
        }

        if (singleLineTmp.size() != 0) {
            addStoryLookAroundModel(dataListTmp, singleLineTmp);
        }

        reassembledListTemp.addAll(dataListTmp);
        reassembledList.addAll(dataListTmp);

        List<BaseModel> storyList = dataListModel.getListPageInfo().getDataList();
        if (storyList != null && storyList.size() > 0) {
            oldStoryInfoList = StoryListItem.toOldStoryInfoList(storyList);
        }

        if (ListenManager.getInstance().isPlaying() || !ListenManager.getInstance().isPause()) {
            resetPlayList(ListenManager.getInstance().getCurrentStoryInfo(), PLAY_MODE);
        }
    }

    /**
     * 添加听书随便看看mode数据
     *
     * @param dataListTmp
     * @param singleLineTmp
     */
    private void addStoryLookAroundModel
    (List<BaseVO> dataListTmp, List<BaseModel> singleLineTmp) {
        BaseModelListVO modelListVO = new BaseModelListVO(View_Type_DataList_StoryList, singleLineTmp);
        singleLineTmp.clear();
        dataListTmp.add(modelListVO);
    }

    private void processStoryItemClicked(StoryListItem item) {
        if (item == null || item.getData() == null) {
            return;
        }

        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (item.getData() instanceof StoryInfo) {
            StoryInfo storyInfo = (StoryInfo) item.getData();

            if (oldStoryInfoList != null) {
                //数据量太大 取200本
                if (oldStoryInfoList.size() > 210) {
                    com.hhdd.core.model.StoryInfo oldStoryInfo = com.hhdd.core.model.StoryInfo.createInfoByNewStory(storyInfo);
                    List<com.hhdd.core.model.StoryInfo> tmpList = new ArrayList<>();
                    int index = oldStoryInfoList.indexOf(oldStoryInfo);
                    if (index < 100) {
                        tmpList.addAll(oldStoryInfoList.subList(0, 200));
                    } else if (oldStoryInfoList.size() - index < 100) {
                        tmpList.addAll(oldStoryInfoList.subList(oldStoryInfoList.size() - 200, oldStoryInfoList.size()));
                    } else {
                        tmpList.addAll(oldStoryInfoList.subList(index - 100, index + 100));
                    }
                    ListenActivity.startActivity(getContext(), storyInfo.getStoryId(), tmpList);
                } else {
                    ListenActivity.startActivity(getContext(), (int) storyInfo.getStoryId(), oldStoryInfoList);
                }
            }

            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1," + storyInfo.getStoryId(), "child_story_home_recommend_click_" + item.getIndex(), TimeUtil.currentTime()));
        } else if (item.getData() instanceof StoryCollectionInfo) {
            StoryCollectionInfo info = (StoryCollectionInfo) item.getData();
            BaseCollectionFragment.CollectionModel model = new BaseCollectionFragment.CollectionModel(info.getCollectId(), true);
            FragmentUtil.presentFragment(StoryCollectionFragment.class, model, true);
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("2," + info.getCollectId(), "child_story_home_recommend_click_" + item.getIndex(), TimeUtil.currentTime()));
        }
    }

    void resetPlayList(com.hhdd.core.model.StoryInfo playStoryInfo, int mode) {
        if (playStoryInfo != null) {
            List reassembledList = getDataListDisplayed().getDataList();
            if (reassembledList != null && reassembledList.size() > 0) {
                for (int i = 0; i < reassembledList.size(); i++) {
                    if (reassembledList.get(i) instanceof BaseModelListVO) {
                        BaseModelListVO modelListVO = (BaseModelListVO) reassembledList.get(i);
                        for (int j = 0; j < modelListVO.getItemList().size(); j++) {
                            if (modelListVO.getItemList().get(j) instanceof StoryListItem) {
                                StoryListItem item = (StoryListItem) modelListVO.getItemList().get(j);
                                if (mode == STOP_MODE) {
                                    item.setPlayMode(mode);
                                } else {
                                    if (item.getData() != null && item.getData() instanceof StoryInfo) {
                                        StoryInfo info = (StoryInfo) item.getData();
                                        if (info.getStoryId() == playStoryInfo.getId()) {
                                            item.setPlayMode(mode);
                                        } else {
                                            item.setPlayMode(STOP_MODE);
                                        }
                                    } else if (item.getData() != null && item.getData() instanceof StoryCollectionInfo) {
                                        StoryCollectionInfo info = (StoryCollectionInfo) item.getData();
                                        if (info.getCollectId() == playStoryInfo.getCollectionId()) {
                                            item.setPlayMode(mode);
                                        } else {
                                            item.setPlayMode(STOP_MODE);
                                        }
                                    } else if (item.getData() != null && item.getData() instanceof StoryHistoryInfo) {
                                        StoryHistoryInfo info = (StoryHistoryInfo) item.getData();
                                        if (info.getStoryId() == playStoryInfo.getId()) {
                                            item.setPlayMode(mode);
                                        } else if (playStoryInfo.getCollectionId() != 0 && info.getCollectId() == playStoryInfo.getCollectionId()) {
                                            item.setPlayMode(mode);
                                        } else {
                                            item.setPlayMode(STOP_MODE);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (commonHeaderView != null) {
            commonHeaderView.doCoinAnim(false);
            commonHeaderView.doMedalAnim(false);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (commonHeaderView != null) {
            commonHeaderView.doCoinAnim(true);
            commonHeaderView.doMedalAnim(true);
        }
    }

    @Override
    protected void onVisible() {
        super.onVisible();
        if (commonHeaderView != null) {
            commonHeaderView.doCoinAnim(true);
            commonHeaderView.doMedalAnim(true);
        }
    }

    @Override
    protected void onInvisible() {
        super.onInvisible();
        if (commonHeaderView != null) {
            commonHeaderView.doCoinAnim(false);
            commonHeaderView.doMedalAnim(false);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (commonHeaderView != null) {
            commonHeaderView.onDestroyView();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (listAPI != null) {
            listAPI.cancel();
            listAPI = null;
        }

        if (subscribeApi != null) {
            subscribeApi.cancel();
            subscribeApi = null;
        }
        if (animatorSet != null) {
            if (animatorSet.isRunning()) {
                animatorSet.cancel();
            }
            animatorSet.end();
            animatorSet = null;
        }
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
    }

    boolean showIcon = false; //设置火箭显示标志
    boolean isTouched = false;
    AnimatorSet animatorSet = null;  //章鱼动画

    private boolean isDataCompleted = false;
    //    private AtomicBoolean isNeedRecordExposureAfterDataCompleted = new AtomicBoolean(false);
    private boolean isNeedRecordExposureAfterDataCompleted = false;
    private final Object mRecordExposureLock = new Object();
    private boolean isBannerShownOnScreen = true;//Banner是否在屏幕上展示出来了，用以曝光统计
//    private int mCurrBannerPosition = 0; //默认为0，这样切换到

//    public void onEvent(OldBannerPageSelectedEvent event) {
////        Log.d(ExposureTracker.TAG, "听书 onPageSelected：" + event.position);
//        if(mCurrBannerPosition == event.position - 1) return;
//        mCurrBannerPosition = event.position - 1; //Old banner回调的位置+了1
//        if (isBannerShownOnScreen) {
//            Log.d(ExposureTracker.TAG, "onPageSelected触发banner统计:" + mCurrBannerPosition);
//            recordExposureBanner(mCurrBannerPosition);
//        }
////        else {
////            Log.d(ExposureTracker.TAG, "onPageSelected触发banner统计，但是banner不可见，不统计");
////        }
//    }

    @Override
    public void handleLoadComplete(boolean hasMoreData) {
        super.handleLoadComplete(hasMoreData);
        synchronized (mRecordExposureLock) {
            isDataCompleted = true;
            if (isNeedRecordExposureAfterDataCompleted) {
                isNeedRecordExposureAfterDataCompleted = false;
                recordExposure();
//                Log.d(ExposureTracker.TAG, "handleLoadComplete触发banner统计");
//                recordExposureBanner(mCurrBannerPosition);
            }
        }
    }

    @Override
    public void onScrollStateChange(RecyclerView view, int scrollState) {
        super.onScrollStateChange(view, scrollState);

        switch (scrollState) {
            // 当不滚动时
            case AbsListView.OnScrollListener.SCROLL_STATE_IDLE:// 是当屏幕停止滚动时
                //统计曝光
                synchronized (mRecordExposureLock) {
                    if (isDataCompleted) {
                        recordExposure();
                    } else {
                        isNeedRecordExposureAfterDataCompleted = true;
                    }
                }

                if (isTouched) {
                    if (animatorSet == null) {
                        animatorSet = new AnimatorSet();
                        ValueAnimator animator = ObjectAnimator.ofFloat(floatIcon, "y", floatIcon.getTop(), 0);
                        ValueAnimator alpha = ObjectAnimator.ofFloat(floatIcon, "alpha", 1.0f, 0.1f);

                        animatorSet.playTogether(animator, alpha);
                        animatorSet.setDuration(600);
                        animatorSet.addListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                                floatIcon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.youyu_stop));
                                floatIcon.setTranslationY(0);
                                floatIcon.setAlpha(1.0f);
                                floatIcon.setVisibility(View.GONE);
                                isTouched = false;
                                showIcon = false;
                            }
                        });
                    }
                    animatorSet.start();
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            synchronized (mRecordExposureLock) {
                if (isDataCompleted) {
                    recordExposure();
//                    Log.d(ExposureTracker.TAG, "听书页面可见性触发banner统计");
//                    recordExposureBanner(mCurrBannerPosition);
                    EventBus.getDefault().post(new OldBannerShownOnScreenEvent(ExposureTracker.SCENE_STORY_HOME_BANNER, isBannerShownOnScreen));
//                    EventBus.getDefault().post(new OldBannerExposureTrackEvent(ExposureTracker.SCENE_STORY_HOME_BANNER));
                } else {
                    isNeedRecordExposureAfterDataCompleted = true;
                }
            }
        } else {
            EventBus.getDefault().post(new OldBannerShownOnScreenEvent(ExposureTracker.SCENE_STORY_HOME_BANNER, false));
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_STORY_HOME_BOOKSHELF);
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_STORY_HOME_HISTORY);
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_STORY_HOME_WATERFALL);
        }
    }

    private void recordExposure() {
        //曝光统计相关注释见MotherExcellentFragment
        final XRecyclerView xRecyclerView = getmListView();
        if (xRecyclerView == null) {
            return;
        }
        final LinearLayoutManager llm = (LinearLayoutManager) xRecyclerView.getLayoutManager();
        if (llm == null) {
            return;
        }
        final RecyclerPagedListDataAdapter adapter = (RecyclerPagedListDataAdapter) xRecyclerView.getAdapter();
        if (adapter == null) {
            return;
        }
        final int first = llm.findFirstVisibleItemPosition();//见下面的【注意】
        final int last = llm.findLastVisibleItemPosition();//见下面的【注意】
        if (first == RecyclerView.NO_POSITION || last == RecyclerView.NO_POSITION) {
            return;
        }

        List<ExposureTracker.ExposureVO> shelfVoList = new ArrayList<>();//10 is ok
        List<ExposureTracker.ExposureVO> historyVoList = new ArrayList<>();//10 is ok
        List<ExposureTracker.ExposureVO> waterfallVoList = new ArrayList<>();//10 is ok
//        List<ExposureTracker.ExposureVO> storyVoList = new ArrayList<>();
//        List<ExposureTracker.ExposureVO> schemaVoList = new ArrayList<>();

        boolean hasShelf = false;
        boolean hasHistory = false;
        boolean hasWaterfall = false;
        boolean hasBanner = false;
//        boolean hasOneColStory = false;
//        boolean hasTwoColStory = false;
//        boolean hasTowColSchema = false;
        for (int i = first - 1; i < last; i++) {//偏移一位
            if (i < 0) continue;
            final int itemViewType = adapter.getItemViewType(i);
            final Object item = adapter.getItem(i);
//            Log.d(ExposureTracker.TAG, "听书界面出现第" + i + "个: itemViewType=" + itemViewType + ",item=" + item);
            if (itemViewType == View_Type_Story_My_Book_Shelf) {
                hasShelf = true;
                recordExposureShelf(item, shelfVoList);
            } else if (itemViewType == View_Type_Story_Reading_History) {
                hasHistory = true;
                recordExposureHistory(item, historyVoList);
            } else if (itemViewType == ViewTypes.View_Type_DataList_StoryList.getId()) {
                hasWaterfall = true;
                recordExposureWaterfall(item, waterfallVoList);
            } else if (itemViewType == View_Type_DataList_Old_Banner) {
                hasBanner = true;
            }
//            else if (itemViewType == ViewTypes.View_Type_Story_Schema_Two_Col.getId()) {
//                // 两张图片配协议
//                hasTowColSchema = true;
//                recordExposureSchema(item, schemaVoList);
//            } else if (itemViewType == View_Type_Story_Collection_One_Col) {
//                // 单张大图听书合集
//                hasOneColStory = true;
//                recordExposureStory(item, storyVoList);
//            } else if (itemViewType == View_Type_Story_Collection_Two_Col) {
//                // 两图合集
//                hasTwoColStory = true;
//                recordExposureStory(item, storyVoList);
//            }
        }
        isBannerShownOnScreen = hasBanner;
        EventBus.getDefault().post(new OldBannerShownOnScreenEvent(ExposureTracker.SCENE_STORY_HOME_BANNER, isBannerShownOnScreen));
//        if (!hasBanner) {
//            Log.d(ExposureTracker.TAG, "听书banner不可见");
//        } else {
//            Log.d(ExposureTracker.TAG, "听书banner可见");
//        }

        if (!hasShelf) {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_STORY_HOME_BOOKSHELF);
        } else {
            ExposureTracker.getInstance().record(ExposureTracker.SCENE_STORY_HOME_BOOKSHELF, ExposureTracker.EVENT_VIEW, shelfVoList);
        }
        if (!hasHistory) {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_STORY_HOME_HISTORY);
        } else {
            ExposureTracker.getInstance().record(ExposureTracker.SCENE_STORY_HOME_HISTORY, ExposureTracker.EVENT_VIEW, historyVoList);
        }
        if (!hasWaterfall) {
            ExposureTracker.getInstance().resetComparisonForScene(ExposureTracker.SCENE_STORY_HOME_WATERFALL);
        } else {
            ExposureTracker.getInstance().record(ExposureTracker.SCENE_STORY_HOME_WATERFALL, ExposureTracker.EVENT_VIEW, waterfallVoList);
        }
//        if (hasOneColStory || hasTwoColStory) {
//
//        } else {
//
//        }
//
//        if(hasTowColSchema) {
//
//        } else {
//
//        }
    }

    private void recordExposureWaterfall(Object item, List<ExposureTracker.ExposureVO> waterfallVoList) {
        BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
        if (model == null) {
            LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
            return;
        }
        final List<BaseModel> itemList = model.getItemList();
        if (itemList == null) {
            return;
        }
        for (int i = 0; i < Math.min(itemList.size(), 3); i++) {//根据StoryListViewHolder代码，只曝光3个
            if (itemList.get(i) instanceof StoryListItem) {
                StoryListItem sli = (StoryListItem) itemList.get(i);
                final BaseModel data = sli.getData();
                if (data instanceof StoryInfo) {
                    StoryInfo si = (StoryInfo) data;
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    vo.type = ExposureTracker.TYPE_STORY;
                    vo.collectionId = si.getCollectId() > 0 ? si.getCollectId() : 0;
                    vo.itemId = si.getStoryId();
//                    Log.d(ExposureTracker.TAG, "recordExposureWaterfall,StoryInfo:" + si.getName());
                    waterfallVoList.add(vo);
                } else if (data instanceof StoryCollectionInfo) {
                    StoryCollectionInfo sci = (StoryCollectionInfo) data;
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    vo.type = ExposureTracker.TYPE_STORY;
                    vo.collectionId = sci.getCollectId();
                    vo.itemId = 0;
//                    Log.d(ExposureTracker.TAG, "recordExposureWaterfall,StoryCollectionInfo:" + sci.getName());
                    waterfallVoList.add(vo);
                }
            }
        }
    }

    private void recordExposureShelf(Object item, List<ExposureTracker.ExposureVO> shelfVoList) {
        BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
        if (model == null) {
            LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
            return;
        }
        final List<BaseModel> itemList = model.getItemList();
        if (itemList == null) {
            return;
        }
        for (int i = 0; i < Math.min(itemList.size(), 3); i++) {//根据SubscribeListViewHolder代码，大于3个是不显示的，不算曝光
            final BaseModel baseModel = itemList.get(i);
            final StoryListItem sli = baseModel instanceof StoryListItem ? ((StoryListItem) baseModel) : null;
            if (sli != null) {
                final BaseModel data = sli.getData();
                if (data instanceof StoryInfo) {
                    StoryInfo si = (StoryInfo) data;
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    vo.type = ExposureTracker.TYPE_STORY;
                    vo.collectionId = si.getCollectId() >= 0 ? si.getCollectId() : 0;
                    vo.itemId = si.getStoryId();
//                    Log.d(ExposureTracker.TAG, "recordExposureShelf,StoryInfo:" + si.getName());
                    shelfVoList.add(vo);
                } else if (data instanceof StoryCollectionInfo) {
                    StoryCollectionInfo sci = (StoryCollectionInfo) data;
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    vo.type = ExposureTracker.TYPE_STORY;
                    vo.collectionId = sci.getCollectId();
                    vo.itemId = 0;
//                    Log.d(ExposureTracker.TAG, "recordExposureShelf,StoryCollectionInfo:" + sci.getName());
                    shelfVoList.add(vo);
                }
            }
        }
    }

    private void recordExposureHistory(Object item, List<ExposureTracker.ExposureVO> historyVoList) {
        BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
        if (model == null) {
            LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
            return;
        }
        final List<BaseModel> itemList = model.getItemList();
        if (itemList == null) {
            return;
        }
        for (int i = 0; i < Math.min(itemList.size(), 3); i++) {//只显示4个，第5个是个跳转界面的
            final StoryListItem sli = itemList.get(i) instanceof StoryListItem ? ((StoryListItem) itemList.get(i)) : null;
            if (sli != null) {
                final BaseModel data = sli.getData();
                final StoryHistoryInfo shi = data instanceof StoryHistoryInfo ? ((StoryHistoryInfo) data) : null;
                if (shi != null) {
                    ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
                    if (shi.getType() == Constants.TYPE_STORY_SINGLE) {
                        //单本
                        vo.type = ExposureTracker.TYPE_STORY;
                        vo.collectionId = shi.getCollectId() >= 0 ? shi.getCollectId() : 0;
                        vo.itemId = shi.getStoryId();
                    } else {
                        //合辑
                        vo.type = ExposureTracker.TYPE_STORY;
                        vo.collectionId = shi.getCollectId();
                        vo.itemId = 0;
                    }
//                    Log.d(ExposureTracker.TAG, "recordExposureHistory,coverUrl=" + shi.getCoverUrl());
                    historyVoList.add(vo);
                }
            }
        }
    }

//    private void recordExposureStory(Object item, List<ExposureTracker.ExposureVO> storyVoList) {
//        BaseModelListVO model = item instanceof BaseModelListVO ? ((BaseModelListVO) item) : null;
//        if (model == null) {
//            LogHelper.e(ExposureTracker.TAG, "vo为空或者不是instanceof BaseModelListVO");
//            return;
//        }
//        final List<BaseModel> itemList = model.getItemList();
//        if (itemList != null && itemList.size() > 0) {
//            final BaseModel baseModel = itemList.get(0);
//            ExposureTracker.ExposureVO vo = ExposureTracker.getInstance().new ExposureVO();
//            StoryCollectionInfo sci = baseModel instanceof StoryCollectionInfo
//                    ? ((StoryCollectionInfo) baseModel) : null;
//            if (sci != null) {
//                vo.type = ExposureTracker.TYPE_STORY;
//                vo.collectionId = sci.getCollectId();
//                vo.itemId = 0;
//                storyVoList.add(vo);
//                LogHelper.d(ExposureTracker.TAG, "viewType==" + model.getViewType() +
//                        ": StoryCollectionInfo," + sci.getName());
//            }
//        }
//    }
//
//    private void recordExposureSchema(Object item, List<ExposureTracker.ExposureVO> schemaVoList) {
//
//    }

    @Override
    public void onScroll(RecyclerView recyclerView, int dx, int dy) {
        super.onScroll(recyclerView, dx, dy);
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
            LinearLayoutManager linearLayoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
            int firstVisibleItem = linearLayoutManager.findFirstVisibleItemPosition();
            if (firstVisibleItem > 15) {
                if (!showIcon) {
                    floatLayout.setVisibility(View.VISIBLE);
                    floatIcon.setVisibility(View.VISIBLE);
                    floatIcon.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.youyu_stop));
                    showIcon = true;
                }
            } else {
                if (showIcon && !isTouched) {
                    floatLayout.setVisibility(View.GONE);
                    showIcon = false;
                }

            }
        }
    }


    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser,
                                       boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_home_view", TimeUtil.currentTime()));
            if (NetworkUtils.isReachable() && tipView.getVisibility() == View.VISIBLE && needPlayTipAinm) {
                startTipAnim(tipView, 30, 0, 2000, true);
            }
        }
    }

    void startTipAnim(final View animView, int from, int scaleY, int delay,
                      final boolean needGone) {

        animator = ObjectAnimator.ofFloat(animView, "translationY", LocalDisplay.dp2px(from), LocalDisplay.dp2px(scaleY));
        animator.setDuration(500);
        animator.setStartDelay(delay);
        animator.setRepeatCount(0);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                getmListView().setTranslationY((float) animation.getAnimatedValue());
            }
        });
        animator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                if (animView.getVisibility() == View.GONE) {
                    animView.setVisibility(View.VISIBLE);
                }
                if (needPlayTipAinm) {
                    needPlayTipAinm = false;
                }
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (needGone) {
                    animView.setVisibility(View.GONE);
                }
                if (!needPlayTipAinm) {
                    needPlayTipAinm = true;
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animator.start();
    }

    void startShowTipViewAnim() {
        if (needPlayTipAinm) {
            startTipAnim(tipView, 0, 30, 0, false);
        }
    }

    void startGoneTipViewAnim() {
        if (needPlayTipAinm) {
            startTipAnim(tipView, 30, 0, 1000, true);
        }
    }

    private void processShelfManageClick(boolean editing) {
        final Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        String userHabitName;
        if (editing) {//点击了管理
            userHabitName = "story_home_bookshelf_manage_click";
        } else {//点击了更多
            userHabitName = "story_bookshelf_more_view";
        }
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", userHabitName, TimeUtil.currentTime()));

        if (editing) {
            ChildrenLockDialog lockDialogEnter = new ChildrenLockDialog(activity);
            lockDialogEnter.setCallback(new ChildrenDialogCallback() {
                @Override
                public void onAnswerRight() {
                    ShelfActivity.start(activity, ShelfActivity.SHELF_TYPE_STORY, true);
                }

                @Override
                public void onDirectDismiss() {
                }
            });
            lockDialogEnter.show();
        } else {
            ShelfActivity.start(activity, ShelfActivity.SHELF_TYPE_STORY, false);
        }

    }

    private void processSubscribeListItemClick(StoryListItem item) {
        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }
        BaseModel baseModel = item.getData();
        if (baseModel != null && baseModel instanceof StoryCollectionInfo) {
            StoryCollectionInfo info = (StoryCollectionInfo) baseModel;
            LocalSubscribeUtil.removeStorySubscribeId(info.getCollectId());
            CollectionCountInfo countInfo = DatabaseManager.getInstance().collectionDB().query(info.getCollectId());
            if (countInfo != null) {
                countInfo.setCount(info.getCurrentCount());
                DatabaseManager.getInstance().collectionDB().refresh(countInfo);
            } else {
                countInfo = new CollectionCountInfo(info.getCollectId(), info.getCurrentCount());
                DatabaseManager.getInstance().collectionDB().refresh(countInfo);
            }

            String name = "child_story_home_bookshelf_click_" + item.getIndex();
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getCollectId() + "", name, TimeUtil.currentTime()));

            BaseCollectionFragment.CollectionModel model = new BaseCollectionFragment.CollectionModel(info.getCollectId(), true);
            FragmentUtil.presentFragment(StoryCollectionFragment.class, model, true);
        }
    }


    private void processHistoryItemClicked(int position, StoryListItem item) {
        if (item == null) {
            return;
        }

        Activity activity = getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        BaseModel model = item.getData();
        if (model == null) {
            return;
        }

        if (model instanceof StoryHistoryInfo) {
            StoryHistoryInfo info = (StoryHistoryInfo) model;
            if (info.getStoryId() == -1) {
                FragmentUtil.presentFragment(StoryHistoryFragment.class, null, true);

                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "story_home_subscribed_history_more_click", TimeUtil.currentMiliTime()));
            } else {
                if (info.getType() == Constants.TYPE_STORY_SINGLE) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1," + info.getStoryId(), "child_story_home_history_click_" + position, TimeUtil.currentTime()));
                } else {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("2," + info.getCollectId(), "child_story_home_history_click_" + position, TimeUtil.currentTime()));
                }

                if (info.getType() == Constants.TYPE_STORY_COLLECT) {
                    FragmentUtil.presentFragment(StoryCollectionFragment.class, new BaseCollectionFragment.CollectionModel(info.getCollectId(), true), true);
                } else {
                    ListenActivity.startActivity(activity, info.getStoryId(), info.getReadCurrentTime(), oldHistoryList);
                }

                UserTrack.track(UserTrack.fush);
            }
        }

    }
}