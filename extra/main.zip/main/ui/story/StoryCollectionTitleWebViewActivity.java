package com.hhdd.kada.main.ui.story;

import android.content.Intent;
import android.text.TextUtils;
import android.view.View;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.controller.StoryCollectionSubscribeController;
import com.hhdd.kada.main.event.CancelSubscribeEvent;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.SubscribeSuccessEvent;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.ui.activity.BaseTitleWebViewActivity;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.widget.StoryCollectionSubscribeView;
import com.umeng.socialize.bean.SHARE_MEDIA;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/4/14
 * @describe : com.hhdd.kada.main.ui.story
 */
public class StoryCollectionTitleWebViewActivity extends BaseTitleWebViewActivity {

    @BindView(R.id.subscribeView)
    StoryCollectionSubscribeView subscribeView;
    private StoryCollectionDetail info;
    private String url;
    private StoryCollectionSubscribeController storyCollectionSubscribeController;
    private StrongReference<DefaultCallback> storyCollectionStrongReference;

    private static final String CREATE_ORDER = StoryCollectionTitleWebViewActivity.class.getSimpleName() + "_CREATE_ORDER";
    private static final String SUBSCRIBE = StoryCollectionTitleWebViewActivity.class.getSimpleName() + "_SUBSCRIBE";


    @Override
    public int getLayoutId() {
        return R.layout.activity_story_collection_intro;
    }

    @Override
    public void doInitData() {
        super.doInitData();
        Intent intent = getIntent();
        if (intent != null) {
            info = (StoryCollectionDetail) intent.getSerializableExtra(Constants.INTENT_KEY_COLLECTION_INFO);
            if (info != null) {
                storyCollectionSubscribeController = new StoryCollectionSubscribeController(this, SUBSCRIBE, CREATE_ORDER);
                storyCollectionSubscribeController.setStoryCollectionDetailInfo(info);
                invalidateSubscribeView();
                subscribeView.setVisibility(View.VISIBLE);
                String introduction = info.getIntroduction();
                if (!TextUtils.isEmpty(introduction)) {
                    url = API.URL_STORY_COLLECTION_INTRODUCTION() + "cid=" + info.getCollectId() + "&url=" + introduction;
                    loadUrl();
                }
            }
        }
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        subscribeView.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                switch (childView.getId()) {
                    case R.id.subscribeLayout:
                        if (info != null) {
                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getCollectId()),
                                    "story_collection_introduction_subscribe_click", TimeUtil.currentTime()));
                        }
                        if (storyCollectionSubscribeController != null) {
                            storyCollectionSubscribeController.doSubscribe();
                        }
                        break;
                    case R.id.subscribeTextViewContainer:
                        if (info != null) {
                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getCollectId()),
                                    "story_collection_introduction_subscribed_click", TimeUtil.currentTime()));
                        }
                        if (storyCollectionSubscribeController != null) {
                            storyCollectionSubscribeController.doCancelSubscribe();
                        }
                        break;
                    default:
                        break;
                }
            }
        });
    }

    @Override
    protected void loadUrl() {
        if (!NetworkUtils.isReachable()) {
            showError();
            return;
        }
        if (contentWebView != null && !TextUtils.isEmpty(url)) {
            contentWebView.loadUrl(url);
        }
    }

    @Override
    protected void doShareHabit() {
        if (info != null) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getCollectId()),
                    "story_collection_introduction_begin_share_click", TimeUtil.currentTime()));
        }
    }

    @Override
    protected void doShareHabitSuccess(SHARE_MEDIA share_media) {
        if (info != null) {
            int collectId = info.getCollectId();
            switch (share_media) {
                case WEIXIN:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "1", "story_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                case WEIXIN_CIRCLE:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "2", "story_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                case QQ:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "3", "story_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                case QZONE:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "4", "story_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                case SINA:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "," + "5", "story_collection_share_success_view", TimeUtil.currentTime()));
                    break;
                default:
                    break;
            }
        }
    }

    public void onEventMainThread(SubscribeSuccessEvent event) {
        finish();
    }

    public void onEventMainThread(CancelSubscribeEvent event) {
        if (info != null && StoryCollectionTitleWebViewActivity.class.getSimpleName().equals(event.getFrom())) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                    info.getCollectId() + "",
                    "story_collection_introduction_cancel_subscribed_success", TimeUtil.currentTime()));
        }
        finish();
    }

    public void onEventMainThread(LoginEvent event) {
        getStoryCollectionDetailInfo(event.getType());
    }

    /**
     * 刷新订阅view
     */
    private void invalidateSubscribeView() {
        subscribeView.updateIntroduction(info.getSubscribe() == 1, info.getExtFlag(), info.getPrice(), info.getOriginalPrice());
    }

    /**
     * 获取听书合集详情信息
     * @param type
     */
    private void getStoryCollectionDetailInfo(final String type) {
        if (info == null) {
            return;
        }
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(this);
        clearStoryCollectionReference();
        storyCollectionStrongReference = new StrongReference<>();
        DefaultCallback storyCollectionCallback = new DefaultCallback<StoryCollectionDetail>() {

            @Override
            public void onDataReceived(final StoryCollectionDetail responseData) {
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(StoryCollectionTitleWebViewActivity.this);
                        if (responseData != null) {
                            info = responseData;
                            storyCollectionSubscribeController.setStoryCollectionDetailInfo(responseData);
                            invalidateSubscribeView();
                            if (info.getSubscribe() != 1) {
                                if (SUBSCRIBE.equals(type)) {
                                    storyCollectionSubscribeController.subscribe(1);
                                } else if (CREATE_ORDER.equals(type)) {
                                    storyCollectionSubscribeController.createOrder();
                                }
                            }
                        }
                    }
                });
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(reason);
                customDialogManager.dismissDialog(StoryCollectionTitleWebViewActivity.this);
            }
        };
        storyCollectionStrongReference.set(storyCollectionCallback);
        StoryAPI.storyAPI_collectItemList(info.getCollectId(), false, storyCollectionStrongReference);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (info != null) {
            String habitName = info.getSubscribe() == 1 ? "story_subscribed_collection_introduction_view" : "story_unsubscribed_collection_introduction_view";
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getCollectId()), habitName, TimeUtil.currentTime()));
        }
    }

    /**
     * 回收合集详情接口强引用资源
     */
    private void clearStoryCollectionReference() {
        if (storyCollectionStrongReference != null) {
            storyCollectionStrongReference.clear();
            storyCollectionStrongReference = null;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clearStoryCollectionReference();
        if (storyCollectionSubscribeController != null) {
            storyCollectionSubscribeController.destroy();
        }
        DialogFactory.dismissAllDialog(this);
    }
}
