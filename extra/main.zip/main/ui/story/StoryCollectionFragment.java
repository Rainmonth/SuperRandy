package com.hhdd.kada.main.ui.story;

import android.app.Activity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.StoryService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.db.main.entities.ListenHistory;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.download.DownloadItemType;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.download.DownloadStatus;
import com.hhdd.kada.download.DownloadStatusVO;
import com.hhdd.kada.download.DownloadTask;
import com.hhdd.kada.download.DownloadTaskListener;
import com.hhdd.kada.main.controller.StoryCollectionSubscribeController;
import com.hhdd.kada.main.event.CancelSubscribeEvent;
import com.hhdd.kada.main.event.ConnectivityChangedEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LimitFreeEndedEvent;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.event.StoryFinishDownloadEvent;
import com.hhdd.kada.main.event.SubscribeSuccessEvent;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.ShareInfo;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryHistoryInfo;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.ui.dialog.ContentIsDeletedDialog;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.SeparatorLineViewHolder;
import com.hhdd.kada.main.viewholders.StoryCollectItemViewHolder;
import com.hhdd.kada.main.viewholders.StoryCollectResumeViewHolder;
import com.hhdd.kada.main.viewholders.StoryCollectionBlurDetailViewHolder;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.module.audio.AudioName;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;
import com.hhdd.kada.share.ShareProvider;
import com.hhdd.kada.widget.StoryCollectionSubscribeView;
import com.hhdd.logger.LogHelper;
import com.umeng.socialize.bean.SHARE_MEDIA;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static com.hhdd.kada.Constants.PAUSE_MODE;
import static com.hhdd.kada.Constants.PLAY_MODE;
import static com.hhdd.kada.Constants.SHARE_WEIXIN;
import static com.hhdd.kada.Constants.STOP_MODE;

/**
 * Created by lj on 17/4/24.
 */

public class StoryCollectionFragment extends BaseCollectionFragment implements DownloadTaskListener {

    private static final String TAG_UPDATE_COLLECTION_AUDIO = "updateCollectionAudio";

    static final int View_Type_List_Item = 4;
    static final int View_Type_Sep_Line = 6;
    static final int View_Type_Resume = 8;
    static final int View_Type_Collection_Detail_Blur = 9;

    private View downloadAllProgressLayout;
    private FishProgressBar fishProgressBar;
    private boolean isFreeListen = false;
    boolean needContinue = true;
    boolean isShowResume; //续播是否显示
    boolean isNeedShowResume;


    StoryHistoryInfo mStoryHistoryInfo; //续播位置
    StoryCollectionDetail storyCollectionDetail;
    StoryCollectionSubscribeView subscribeLayout; //未订阅控制栏
    private StoryCollectionSubscribeController subscribeController;

    List<com.hhdd.core.model.StoryInfo> oldStoryInfoList = new ArrayList<>();
    List<com.hhdd.core.model.StoryInfo> oldFreeStoryInfoList = new ArrayList<>();

    List<StoryListItem> dataList = new ArrayList<>(); //用于下载

    API.UrlAPI collectItemApi;
    private StrongReference<DefaultCallback> storyCollectionStrongReference;
    private int currentDownloadId;

    private IMediaPlayer mShortMediaPlayer;
    private boolean isNeedMomSubscribeMusicPlaying = false;
    private boolean isNeedContinuePlayListen = false;

    private static final String CREATE_ORDER = StoryCollectionFragment.class.getSimpleName() + "_CREATE_ORDER";
    private static final String SUBSCRIBE = StoryCollectionFragment.class.getSimpleName() + "_SUBSCRIBE";

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case StoryCollectionBlurDetailViewHolder.TYPE_SUBSCRIBE_CLICKED:
                    processSubscribeClicked();
                    return true;

                case StoryCollectionBlurDetailViewHolder.TYPE_INTRODUCATION_CLICKED:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                            collectId + "",
                            "story_collection_tree_btn_click", TimeUtil.currentTime()));
                    processIntroductionClicked();
                    return true;

                case StoryCollectItemViewHolder.TYPE_STORY_COLLECT_TIEM_CLICKED:
                    try {
                        StoryInfo storyInfo = (StoryInfo) args[0];
                        processItemClicked(storyInfo);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    return true;

                case StoryCollectResumeViewHolder.TYPE_STORY_RESUME_CLICKED:
                    processCollectResumeClicked();
                    return true;
            }
            return false;
        }
    };

    private OnPlayListener mOnPlayListener = new OnPlayListener() {
        @Override
        public void onPrepared(String audioTag, int playMode) {

        }

        @Override
        public void onCompletion(String audioTag, int playMode) {
            if (AudioName.NEET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                isNeedMomSubscribeMusicPlaying = false;

                continuePlayListen();
            } else if (TAG_UPDATE_COLLECTION_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onError(String audioTag, int playMode) {
            if (AudioName.NEET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                isNeedMomSubscribeMusicPlaying = false;

                continuePlayListen();
            } else if (TAG_UPDATE_COLLECTION_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onStop(String audioTag, int playMode) {
            if (AudioName.NEET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                isNeedMomSubscribeMusicPlaying = false;
            }
        }
    };

    private void continuePlayListen() {
        if (isNeedContinuePlayListen || ListenManager.getInstance().isPausedByShortAudio()) {
            isNeedContinuePlayListen = false;

            ListenManager.getInstance().setPause(false);
            ListenManager.getInstance().play();
        }
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);

        if (((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).isStoryCollectDownloading(collectId)) {
            downloadStatus = DownloadStatus.STATUS_DOWNLOADING;
        } else if (((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).isStoryCollectDownloadCompletion(collectId)) {
            downloadStatus = DownloadStatus.STATUS_COMPLETE;
        } else {
            downloadStatus = DownloadStatus.STATUS_INITIAL;
        }
        bookTitleBar.setResIdByStatus(downloadStatus);

        mShortMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
        mShortMediaPlayer.addOnPlayListener(mOnPlayListener);

        ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).addListener(this);

        initView();
        showLoadingView();
        getStoryCollectionInfo();

        EventCenter.bindContainerAndHandler(this, new SimpleEventHandler() {

            public void onEvent(StoryService.StartReadingEvent event) {
                resetPlayList(event.getStoryInfo(), PLAY_MODE);
            }

            public void onEvent(StoryService.PauseReadingEvent event) {
                resetPlayList(event.getStoryInfo(), PAUSE_MODE);
                isNeedShowResume = true;
                reloadDataImpl();
            }

            public void onEvent(StoryService.StopReadingEvent event) {
                resetPlayList(event.getStoryInfo(), STOP_MODE);
            }

            public void onEvent(LoginEvent event) {
//                handleRetry();
                getStoryCollectionInfo(event.getType());
            }

            public void onEvent(StoryFinishDownloadEvent event) {
                mAdapter.notifyDataSetChanged();
            }

            public void onEvent(SubscribeSuccessEvent event) {
//                handleRetry();
                if (isVisibleToUser()) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(collectId),
                            "story_collection_subscribed_view", TimeUtil.currentTime()));
                }
                getStoryCollectionInfo();
            }

            public void onEvent(CancelSubscribeEvent event) {
                if (storyCollectionDetail == null) {
                    return;
                }
                if (StoryCollectionFragment.class.getSimpleName().equals(event.getFrom())) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                            collectId + "",
                            "story_collection_cancel_subscribed_success", TimeUtil.currentTime()));
                }
                if (isVisibleToUser()) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(collectId),
                            "story_collection_unsubscribed_view", TimeUtil.currentTime()));
                }
                doPauseDownload();
                getStoryCollectionInfo();
            }

            public void onEvent(ConnectivityChangedEvent event) {
                if (event.isConnected) {
                    getStoryCollectionInfo();
                }
            }

            public void onEvent(LimitFreeEndedEvent event) {
                // 刷新列表
                LogHelper.d("Randy", "StoryCollectionFragment接受到事件LimitFreeEndedEvent，限免结束");
                doRefresh();
            }


        }).tryToRegisterIfNot();
    }

    @Override
    protected void initTitleBar() {
        super.initTitleBar();
        titleBar.addView(bookTitleBar, headerParams);
    }

    private static class LoadHistoryInfoFlowableOnSubscribe implements FlowableOnSubscribe<StoryHistoryInfo> {

        private int mCollectId;

        public LoadHistoryInfoFlowableOnSubscribe(int collectId) {
            mCollectId = collectId;
        }

        @Override
        public void subscribe(FlowableEmitter<StoryHistoryInfo> e) throws Exception {
            ListenHistory listenHistory = DatabaseManager.getInstance().listenhistoryDB().queryCollectHistory(mCollectId);
            if (listenHistory != null) {
                StoryHistoryInfo storyHistoryInfo = StoryHistoryInfo.createByHistory(listenHistory);
                e.onNext(storyHistoryInfo);
            }
            e.onComplete();
        }
    }

    private void loadResumeData() {
        //是否续播该合辑 已订阅合集支持续播
        if (needContinue && storyCollectionDetail != null && (storyCollectionDetail.getSubscribe() == 1 || storyCollectionDetail.getSubscribe() == 3)) {
            needContinue = false;

            Flowable.create(new LoadHistoryInfoFlowableOnSubscribe(collectId), BackpressureStrategy.BUFFER)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<StoryHistoryInfo>() {
                        @Override
                        public void accept(final StoryHistoryInfo storyHistoryInfo) throws Exception {
                            if (storyHistoryInfo != null) {
                                getHandler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        mStoryHistoryInfo = storyHistoryInfo;
                                        reloadDataImpl();
                                    }
                                }, 100);
                            }
                        }
                    });
        }
    }

    void initView() {
        if (getContext() == null || getContext().isFinishing()) {
            return;
        }
        Map<Integer, Class<?>> map = new HashMap<>();
        map.put(View_Type_List_Item, StoryCollectItemViewHolder.class);
        map.put(View_Type_Sep_Line, SeparatorLineViewHolder.class);
        map.put(View_Type_Resume, StoryCollectResumeViewHolder.class);
        map.put(View_Type_Collection_Detail_Blur, StoryCollectionBlurDetailViewHolder.class);

        BaseViewHolderCreator creator = new BaseViewHolderCreator(this, map);
        creator.setOnEventProcessor(mOnEventProcessor);
        setViewHolderCreator(creator);

        subscribeController = new StoryCollectionSubscribeController(getContext(), SUBSCRIBE, CREATE_ORDER);
        /* 订阅底部栏 */
        subscribeLayout = new StoryCollectionSubscribeView(getContext());
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.gravity = Gravity.BOTTOM;
        getInnerContainer().addView(subscribeLayout, params);
        subscribeLayout.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                switch (childView.getId()) {
                    case R.id.introduceLayout:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                                collectId + "", "story_collection_introduction_btn_click", TimeUtil.currentTime()));
                        processIntroductionClicked();
                        break;
                    case R.id.subscribeLayout:
                        if (subscribeController != null) {
                            subscribeController.doSubscribe();
                        }

                        if (storyCollectionDetail == null) {
                            return;
                        }
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                                collectId + "", "story_collection_subscribe_btn_click", TimeUtil.currentTime()));
                        break;
                    default:
                        break;
                }
            }
        });
        subscribeLayout.setVisibility(View.GONE);


        /* 全部下载进度底部栏 */
        downloadAllProgressLayout = LayoutInflater.from(getContext()).inflate(R.layout.download_all_progress_layout, null);
        FrameLayout.LayoutParams downloadParams = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, LocalDisplay.dp2px(50));
        downloadParams.gravity = Gravity.BOTTOM;
        getInnerContainer().addView(downloadAllProgressLayout, downloadParams);
        fishProgressBar = (FishProgressBar) downloadAllProgressLayout.findViewById(R.id.pb_download_all);
        fishProgressBar.setMax(100);
        fishProgressBar.setProgress(0);
        if (downloadStatus == DownloadStatus.STATUS_DOWNLOADING) {
            downloadAllProgressLayout.setVisibility(View.VISIBLE);
        } else {
            downloadAllProgressLayout.setVisibility(View.GONE);
        }
    }

    @Override
    protected void doShare() {
        if (storyCollectionDetail != null) {
            if (storyCollectionDetail.getStatus() != Constants.ONLINE && storyCollectionDetail.getStatus() != 0) {
                ToastUtils.showToast(getContext().getString(R.string.content_is_offline_can_not_share));
                return;
            }

            String recommend;
            if (TextUtils.isEmpty(storyCollectionDetail.getRecommend())) {
                recommend = storyCollectionDetail.getName();
            } else {
                recommend = storyCollectionDetail.getRecommend();
            }

            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(storyCollectionDetail.getCollectId() + "", "story_collection_begin_share_click", TimeUtil.currentTime()));

            if (getContext() == null || getContext().isFinishing()) {
                return;
            }
            String title = storyCollectionDetail.getName();
            if (TextUtils.isEmpty(title)) {
                title = getResources().getString(R.string.share_story_default_title);
            }
            String content = recommend;
            if (TextUtils.isEmpty(content)) {
                content = getResources().getString(R.string.share_default_content);
            }

            int collectionId = storyCollectionDetail.getCollectId();
            ShareInfo shareInfo = new ShareInfo();
            shareInfo.setTitle(title);
            shareInfo.setContent(content);
            shareInfo.setImageUrl(storyCollectionDetail.getCoverUrl());
            shareInfo.setTargetUrl(API.STORY_COLLECTION_SHARE_URL() + collectionId);
            ShareProvider.share(getActivity(), shareInfo, new MyShareListener(collectionId, storyCollectionDetail.getSubscribe()));
        }
    }

    /**
     * 获取听书合集信息
     */
    private void getStoryCollectionInfo() {
        getStoryCollectionInfo("");
    }

    /**
     * 获取听书合集信息
     *
     * @param type
     */
    private void getStoryCollectionInfo(final String type) {
        clearStoryCollectionReference();
        storyCollectionStrongReference = new StrongReference<>();
        DefaultCallback storyCollectionCallback = new DefaultCallback<StoryCollectionDetail>() {

            @Override
            public void onLoadFromCache(StoryCollectionDetail cachedData) {
                if (cachedData != null && cachedData.getItems() != null && cachedData.getItems().size() > 0) {
                    storyCollectionDetail = cachedData;
                    subscribeController.setStoryCollectionDetailInfo(storyCollectionDetail);
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            showBackground();
                            reloadDataImpl();
                        }
                    });
                }
            }

            @Override
            public void onDataReceived(final StoryCollectionDetail responseData) {
                if (responseData != null && responseData.getItems() != null && responseData.getItems().size() > 0) {
                    storyCollectionDetail = responseData;
                    subscribeController.setStoryCollectionDetailInfo(storyCollectionDetail);

                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            showBackground();
                            reloadDataImpl();

                            doOperate(responseData, type);


                        }
                    });
                } else {
                    getHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            showContentDialog(2, 1, collectId);
                            handleErrorOccurred(true, 0, "加载数据为空");
                        }
                    });
                }
            }

            @Override
            public void onException(int code, String reason) {
                if (storyCollectionDetail != null) {
                    showBackground();
                    reloadDataImpl();
                } else {
                    handleErrorOccurred(true, code, reason);
                }
            }
        };
        storyCollectionStrongReference.set(storyCollectionCallback);
        StoryAPI.storyAPI_collectItemList(collectId, false, storyCollectionStrongReference);
    }

    /**
     * 根据type进行对应操作
     *
     * @param responseData
     * @param type
     */
    private void doOperate(StoryCollectionDetail responseData, String type) {
        //如果是未订阅状态，根据操作类型进行对应的操作
        if (responseData.getSubscribe() != 1) {
            if (SUBSCRIBE.equals(type)) {
                if (subscribeController != null) {
                    subscribeController.subscribe(1);
                }
            } else if (CREATE_ORDER.equals(type)) {
                if (subscribeController != null) {
                    subscribeController.createOrder();
                }
            }
        }
    }

    void reloadDataImpl() {
        dataList.clear();
        loadResumeData();
        if (storyCollectionDetail != null && storyCollectionDetail.getItems() != null) {

            List<BaseModel> models = new ArrayList<>();

            //续播VO
            StoryInfo info = null;
            isShowResume = false;
            //是否续播该合辑 已订阅合集支持续播
            if (mStoryHistoryInfo != null && storyCollectionDetail.getSubscribe() == 1 &&
                    ListenManager.getInstance().getCollectId() != collectId) {
                if (storyCollectionDetail.getItems() != null && storyCollectionDetail.getItems().size() > 0) {
                    for (int i = 0; i < storyCollectionDetail.getItems().size(); i++) {
                        info = storyCollectionDetail.getItems().get(i);
                        if (info.getStoryId() == mStoryHistoryInfo.getStoryId()) {
                            isShowResume = true; //显示续播
                            break;
                        }
                    }
                }
            }

            storyCollectionDetail.setShowResume(isShowResume);
            BaseModelVO baseModelVO = new BaseModelVO();
            baseModelVO.setModel(storyCollectionDetail);
            baseModelVO.setViewType(View_Type_Collection_Detail_Blur);
            models.add(baseModelVO);

            if (isShowResume) {
                BaseModelVO resumeVO = new BaseModelVO();
                resumeVO.setModel(info);
                resumeVO.setViewType(View_Type_Resume);
                models.add(resumeVO);
            }

            if (storyCollectionDetail.getItems() != null && storyCollectionDetail.getItems().size() > 0) {
                oldFreeStoryInfoList.clear();
                oldStoryInfoList.clear();
                List<BaseModel> singleLineTmp = new ArrayList<>();
                for (int i = 0; i < storyCollectionDetail.getItems().size(); i++) {
                    StoryInfo storyInfo = storyCollectionDetail.getItems().get(i);
                    storyInfo.setCollectId(storyCollectionDetail.getCollectId());
                    storyInfo.setCollectCover(storyCollectionDetail.getCoverUrl());
                    storyInfo.setCollectExtFlag(storyCollectionDetail.getExtFlag());
//                    storyInfo.setCollectExtFlag(65540);
                    storyInfo.setIndex(i);
                    int status = storyCollectionDetail.getSubscribe() == 1 ? StoryListItem.STATUS_FREE : StoryListItem.STATUS_CHARGE;
                    StoryListItem item = new StoryListItem(StoryListItem.TYPE_STORY, storyInfo, status, storyCollectionDetail.getSubscribe());
                    singleLineTmp.add(item);
                    dataList.add(item);

                    if (singleLineTmp.size() >= 3) {
                        BaseModelListVO vo = new BaseModelListVO(View_Type_List_Item);
                        vo.setItemList(singleLineTmp);
                        models.add(vo);
                        singleLineTmp.clear();
                    }

                    //免费列表
                    if ((storyInfo.getExtFlag() & Extflag.STORY_EXT_FLAG_256) == Extflag.STORY_EXT_FLAG_256) {
                        oldFreeStoryInfoList.add(com.hhdd.core.model.StoryInfo.createInfoByStoryInfo(storyInfo, storyCollectionDetail));
                    }
                    oldStoryInfoList.add(com.hhdd.core.model.StoryInfo.createInfoByStoryInfo(storyInfo, storyCollectionDetail));
                }
                //添加未完待续view
                if ((storyCollectionDetail.getExtFlag() & Extflag.STORY_EXT_FLAG_16) == Extflag.STORY_EXT_FLAG_16
                        && storyCollectionDetail.getItems().size() < storyCollectionDetail.getCount()) {
                    StoryListItem continueItem = new StoryListItem();
                    continueItem.setSubscribeStatus(storyCollectionDetail.getSubscribe());
                    StoryInfo storyInfo = new StoryInfo();
                    storyInfo.setCoverUrl(storyCollectionDetail.getCoverUrl());
                    storyInfo.setLeftCount(storyCollectionDetail.getCount() - storyCollectionDetail.getItems().size());
                    storyInfo.setPlaceholder(true);
                    continueItem.setData(storyInfo);
                    singleLineTmp.add(continueItem);
                }
                if (singleLineTmp.size() > 0) {
                    BaseModelListVO vo = new BaseModelListVO(View_Type_List_Item);
                    vo.setItemList(singleLineTmp);
                    models.add(vo);
                    singleLineTmp.clear();
                }
            }
            //显示底部栏
            int allCount = storyCollectionDetail.getCount();
            subscribeLayout.update(storyCollectionDetail.getExtFlag(), allCount, storyCollectionDetail.getPrice(), storyCollectionDetail.getOriginalPrice(), true);
            if (storyCollectionDetail.getSubscribe() == 1) {
                subscribeLayout.setVisibility(View.GONE);
                setInnerViewPaddingBottom(LocalDisplay.dp2px(0));
            } else {
                subscribeLayout.setVisibility(View.VISIBLE);
                setInnerViewPaddingBottom(LocalDisplay.dp2px(50));
            }
            reloadData(models);
            handleLoadComplete(false);

            if (ListenManager.getInstance().isPlaying() || !ListenManager.getInstance().isPause()) {
                resetPlayList(ListenManager.getInstance().getCurrentStoryInfo(), PLAY_MODE);
            }

            bookTitleBar.initialize(storyCollectionDetail.getSubscribe());
            bookTitleBar.updateTitle(storyCollectionDetail.getName());
        }
    }

    private void showBackground() {
        String imgUrl = CdnUtils.getImgCdnBlurUrl(storyCollectionDetail.getBannerUrl(), 30, 30, true);
        setBackground(imgUrl, R.drawable.collection_bg);
    }

    private void processItemClicked(StoryInfo info) {
        Activity activity = getContext();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (storyCollectionDetail == null) {
            return;
        }

        if (info == null) {
            return;
        }

        if (storyCollectionDetail.getStatus() != Constants.ONLINE && storyCollectionDetail.getStatus() != Constants.OFFLINE) {
            ContentIsDeletedDialog contentIsDeletedDialog = new ContentIsDeletedDialog(activity);
            contentIsDeletedDialog.setData(2, 2, info.getStoryId());
            contentIsDeletedDialog.show();
            return;
        }

        if (info.isPlaceholder()) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_content_coming_click", TimeUtil.currentTime()));
            if (mShortMediaPlayer != null) {
                isNeedContinuePlayListen = ListenManager.getInstance().isPlayingOrPromptAudioPlaying();

                if (isNeedContinuePlayListen) {
                    ListenManager.getInstance().setPausedByShortAudio(true);
                    ListenManager.getInstance().pause(false);
                }

                mShortMediaPlayer.addPlayQueue(R.raw.update_collection, PlayMode.IMMEDIATELY_PLAY_MODE, TAG_UPDATE_COLLECTION_AUDIO);
            }
            return;
        }

        //已订阅
        if (storyCollectionDetail.getSubscribe() == 1) {

            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getStoryId() + "," + collectId, "story_subscribed_collection_content_list_click_" + info.getIndex(), TimeUtil.currentTime()));
            ListenManager.getInstance().setCollectId(collectId);
            if (oldStoryInfoList.size() > 0) {
                ListenActivity.startActivity(activity, info.getStoryId(), oldStoryInfoList);
            } else {
                ListenActivity.startActivity(activity, info.getStoryId());
            }

            //如果续播按钮显示状态 刷新隐藏续播按钮
            if (isShowResume) {
                reloadDataImpl();
            }
        } else {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getStoryId() + "," + collectId, "story_unsubscribed_collection_content_list_click_" + info.getIndex(), TimeUtil.currentTime()));
            // 优先处理限免
            boolean isLimitFree = ((info.getCollectExtFlag() & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW) ||
                    ((info.getCollectExtFlag() & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL);
            if (isLimitFree) {
                ListenManager.getInstance().setCollectId(collectId);
                if (oldStoryInfoList.size() > 0) {
                    ListenActivity.startActivity(activity, info.getStoryId(), oldStoryInfoList, info.getCollectExtFlag());
                }
            } else {
                //试听
                if ((info.getExtFlag() & Extflag.STORY_EXT_FLAG_256) == Extflag.STORY_EXT_FLAG_256) {
                    //播放试听
                    if (oldStoryInfoList.size() > 0) {
                        if (storyCollectionDetail.getSubscribe() == 1) {
                            isFreeListen = false;
                        } else {
                            isFreeListen = true;
                        }
                        ListenActivity.startActivity(activity, info.getStoryId(), oldStoryInfoList, isFreeListen, storyCollectionDetail.getExtFlag());
                        ListenManager.getInstance().setCollectId(collectId);
                    }
                } else {
                    /**
                     * https://www.tapd.cn/21794391/prong/stories/view/1121794391001002042?url_cache_key=94970b5b787f68b17b259199d62fd552&action_entry_type=story_tree_list
                     * 2、提示订阅音频出现期间再次点击带锁内容，提示订阅音频和手势引导不重新计时。提示订阅音频结束后再次点击带锁内容，提示订阅音频和手势引导从0开始重新计时。
                     */
                    if (isNeedMomSubscribeMusicPlaying) {
                        return;
                    }

                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(collectId), "story_unsubscribed_collection_lock_click", TimeUtil.currentTime()));
                    if (mShortMediaPlayer != null) {
                        isNeedMomSubscribeMusicPlaying = true;

                        isNeedContinuePlayListen = ListenManager.getInstance().isPlayingOrPromptAudioPlaying();
                        if (isNeedContinuePlayListen) {
                            ListenManager.getInstance().setPausedByShortAudio(true);
                            ListenManager.getInstance().pause(false);
                        }

                        mShortMediaPlayer.addPlayQueue(R.raw.need_mom_subscribe, PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.NEET_MOM_SUBSCRIBE_AUDIO);
                    }

                    subscribeLayout.showSubscribeFingerGuideAnim();
                }
            }
        }
    }


    @Override
    protected void handleRetry() {
        ((LinearLayoutManager) getmListView().getLayoutManager()).setStackFromEnd(false);
        storyCollectionDetail = null;
        downloadAllProgressLayout.setVisibility(View.GONE);
        subscribeLayout.setVisibility(View.GONE);
        getDataListDisplayed().getDataList().clear();
        notifyDataSetChanged();
        showLoadingView();
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                getStoryCollectionInfo();
            }
        }, 100);
    }

    @Override
    protected void doRefresh() {
        getStoryCollectionInfo();
    }


    long taskId;
    Map<Integer, StoryListItem> downloadStatusVOMap = new HashMap<Integer, StoryListItem>();

    @Override
    public void addedDownloads(List<DownloadTask> taskList) {
    }

    @Override
    public void addedDownload(DownloadTask task) {
        if (task == null || task.getDownloadInfo() == null) {
            return;
        }

        if (task.getDownloadInfo().getItemId() == collectId) {
            taskId = task.getDownloadInfo().getId();
        }
    }

    @Override
    public void preDownload(DownloadTask task) {
    }

    @Override
    public void pausedDownload(long downloadId) {

    }

    @Override
    public void finishDownload(DownloadTask task) {
        if (task == null || task.getDownloadInfo() == null) {
            return;
        }
        //合集详情下载完成
        if (task.getDownloadInfo().getItemId() == collectId) {
            downloadAllProgressLayout.setVisibility(View.GONE);
            downloadStatus = DownloadStatus.STATUS_COMPLETE;
            downloadStatusVOMap.clear();
            ToastUtils.showToast("下载完成");
            bookTitleBar.setResIdByStatus(downloadStatus);
        }
    }

    @Override
    public void updateCollectItemProcess(int downloadId, int progress) {
        if (downloadStatus != DownloadStatus.STATUS_DOWNLOADING) {
            return;
        }
        currentDownloadId = downloadId;
        try {
            StoryListItem item = downloadStatusVOMap.get(downloadId);
            if (item == null) {
                for (int i = 0; i < dataList.size(); i++) {
                    StoryListItem data = dataList.get(i);
                    if (data.getData() instanceof StoryInfo) {
                        StoryInfo storyInfo = (StoryInfo) data.getData();
                        if (storyInfo.getStoryId() == downloadId) {
                            downloadStatusVOMap.put(downloadId, data);
                            break;
                        }
                    } else if (data.getData() instanceof StoryCollectionInfo) {
                        StoryCollectionInfo info = (StoryCollectionInfo) data.getData();
                        if (info.getCollectId() == downloadId) {
                            downloadStatusVOMap.put(downloadId, data);
                            break;
                        }
                    }
                }
                item = downloadStatusVOMap.get(downloadId);
                if (item != null) {
                    DownloadStatusVO downloadStatusVO = item.getDownloadStatusVO();
                    if (downloadStatusVO != null) {
                        downloadStatusVO.setDownloadStatus(DownloadStatus.STATUS_ADDED);
                    } else {
                        downloadStatusVO = new DownloadStatusVO();
                        downloadStatusVO.setDownloadId(downloadId);
                        downloadStatusVO.setDownloadStatus(DownloadStatus.STATUS_ADDED);
                        item.setDownloadStatusVO(downloadStatusVO);
                    }
                }
            }

            if (item != null) {
                DownloadStatusVO downloadStatusVO = item.getDownloadStatusVO();
                if (downloadStatusVO != null) {
                    downloadStatusVO.setProcess(progress);
                    if (progress == 100) {
                        downloadStatusVO.setDownloadStatus(DownloadStatus.STATUS_COMPLETE);
                    }
                }
                if (isVisible()) {
                    updateDownloadView(downloadId, progress, item);
                }
            }
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
    }

    private void updateDownloadView(int downloadId, int progress, StoryListItem item) {
        String tag = "" + downloadId + "_" + DownloadItemType.STORY;
        View taskListItem = item.getItemView();//mListView.getRefreshableView().findViewWithTag(tag);
        if (taskListItem != null && taskListItem.getTag() != null && TextUtils.equals(tag, (String) taskListItem.getTag())) {
            View container = taskListItem.findViewById(R.id.alpha_container2);
            CircleProgressBar progressBar = (CircleProgressBar) taskListItem.findViewById(R.id.download_progress_per);
            if (container != null && progressBar != null) {
                container.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.VISIBLE);
                progressBar.setProgress(progress);
                if (progress == 100) {
                    progressBar.setVisibility(View.GONE);
                    container.setVisibility(View.GONE);
                    taskListItem.findViewById(R.id.has_downloaded).setVisibility(View.VISIBLE);
                }
            }
        }
    }

    @Override
    public void updateProcess(DownloadTask task) {
        if (task == null || task.getDownloadInfo() == null) {
            return;
        }
        if (task.getDownloadInfo().getItemId() == collectId) {
            taskId = task.getDownloadInfo().getId();
            fishProgressBar.setProgress((int) task.getDownloadProcess());
        }
    }

    @Override
    public void errorDownload(DownloadTask task, Throwable error) {
        doPauseDownload();
        downloadStatus = DownloadStatus.STATUS_ERROR;
        ToastUtils.showToast("网络有问题，请稍后再试");
    }

    void resetPlayList(com.hhdd.core.model.StoryInfo playStoryInfo, int mode) {
        if (playStoryInfo != null) {
            List reassembledList = getDataListDisplayed().getDataList();
            if (reassembledList != null && reassembledList.size() > 0) {
                for (int i = 0; i < reassembledList.size(); i++) {
                    if (reassembledList.get(i) instanceof BaseModelListVO) {
                        BaseModelListVO modelListVO = (BaseModelListVO) reassembledList.get(i);
                        for (int j = 0; j < modelListVO.getItemList().size(); j++) {
                            if (modelListVO.getItemList().get(j) instanceof StoryListItem) {
                                StoryListItem item = (StoryListItem) modelListVO.getItemList().get(j);
                                if (mode == STOP_MODE) {
                                    item.setPlayMode(mode);
                                } else {
                                    if (item.getData() != null && item.getData() instanceof StoryInfo) {
                                        StoryInfo info = (StoryInfo) item.getData();
                                        if (info.getStoryId() == playStoryInfo.getId()) {
                                            item.setPlayMode(mode);
                                        } else {
                                            item.setPlayMode(STOP_MODE);
                                        }
                                    } else if (item.getData() != null && item.getData() instanceof StoryCollectionInfo) {
                                        StoryCollectionInfo info = (StoryCollectionInfo) item.getData();
                                        if (info.getCollectId() == playStoryInfo.getCollectionId()) {
                                            item.setPlayMode(mode);
                                        } else {
                                            item.setPlayMode(STOP_MODE);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                notifyDataSetChanged();
            }
        }
    }

    /**
     * 回收强引用资源
     */
    private void clearStoryCollectionReference() {
        if (storyCollectionStrongReference != null) {
            storyCollectionStrongReference.clear();
            storyCollectionStrongReference = null;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (collectItemApi != null) {
            collectItemApi.cancel();
            collectItemApi = null;
        }

        clearStoryCollectionReference();

        continuePlayListen();

        releaseSoundPlay();

        ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeListener(this);
        if (subscribeController != null) {
            subscribeController.destroy();
        }

        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.removeOnPlayListener(mOnPlayListener);
        }
        DialogFactory.dismissAllDialog(getContext());
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    private void releaseSoundPlay() {
        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.NEET_MOM_SUBSCRIBE_AUDIO);
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, TAG_UPDATE_COLLECTION_AUDIO);
        }

        isNeedMomSubscribeMusicPlaying = false;
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser) {
            getHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (storyCollectionDetail != null) {
                        String name = "";
                        int subscribeStatus = storyCollectionDetail.getSubscribe();

                        if (subscribeStatus == 1) {
                            name = "story_collection_subscribed_view";
                        } else {
                            name = "story_collection_unsubscribed_view";
                        }
                        String content = collectId + "";

                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(content, name, TimeUtil.currentTime()));
                    }
                }
            }, 500);
        }
    }

    @Override
    public void doStartDownload() {
        if (storyCollectionDetail == null) {
            return;
        }

        if (storyCollectionDetail.getStatus() != Constants.ONLINE && storyCollectionDetail.getStatus() != 0) {
            ToastUtils.showToast(getContext().getString(R.string.content_is_offline_can_not_download));
            return;
        }
        downloadStatus = DownloadStatus.STATUS_DOWNLOADING;
        bookTitleBar.setResIdByStatus(downloadStatus);
        downloadAllProgressLayout.setVisibility(View.VISIBLE);
        ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).download(storyCollectionDetail);
    }

    @Override
    public void doPauseDownload() {
        downloadStatus = DownloadStatus.STATUS_PAUSED;
        bookTitleBar.setResIdByStatus(downloadStatus);
        StoryListItem item = downloadStatusVOMap.get(currentDownloadId);
        if (isVisible() && item != null) {
            String tag = "" + currentDownloadId + "_" + DownloadItemType.STORY;
            View itemView = item.getItemView();
            if (itemView != null && itemView.getTag() != null && TextUtils.equals(tag, (String) itemView.getTag())) {
                View container = itemView.findViewById(R.id.alpha_container2);
                CircleProgressBar progressBar = (CircleProgressBar) itemView.findViewById(R.id.download_progress_per);
                container.setVisibility(View.GONE);
                progressBar.setVisibility(View.GONE);
            }
        }
        downloadAllProgressLayout.setVisibility(View.GONE);
        ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).pause(taskId);
    }

    void showContentDialog(int kind, int type, int id) {
        if (getContext() == null || getActivity().isFinishing()) {
            return;
        }
        ContentIsDeletedDialog contentIsDeletedDialog = new ContentIsDeletedDialog(getContext());
        contentIsDeletedDialog.setCallback(new ContentIsDeletedDialog.ContentDialogCallback() {
            @Override
            public void doYes() {
                onBackPressed();
            }
        });
        contentIsDeletedDialog.setData(kind, type, id);
        contentIsDeletedDialog.show();

    }

    private void processSubscribeClicked() {
        Activity activity = getContext();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (storyCollectionDetail == null) {
            return;
        }

        if (storyCollectionDetail.getSubscribe() == 1) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "", "story_collection_subscribed_btn_click", TimeUtil.currentTime()));
            if (NetworkUtils.isReachable()) {
                if (subscribeController != null) {
                    subscribeController.doCancelSubscribe();
                }
            } else {
                ToastUtils.showToast("网络异常，请检查网络");
            }
        } else {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(collectId + "", "story_fake_subscribed_collection_subscribe_btn_click", TimeUtil.currentTime()));

            storyCollectionDetail.setSubscribe(0);
            showBackground();
            reloadDataImpl();

        }
    }

    private void processIntroductionClicked() {
        Activity activity = getContext();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (storyCollectionDetail == null) {
            return;
        }

        String introduction = storyCollectionDetail.getIntroduction();
        if (StringUtil.isEmpty(introduction)) {
            return;
        }
        ActivityUtil.nextStoryCollectionTitleWebViewActivity(getContext(), storyCollectionDetail);
    }

    private void processCollectResumeClicked() {
        Activity activity = getContext();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (mStoryHistoryInfo == null) {
            return;
        }

        ListenManager.getInstance().setCollectId(collectId);
        ListenActivity.startActivity(activity, mStoryHistoryInfo.getStoryId(), mStoryHistoryInfo.getReadCurrentTime(), oldStoryInfoList);

        //续播点击 刷新界面隐藏续播按钮
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(collectId), "story_collection_continue_play_click", TimeUtil.currentTime()));
        reloadDataImpl();
    }

    private static class MyShareListener implements ShareProvider.Listener {

        private long mId;
        private int mSubscribe;

        public MyShareListener(long id, int subscribe) {
            mId = id;
            mSubscribe = subscribe;
        }

        @Override
        public void onComplete(boolean success, SHARE_MEDIA share_media) {

            if (success) {
                //成功
                switch (share_media) {
                    case WEIXIN:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mId + "," + "1", "story_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    case WEIXIN_CIRCLE:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mId + "," + "2", "story_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    case QQ:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mId + "," + "3", "story_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    case QZONE:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mId + "," + "4", "story_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    case SINA:
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mId + "," + "5", "story_collection_share_success_view", TimeUtil.currentTime()));
                        break;
                    default:
                        break;
                }
            } else {
                //失败
            }
        }
    }
}
