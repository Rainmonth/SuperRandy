package com.hhdd.kada.main.ui.story;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.main.common.RecyclerDataListFragment2;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionCategoryInfo;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.StoryCollectionCategoryViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;

import java.util.ArrayList;
import java.util.HashMap;


/**
 * Created by sxh on 2017/4/24.
 */

public class StoryCollectionCategoryFragment extends RecyclerDataListFragment2 {

    static final int View_Type_Item_Collection_Category = 100;
    BaseViewHolderCreator viewHolderCreator;

    private ArrayList<BaseModel> pageList = new ArrayList<>();

    public StoryCollectionCategoryFragment() {
        super(LIST_MODE_NONE, "", null);
    }


    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        useTitleBar("分类");
        initView();

        showLoadingView();
        reloadData();
    }

    private void initView() {
        HashMap map = new HashMap();
        map.put(View_Type_Item_Collection_Category, StoryCollectionCategoryViewHolder.class);
        this.viewHolderCreator = new BaseViewHolderCreator(this, map);
        setViewHolderCreator(this.viewHolderCreator);

        Activity activity = getActivity();
        if (activity != null) {
            Window window = activity.getWindow();
            if (window != null) {
                View view = window.getDecorView();
                if (view != null) {
                    view.setBackgroundDrawable(null);
                }
            }
        }

        setBackgroundColor(getResources().getColor(R.color.white));
    }


    private void reloadData() {

        StoryAPI.getStoryCategoryList(new API.ResponseHandler<ArrayList<StoryCollectionCategoryInfo>>() {
            @Override
            public void onSuccess(ArrayList<StoryCollectionCategoryInfo> responseData) {
                for (int i = 0; i < responseData.size(); i++) {
                    BaseModelVO baseModelVO = new BaseModelVO(responseData.get(i), View_Type_Item_Collection_Category);
                    pageList.add(baseModelVO);
                }

                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        reloadData(pageList);
                    }
                });
            }

            @Override
            public void onFailure(int code, String message) {
                handleErrorOccurred(true, 0, "加载数据为空");
            }
        });
    }

    @Override
    public void onVisibleChangedToUser(boolean isVisibleToUser, boolean isHappenedInSetUserVisibleHintMethod) {
        super.onVisibleChangedToUser(isVisibleToUser, isHappenedInSetUserVisibleHintMethod);
        if (isVisibleToUser){
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_kind_view", TimeUtil.currentTime()));
        }
    }
}
