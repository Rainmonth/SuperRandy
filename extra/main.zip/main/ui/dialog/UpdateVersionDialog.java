package com.hhdd.kada.main.ui.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.ui.activity.TransparentActivity;
import com.hhdd.kada.main.utils.TimeUtil;

/**
 * Created by lj on 16/7/14.
 */
public class UpdateVersionDialog extends BaseDialog {
    public UpdateVersionDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    public UpdateVersionDialog(Context context, int theme) {
        super(context, theme);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dig_hint_layout);
        initViews();
    }

//    TextView mTitle;
    TextView mContent;
    View no;

//    String title;
    String content;
    boolean isCenter;
    boolean isForceUpdate;
    @Override
    protected void initViews() {

//        mTitle = (TextView) findViewById(R.id.title);
        mContent = (TextView) findViewById(R.id.content);
//        if(title != null && title.length()>0){
//            mTitle.setText(title);
//        }
        if(content != null && content.length()>0){
            mContent.setText(content);
        }
        if(isCenter){
            mContent.setGravity(Gravity.CENTER);
        }

        View yes = findViewById(R.id.confirm);
        yes.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                dismiss();
                if(listener != null){
                    listener.onConfirmBtnClick();
                }
                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "update_notice_download", TimeUtil.currentTime()));

            }
        });
        no = findViewById(R.id.cancel);
        no.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                dismiss();
                if(mContext instanceof Activity && mContext instanceof TransparentActivity){
                    ((TransparentActivity) mContext).finish();
                }
                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "update_notice_cancel", TimeUtil.currentTime()));
            }
        });
        if(isForceUpdate){
            no.setVisibility(View.GONE);
        }

        setCancelable(false);
    }

//    public void setTitle(String title){
//        this.title = title;
//        if(mTitle != null){
//            mTitle.setText(title);
//        }
//    }
    public void setContent(String content,boolean isCenter){
        this.content = content;
        this.isCenter = isCenter;
        if(mContent != null){
            mContent.setText(content);
            if(isCenter){
                mContent.setGravity(Gravity.CENTER);
            }
        }
    }

    public void setForceUpdate(boolean isForceUpdate){
        this.isForceUpdate = isForceUpdate;
        if(no != null){
            no.setVisibility(View.GONE);
        }
    }

    public interface Listner {
        void onConfirmBtnClick();
    }
    public Listner getListner() {
        return listener;
    }

    public void setListner(Listner listner) {
        this.listener = listner;
    }

    Listner listener;
}
