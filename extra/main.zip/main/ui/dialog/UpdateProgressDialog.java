package com.hhdd.kada.main.ui.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

import com.hhdd.kada.R;
import com.hhdd.kada.main.ui.activity.TransparentActivity;
import com.hhdd.kada.main.views.DownloadProgressBar;

/**
 * Created by lj on 16/7/14.
 */
public class UpdateProgressDialog extends BaseDialog {
    public UpdateProgressDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    public UpdateProgressDialog(Context context, int theme) {
        super(context, theme);
    }

    boolean isForceUpdate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.softupdate_progress);
        initViews();
    }


    View cancel;
    DownloadProgressBar mProgress;
    @Override
    protected void initViews() {
        mProgress = (DownloadProgressBar) findViewById(R.id.update_progress);

        cancel = findViewById(R.id.cancel);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                if(mContext instanceof Activity && mContext instanceof TransparentActivity){
                    ((TransparentActivity) mContext).finish();
                }
                if(listener != null){
                    listener.onCancelBtnClick();
                }
            }
        });
        if(isForceUpdate){
            cancel.setVisibility(View.GONE);
        }
        setCancelable(false);
    }

    public void startDownload(){
        if(mProgress != null){
            mProgress.setStartDownloading();
        }
    }
    public void setProgress(int progress){
        mProgress.setProcess(progress);
    }
    public void finishDownload(){
        if(mProgress != null){
            mProgress.setFinishDownloading();
        }

    }


    public void setForceUpdate(boolean isForceUpdate){
        this.isForceUpdate = isForceUpdate;
        if(cancel != null){
            cancel.setVisibility(View.GONE);
        }
    }

    public interface Listner {
        void onCancelBtnClick();
    }
    public Listner getListner() {
        return listener;
    }

    public void setListner(Listner listner) {
        this.listener = listner;
    }

    Listner listener;

}