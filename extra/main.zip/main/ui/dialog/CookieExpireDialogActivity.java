package com.hhdd.kada.main.ui.dialog;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.event.CookieExpireDialogActivityFinishEvent;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.ui.activity.LoginOrRegisterActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/7/5
 * @describe : com.hhdd.kada.main.ui.dialog
 */
public class CookieExpireDialogActivity extends Activity {

    @BindView(R.id.dismiss)
    ImageView dismissImageView;
    @BindView(R.id.icon_left)
    TextView knowTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dia_function_describe2);
        ButterKnife.bind(this);
        EventBus.getDefault().register(this);
        setFinishOnTouchOutside(false);
        KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                switch (v.getId()){
                    case R.id.dismiss:
                        finish();
                        break;
                    case R.id.icon_left:
                        LoginOrRegisterActivity.startActivity(CookieExpireDialogActivity.this,"",true);
                        finish();
                        break;
                }

            }
        };
        dismissImageView.setOnClickListener(listener);
        knowTextView.setOnClickListener(listener);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }

    public void onEvent(LoginEvent event) {
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().post(new CookieExpireDialogActivityFinishEvent());
        EventBus.getDefault().unregister(this);
    }
}
