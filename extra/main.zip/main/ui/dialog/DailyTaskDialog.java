package com.hhdd.kada.main.ui.dialog;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.widget.ImageView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.CoinService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.coin.view.MagicTextView;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.audio.AudioName;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;

/**
 * Created by MCX on 2017/2/21.
 */

public class DailyTaskDialog extends BaseDialog {

    private ImageView ivDismiss, ivOk, ivBg;
    private MagicTextView mtvNum;
    private View container;
    private Context context;
    private boolean isFromExplore = false;

    private IMediaPlayer mShortMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);

    int coin;//每日任务可获得咔哒币
    int bgList[] = {R.drawable.bg_daily_task_1, R.drawable.bg_daily_task_2, R.drawable.bg_daily_task_3, R.drawable.bg_daily_task_4, R.drawable.bg_daily_task_5};
    //    int voiceList[] = {R.raw.voice_task_1, R.raw.voice_task_2, R.raw.voice_task_3, R.raw.voice_task_4, R.raw.voice_task_5};
    int finishVoiceList[] = {R.raw.finish_task_voice1, R.raw.finish_task_voice2, R.raw.finish_task_voice3, R.raw.finish_task_voice4, R.raw.finish_task_voice5};


    public DailyTaskDialog(Context context, int coin) {
        super(context, R.style.daily_task_dialog);
        this.context = context;
        this.coin = coin;
    }

    public DailyTaskDialog(Context context, int coin, boolean isFromExplore) {
        super(context, R.style.daily_task_dialog);
        this.context = context;
        this.coin = coin;
        this.isFromExplore = isFromExplore;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.daily_task_dialog);
        WindowManager m = getWindow().getWindowManager();
        Display d = m.getDefaultDisplay();
        WindowManager.LayoutParams p = getWindow().getAttributes();
//        p.height = d.getHeight(d.getHeight());
        p.width = (int) (d.getWidth() - 2 * 40);
        p.gravity = Gravity.CENTER_HORIZONTAL;

        mShortMediaPlayer.addOnPlayListener(mOnPlayListener);

        getWindow().setAttributes(p);
        initViews();
    }

    @Override
    protected void initViews() {
        setCancelable(true);
        ivDismiss = (ImageView) findViewById(R.id.dismiss_iv);
        ivOk = (ImageView) findViewById(R.id.ok_iv);
        mtvNum = (MagicTextView) findViewById(R.id.num_mtv);
        ivBg = (ImageView) findViewById(R.id.bg_iv);
        container = findViewById(R.id.container);

        mtvNum.setText("x" + coin);
        int index = ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getVoiceIndex();
        ivBg.setImageResource(bgList[index]);

        mShortMediaPlayer.addPlayQueue(finishVoiceList[index], PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.FINISH_TASK_AUDIO);

//        if(!UserService.getInstance().isLogining() || UserService.getInstance().getCurrentUserLevel() == Constants.LEVEL_0){
//            ivBg.setImageResource(bgList[0]);
//        }else if(UserService.getInstance().getCurrentUserLevel() == Constants.LEVEL_1){
//            ivBg.setImageResource(bgList[1]);
//        }else if(UserService.getInstance().getCurrentUserLevel() == Constants.LEVEL_2){
//            ivBg.setImageResource(bgList[2]);
//        }else if(UserService.getInstance().getCurrentUserLevel() == Constants.LEVEL_3){
//            ivBg.setImageResource(bgList[3]);
//        }else{
//            ivBg.setImageResource(bgList[4]);
//        }


        ivDismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("0", "discovery_home_page_daily_task_alert_window", TimeUtil.currentTime()));
                playDismissAnim(false);
            }
        });

        ivOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1", "discovery_home_page_daily_task_alert_window", TimeUtil.currentTime()));
                playDismissAnim(true);
            }
        });

//        mtvNum.setStroke(9, Color.rgb(239,227,44));

    }

    AnimatorSet endAnimSet;

    public void playDismissAnim(final boolean showTaskList) {
        if (endAnimSet == null) {
            container.setBackgroundColor(0);

            endAnimSet = new AnimatorSet();

            //旋转 缩放 位移 到头像位置
            ValueAnimator logo_rotation = ObjectAnimator.ofFloat(container, "rotation", 0, 360);
            ValueAnimator logo_scaleY = ObjectAnimator.ofFloat(container, "scaleY", 1.0f, 0.0f);
            ValueAnimator logo_scaleX = ObjectAnimator.ofFloat(container, "scaleX", 1.0f, 0.0f);
            ValueAnimator logo_translationY = ObjectAnimator.ofFloat(container, "translationY", 0, LocalDisplay.dp2px(150) - LocalDisplay.SCREEN_HEIGHT_PIXELS / 2.0f);
            endAnimSet.playTogether(logo_rotation, logo_scaleY, logo_scaleX, logo_translationY);

            endAnimSet.setDuration(1000);
            endAnimSet.setInterpolator(new AccelerateInterpolator());
            endAnimSet.start();
            endAnimSet.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
//                    if (showTaskList) {
//                        if (UserService.getInstance().isLogining()) {
//                            FragmentUtil.pushFragment(TaskFragment.class, null);
//                        } else {
//                            LoginOrRegisterActivity.startActivity(getContext(), "登录才能去完成任务哦", "kada://opentasklist");
//                        }
//                    }
                    dismiss();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        playDismissAnim(false);
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void dismiss() {
        super.dismiss();

        getHandler().removeCallbacksAndMessages(null);
        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.FINISH_TASK_AUDIO);

            mShortMediaPlayer.removeOnPlayListener(mOnPlayListener);
        }

//        if (!isFromExplore){
//            EventBus.getDefault().post(new CoinNeedRefreshEvent(true));
//            EventBus.getDefault().post(new CoinUpdateEvent());
//            EventBus.getDefault().post(new ExploreFragmentRefreshEvent());
//        }
    }

    private OnPlayListener mOnPlayListener = new OnPlayListener() {
        @Override
        public void onPrepared(String audioTag, int playMode) {

        }

        @Override
        public void onCompletion(String audioTag, int playMode) {
            if (AudioName.FINISH_TASK_AUDIO.equals(audioTag)) {
                //v3.6.5需求  音频播放完后3秒内无操作自动关闭，操作处理同点击 确定
                getHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        playDismissAnim(true);
                    }
                }, 3000);
            }
        }

        @Override
        public void onError(String audioTag, int playMode) {
            if (AudioName.FINISH_TASK_AUDIO.equals(audioTag)) {
                //v3.6.5需求  音频播放完后3秒内无操作自动关闭，操作处理同点击 确定
                getHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        playDismissAnim(true);
                    }
                }, 3000);
            }
        }

        @Override
        public void onStop(String audioTag, int playMode) {

        }
    };

}
