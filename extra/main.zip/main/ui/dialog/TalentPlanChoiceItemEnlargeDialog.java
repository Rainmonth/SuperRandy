package com.hhdd.kada.main.ui.dialog;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.event.EnlargeChoiceCoverEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;
import com.hhdd.kada.module.talentplan.model.TalentPlanChoiceItemInfo;
import com.hhdd.kada.module.userhabit.StaCtrName;

import butterknife.BindView;
import butterknife.ButterKnife;


public class TalentPlanChoiceItemEnlargeDialog extends BaseDialog {

    @BindView(R.id.iv_choice)
    ScaleDraweeView ivChoice;
    @BindView(R.id.layout_enlarge_dialog)
    LinearLayout layoutEnlargeDialog;

    private String TAG_TALENT_PLAN_CHOICE_ITEM_ENLARGE_DIALOG_MEDIA = "talentPlanChoiceItemEnlargeDialogTag";

    private TalentPlanChoiceItemInfo mItemInfo;
    private View mView;
    private int centerX;
    private int centerY;
    private AnimatorSet animatorSet;
    private LinearLayout.LayoutParams imageParams;
    private boolean isDismissByUser;
    private int mBookId;
    private int mQuestionId;
    private IMediaPlayer mMediaPlayer;
    private OnPlayListener onPlayListener;
    private int nextPosition;

    public TalentPlanChoiceItemEnlargeDialog(Context context) {

        super(context, R.style.popup_dialog);
    }

    public void setBookIdAndQuestionId(int bookId, int questionId) {
        mBookId = bookId;
        mQuestionId = questionId;
    }

    public void setNextPosition(int position) {
        this.nextPosition = position;
    }

    public void setChoiceItemInfo(TalentPlanChoiceItemInfo info) {
        this.mItemInfo = info;
    }

    public void setView(View view) {
        this.mView = view;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_talent_plan_choice_item_enlarge);
        ButterKnife.bind(this);

        initWindowSize();

        imageParams = (LinearLayout.LayoutParams) ivChoice.getLayoutParams();
        if (imageParams == null) {
            imageParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        int[] location = new int[2];
        mView.getLocationOnScreen(location);

        imageParams.leftMargin = location[0];
        imageParams.topMargin = location[1] - LocalDisplay.getStatusBarHeight(mContext);
        imageParams.width = mView.getWidth();
        imageParams.height = mView.getWidth();

        centerX = location[0] + mView.getWidth() / 2;
        centerY = location[1] + mView.getWidth() / 2;

        layoutEnlargeDialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isDismissByUser = true;
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mBookId + "," + mQuestionId, StaCtrName.auto_enlarge_cancel_all, TimeUtil.currentTime()));
                dismiss();
            }
        });
    }


    @Override
    public void show() {
        super.show();
        if (!isValidContext(mContext)) {
            return;
        }
        if (mItemInfo != null) {
            FrescoUtils.showImg(ivChoice, CdnUtils.getImgCdnUrl(mItemInfo.subjectUrl, true));
            playEnlargeAnim();
            if (!TextUtils.isEmpty(mItemInfo.soundUrl)) {
                mMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
                onPlayListener = new OnPlayListener() {
                    @Override
                    public void onPrepared(String audioTag, int playMode) {

                    }

                    @Override
                    public void onCompletion(String audioTag, int playMode) {
                        if (audioTag.equals(TAG_TALENT_PLAN_CHOICE_ITEM_ENLARGE_DIALOG_MEDIA)) {
                            dismiss();
                        }
                    }

                    @Override
                    public void onError(String audioTag, int playMode) {

                    }

                    @Override
                    public void onStop(String audioTag, int playMode) {

                    }
                };
                mMediaPlayer.addOnPlayListener(onPlayListener);
                mMediaPlayer.addPlayQueue(Uri.parse(mItemInfo.soundUrl), PlayMode.IMMEDIATELY_PLAY_MODE, TAG_TALENT_PLAN_CHOICE_ITEM_ENLARGE_DIALOG_MEDIA);
            } else {
                getHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        dismiss();
                    }
                }, 3000);
            }
        }
    }

    @Override
    public void onBackPressed() {
        isDismissByUser = true;
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(mBookId + "," + mQuestionId, StaCtrName.auto_enlarge_cancel_all, TimeUtil.currentTime()));
        dismiss();
        super.onBackPressed();
    }

    @Override
    public void dismiss() {
        if (mMediaPlayer != null) {
            mMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, TAG_TALENT_PLAN_CHOICE_ITEM_ENLARGE_DIALOG_MEDIA);
            if (onPlayListener != null) {
                mMediaPlayer.removeOnPlayListener(onPlayListener);
            }
        }
        if (animatorSet != null) {
            animatorSet.removeAllListeners();
            animatorSet.cancel();
            animatorSet = null;
        }
        if (getHandler() != null) {
            getHandler().removeCallbacksAndMessages(null);
        }
        super.dismiss();

        if (nextPosition > 0 && !isDismissByUser) {
            EventCenter.fireEvent(new EnlargeChoiceCoverEvent(nextPosition, mQuestionId));
        }
    }

    private void playEnlargeAnim() {
        int endX = 0;
        int endY = 0;

        if (AppUtils.getOritation() == Configuration.ORIENTATION_PORTRAIT) {//判断是否为竖屏
            endX = LocalDisplay.SCREEN_WIDTH_PIXELS / 2 - centerX;
            endY = LocalDisplay.SCREEN_HEIGHT_PIXELS / 2 - centerY;
        } else if (AppUtils.getOritation() == Configuration.ORIENTATION_LANDSCAPE) {
            endX = LocalDisplay.SCREEN_HEIGHT_PIXELS / 2 - centerX;
            endY = LocalDisplay.SCREEN_WIDTH_PIXELS / 2 - centerY;
        }

        float ratio = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(60)) / mView.getWidth();

        ObjectAnimator animator1 = ObjectAnimator.ofFloat(ivChoice, "translationX", 0, endX);
        ObjectAnimator animator2 = ObjectAnimator.ofFloat(ivChoice, "translationY", 0, endY);

        ObjectAnimator animator3 = ObjectAnimator.ofFloat(ivChoice, "scaleX", 1, ratio);
        ObjectAnimator animator4 = ObjectAnimator.ofFloat(ivChoice, "scaleY", 1, ratio);

        ObjectAnimator animator5 = ObjectAnimator.ofFloat(ivChoice, "alpha", 0, 1f);

        if (animatorSet == null) {
            animatorSet = new AnimatorSet();
        }
        animatorSet.play(animator1).with(animator2).with(animator3).with(animator4).with(animator5);
        animatorSet.setDuration(300);
        animatorSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationEnd(Animator animation) {
                ivChoice.clearAnimation();
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animatorSet.start();
    }

    private void initWindowSize() {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        if (AppUtils.getOritation() == Configuration.ORIENTATION_PORTRAIT) {//判断是否为竖屏
            params.width = LocalDisplay.SCREEN_WIDTH_PIXELS;
            params.height = LocalDisplay.SCREEN_HEIGHT_PIXELS;
        } else if (AppUtils.getOritation() == Configuration.ORIENTATION_LANDSCAPE) {
            params.width = LocalDisplay.SCREEN_HEIGHT_PIXELS;
            params.height = LocalDisplay.SCREEN_WIDTH_PIXELS;
        }
        getWindow().setAttributes(params);
    }

}
