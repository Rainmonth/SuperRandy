package com.hhdd.kada.main.ui.dialog;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.view.Display;
import android.view.WindowManager;
import android.widget.ImageView;

import com.hhdd.kada.R;

/**
 * Created by lj on 15/7/7.
 */
public class ClearCacheDialog extends BaseDialog {

    private ValueAnimator animator;

    public ClearCacheDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dia_clear_cache);

        WindowManager m = getWindow().getWindowManager();
        Display d = m.getDefaultDisplay(); // 为获取屏幕宽、高
        WindowManager.LayoutParams p = getWindow().getAttributes(); // 获取对话框当前的参值
        p.height = (int) (d.getHeight() * 1.0); // 高度设置为屏幕的1.0
        p.width = (int) (d.getWidth() * 1.0); // 宽度设置为屏幕的0.8
        getWindow().setAttributes(p);

        initView();
    }

    void initView(){
        ImageView clear = (ImageView) findViewById(R.id.iv_clear);

        animator = ObjectAnimator.ofFloat(clear,"rotation",0,360);
        animator.setDuration(4000);
        animator.setRepeatCount(-1);
        animator.start();
    }

    @Override
    public void dismiss() {
        if(animator != null && animator.isRunning()){
            animator.cancel();
            animator = null;
        }
        super.dismiss();
    }
}
