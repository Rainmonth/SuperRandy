package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.hhdd.kada.R;
import com.hhdd.kada.main.views.fontinator.FontTextView;

/**
 * Created by sxh on 2017/8/24.
 */

public abstract class CommonDialog extends BaseDialog {

    protected Button yes;
    protected Button no;
    protected FontTextView content;

    protected CommonDialogCallback mCallback;

    public void setCallback(CommonDialogCallback callback){
        mCallback = callback;
    }

    public CommonDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    public CommonDialog(Context context, int theme) {
        super(context, R.style.popup_dialog);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dia_delete_book);
        initView();
    }

    private void initView() {
        setCancelable(false);
        yes = (Button) findViewById(R.id.btn_yes);
        no = (Button) findViewById(R.id.btn_no);
        content = (FontTextView) findViewById(R.id.content);
        doSpecialNeeds();
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallback !=null){
                    mCallback.doYes();
                }
                dismiss();
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallback !=null){
                    mCallback.doNo();
                }
                dismiss();
            }
        });
    }

    public abstract void doSpecialNeeds();

    public interface CommonDialogCallback{
        void doYes();
        void doNo();
    }
}
