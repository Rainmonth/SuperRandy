package com.hhdd.kada.main.ui.dialog;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.thread.IThread;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.main.mediaserver.MediaServer2;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.MemoryBar;
import com.hhdd.logger.LogHelper;

import java.io.File;
import java.math.BigDecimal;

/**
 * Created by lj on 16/4/19.
 */
public class ClearCacheDialog2 extends BaseDialog {


    Callback callback;
    String text;
    private int type;

    public static final int TYPE_BOOK = 1;
    public static final int TYPE_STORY = 2;
    public static final int TYPE_ALL = 3;

    public ClearCacheDialog2(Context context,Callback callback) {
        this(context, callback, TYPE_ALL);
    }

    public ClearCacheDialog2(Context context, Callback callback, int type) {
        super(context, R.style.popup_dialog);
        mContext = context;
        this.callback = callback;
        this.type = type;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dia_clear_cache2);

        initView();
        updateMemBar();
    }

    public void setText(String text){
        this.text = text;
        if(title != null){
            title.setText(text);
            title.invalidate();
        }
    }

    Context mContext;
    private ClearCacheDialog mClearCacheDialog;
    MemoryBar memoryBar;
    TextView title;
    void initView() {
        title = (TextView) findViewById(R.id.title);
        if(text != null && text.length() > 0){
            title.setText(text);
        }

        memoryBar = (MemoryBar) findViewById(R.id.memorybar);

        memoryBar.getLayoutParams().width = ScreenUtil.getScreenWidth(mContext);
        Button yes = (Button) findViewById(R.id.btn_yes);
        Button no = (Button) findViewById(R.id.btn_no);

        yes.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View view) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                        "1", "click_setting_clear_buffer_select", TimeUtil.currentTime()));

                if(mContext == null){
                    return;
                }
                if(mContext instanceof Activity){
                    if(((Activity) mContext).isFinishing()){
                        return;
                    }
                }
                mClearCacheDialog = new ClearCacheDialog(mContext);

                mClearCacheDialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialogInterface, int i, KeyEvent keyEvent) {
                        return false;
                    }
                });

                mClearCacheDialog.show();

                if(type == TYPE_BOOK){
                    ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeAllBookPendigTasks();
                    ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeAllBookItems();
                }else if(type == TYPE_STORY){
                    ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeAllStoryPendigTasks();
                    ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeAllStoryItems();
                }else if(type == TYPE_ALL){
                    ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeAllPendingTasks(true);
                    ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeAllItems();
                }

                ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE))
                        .postDaemonTask(clearCacheRunnable, "clearCacheJob");
            }
        });

        no.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View view) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(
                        "0", "click_setting_clear_buffer_select", TimeUtil.currentTime()));
                dismiss();
            }
        });
    }

    Runnable clearCacheRunnable = new Runnable() {
        @Override
        public void run() {
            dismiss();
            if(type != TYPE_STORY) {
                DatabaseManager.getInstance().bookCollectionItemStatusDB().deleteAllBookItemStatus();
                FileUtils.deleteFolderFile(Dirs.getBooksCachePath(), false);
            }
            if(type != TYPE_BOOK){
                //更新听书合集下所有合集下载状态
                DatabaseManager.getInstance().collectionItemStatusDB().deleteAllStoryItemStatus();
                FileUtils.deleteFolderFile(Dirs.getListenCachePath(), false);
            }
            if(type == TYPE_ALL) {
                FileUtils.deleteFolderFile(Dirs.getImageCachePath(), false);
                FileUtils.deleteFolderFile(Dirs.getTmpCachePath(), false);
                FileUtils.deleteFolderFile(MediaServer2.getRootPath(), false);
                FileUtils.deleteFolderFile(Dirs.getRequestCachePath(), false);
                FileUtils.deleteFolderFile(Dirs.getVideoCacheDir(), false);
            }
            getHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mClearCacheDialog != null) {
                        mClearCacheDialog.dismiss();
                    }

                    Toast.makeText(mContext, "清理缓存成功", Toast.LENGTH_SHORT).
                            show();

                    if(callback != null){
                        callback.refresh();
                    }
                }
            }, 3000);
        }
    };

    protected void updateMemBar() {
        ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE))
                .postDaemonTask(getCacheSizeRunnable, "GetCacheJob");
    }

    private Runnable getCacheSizeRunnable = new Runnable() {
        @Override
        public void run() {
            try {
                final Long booksCacheize = type != TYPE_STORY ? FileUtils.getFolderSize(Dirs.getBooksCachePath()) : 0;
                final Long storyCacheize = type != TYPE_BOOK ? FileUtils.getFolderSize(Dirs.getListenCachePath()) : 0;
                final long availableSize = getAvailableMemorySize();
                getHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        if (memoryBar != null) {
                            memoryBar.setProgress(formatM(booksCacheize),
                                    formatM(storyCacheize),
                                    formatM(availableSize));
                        }
                    }
                });
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        }
    };

    long formatM(long size) {
        double kiloByte = size / 1024;
        double megaByte = kiloByte / 1024;
        BigDecimal result2 = new BigDecimal(Double.toString(megaByte));
        return result2.longValue();
    }

    /**
     * @return isExit SDCard
     */
    public static boolean externalMemoryAvailable() {
        return android.os.Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED);
    }

    /**
     * @return Available of CacheDirectory
     */
    public static long getAvailableMemorySize() {
        if (externalMemoryAvailable())
            return getAvailableExternalMemorySize();
        else
            return getAvailableInternalMemorySize();
    }

    /**
     * @return Available Internal
     */
    public static long getAvailableInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return availableBlocks * blockSize;
    }

    /**
     * @return Available External
     */
    public static long getAvailableExternalMemorySize() {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return availableBlocks * blockSize;
    }

    public interface Callback{
        void refresh();
    }
}