package com.hhdd.kada.main.ui.dialog;

import android.animation.Animator;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.manager.DialogManager;
import com.hhdd.kada.main.model.IdiomInfo;
import com.hhdd.kada.main.ui.StreamUtils;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.record.callback.ChildrenDialogCallback;

import java.util.List;
import java.util.Random;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by mcx on 2017/7/24.
 */

public class ChildrenLockDialog extends BaseDialog {

    @BindView(R.id.iv_close)
    ImageView ivClose;

    @BindView(R.id.answer1)
    TextView answer1;
    @BindView(R.id.answer2)
    TextView answer2;
    @BindView(R.id.answer3)
    TextView answer3;
    @BindView(R.id.answer4)
    TextView answer4;

    @BindView(R.id.question1)
    TextView question1;
    @BindView(R.id.question2)
    TextView question2;
    @BindView(R.id.question3)
    TextView question3;

    @BindView(R.id.tv_tryAgain)
    TextView btnTryAgain;

    @BindView(R.id.container)
    View container;

    @BindView(R.id.wrong_message)
    TextView wrongMessage;
    @BindView(R.id.iv_bg)
    ImageView background;

    //控制儿童锁不再弹出的时间
    long lockTime = 30 * 60 * 1000;

    int[] ints = {1, 2, 3};
    TextView[] answers;
    TextView[] questions;
    private IdiomInfo idiomInfo;

    boolean isRight = false;
    boolean isMustShow = false;  //是否必须弹出，无30分钟限制
    private ChildrenDialogCallback mCallback;

    String idiomJson;
    int randomIndex;

    PrefsManager prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
    long childrenDialogTime = 0;

    public ChildrenLockDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    public ChildrenLockDialog(Context context, boolean isMustShow) {
        super(context, R.style.popup_dialog);
        this.isMustShow = isMustShow;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_children_lock);
        ButterKnife.bind(this);
        idiomJson = StreamUtils.get(getContext(), R.raw.idiom);

        answers = new TextView[]{answer1, answer2, answer3, answer4};
        questions = new TextView[]{question1, question2, question3};

        loadIdiom();
        tryAgain();

        ivClose.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_lock_close_click", TimeUtil.currentTime()));
                dismiss();
            }
        });

        btnTryAgain.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_lock_next_click", TimeUtil.currentTime()));
                tryAgain();
            }
        });
        setOnCancelListener(new OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialog) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_lock_other_place_click", TimeUtil.currentTime()));
            }
        });

        question1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickQuestion(0);
            }
        });
        question2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickQuestion(1);
            }
        });
        question3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clickQuestion(2);
            }
        });

        answer2.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                clickAnswer(1);
            }
        });

        answer3.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                clickAnswer(2);
            }
        });

        answer4.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                clickAnswer(3);
            }
        });

    }

    public void setCallback(ChildrenDialogCallback callback) {
        mCallback = callback;
    }

    public void clearCallback() {
        mCallback = null;
    }

    void check() {
        String answer = "";
        for (int i = 0; i < answers.length; i++) {
            answer = answer + answers[i].getText();
        }
        if (answer.length() < 4) {
            return;
        }

        String idiom = idiomInfo.getData().get(randomIndex).getIdiom();
        if (TextUtils.equals(answer, idiom)) {
            getHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    isRight = true;
                    prefsManager.putBoolean(Constants.IS_CHILDREN_LOCK_ANSWER_RIGHT, isRight);
                    dismiss();
                }
            }, 100);
        } else {
            getHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_lock_failure", TimeUtil.currentTime()));
                    isRight = false;
                    wrongMessage.setVisibility(View.VISIBLE);
                    playFalseAnim();
                }
            }, 100);
        }
    }

    void clickAnswer(int index) {

        if (answers[index].getText() != null && answers[index].getText().length() > 0) {
            for (int i = 0; i < questions.length; i++)
                if (TextUtils.equals(answers[index].getText(), questions[i].getText()) && questions[i].getVisibility() == View.INVISIBLE) {
                    questions[i].setVisibility(View.VISIBLE);
                    break;
                }

            answers[index].setBackgroundResource(R.drawable.bg_children_dialog_ask);
            answers[index].setText("");
        }
    }

    void clickQuestion(int index) {
        for (int i = 1; i < answers.length; i++) {
            if (answers[i].getText() == null || answers[i].getText().length() == 0) {
                answers[i].setText(questions[index].getText());
                questions[index].setVisibility(View.INVISIBLE);
                answers[i].setBackgroundResource(R.drawable.bg_children_dialog_text);
                answers[i].setTextColor(Color.WHITE);
                break;
            }
        }
        check();
    }

    void loadIdiom() {
        Gson gson = new Gson();
        idiomInfo = gson.fromJson(idiomJson, new TypeToken<IdiomInfo>() {
        }.getType());
    }

    void tryAgain() {
        if (idiomInfo == null) {
            return;
        }

        List<IdiomInfo.DataBean> dataBeens = idiomInfo.getData();
        if (dataBeens == null || dataBeens.isEmpty()) {
            return;
        }

        int size = dataBeens.size();

        Random random = new Random();
        randomIndex = random.nextInt(size);
        wrongMessage.setVisibility(View.GONE);

        int[] index = getRandomArray(1, 3, 3);

        List<String> textList = dataBeens.get(randomIndex).getTextList();

        answer1.setText(textList.get(0));

        answer2.setBackgroundResource(R.drawable.bg_children_dialog_ask);
        answer2.setText("");

        answer3.setBackgroundResource(R.drawable.bg_children_dialog_ask);
        answer3.setText("");

        answer4.setBackgroundResource(R.drawable.bg_children_dialog_ask);
        answer4.setText("");

        question1.setBackgroundResource(R.drawable.bg_children_dialog_text);
        question1.setText(textList.get(index[0]));
        question1.setVisibility(View.VISIBLE);

        question2.setBackgroundResource(R.drawable.bg_children_dialog_text);
        question2.setText(textList.get(index[1]));
        question2.setVisibility(View.VISIBLE);

        question3.setBackgroundResource(R.drawable.bg_children_dialog_text);
        question3.setText(textList.get(index[2]));
        question3.setVisibility(View.VISIBLE);
    }

    void playFalseAnim() {

        ObjectAnimator nopeAnimator = tada(container);
        nopeAnimator.setRepeatCount(1);
        nopeAnimator.setInterpolator(new LinearInterpolator());

        nopeAnimator.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                btnTryAgain.setClickable(false);
                for (int i = 0; i < answers.length; i++) {
                    answers[i].setClickable(false);
                }
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                tryAgain();
                btnTryAgain.setClickable(true);
                for (int i = 0; i < answers.length; i++) {
                    answers[i].setClickable(true);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        nopeAnimator.start();
    }

    @Override
    public void dismiss() {

        if (!isMustShow) {
            isRight = prefsManager.getBoolean(Constants.IS_CHILDREN_LOCK_ANSWER_RIGHT);
            if (isRight) {
                prefsManager.putLong("children_dialog_time", System.currentTimeMillis());
            } else {
                prefsManager.putLong("children_dialog_time", 0);
            }
        }
        if (isRight) {
            if (mCallback != null) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_lock_success", TimeUtil.currentTime()));
                mCallback.onAnswerRight();
            }
        } else {
            if (mCallback != null) {
                mCallback.onDirectDismiss();
            }
        }
        super.dismiss();
    }


    @Override
    public void show() {
        if (!isMustShow) {
            childrenDialogTime = prefsManager.getLong("children_dialog_time");
            isRight = prefsManager.getBoolean(Constants.IS_CHILDREN_LOCK_ANSWER_RIGHT);
            //回答正确后在lockTime时间内不再展示

            //回答正确后30分钟内不再展示
            if (System.currentTimeMillis() - childrenDialogTime > lockTime || childrenDialogTime == 0) {
                super.show();
                prefsManager.putLong("children_dialog_time", System.currentTimeMillis());
                prefsManager.putBoolean(Constants.IS_CHILDREN_LOCK_ANSWER_RIGHT, false);
            } else if (mCallback != null && isRight) {
                mCallback.onAnswerRight();
                ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissDialog(this);
            } else {
                ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissDialog(this);
            }
        } else {
            isRight = false;
            super.show();
        }
    }


    /**
     * 回答错误动画
     *
     * @param view
     * @return
     */

    public static ObjectAnimator tada(View view) {
        return tada(view, 1f);
    }

    public static ObjectAnimator tada(View view, float shakeFactor) {

//        PropertyValuesHolder pvhScaleX = PropertyValuesHolder.ofKeyframe(View.SCALE_X,
//                Keyframe.ofFloat(0f, 1f),
//                Keyframe.ofFloat(.1f, .9f),
//                Keyframe.ofFloat(.2f, .9f),
//                Keyframe.ofFloat(.3f, 1.0f),
//                Keyframe.ofFloat(.4f, 1.0f),
//                Keyframe.ofFloat(.5f, 1.0f),
//                Keyframe.ofFloat(.6f, 1.0f),
//                Keyframe.ofFloat(.7f, 1.0f),
//                Keyframe.ofFloat(.8f, 1.0f),
//                Keyframe.ofFloat(.9f, 1.0f),
//                Keyframe.ofFloat(1f, 1f)
//        );
//
//        PropertyValuesHolder pvhScaleY = PropertyValuesHolder.ofKeyframe(View.SCALE_Y,
//                Keyframe.ofFloat(0f, 1f),
//                Keyframe.ofFloat(.1f, .9f),
//                Keyframe.ofFloat(.2f, .9f),
//                Keyframe.ofFloat(.3f, 1.0f),
//                Keyframe.ofFloat(.4f, 1.0f),
//                Keyframe.ofFloat(.5f, 1.0f),
//                Keyframe.ofFloat(.6f, 1.0f),
//                Keyframe.ofFloat(.7f, 1.0f),
//                Keyframe.ofFloat(.8f, 1.0f),
//                Keyframe.ofFloat(.9f, 1.0f),
//                Keyframe.ofFloat(1f, 1f)
//        );

        PropertyValuesHolder pvhRotate = PropertyValuesHolder.ofKeyframe(View.ROTATION,
                Keyframe.ofFloat(0f, 0f),
                Keyframe.ofFloat(.1f, -4f * shakeFactor),
                Keyframe.ofFloat(.2f, -4f * shakeFactor),
                Keyframe.ofFloat(.3f, 4f * shakeFactor),
                Keyframe.ofFloat(.4f, -4f * shakeFactor),
                Keyframe.ofFloat(.5f, 4f * shakeFactor),
                Keyframe.ofFloat(.6f, -4f * shakeFactor),
                Keyframe.ofFloat(.7f, 4f * shakeFactor),
                Keyframe.ofFloat(.8f, -4f * shakeFactor),
                Keyframe.ofFloat(.9f, 4f * shakeFactor),
                Keyframe.ofFloat(1f, 0)
        );

        return ObjectAnimator.ofPropertyValuesHolder(view, pvhRotate).
                setDuration(500);
    }

    /**
     * 取随机数组
     */

    public static int[] randomArray(int min, int max, int n) {
        int len = max - min + 1;

        if (max < min || n > len) {
            return null;
        }

        //初始化给定范围的待选数组
        int[] source = new int[len];
        for (int i = min; i < min + len; i++) {
            source[i - min] = i;
        }

        int[] result = new int[n];
        Random rd = new Random();
        int index = 0;
        for (int i = 0; i < result.length; i++) {
            //待选数组0到(len-2)随机一个下标
            index = Math.abs(rd.nextInt() % len--);
            //将随机到的数放入结果集
            result[i] = source[index];
            //将待选数组中被随机到的数，用待选数组(len-1)下标对应的数替换
            source[index] = source[len];
        }
        return result;
    }

    //排除{1，2，3}
    private int[] getRandomArray(int min, int max, int n) {
        int[] random = randomArray(min, max, n);
        if (ints != null) {

            if (isEquals(random, ints)) {
                return getRandomArray(min, max, n);
            } else {
                return random;
            }
        } else {
            return random;
        }
    }

    public static boolean isEquals(int[] a, int[] b) {
        for (int i = 0; i != (a.length < b.length ? a.length : b.length); i++)
            if (a[i] != b[i]) return false;
        return true;
    }

    @Override
    public boolean onTouchEvent(@NonNull MotionEvent event) {
        if (!newInRangeOfView(background, event)) {
            dismiss();
            return true;
        }
        return super.onTouchEvent(event);
    }


    private boolean newInRangeOfView(View view, MotionEvent ev) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        if (ev.getRawX() < location[0] || ev.getRawX() > (location[0] + view.getWidth()) || ev.getRawY() < location[1] || ev.getRawY() > (location[1] + view.getHeight())) {
            return false;
        }
        return true;
    }

    @Override
    public void setCanceledOnTouchOutside(boolean cancel) {

    }
}
