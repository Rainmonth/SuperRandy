package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.kada.main.utils.ScreenUtil;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/8/16
 * @describe : com.hhdd.kada.main.ui.dialog
 */
public class ConfirmDialog extends BaseDialog {

    @BindView(R.id.layout)
    View layout;
    @BindView(R.id.contentTextView)
    TextView contentTextView;
    @BindView(R.id.cancelTextView)
    TextView cancelTextView;
    @BindView(R.id.confirmTextView)
    TextView confirmTextView;
    private OnConfirmDialogListener listener;

    public ConfirmDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_confirm);
        ButterKnife.bind(this);

        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.dimAmount = 0.5f;
        getWindow().setAttributes(params);

        layout.getLayoutParams().width = ScreenUtil.getScreenWidth() * 3 / 4;
        initListener();
    }

    /**
     * 初始化事件监听
     */
    private void initListener() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.cancelTextView:
                        dismiss();
                        if (ConfirmDialog.this.listener != null) {
                            ConfirmDialog.this.listener.onCancel();
                        }
                        break;
                    case R.id.confirmTextView:
                        if (ConfirmDialog.this.listener != null) {
                            ConfirmDialog.this.listener.onConfirm();
                        }
                        break;
                    default:
                        break;
                }
            }
        };
        cancelTextView.setOnClickListener(listener);
        confirmTextView.setOnClickListener(listener);
    }

    /**
     * 更新弹窗展示内容及按钮文案
     * @param contentResId
     */
    public void update(int contentResId) {
        update(AppUtils.getString(contentResId));
    }

    /**
     * 更新弹窗展示内容及按钮文案
     * @param content
     */
    public void update(String content) {
        update(content, R.string.confirm_dialog_cancel, R.string.confirm_dialog_confirm);
    }

    /**
     * 更新弹窗展示内容及按钮文案
     * @param contentResId
     * @param cancelTextResId
     * @param confirmTextResId
     */
    public void update(int contentResId, int cancelTextResId, int confirmTextResId) {
        update(AppUtils.getString(contentResId), cancelTextResId, confirmTextResId);
    }

    /**
     * 更新弹窗展示内容及按钮文案
     * @param content
     * @param cancelTextResId
     * @param confirmTextResId
     */
    public void update(String content, int cancelTextResId, int confirmTextResId) {
        if (contentTextView != null) {
            contentTextView.setText(content);
        }
        if (cancelTextView != null) {
            cancelTextView.setText(cancelTextResId);
        }
        if (confirmTextView != null) {
            confirmTextView.setText(confirmTextResId);
        }
    }

    /**
     * 设置回调监听
     * @param listener
     */
    public void setOnConfirmDialogListener(OnConfirmDialogListener listener) {
        this.listener = listener;
    }

    /**
     * 设置内容对齐方式
     * @param gravity
     */
    public void setContentGravity(int gravity) {
        contentTextView.setGravity(gravity);
    }

    /**
     * 是否显示单按钮
     * @param isShowSingleButton
     */
    public void setShowSingleButton(boolean isShowSingleButton) {
        if (cancelTextView != null && confirmTextView != null) {
            cancelTextView.setVisibility(isShowSingleButton ? View.GONE : View.VISIBLE);
            confirmTextView.setBackgroundResource(isShowSingleButton ? R.drawable.bg_dialog_confirm_confirm_single
                    : R.drawable.bg_dialog_confirm_confirm);
        }
    }

    /**
     * 自定义监听
     */
    public static abstract class MyConfirmDialogListener implements OnConfirmDialogListener {

        @Override
        public void onCancel() {

        }
    }

    /**
     * 确认框按钮点击回调监听
     */
    public interface OnConfirmDialogListener {

        /**
         * 点击取消按钮
         */
        void onCancel();

        /**
         * 点击确认按钮
         */
        void onConfirm();
    }
}
