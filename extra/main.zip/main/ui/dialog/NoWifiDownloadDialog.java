package com.hhdd.kada.main.ui.dialog;

import android.content.Context;

/**
 * Created by sxh on 2017/8/24.
 */

public class NoWifiDownloadDialog extends CommonDialog {

    public NoWifiDownloadDialog(Context context) {
        super(context);
    }

    public NoWifiDownloadDialog(Context context, int theme) {
        super(context, theme);
    }

    @Override
    public void doSpecialNeeds() {
        content.setText("当前网络不是WiFi环境\n是否继续下载?");
    }
}
