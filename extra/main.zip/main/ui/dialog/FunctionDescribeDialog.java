package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.TimeUtil;

/**
 * Created by sxh on 17/6/22.
 */
public class FunctionDescribeDialog extends BaseDialog {


    private TextView tvContent;
    Context mContext;
    private ImageView btnOk;
    private Callback mCallback;
    private String mContent;
    private String mTitle;
    private ImageView dismiss;
    private TextView tvTitle;
    private int mButtonImage;

    public static class Build {
        private Context ctx;
        private String content;
        private String title;
        private Callback callback;
        private int buttonImage;

        public int getButtonImage() {
            return buttonImage;
        }

        public Build setButtonImage(int buttonImage) {
            this.buttonImage = buttonImage;
            return this;
        }

        public Build() {
        }

        public String getTitle() {
            return title;
        }

        public Build setTitle(String title) {
            this.title = title;
            return this;
        }

        public Context getContext() {
            return ctx;
        }

        public Build setContext(Context ctx) {
            this.ctx = ctx;
            return this;
        }

        public String getContent() {
            return content;
        }

        public Build setContent(String content) {
            this.content = content;
            return this;
        }


        public Callback getCallback() {
            return callback;
        }

        public Build setCallback(Callback callback) {
            this.callback = callback;
            return this;
        }

        public FunctionDescribeDialog create() {
            return new FunctionDescribeDialog(ctx, content, buttonImage, title, callback);
        }


    }

    private FunctionDescribeDialog(Context context, String content, int buttonImage, String title, Callback callback) {
        super(context, R.style.popup_dialog);
        mCallback = callback;
        mButtonImage = buttonImage;
        mContext = context;
        this.mTitle = title;
        this.mContent = content;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dia_function_describe1);
        initView();
    }

    @Override
    public void show() {
        super.show();
    }


    void initView() {
        setCanceledOnTouchOutside(false);
        tvContent = (TextView) findViewById(R.id.content_permission);
        tvTitle = (TextView) findViewById(R.id.title);
        dismiss = (ImageView) findViewById(R.id.dismiss);
        btnOk = (ImageView) findViewById(R.id.icon_ok);
        if (!TextUtils.isEmpty(mContent)) {
            tvContent.setText(mContent);
        }
        if (mButtonImage > 0) {
            btnOk.setImageResource(mButtonImage);
        }
        if (!TextUtils.isEmpty(mTitle)) {
            tvTitle.setText(mTitle);
        }

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mCallback != null) {
                    mCallback.refresh();
                }
                dismiss();
            }
        });
        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "network_authority_notice_close_click", TimeUtil.currentTime()));
                dismiss();
            }
        });
    }

    public interface Callback {
        void refresh();
    }

}