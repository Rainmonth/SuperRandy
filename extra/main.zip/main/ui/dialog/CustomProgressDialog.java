package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.content.DialogInterface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.widget.TextView;

import com.hhdd.kada.android.library.R;


/**
 * Created by lj on 16/9/10.
 */
public class CustomProgressDialog extends BaseDialog {

    private Context mContext;

    public CustomProgressDialog(Context context){
        this(context, null);
    }
    public CustomProgressDialog(Context context, String strMessage) {
        this(context, R.style.progress_dialog, strMessage);
    }

    TextView tvMsg;
    public CustomProgressDialog(Context context, int theme, String strMessage) {
        super(context, theme);
        mContext = context;
        this.setContentView(R.layout.dig_progress);
        this.getWindow().getAttributes().gravity = Gravity.CENTER;
        tvMsg = (TextView) this.findViewById(R.id.id_tv_loadingmsg);
        if (strMessage != null) {
            tvMsg.setText(strMessage);
        }else{
            tvMsg.setText("载入中...");
        }


        getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        setCanceledOnTouchOutside(false);

        setOnKeyListener(new OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if(keyCode==KeyEvent.KEYCODE_BACK){
                    if(mListener != null){
                        mListener.onClosed();
                    }
                }
                return false;
            }
        });
    }


    Listener mListener;
    public void setListener(Listener listener){
        mListener = listener;
    }


    public void setStrMessage(String strMessage){
        if(tvMsg != null){
            tvMsg.setText(strMessage);
        }
    }

    public interface Listener{
        public void onClosed();
    }
}
