package com.hhdd.kada.main.ui.dialog;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.R;
import com.hhdd.kada.main.playback.SoundPlayback;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.medal.Medal;
import com.hhdd.kada.medal.MedalManager;

import butterknife.BindView;

public class MedalGainedDialog extends MedalBaseDialog {

    @BindView(R.id.iv_light1)
    ImageView ivLight1;
    @BindView(R.id.iv_light2)
    ImageView ivLight2;
    @BindView(R.id.iv_background)
    ImageView ivBackground;
    @BindView(R.id.iv_logo)
    SimpleDraweeView ivLogo;
    @BindView(R.id.iv_stars)
    ImageView ivStars;
    @BindView(R.id.iv_left)
    ImageView ivLeft;
    @BindView(R.id.iv_right)
    ImageView ivRight;
    @BindView(R.id.tv_medal_desc)
    TextView tvMedalDesc;
    @BindView(R.id.flag_medal_time)
    TextView flagMedalTime;
    @BindView(R.id.tv_medal_name)
    TextView tvMedalName;
    @BindView(R.id.tv_medal_time)
    TextView tvMedalTime;
    @BindView(R.id.layout_medal_gain)
    LinearLayout layoutMedalGain;

    //当这个两个字段都为true时，dialog才可以dismiss
    private boolean isMediaEnd;
    private boolean isAnimEnd;

    public MedalGainedDialog(Context context, Medal medal) {
        super(context, medal);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.dia_medal_gained;
    }

    @Override
    protected void initViews() {
        super.initViews();
        FrescoUtils.showUrl(mMedal.getGainImg(), ivLogo);
        tvMedalDesc.setText(mMedal.getDescription());
        tvMedalName.setText(mMedal.getName());
//        flagMedalTime.setVisibility(View.GONE);
        layoutMedalGain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    @Override
    public void show() {
        super.show();
        playMealSound(mMedal.getSoundUrl());
        playMedalAnim();
    }

    @Override
    protected void playMealSound(String soundUrl) {
        super.playMealSound(soundUrl);
        if (soundUrl != null && soundUrl.length() > 0) {
            String cacheFilePath = MedalManager.getMedalSoundFilePath(mMedal.getMedalId());
            if (mSoundPlayback == null) {
                mSoundPlayback = new SoundPlayback();
            }
            mSoundPlayback.setListener(new SoundPlayback.Listener() {
                @Override
                public void handlePrepared(SoundPlayback playback) {
                    playback.playFromBegin();
                }

                @Override
                public void handleCompletion(SoundPlayback playback) {
                    isMediaEnd = true;
                    if (isAnimEnd) {
                        dismiss();
                    }
                }
            });

            mSoundPlayback.prepare(getContext(), soundUrl, cacheFilePath);
        }
        //防止音频播放失败，从而导致dialog无法消失，这里做一个10s强制dismiss
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                dismiss();
            }
        }, 10000);
    }

    private void playMedalAnim() {
        //大光圈动画
        ObjectAnimator lightAnim1 = ObjectAnimator.ofFloat(ivLight1, "rotation", 0, 360);
        lightAnim1.setRepeatCount(-1);
        lightAnim1.setDuration(40000);
        lightAnim1.setInterpolator(new LinearInterpolator());
        lightAnim1.start();
        //小光圈动画
        ObjectAnimator lightAnim2 = ObjectAnimator.ofFloat(ivLight2, "rotation", 360, 0);
        lightAnim2.setRepeatCount(-1);
        lightAnim2.setDuration(40000);
        lightAnim2.setInterpolator(new LinearInterpolator());
        lightAnim2.start();

        AnimatorSet set = new AnimatorSet();
        set.play(lightAnim1).with(lightAnim2);
        set.start();

        final AnimatorSet startAnimSet = new AnimatorSet();
        startAnimSet.setInterpolator(new LinearInterpolator());
        startAnimSet.setDuration(500);

        //Logo缩放到中心
        final ValueAnimator animatorLogo = ObjectAnimator.ofFloat(ivLogo, "scaleY", 5.0f, 1.0f);
        animatorLogo.setRepeatCount(0);
        final ValueAnimator animatorLogo2 = ObjectAnimator.ofFloat(ivLogo, "scaleX", 5.0f, 1.0f);
        animatorLogo2.setRepeatCount(0);

        startAnimSet.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
                ivLogo.setVisibility(View.VISIBLE);
            }
        });
        startAnimSet.play(animatorLogo).with(animatorLogo2);

        //星星 翅膀 出现动画
        ValueAnimator star_scaleY = ObjectAnimator.ofFloat(ivStars, "scaleY", 0.0f, 1.0f);
        ValueAnimator star_scaleX = ObjectAnimator.ofFloat(ivStars, "scaleX", 0.0f, 1.0f);

        ValueAnimator wingleft_scaleY = ObjectAnimator.ofFloat(ivLeft, "scaleY", 1.0f, 2.3f);
        ValueAnimator wingleft_scaleX = ObjectAnimator.ofFloat(ivLeft, "scaleX", 1.0f, 2.3f);
        ValueAnimator wingleft_rotation = ObjectAnimator.ofFloat(ivLeft, "rotation", 90, 140);

        ValueAnimator wingright_scaleY = ObjectAnimator.ofFloat(ivRight, "scaleY", 1.0f, 2.3f);
        ValueAnimator wingright_scaleX = ObjectAnimator.ofFloat(ivRight, "scaleX", 1.0f, 2.3f);
        ValueAnimator wingright_rotation = ObjectAnimator.ofFloat(ivRight, "rotation", -90, -140);

        ivLeft.setPivotX(0);
        ivLeft.setPivotY(0);
        float scale = this.getContext().getResources().getDisplayMetrics().density;
        ivRight.setPivotX(40 * scale + 0.5f);
        ivRight.setPivotY(0);
        AnimatorSet animSet = new AnimatorSet();
        animSet.playTogether(star_scaleY, star_scaleX,
                wingleft_scaleY, wingleft_scaleX,
                wingleft_rotation, wingright_scaleY,
                wingright_scaleX, wingright_rotation);
        animSet.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                super.onAnimationStart(animation);
                ivStars.setVisibility(View.VISIBLE);
                ivRight.setVisibility(View.VISIBLE);
                ivLeft.setVisibility(View.VISIBLE);
            }
        });
        startAnimSet.play(animSet).after(animatorLogo);

        ValueAnimator wingleft_rotation1 = ObjectAnimator.ofFloat(ivLeft, "rotation", 140, 130);
        ValueAnimator wingright_rotation2 = ObjectAnimator.ofFloat(ivRight, "rotation", -140, -130);
        startAnimSet.play(wingleft_rotation1).after(animSet);
        startAnimSet.play(wingleft_rotation1).with(wingright_rotation2);

        startAnimSet.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                isAnimEnd = true;
                if (isMediaEnd) {
                    dismiss();
                }
            }
        });

        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startAnimSet.start();
            }
        }, 1500);

    }

}
