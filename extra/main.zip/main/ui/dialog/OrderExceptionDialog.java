package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.hhdd.kada.R;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/6
 * @describe : com.hhdd.kada.main.ui.dialog
 */
public class OrderExceptionDialog extends BaseDialog {

    private ContentIsDeletedDialog.ContentDialogCallback callback;

    public void setCallback(ContentIsDeletedDialog.ContentDialogCallback callback) {
        this.callback = callback;
    }

    public OrderExceptionDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_content_is_deleted);
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        TextView contentTextView = (TextView) findViewById(R.id.content);
        contentTextView.setText(R.string.order_exception_text);
        findViewById(R.id.btn_yes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (callback != null) {
                    callback.doYes();
                }
            }
        });
    }
}
