package com.hhdd.kada.main.ui.dialog;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.manager.TimeOutManager;
import com.hhdd.kada.main.playback.SoundPlayback;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.utils.SafeHandler;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.RangeBar;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by lj on 15/7/6.
 */
public class SettingDialog extends BaseDialog implements View.OnClickListener {


    private ArrayList<EditText> mEditTextList;
    private int[] image = {R.drawable.share_rest1, R.drawable.share_rest2, R.drawable.share_rest3};
    private EditText et_year, et_month;
    private TextView tv;
    private FrameLayout layout;
    private ImageView confirm;

    private FrameLayout mLayout1, mLayout2;
    private RangeBar mSeekBar;

    public SettingDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    private SafeHandler mCloseSettingHandler;

    SafeHandler getCloseSettingHandler() {
        if (mCloseSettingHandler == null) {
            mCloseSettingHandler = new SafeHandler();
        }
        return mCloseSettingHandler;
    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (((TimeOutManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.TIME_OUT_MANAGER)).isShow()) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "parentcontrolremovebywaiting", TimeUtil.currentTime()));
                Settings.getInstance().setUsingDuration(15);
                Settings.getInstance().refreshToCache();
                ((TimeOutManager)ServiceProxyFactory.getProxy().getService(ServiceProxyName.TIME_OUT_MANAGER)).setSettingDialogNeedDisplay(false);
                ((TimeOutManager)ServiceProxyFactory.getProxy().getService(ServiceProxyName.TIME_OUT_MANAGER)).setShow(false);
                dismiss();
            }
        }
    };

    @Override
    public void dismiss() {
        super.dismiss();
        if (mCloseSettingHandler != null) {
            mCloseSettingHandler.destroy();
            mCloseSettingHandler = null;
        }

        if (mSoundPlayback != null) {
            mSoundPlayback.releaseMediaPlayer();
            mSoundPlayback = null;
        }
    }

    SoundPlayback mSoundPlayback;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_setting);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        WindowManager m = getWindow().getWindowManager();
        Display d = m.getDefaultDisplay(); // 为获取屏幕宽、高
        WindowManager.LayoutParams p = getWindow().getAttributes(); // 获取对话框当前的参值
        p.width = (int) (d.getWidth() * 1.0); // 宽度设置为屏幕的0.8
        getWindow().setAttributes(p);

        final ScrollView scrollView = (ScrollView) findViewById(R.id.dialog_layout);
        scrollView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                scrollView.smoothScrollTo(0, scrollView.getBottom());
            }
        });
        //禁止ScrollView滑动
        scrollView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                hideSoftKeyboard(getCurrentFocus());
                return true;
            }
        });

        initView();

        setCancelable(false);

        getCloseSettingHandler().postDelayed(runnable, 15 * 60 * 1000);

        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                //播放提示音
                playSound();
            }
        },100);
    }

    void initView() {
        mLayout1 = (FrameLayout) findViewById(R.id.dialog_setting1);
        mLayout2 = (FrameLayout) findViewById(R.id.dialog_setting2);

        tv = (TextView) findViewById(R.id.tv_setting);
        layout = (FrameLayout) findViewById(R.id.birthday_login);
        confirm = (ImageView) findViewById(R.id.iv_confirm);

        et_year = (EditText) findViewById(R.id.year);
        et_month = (EditText) findViewById(R.id.month);

        ImageView imageView = (ImageView) findViewById(R.id.logo_setting);
        imageView.setImageResource(image[new Random().nextInt(3)]);

        mEditTextList = new ArrayList<EditText>();
        mEditTextList.add(et_year);
        mEditTextList.add(et_month);
        for (int i = 0; i < mEditTextList.size(); i++) {
            mEditTextList.get(i).addTextChangedListener(mTextWatcher);
        }

        tv.setOnClickListener(this);

        tv.setOnTouchListener(new View.OnTouchListener() {

            float firstlocation;
            float distance;

            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        firstlocation = motionEvent.getRawX();
                        break;
                    case MotionEvent.ACTION_MOVE:
                        distance = motionEvent.getRawX() - firstlocation;
                        break;
                    case MotionEvent.ACTION_UP:
                        if (distance > 0 && distance > (float) ScreenUtil.getScreenSize(getContext()).x * 0.3) {
                            mLayout1.setVisibility(View.GONE);
                            mLayout2.setVisibility(View.VISIBLE);
                        }


                }
                return false;
            }
        });

        layout.setOnClickListener(this);

        ImageView time_confirm = (ImageView) findViewById(R.id.time_confirm);

        mSeekBar = (RangeBar) findViewById(R.id.rangebar);
        mSeekBar.setTime(5);

        final CheckBox cb = (CheckBox) findViewById(R.id.cb_settime);
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                mSeekBar.setChecked(b);
                mSeekBar.invalidate();
            }
        });

        mSeekBar.setCallback(new RangeBar.ViewCallback() {
            @Override
            public void changeSeekBarStatus(boolean isSelected) {
                if (cb != null) {
                    cb.setChecked(isSelected);
                    cb.invalidate();
                }
            }
        });

        time_confirm.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View view) {
//                int time = mSeekBar.getTime();
                UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "parentcontrolremovebyslide", TimeUtil.currentTime()));
                Settings.getInstance().setNoLimitUsing(cb.isChecked());
                Settings.getInstance().setUsingDuration(mSeekBar.getTime());
                Settings.getInstance().refreshToCache();
                ((TimeOutManager)ServiceProxyFactory.getProxy().getService(ServiceProxyName.TIME_OUT_MANAGER)).setSettingDialogNeedDisplay(false);
                ((TimeOutManager)ServiceProxyFactory.getProxy().getService(ServiceProxyName.TIME_OUT_MANAGER)).setShow(false);
                getCloseSettingHandler().removeCallbacks(runnable);
                dismiss();
            }
        });


    }

    TextWatcher mTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (charSequence.length() == 2) {
                int done_input_id = SettingDialog.this.getCurrentFocus().getId();
                for (int a = 0; a < mEditTextList.size(); a++) {
                    if (mEditTextList.get(a).getId() == done_input_id) {
                        int next_index = (a + 1) % mEditTextList.size();
                        if (mEditTextList.get(next_index).getText().toString().length() < 2)
                            mEditTextList.get(next_index).requestFocus();
                    }
                }
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

    boolean isAnimating = false;
    boolean isAnimatingSecond = false;

    @Override
    public void onClick(View view) {

        if (isAnimating || isAnimatingSecond) return;

        if (view instanceof FrameLayout) {

            ValueAnimator animator = ObjectAnimator.ofFloat(layout, "rotationY", 0, 90);
            animator.setDuration(500);
            ValueAnimator animator1 = ObjectAnimator.ofFloat(confirm, "translationY", 0, confirm.getLayoutParams().height);
            animator1.setDuration(500);
            AnimatorSet set = new AnimatorSet();
            set.playTogether(animator, animator1);
            hideSoftKeyboard(SettingDialog.this.getCurrentFocus());
            set.start();
            isAnimating = true;
            animator.addListener(new AnimatorListenerAdapter() {

                @Override
                public void onAnimationStart(Animator animation) {
                    super.onAnimationStart(animation);
                }

                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    layout.setVisibility(View.GONE);
                    confirm.setVisibility(View.GONE);
                    ValueAnimator animator = ObjectAnimator.ofFloat(tv, "rotationY", 270, 360);
                    animator.setDuration(500);
                    animator.start();
                    animator.addListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            super.onAnimationEnd(animation);
                            isAnimating = false;
                        }
                    });
                }
            });
        }
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return false;
        }
        return super.onKeyDown(keyCode, event);
    }


    void playSound() {
        if (mSoundPlayback == null) {
            mSoundPlayback = new SoundPlayback();
        }
        mSoundPlayback.setListener(new SoundPlayback.Listener() {
            @Override
            public void handlePrepared(SoundPlayback playback) {
                playback.playFromBegin();
            }

            @Override
            public void handleCompletion(SoundPlayback playback) {
            }
        });
        mSoundPlayback.prepare(getContext(), Uri.parse("android.resource://" + KaDaApplication.getInstance().getPackageName() + "/" + R.raw.timeout_audio));
    }
}
