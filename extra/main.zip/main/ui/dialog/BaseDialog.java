package com.hhdd.kada.main.ui.dialog;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.manager.DialogManager;
import com.hhdd.kada.main.utils.SafeHandler;
import com.hhdd.logger.LogHelper;

/**
 * Created by simon on 18/6/15.
 */
public abstract class BaseDialog extends Dialog {

    private SafeHandler mHandler = null;
    protected Context mContext;

    public Handler getHandler() {
        if (mHandler == null) {
            mHandler = new SafeHandler(Looper.getMainLooper());
        }
        return mHandler;
    }

    public BaseDialog(Context context) {
        super(context);
        mContext = context;
    }

    public BaseDialog(Context context, int theme) {
        super(context, theme);
        mContext = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        setCanceledOnTouchOutside(true);
    }

    protected void initViews() {

    }

    @Override
    public void dismiss() {
        if (isValidContext(mContext) && this.isShowing()) {
            super.dismiss();
        }

        ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissDialog(this);

        //防止dialog在dismiss后 listener没有被回收而导致内存溢出
        try {
            setOnKeyListener(null);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }

        try {
            setOnCancelListener(null);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }

        try {
            setOnShowListener(null);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }

        try {
            setOnDismissListener(null);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }

        if (mHandler != null) {
            mHandler.destroy();
            mHandler = null;
        }
    }


    //检查context对应的Activity的状态
    protected boolean isValidContext(Context c) {
        if (c == null) {
            return false;
        }

        if (c instanceof Activity) {
            Activity a = (Activity) c;
            if (a.isFinishing()) {
                return false;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                if (a.isDestroyed()) {
                    return false;
                }
            }
        }

        return true;
    }


    void showSoftKeyboard() {
        InputMethodManager im = ((InputMethodManager) KaDaApplication.getInstance().getSystemService(Context.INPUT_METHOD_SERVICE));
//        im.showSoftInput(edit, InputMethodManager.SHOW_FORCED);
        im.toggleSoftInput(0, InputMethodManager.SHOW_FORCED);
    }

    void hideSoftKeyboard(View view) {
        InputMethodManager im = (InputMethodManager) KaDaApplication.getInstance().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (view != null && view.getWindowToken() != null) {
            im.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    public void show() {
        if (isValidContext(mContext)) {
            super.show();
        } else {
            ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissDialog(this);
        }
    }
}
