package com.hhdd.kada.main.ui.dialog;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;

/**
 * Created by simon on 18/6/15.
 */
public class TakePhotoSelectDialog extends BaseDialog {

    public TakePhotoSelectDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    RelativeLayout layout ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dlg_take_photo_selector);
        initViews();


    }

    @Override
    protected void initViews() {
        super.initViews();
        layout = (RelativeLayout) findViewById(R.id.photo_layout);
        findViewById(R.id.close).setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View view) {
                dismiss();
            }
        });
        findViewById(R.id.camera).setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View view) {
                if (mOnClickListener!=null) {
                    mOnClickListener.onClick(TakePhotoSelectDialog.this,0);
                }
                dismiss();
            }
        });
        findViewById(R.id.gallery).setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View view) {
                if (mOnClickListener!=null) {
                    mOnClickListener.onClick(TakePhotoSelectDialog.this,1);
                }
                dismiss();
            }
        });

    }

    OnClickListener mOnClickListener;

    public void show(OnClickListener listener) {
        mOnClickListener = listener;
        show();
    }

    @Override
    public void show() {
        if (mContext == null) {
            return;
        }

        if (mContext instanceof Activity) {
            if (((Activity) mContext).isFinishing()) {
                return;
            }
        }

        super.show();
    }
}
