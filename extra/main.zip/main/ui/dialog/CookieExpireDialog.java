package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.TimeUtil;

/**
 * Created by sxh on 17/6/22.
 */
public class CookieExpireDialog extends BaseDialog {


    private TextView tvContent;
    private TextView btnLeft;
//    private ImageView btnRight;
    private ImageView dismiss;
    private TextView tvTitle;

    private Callback mRightCallback;
    private String mContent;
    private String mTitle;

    public static class Build {
        private Context ctx;
        private String content;
        private String title;
        private Callback rightCallback;

        public Build() {
        }

        public String getTitle() {
            return title;
        }

        public Build setTitle(String title) {
            this.title = title;
            return this;
        }

        public Context getContext() {
            return ctx;
        }

        public Build setContext(Context ctx) {
            this.ctx = ctx;
            return this;
        }

        public String getContent() {
            return content;
        }

        public Build setContent(String content) {
            this.content = content;
            return this;
        }

        public Callback getRightCallback() {
            return rightCallback;
        }

        public Build setRightCallback(Callback rightCallback) {
            this.rightCallback = rightCallback;
            return this;
        }


        public CookieExpireDialog create() {
            return new CookieExpireDialog(ctx, content, title, rightCallback);
        }
    }

    private CookieExpireDialog(Context context, String content, String title, Callback rightCallback) {
        super(context, R.style.popup_dialog);
        mRightCallback = rightCallback;
        mContext = context;
        this.mTitle = title;
        this.mContent = content;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dia_function_describe2);
        initView();
    }

    @Override
    public void show() {
        super.show();
    }


    void initView() {
        setCanceledOnTouchOutside(false);
        tvContent = (TextView) findViewById(R.id.content_permission);
        tvTitle = (TextView) findViewById(R.id.title);
        dismiss = (ImageView) findViewById(R.id.dismiss);

        if (!TextUtils.isEmpty(mContent)) {
            tvContent.setText(mContent);
        }
        if (!TextUtils.isEmpty(mTitle)) {
            tvTitle.setText(mTitle);
        }

        btnLeft = (TextView) findViewById(R.id.icon_left);
        btnLeft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "account_login_expiration_click_login", TimeUtil.currentTime()));
                if (mRightCallback != null) {
                    mRightCallback.refresh();
                }
                dismiss();
            }
        });

//        btnRight = (ImageView) findViewById(R.id.icon_right);
//        btnRight.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "account_login_expiration_click_login", TimeUtil.currentTime()));
//                if (mRightCallback != null) {
//                    mRightCallback.refresh();
//                }
//                dismiss();
//            }
//        });

        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

    }

    public interface Callback {
        void refresh();
    }

    @Override
    public void onBackPressed() {

    }
}