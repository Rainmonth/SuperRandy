package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.content.res.Configuration;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.WindowManager;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.manager.DialogManager;
import com.hhdd.kada.main.playback.SoundPlayback;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.kada.medal.Medal;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnKdAudioFocusChangeListener;

import butterknife.ButterKnife;

public class MedalBaseDialog extends BaseDialog {

    protected Medal mMedal;
    protected SoundPlayback mSoundPlayback;

    public MedalBaseDialog(Context context, Medal medal) {
        super(context, R.style.popup_dialog);
        this.mMedal = medal;
    }

    protected OnKdAudioFocusChangeListener mAudioFocusChangeListener = new OnKdAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS) {
                //失去焦点之后的操作
                if (mSoundPlayback != null && mSoundPlayback.isPlaying()) {
                    mSoundPlayback.pause();
                }
            } else if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getLayoutId() != 0) {
            setContentView(getLayoutId());
            ButterKnife.bind(this);
            initViews();
        }
    }

    protected int getLayoutId(){
        return 0;
    }

    @Override
    protected void initViews() {
        super.initViews();
        initWindowSize();
    }

    private void initWindowSize() {
        if (AppUtils.getOritation() == Configuration.ORIENTATION_PORTRAIT) {//判断是否为竖屏
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.width = LocalDisplay.SCREEN_WIDTH_PIXELS;
            params.height = LocalDisplay.SCREEN_HEIGHT_PIXELS;
        } else if (AppUtils.getOritation() == Configuration.ORIENTATION_LANDSCAPE) {
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.width = LocalDisplay.SCREEN_HEIGHT_PIXELS;
            params.height = LocalDisplay.SCREEN_WIDTH_PIXELS;
        }
    }

    protected void playMealSound(String soundUrl){
        IMediaPlayer mediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
        mediaPlayer.addOnKdAudioFocusChangeListener(mAudioFocusChangeListener);
    }

    @Override
    public void dismiss() {
        super.dismiss();

        IMediaPlayer mediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
        mediaPlayer.removeOnKdAudioFocusChangeListener(mAudioFocusChangeListener);

        ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissDialog(MedalBaseDialog.this);

        if (mSoundPlayback != null) {
            mSoundPlayback.releaseMediaPlayer();
            mSoundPlayback = null;
        }

        if (getHandler()!=null){
            getHandler().removeCallbacksAndMessages(null);
        }
    }

}
