package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.NoDoubleClickListener;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by zhengkaituo on 16/2/24.
 */
public class AgeOptionDialog extends BaseDialog {

    public AgeOptionDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    public AgeOptionDialog(Context context, boolean isFromStoryCollectionList) {
        super(context, R.style.popup_dialog);
        this.isFromStoryCollectionList = isFromStoryCollectionList;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.age_option_layout);
        initViews();
        hideMyAge(isFromStoryCollectionList);
    }

    TextView option1;
    View option2;
    View option3;
    View option4;
    View option5;
    List<View> optionList;
    private int index;
    boolean isFromStoryCollectionList = false;

    @Override
    protected void initViews() {

        optionList = new ArrayList<View>();
        option1 = (TextView) findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        option5 = findViewById(R.id.option5);
        optionList.add(option1);
        optionList.add(option2);
        optionList.add(option3);
        optionList.add(option4);
        optionList.add(option5);

        optionList.get(index).setSelected(true);
        option1.setOnClickListener(new NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (UserService.getInstance().isLogining() || Settings.getInstance().getBookAgeType() != null && Settings.getInstance().getBookAgeType().length() > 0) {
                    reset();
                    option1.setSelected(true);
                    if (callback != null) {
                        callback.onSelect("我的年龄");
                    }
                    dismiss();
                } else {
                    reset();
                    option1.setSelected(true);
                    if (callback != null) {
                        callback.onSelect("全部");
                    }
                    dismiss();
                }
            }
        });

        option2.setOnClickListener(new NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (isFromStoryCollectionList) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_normal_list_age_zero_to_three_click", TimeUtil.currentTime()));
                }
                reset();
                option2.setSelected(true);
                if (callback != null) {
                    callback.onSelect("0-3");
                }
                dismiss();
            }
        });

        option3.setOnClickListener(new NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (isFromStoryCollectionList) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_normal_list_age_four_to_six_click", TimeUtil.currentTime()));
                }
                reset();
                option3.setSelected(true);
                if (callback != null) {
                    callback.onSelect("4-6");
                }
                dismiss();
            }
        });

        option4.setOnClickListener(new NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (isFromStoryCollectionList) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_normal_list_age_seven_to_nine_click", TimeUtil.currentTime()));
                }
                reset();
                option4.setSelected(true);
                if (callback != null) {
                    callback.onSelect("7-9");
                }
                dismiss();
            }
        });


        option5.setOnClickListener(new NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (isFromStoryCollectionList) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_normal_list_age_all_age_click", TimeUtil.currentTime()));
                }
                reset();
                option1.setSelected(true);
                if (callback != null) {
                    callback.onSelect("所有年龄");
                }
                dismiss();
            }
        });
    }

    public void setSelectIndex(int index) {
        this.index = index;
        if (optionList != null && optionList.size() > 0) {
            reset();
            optionList.get(index).setSelected(true);
        }
    }

    void reset() {
        option1.setSelected(false);
        option2.setSelected(false);
        option3.setSelected(false);
        option4.setSelected(false);
        option5.setSelected(false);
    }

    DefaultCallback callback;

    public void setCallback(DefaultCallback callback) {
        this.callback = callback;
    }

    public static abstract class DefaultCallback {
        public abstract void onSelect(String name);
    }

    void hideMyAge(boolean isFromStoryCollectionList) {
        if (isFromStoryCollectionList) {
            option1.setVisibility(View.GONE);
            optionList.get(4).setSelected(true);
        }
    }
}
