package com.hhdd.kada.main.ui.dialog;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.playback.SoundPlayback;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.medal.Medal;
import com.hhdd.kada.medal.MedalManager;
import com.hhdd.kada.widget.FruitHorizontalProgressView;

import butterknife.BindView;

public class MedalUnGainDialog extends MedalBaseDialog {

    @BindView(R.id.iv_light1)
    ImageView ivLight1;
    @BindView(R.id.iv_light2)
    ImageView ivLight2;
    @BindView(R.id.iv_logo)
    SimpleDraweeView ivLogo;
    @BindView(R.id.tv_medal_name)
    TextView tvMedalName;
    @BindView(R.id.tv_medal_desc)
    TextView tvMedalDesc;
    @BindView(R.id.pb_medal_progress)
    FruitHorizontalProgressView pbMedalProgress;
    @BindView(R.id.tv_medal_action)
    TextView tvMedalAction;
    @BindView(R.id.layout_medal_ungain)
    LinearLayout layoutMedalUngain;

    private boolean needProcessRedirectUrl;

    public void setNeedProcessRedirectUrl(boolean needProcessRedirectUrl) {
        this.needProcessRedirectUrl = needProcessRedirectUrl;
    }

    public MedalUnGainDialog(Context context, Medal medal) {
        super(context, medal);
    }

    @Override
    protected int getLayoutId() {
        return R.layout.dia_medal_ungain;
    }

    @Override
    protected void initViews() {
        super.initViews();
        FrescoUtils.showUrl(mMedal.getUnGainImg(), ivLogo);
        tvMedalDesc.setText(mMedal.getDescription());
        tvMedalName.setText(mMedal.getName());

        if (!TextUtils.isEmpty(mMedal.getRedirectUrl())) {
            tvMedalAction.setVisibility(View.VISIBLE);
        }

        tvMedalAction.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                dismiss();
                if (!TextUtils.isEmpty(mMedal.getRedirectUrl()) && needProcessRedirectUrl) {
                    RedirectActivity.startActivity(getContext(), mMedal.getRedirectUrl());
                }
            }
        });

        layoutMedalUngain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });
    }

    @Override
    public void show() {
        super.show();
        playMedalAnim();
        pbMedalProgress.update(R.color.color_1afa29, 0.8f, LocalDisplay.dp2px(20), R.drawable.bg_medal_ungain_horizontal_progress);
        playMealSound(mMedal.getUngainSoundUrl());
    }

    @Override
    protected void playMealSound(String soundUrl) {
        super.playMealSound(soundUrl);
        if (soundUrl != null && soundUrl.length() > 0) {
            String cacheFilePath = MedalManager.getMedalSoundFilePath(mMedal.getMedalId());
            if (mSoundPlayback == null) {
                mSoundPlayback = new SoundPlayback();
            }
            mSoundPlayback.setListener(new SoundPlayback.Listener() {
                @Override
                public void handlePrepared(SoundPlayback playback) {
                    playback.playFromBegin();
                }

                @Override
                public void handleCompletion(SoundPlayback playback) {
                    dismiss();
                }
            });

            mSoundPlayback.prepare(getContext(), soundUrl, cacheFilePath);
        }
        //防止音频播放失败，从而导致dialog无法消失，这里做一个10s强制dismiss
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                dismiss();
            }
        }, 10000);
    }

    private void playMedalAnim() {
        //大光圈动画
        ObjectAnimator lightAnim1 = ObjectAnimator.ofFloat(ivLight1, "rotation", 0, 360);
        lightAnim1.setRepeatCount(-1);
        lightAnim1.setDuration(40000);
        lightAnim1.setInterpolator(new LinearInterpolator());
        lightAnim1.start();
        //小光圈动画
        ObjectAnimator lightAnim2 = ObjectAnimator.ofFloat(ivLight2, "rotation", 360, 0);
        lightAnim2.setRepeatCount(-1);
        lightAnim2.setDuration(40000);
        lightAnim2.setInterpolator(new LinearInterpolator());
        lightAnim2.start();

        AnimatorSet set = new AnimatorSet();
        set.play(lightAnim1).with(lightAnim2);
        set.start();
    }
}
