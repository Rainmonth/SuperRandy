package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.manager.PermissionManager;
import com.hhdd.kada.main.utils.TimeUtil;

/**
 * Created by sxh on 2017/7/13.
 */

public class PermissionDialog extends BaseDialog {

    private TextView tvContent;
    Context mContext;
    private ImageView btnOk;
    private Callback mCallback;
    private ImageView dismiss;
    private TextView tvTitle;

    private int permissionType;

    public PermissionDialog(Context context) {
        super(context, R.style.popup_dialog);
        mContext = context;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dia_function_describe1);
        initView();
    }

    public int getPermissionType() {
        return permissionType;
    }

    public void setPermissionType(int permissionType) {
        this.permissionType = permissionType;
    }

    public Callback getCallback() {
        return mCallback;
    }

    public void setCallback(Callback mCallback) {
        this.mCallback = mCallback;
    }

    @Override
    public void show() {
        super.show();
    }


    void initView() {
        setCanceledOnTouchOutside(false);
        tvContent = (TextView) findViewById(R.id.content_permission);
        tvTitle = (TextView) findViewById(R.id.title);
        dismiss = (ImageView) findViewById(R.id.dismiss);
        btnOk = (ImageView) findViewById(R.id.icon_ok);

        if (permissionType== PermissionManager.PERMISSION_CAMERA){
            tvTitle.setText("相机权限没有开启");
            tvContent.setText("请允许使用相机\n否则无法拍照哦");
        }else if (permissionType ==PermissionManager.PERMISSION_READ_EXTERNAL_STORAGE){
            tvTitle.setText("相册权限没有开启");
            tvContent.setText("请允许访问相册\n否则无法上传照片哦");
        }else if (permissionType==PermissionManager.PERMISSION_WRITE_EXTERNAL_STORAGE){
            tvTitle.setText("存储卡权限没有开启");
            tvContent.setText("请允许访问存储卡\n否则功能可能无法正常使用哦");
        }else if (permissionType==PermissionManager.STORAGE_NOT_ENOUGH){
            tvTitle.setText("存储空间不足");
            tvContent.setText("手机存储不太够了\n快去清理一下吧");
        }else if (permissionType==PermissionManager.PERMISSION_READ_WRITE_EXTERNAL_STORAGE){
            tvTitle.setText("文件读写权限没有开启");
            tvContent.setText("请允许文件读写\n否则功能可能无法正常使用哦");
        }

        btnOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mCallback != null) {
                    mCallback.refresh();
                }
                dismiss();
            }
        });

        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (permissionType== PermissionManager.PERMISSION_CAMERA){
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "camera_authority_notice_close_click", TimeUtil.currentTime()));
                }else if (permissionType ==PermissionManager.PERMISSION_READ_EXTERNAL_STORAGE){
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "photo_authority_notice_close_click", TimeUtil.currentTime()));
                }else if (permissionType==PermissionManager.PERMISSION_WRITE_EXTERNAL_STORAGE){
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "sd_visit_authority_notice_close_click", TimeUtil.currentTime()));
                }else if (permissionType==PermissionManager.STORAGE_NOT_ENOUGH){
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "no_enough_space_notice_close_click", TimeUtil.currentTime()));
                }
                dismiss();
            }
        });
    }

    public interface Callback {
        void refresh();
    }

}
