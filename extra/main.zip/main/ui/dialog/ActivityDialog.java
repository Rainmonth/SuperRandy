package com.hhdd.kada.main.ui.dialog;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.google.gson.Gson;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.model.DialogConfigInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.ui.book.BookFragment;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.PlayMode;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by sxh on 17/5/19.
 */
public class ActivityDialog extends BaseDialog {

    @BindView(R.id.layout)
    View layout;
    @BindView(R.id.contentImageView)
    SimpleDraweeView contentImageView;
    @BindView(R.id.dialogCloseView)
    ImageView dialogCloseView;
    private AnimatorSet animatorSet;
    private float translationValueX, translationValueY;
    private DialogConfigInfo dialogConfigInfo;
//    private SoundPlayback mSoundPlayback;
    private int id;

    private IMediaPlayer mMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
    private String mAudioTag;

    List<Integer> showIdList = new ArrayList<>();


    public void setShowIdList(List<Integer> list) {
        this.showIdList = list;
    }

    public ActivityDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_activity);
        ButterKnife.bind(this);
        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.width = ScreenUtil.getScreenWidth();
        params.height = ScreenUtil.getScreenHeight();
        params.dimAmount = 0.8f;
        getWindow().setAttributes(params);
        int imageWidth = LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(40);
        int imageHeight = imageWidth * 346 / 300;
        ViewGroup.LayoutParams imageParams = contentImageView.getLayoutParams();
        if(imageParams == null) {
            imageParams = new ViewGroup.LayoutParams(imageWidth, imageHeight);
        } else {
            imageParams.width = imageWidth;
            imageParams.height = imageHeight;
        }
        contentImageView.setLayoutParams(imageParams);
        contentImageView.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(id), "home_pop_out_image_click", TimeUtil.currentTime()));
                playDismissAnim(true);
            }
        });
        dialogCloseView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(id), "home_pop_out_close_click", TimeUtil.currentTime()));
                playDismissAnim(false);
            }
        });
    }

    @Override
    public void onBackPressed() {
        playDismissAnim(false);
    }

    public void setDialogConfigInfo(DialogConfigInfo dialogConfigInfo) {
        id = 0;
        if(dialogConfigInfo != null) {
            this.dialogConfigInfo = dialogConfigInfo;
            id = dialogConfigInfo.getRedirectId();
        }
    }

    public void setAnimValue(float translationValueX, float translationValueY) {
        this.translationValueX = translationValueX;
        this.translationValueY = translationValueY;
    }

    public void playDismissAnim(final boolean isClickContent) {
        if (dialogConfigInfo == null || dialogConfigInfo.getHaveFlash() == 0) {
            skip(isClickContent);
            dismiss();
            return;
        }
        if (animatorSet == null) {
            dialogCloseView.setVisibility(View.INVISIBLE);
            animatorSet = new AnimatorSet();
            float layoutX = layout.getX() + layout.getWidth() / 2 - translationValueX;
            float layoutY = layout.getY() + layout.getHeight() / 2 - translationValueY;
            ValueAnimator anim1_scaleY = ObjectAnimator.ofFloat(layout, "scaleY", 1.0f, 1.2f);
            ValueAnimator anim1_scaleX = ObjectAnimator.ofFloat(layout, "scaleX", 1.0f, 1.2f);
            ValueAnimator anim2_scaleY = ObjectAnimator.ofFloat(layout, "scaleY", 1.2f, 1.0f);
            ValueAnimator anim2_scaleX = ObjectAnimator.ofFloat(layout, "scaleX", 1.2f, 1.0f);
            ValueAnimator anim_scaleY = ObjectAnimator.ofFloat(layout, "scaleY", 1.0f, 0.0f);
            ValueAnimator anim_scaleX = ObjectAnimator.ofFloat(layout, "scaleX", 1.0f, 0.0f);
            ValueAnimator anim_translationY = ObjectAnimator.ofFloat(layout, "translationY", 0, -layoutY);
            ValueAnimator anim_translationX = ObjectAnimator.ofFloat(layout, "translationX", 0, -layoutX);

            animatorSet.play(anim1_scaleX).with(anim1_scaleY).before(anim2_scaleX);
            animatorSet.play(anim2_scaleX).with(anim2_scaleY).before(anim_scaleX);
            animatorSet.play(anim_scaleX).with(anim_scaleY).with(anim_translationX).with(anim_translationY);
            animatorSet.setDuration(500);
            animatorSet.start();
            animatorSet.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    skip(isClickContent);
                    dismiss();
                }
            });
        }
    }

    private void skip(boolean isClickContent) {
        if (isClickContent && dialogConfigInfo != null && !TextUtils.isEmpty(dialogConfigInfo.getRedirectUri())) {
            RedirectActivity.startActivity(getContext(), dialogConfigInfo.getRedirectUri());
        }
    }

    @Override
    public void show() {
        super.show();
        if(!isValidContext(mContext)) {
            return;
        }
        if(dialogConfigInfo != null) {
            FrescoUtils.showImg(contentImageView, CdnUtils.getImgCdnUrl(dialogConfigInfo.getImageUrl(), true));
            if (!TextUtils.isEmpty(dialogConfigInfo.getSoundUrl())) {
//                mSoundPlayback = new SoundPlayback();
//                mSoundPlayback.setListener(new SoundPlayback.Listener() {
//                    @Override
//                    public void handlePrepared(SoundPlayback playback) {
//                        playback.playFromBegin();
//                    }
//
//                    @Override
//                    public void handleCompletion(SoundPlayback playback) {
//
//                    }
//                });
//                mSoundPlayback.prepare(getContext(), Uri.parse(dialogConfigInfo.getSoundUrl()));

                mAudioTag = "TagActivityDialog" + System.currentTimeMillis();
                mMediaPlayer.addPlayQueue(Uri.parse(dialogConfigInfo.getSoundUrl()), PlayMode.SEQUENCE_PLAY_MODE, mAudioTag);
            }
            //记录到SharedPreference
            showIdList.add(id);
            Gson gson = new Gson();
            String idListStr = gson.toJson(showIdList);
            ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).putString(BookFragment.ACTIVITY_DIALOG_SHOW_ID_LIST, idListStr);
        }
    }

    @Override
    public void dismiss() {
//        if (mSoundPlayback != null) {
//            mSoundPlayback.releaseMediaPlayer();
//            mSoundPlayback = null;
//        }

        if (!StringUtil.isEmpty(mAudioTag)) {
            mMediaPlayer.stop(PlayMode.SEQUENCE_PLAY_MODE, mAudioTag);
        }

        if (animatorSet != null) {
            animatorSet.removeAllListeners();
            animatorSet.cancel();
            animatorSet = null;
        }
        super.dismiss();
    }

    @Override
    public boolean dispatchTouchEvent(@NonNull MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN && !ScreenUtil.inRangeOfView(contentImageView, ev)
                && !ScreenUtil.inRangeOfView(dialogCloseView, ev)) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(id), "home_pop_out_other_area_click", TimeUtil.currentTime()));
            playDismissAnim(false);
        }
        return super.dispatchTouchEvent(ev);
    }
}
