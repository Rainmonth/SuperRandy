package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.fontinator.FontButton;
import com.hhdd.kada.module.userhabit.StaPageName;

/**
 * Created by mcx on 2017/10/19.
 */

public class ContentIsDeletedDialog extends BaseDialog {

    private int mKind; // 类别(1 绘本，2 听书）
    private int mType; // 类型（1 合辑，2单品） 
    private int mId; // id（合辑id或单品id）

    FontButton btnYes;

    public ContentIsDeletedDialog(Context context) {
        super(context, R.style.popup_dialog);
    }

    public ContentIsDeletedDialog(Context context, int theme) {
        super(context, R.style.popup_dialog);
    }

    protected ContentDialogCallback mCallback;

    public void setCallback(ContentDialogCallback callback) {
        mCallback = callback;
    }

    /**
     * @param kind 类别(1 绘本，2 听书）
     * @param type 类型（1 合辑，2单品）
     * @param id   id（合辑id或单品id）
     */
    public void setData(int kind, int type, int id) {
        mKind = kind;
        mType = type;
        mId = id;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_content_is_deleted);

        btnYes = (FontButton) findViewById(R.id.btn_yes);
        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mCallback != null) {
                    mCallback.doYes();
                    mCallback = null;
                }
                dismiss();
            }
        });
        setOnDismissListener(new OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if (mCallback != null) {
                    mCallback.doYes();
                }
            }
        });

        StringBuilder content = new StringBuilder();
        content.append(mKind)
                .append(",").append(mType)
                .append(",").append(mId);
        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(content.toString(), StaPageName.content_off_line_view, TimeUtil.currentTime()));
    }

    public interface ContentDialogCallback {
        void doYes();
    }

    @Override
    public void dismiss() {
        super.dismiss();
    }
}
