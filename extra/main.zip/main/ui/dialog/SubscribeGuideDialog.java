package com.hhdd.kada.main.ui.dialog;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.widget.ImageView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.ScreenUtil;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * Created by sxh on 17/5/19.
 */
public class SubscribeGuideDialog extends BaseDialog {

    @BindView(R.id.knowImageView)
    View knowImageView;
    @BindView(R.id.guide_container)
    ImageView guideContainer;
    private ViewTreeObserver.OnGlobalLayoutListener layoutListener;

    public SubscribeGuideDialog(Context context) {
        super(context, R.style.popup_dialog2);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_subscribe_guide);
        ButterKnife.bind(this);

        //适配全面屏模式及底部导航栏显示隐藏
        layoutListener = new ViewTreeObserver.OnGlobalLayoutListener() {
            @Override
            public void onGlobalLayout() {
                getWindow().getDecorView().getViewTreeObserver().removeGlobalOnLayoutListener(layoutListener);
                WindowManager.LayoutParams params = getWindow().getAttributes();
                params.height = WindowManager.LayoutParams.MATCH_PARENT;
                getWindow().setAttributes(params);
                //延迟50ms再添加监听，防止一直回调该方法
                getHandler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        getWindow().getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);
                    }
                }, 50);
            }
        };
        getWindow().getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(layoutListener);

//        WindowManager.LayoutParams lp = getWindow().getAttributes();
//        lp.width = ScreenUtil.getScreenWidth();
//        lp.height = ScreenUtil.getScreenHeight()-ScreenUtil.getStatusBarHeight(getContext());
//        getWindow().setAttributes(lp);
        setCancelable(false);
        setCanceledOnTouchOutside(false);
        knowImageView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                dismiss();
            }
        });
    }

    @Override
    public void dismiss() {
        super.dismiss();
        getWindow().getDecorView().getViewTreeObserver().removeGlobalOnLayoutListener(layoutListener);
    }
}
