package com.hhdd.kada.main.ui.bookshelf;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.hhdd.core.service.StoryService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.vo.BookStoryModelListVO;

import java.util.List;

import static com.hhdd.kada.Constants.PLAY_MODE;
import static com.hhdd.kada.Constants.STOP_MODE;

/**
 * Created by lj on 17/1/4.
 */

public class BookShelfStoryListViewHolder extends BaseViewHolder<BookStoryModelListVO> {

    public static final int TYPE_BOOK_SHELF_STORY_ITEM_CLICKED = 701;
    public static final int TYPE_BOOK_SHELF_STORY_DELETE_CLICKED = 702;

    int mItemWidth;
    int mCoverSize;
    ViewGroup container;
    List<BaseModel> modelList;

    public BookShelfStoryListViewHolder() {

        int viewMarginLeft = (int) KaDaApplication.getInstance().getResources().getDimension(
                R.dimen.bookshelf_padding_left);
        int viewMarginRight = (int) KaDaApplication.getInstance().getResources().getDimension(
                R.dimen.bookshelf_padding_right);

        int viewPaddingLeft = (int) KaDaApplication.getInstance().getResources().getDimension(
                R.dimen.bookshelf_inner_padding_left);
        int viewPaddingRight = (int) KaDaApplication.getInstance().getResources().getDimension(
                R.dimen.bookshelf_inner_padding_right);


        int screenWidth = ScreenUtil.getScreenSize(KaDaApplication.getInstance()).x < ScreenUtil.getScreenSize(KaDaApplication.getInstance()).y
                ? ScreenUtil.getScreenSize(KaDaApplication.getInstance()).x : ScreenUtil.getScreenSize(KaDaApplication.getInstance()).y;
        mItemWidth = (int) ((screenWidth - viewMarginLeft - viewMarginRight - viewPaddingLeft - viewPaddingRight) / 3.0f);
        mCoverSize = mItemWidth - LocalDisplay.dp2px(5);
    }


    @Override
    public View createView(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_holder_bookshelf_story_list, null);
        container = (ViewGroup) view.findViewById(R.id.container);
        ViewGroup.LayoutParams viewParams = new ViewGroup.LayoutParams(LocalDisplay.SCREEN_WIDTH_PIXELS, ViewGroup.LayoutParams.WRAP_CONTENT);
        view.setLayoutParams(viewParams);
        for (int index = 0; index < container.getChildCount(); index++) {
            final FrameLayout layout = ((FrameLayout) container.getChildAt(index));
            final CustomStoryView customStoryView = (CustomStoryView) layout.getChildAt(0);

            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) (layout.getLayoutParams());
            FrameLayout.LayoutParams coverParams = (FrameLayout.LayoutParams) customStoryView.getLayoutParams();
            params.width = mItemWidth;
            params.height = mItemWidth;
            coverParams.width = mCoverSize;
            coverParams.height = mCoverSize;
            coverParams.gravity = Gravity.LEFT | Gravity.BOTTOM;

            customStoryView.setLayoutParams(coverParams);
            layout.setLayoutParams(params);

            customStoryView.setRound();

            layout.setOnClickListener(listener);
        }

        if (componentContainer != null) {
            EventCenter.bindContainerAndHandler(componentContainer, new SimpleEventHandler() {

                public void onEvent(StoryService.StartReadingEvent event) {
                    setPlayMode(event.getStoryInfo(),PLAY_MODE);
                }

                public void onEvent(StoryService.PauseReadingEvent event) {
                    setMode(STOP_MODE, -1);
                }

                public void onEvent(StoryService.StopReadingEvent event) {
                    setMode(STOP_MODE, -1);
                }
            }).tryToRegisterIfNot();
        }

        return view;
    }

    @Override
    public void showData(int position, BookStoryModelListVO itemData) {
        modelList = itemData.getItemList();
        List<BaseModel> list = itemData.getItemList();
        if (list != null && list.size() > 0) {

            container.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
            container.setVisibility(View.VISIBLE);

            int count = list.size() > 3 ? 3 : list.size();
            for (int i = 0; i < count; i++) {

                final BaseModel model = list.get(i);
                final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(i));
                CustomStoryView customStoryView = (CustomStoryView) frameLayout.getChildAt(0);

                frameLayout.setVisibility(View.VISIBLE);
                if (list.get(i) != null && list.get(i) instanceof StoryInfo) {
                    StoryInfo info = (StoryInfo) list.get(i);

                    customStoryView.hideCollectionBg();

                    String coverUrl = info.getCoverUrl();
                    boolean needResetImageUrl = true;
                    if (customStoryView.getTag(R.id.book_list_item_image_url) != null) {
                        String url = (String) customStoryView.getTag(R.id.book_list_item_image_url);
                        if (TextUtils.equals(url, coverUrl)) {
                            needResetImageUrl = false;
                        }
                    }
                    if (needResetImageUrl) {
                        customStoryView.setTag(R.id.book_list_item_image_url, coverUrl);
                        customStoryView.showUrl(coverUrl);
                    }

                    frameLayout.setTag(R.id.view_holder_item, info);
                } else if (list.get(i) != null && list.get(i) instanceof StoryCollectionInfo) {
                    StoryCollectionInfo info = (StoryCollectionInfo) list.get(i);

                    customStoryView.showCollectionBg(R.drawable.bg_story_collect);

                    String coverUrl = info.getCoverUrl();
                    boolean needResetImageUrl = true;
                    if (customStoryView.getTag(R.id.book_list_item_image_url) != null) {
                        String url = (String) customStoryView.getTag(R.id.book_list_item_image_url);
                        if (TextUtils.equals(url, coverUrl)) {
                            needResetImageUrl = false;
                        }
                    }
                    if (needResetImageUrl) {
                        customStoryView.setTag(R.id.book_list_item_image_url, coverUrl);
                        customStoryView.showUrl(coverUrl);
                    }

                    frameLayout.setTag(R.id.view_holder_item, info);
                } else {
                    frameLayout.setVisibility(View.GONE);
                }

                ImageView delete = (ImageView) frameLayout.getChildAt(1);
                if(itemData.isEdit){
                    delete.setVisibility(View.VISIBLE);
                }else{
                    delete.setVisibility(View.GONE);
                }
                delete.setTag(R.id.book_shelf_list_view_holder,model);
                delete.setOnClickListener(deleteListener);
            }
            for (int i = count; i < 3; i++) {
                final View layout = container.getChildAt(i);
                layout.setVisibility(View.GONE);
                layout.setTag(R.id.view_holder_item, null);
            }

            int mode;
            if(ListenManager.getInstance().isPlaying()){
                mode = PLAY_MODE;
            }else{
                mode = STOP_MODE;
            }
            setPlayMode(ListenManager.getInstance().getCurrentStoryInfo(),mode);

        } else {
            container.getLayoutParams().height = LocalDisplay.dp2px(120);
            container.setVisibility(View.INVISIBLE);
        }
    }

    public void setPlayMode(com.hhdd.core.model.StoryInfo playStoryInfo,int mode) {
        if(playStoryInfo != null){
            if (modelList.size() > 0) {
                boolean isAnim = false;
                for (int i = 0; i < modelList.size(); i++) {
                    if (modelList.get(i) instanceof StoryInfo) {
                        StoryInfo info = (StoryInfo) modelList.get(i);
                        if (info.getStoryId() == playStoryInfo.getId()) {
                            isAnim = true;
                            setMode(mode, i);
                            break;
                        }
                    } else if (modelList.get(i) instanceof StoryCollectionInfo) {
                        StoryCollectionInfo info = (StoryCollectionInfo) modelList.get(i);
                        if (info.getCollectId() == playStoryInfo.getCollectionId()) {
                            isAnim = true;
                            setMode(mode, i);
                            break;
                        }
                    }
                }
                if (!isAnim) {
                    setMode(STOP_MODE, -1);
                }
            } else {
                setMode(STOP_MODE, -1);
            }
        }
    }



    public void setMode(int mode, int index) {
        int size = (mCoverSize - LocalDisplay.dp2px(4)) / 2;
        for (int i = 0; i < container.getChildCount(); i++) {
            FrameLayout view = (FrameLayout) container.getChildAt(i);
            CustomStoryView customStoryView = (CustomStoryView) view.getChildAt(0);
            if (i == index) {
                customStoryView.setMode(mode, size, size);
            } else {
                customStoryView.setMode(STOP_MODE, size, size);
            }
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            Object o = v.getTag(R.id.view_holder_item);
            if (o != null && mOnEventProcessor != null) {
                mOnEventProcessor.process(TYPE_BOOK_SHELF_STORY_ITEM_CLICKED, o);
            }
        }
    };

    KaDaApplication.OnClickWithAnimListener deleteListener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            BaseModel model = (BaseModel) v.getTag(R.id.book_shelf_list_view_holder);
            if(mOnEventProcessor != null){
                mOnEventProcessor.process(TYPE_BOOK_SHELF_STORY_DELETE_CLICKED, model);
            }
        }
    };


}