package com.hhdd.kada.main.ui.bookshelf;

import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.views.BookShelfItemView;
import com.hhdd.kada.main.vo.BookStoryModelListVO;

import java.util.List;

import butterknife.BindView;

/**
 * Created by lj on 17/1/4.
 */

public class BookShelfBookListViewHolder extends BaseViewHolder<BookStoryModelListVO> implements OnChildViewClickListener{

    public static final int TYPE_BOOK_SHELF_BOOK_ITEM_CLICKED = 601;
    public static final int TYPE_BOOK_SHELF_BOOK_DELETE_CLICKED = 602;

    @BindView(R.id.container)
    LinearLayout container;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_bookshelf_book_list;
    }

    @Override
    public View createView(ViewGroup parent) {
        int itemViewWidth = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(24 * 2 + 3 * 10 + 3 * 10)) / 3;
        for (int i = 0; i < container.getChildCount(); i++){
            BookShelfItemView bookShelfItemView = (BookShelfItemView) container.getChildAt(i);
            bookShelfItemView.getBookItemView().setViewSize(itemViewWidth);
        }
        return super.createView(parent);
    }

    @Override
    public void showData(int position, BookStoryModelListVO itemData) {
        List<BaseModel> list = itemData.getItemList();
        if (list != null && list.size() > 0) {

            container.getLayoutParams().height = ViewGroup.LayoutParams.WRAP_CONTENT;
            container.setVisibility(View.VISIBLE);

            int count = list.size() > 3 ? 3 : list.size();
            for (int i = 0; i < count; i++) {
                final BaseModel model = list.get(i);
                BookShelfItemView bookShelfItemView = (BookShelfItemView) container.getChildAt(i);
                bookShelfItemView.setVisibility(View.VISIBLE);
                bookShelfItemView.getBookItemView().setTag(R.id.container,model);
                bookShelfItemView.getDeleteView().setTag(R.id.book_shelf_list_view_holder,model);
                bookShelfItemView.setOnChildViewClickListener(this);
                if (list.get(i) != null && list.get(i) instanceof BookInfo) {
                    BookInfo info = (BookInfo) list.get(i);
                    bookShelfItemView.update(info, itemData.isEdit);
                } else if (list.get(i) != null && list.get(i) instanceof BookCollectionInfo) {
                    BookCollectionInfo info = (BookCollectionInfo) list.get(i);
                    bookShelfItemView.update(info, itemData.isEdit);
                }
            }

            for (int i = count; i < 3; i++) {
                final View layout = container.getChildAt(i);
                layout.setVisibility(View.INVISIBLE);
                layout.setTag(R.id.view_holder_item, null);
            }
        } else {
            container.getLayoutParams().height = LocalDisplay.dp2px(120);
            container.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onChildViewClick(View childView, int action, Object obj) {
        BaseModel model = (BaseModel) childView.getTag(R.id.container);
        if (model==null){
            model = (BaseModel) childView.getTag(R.id.book_shelf_list_view_holder);
        }

        if(model != null && mOnEventProcessor != null) {
            if (action == Constants.ACTION_BOOKSHELF_ITEM) {
                mOnEventProcessor.process(TYPE_BOOK_SHELF_BOOK_ITEM_CLICKED, model);
            } else if (action == Constants.ACTION_BOOKSHELF_ITEM_DELETE) {
                mOnEventProcessor.process(TYPE_BOOK_SHELF_BOOK_DELETE_CLICKED, model);
            }
        }
    }
}