package com.hhdd.kada.main.mediaserver;

import android.os.Build;
import android.os.Looper;
import android.text.TextUtils;

import com.hhdd.core.service.BookService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.cryptokada.CryptoKadaLib;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.Md5Util;
import com.hhdd.kada.main.utils.PatternUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.logger.LogHelper;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.ProtocolVersion;
import org.apache.http.RequestLine;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ClientConnectionOperator;
import org.apache.http.conn.OperatedClientConnection;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.DefaultClientConnection;
import org.apache.http.impl.conn.DefaultClientConnectionOperator;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.message.BasicHttpResponse;
import org.apache.http.message.BasicLineParser;
import org.apache.http.message.ParserCursor;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.CharArrayBuffer;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

/**
 * Created by simon on 13/11/15.
 */
public class MediaServer2 {

    public static String TAG = "MediaServer";
//    public static final String UMENG_TAG_AUDIODECRYPTPLAY = "AudioDecryptPlay";

    private static final String KEY_ENCRYPT = "encrypt";
    private static final String KEY_ENCRYPT_TYPE = "encryptTppe";
    private static final String KEY_VERSION = "version";
    private static final String KEY_COLLECT_ID = "collectId";
    private static final String KEY_AESST = "AESST";
    private static final String KEY_TARGET_FILE_PATH = "targetFilePath";
    private static final String KEY_TARGET_DIR = "targetDir";

    private static final String KEY_HEADER_RANGE = "range";
    private static final String KEY_HEADER_DATE = "Date";
    private static final String KEY_HEADER_HOST = "host";

    private static final String KEY_HTTP_HEADER_CONTENT_LENGTH = "Content-Length";
    private static final String KEY_HTTP_HEADER_CONTENT_RANGE = "Content-Range";
    private static final String KEY_HTTP_HEADER_ACCEPT_RANGES = "Accept-Ranges";
    private static final String KEY_HTTP_HEADER_CONNECTION = "Connection";

    private static String ROOT_PATH = "media";

    private static MediaServer3 mediaServer;

    public static MediaServer3 getInstance() {
        if (mediaServer == null) {
            synchronized (MediaServer2.class) {
                if (mediaServer == null) {
                    mediaServer = new MediaServer3();
                }
            }
        }
        return mediaServer;
    }

    public static MediaServer3 getMediaServer() {
        return mediaServer;
    }

    private int myTcpPort = 0;
    private ServerSocket myServerSocket;
    private Thread myThread;
//    private File myRootDir;

    private MediaServer2() throws IOException {
//        this.myRootDir = new File("/");
        StringBuilder errContent = null;
        try {
            myServerSocket = new ServerSocket(myTcpPort);
        } catch (IOException e) {
            errContent = new StringBuilder();
            errContent.append("failed to create serverSocket : auto").append(e.toString());
            LogHelper.printStackTrace(e);

            myTcpPort = 16823;
            int count = 5;
            while (count > 0) {
                count--;
                try {
                    myServerSocket = new ServerSocket(myTcpPort);
                    break;
                } catch (IOException e2) {
                    errContent.append("failed to create serverSocket:").append(myTcpPort).append(e2.toString());
                    LogHelper.printStackTrace(e2);
                }
                myTcpPort += 2;
            }
        }

        if (myServerSocket != null) {
            myTcpPort = myServerSocket.getLocalPort();
            myThread = new Thread(new Runnable() {

                @Override
                public void run() {
                    try {
                        while (true) {
                            Socket client = myServerSocket.accept();
                            if (client == null) {
                                continue;
                            }

                            handleAccept(client);
                        }
                    } catch (IOException ioe) {
//                        UserHabitService.getInstance().trackHabit2Umeng(
//                                UserHabitService.newUserHabit(packageString("ServerSocket分发出错："+ioe.toString()),UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                        LogHelper.e(TAG, "Error Server", ioe);
                        LogHelper.printStackTrace(ioe);
                    }
                }
            });

            myThread.start();
        }else{
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(packageString(errContent.toString()),
//                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
        }

//        FileUtils.deleteAllFiles(getRootPathTemp());
    }

    public int getLocalPort() {
        return myTcpPort;
    }

    public void stop() {
        try {
            if (myServerSocket != null) {
                myServerSocket.close();
            }

            if (myThread != null) {
                myThread.join();
            }
        } catch (IOException ioe) {
            LogHelper.e(TAG, "Error stop", ioe);
            LogHelper.printStackTrace(ioe);
        } catch (InterruptedException e) {
            LogHelper.e(TAG, "Error stop", e);
            LogHelper.printStackTrace(e);
        }
    }

    public static String getRootPath() {
        String root = Dirs.getCachePath(KaDaApplication.getInstance());
        if (!TextUtils.isEmpty(root)) {
            return FileUtils.makeDirIfNoExist(root + File.separator + MediaServer2.ROOT_PATH);
        }
        return "";
    }

    public static String getRootPathTemp() {
        String root = Dirs.getCachePath(KaDaApplication.getInstance());
        if (!TextUtils.isEmpty(root)) {
            return FileUtils.makeDirIfNoExist(root + File.separator + MediaServer2.ROOT_PATH + File.separator + "tmp");
        }
        return "";
    }

    public static boolean cachedFileExist(String origUrl, int itemId, int version) {
        String fileName = cachedFileName(origUrl, itemId, version);
//        String storeFilePath = getRootPath()+File.separator+fileName;
        String storeFilePath = BookService.getBookCachePath(itemId) + File.separator + fileName;

        return FileUtils.fileExist(storeFilePath);
    }

    public static String cachedFileNameForBookQuestionSound(String origUrl, int itemId) {
        int version = 0; //对于问题声音不加密强制为零
        return Md5Util.getStringMD5("/" + itemId + "/" + origUrl) + "_" + version + ".mp3";
    }

    public static String cachedFileName(String origUrl, int itemId, int version) {
        if (version == 0) {
            version = 1; //从v2.1开始默认为1
        }

        return Md5Util.getStringMD5("/" + itemId + "/" + origUrl) + "_" + version + ".mp3";
    }

    //type=1：绘本、2：故事
    public static String prepareBook(String origUrl, int itemId, int version, String mediaTargetDir, String AESST) {
        if (version == 0) {
            version = 1; //从v2.1开始默认为1
        }

        return prepare(origUrl, itemId, true, CryptoKadaLib.SourceType_Book, version, 0, mediaTargetDir, AESST);
    }

    public static String prepareStory(String origUrl, int itemId, int version, int collectId, String mediaTargetDir, String AESST) {
        if (version == 0) {
            version = 1; //从v2.1开始默认为1
        }

        return prepare(origUrl, itemId, true, CryptoKadaLib.SourceType_Story, version, collectId, mediaTargetDir, AESST);
    }

    public static String prepare(String origUrl, int itemId, boolean encrypt, int type, int version, int collectId, String mediaTargetDir, String AESST) {
//        if (!CryptoKadaLib.getInstance().isCompatV(version)) {
//            KaDaApplication.getInstance().mainLooperHandler().post(new Runnable() {
//                @Override
//                public void run() {
//                    TransparentActivity.startActivity(KaDaApplication.getInstance());
//                }
//            });
//            return "";
//        }

        StringBuilder encodedParams = new StringBuilder();
        encodedParams.append("http://127.0.0.1");
        encodedParams.append(":");
        encodedParams.append(MediaServer2.getInstance().getLocalPort());
        try {
            String paramOrigUrl = URLEncoder.encode(origUrl, "UTF-8");
            encodedParams.append("?url=").append(paramOrigUrl);
            encodedParams.append("&itemId=").append(itemId);
            if (encrypt) {
                encodedParams.append("&encrypt=1");
            } else {
                encodedParams.append("&encrypt=0");
            }
            encodedParams.append("&targetDir=").append(URLEncoder.encode(mediaTargetDir, "UTF-8"));
            encodedParams.append("&encryptTppe=").append(type);
            encodedParams.append("&version=").append(version);
            encodedParams.append("&AESST=").append(URLEncoder.encode(AESST.toString(), "UTF-8"));
            encodedParams.append("&collectId=").append(collectId);
        } catch (UnsupportedEncodingException e) {
            LogHelper.printStackTrace(e);
        }
        return encodedParams.toString();
    }

    public static String prepare(String origUrl, String mediaTargetFilePath) {
        StringBuilder encodedParams = new StringBuilder();
        encodedParams.append("http://127.0.0.1");
        encodedParams.append(":");
        encodedParams.append(MediaServer2.getInstance().getLocalPort());
        try {
            String paramOrigUrl = URLEncoder.encode(origUrl, "UTF-8");
            encodedParams.append("?url=").append(paramOrigUrl);
            encodedParams.append("&encrypt=0");
            encodedParams.append("&targetFilePath=").append(URLEncoder.encode(mediaTargetFilePath, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            LogHelper.printStackTrace(e);
        }
        return encodedParams.toString();
    }

    void handleAccept(Socket s) {
        Thread t = new HTTPSession(s);
        t.setDaemon(true);
        t.start();
    }

    List<HTTPSession> sessions = new ArrayList<HTTPSession>();

    public void removeSession(String url) {
        if (url != null) {
            synchronized (sessions) {
                List<HTTPSession> sessionsRemoved = new ArrayList<HTTPSession>();
                for (HTTPSession session : sessions) {
                    if (TextUtils.equals(session.getMyUrl(), url)) {
                        session.closeSession();
                        sessionsRemoved.add(session);
                    }
                }
                for (HTTPSession session : sessionsRemoved) {
                    sessions.remove(session);
                }
            }
        }
    }

    private void addSession(HTTPSession session) {
//        removeSession(session.getMyUrl());
        synchronized (sessions) {
//            String url = session.getMyUrl();
//            List<HTTPSession> sessionsRemoved = new ArrayList<HTTPSession>();
            for (HTTPSession sessionTmp : sessions) {
//                if (TextUtils.equals(sessionTmp.getMyUrl(),url)) {
                sessionTmp.closeSession();
//                    sessionsRemoved.add(sessionTmp);
//                }
            }
            sessions.clear();
//            for (HTTPSession sessionTmp : sessionsRemoved) {
//                sessions.remove(sessionTmp);
//            }
            if (!sessions.contains(session)) {
                sessions.add(session);
            }
        }
    }

    private void removeSession(HTTPSession session) {
        synchronized (sessions) {
            if (sessions.contains(session)) {
                sessions.remove(session);
            }
        }
    }

    public static final String
            HTTP_OK = "200 OK",
            HTTP_PARTIALCONTENT = "206 Partial Content",
            HTTP_RANGE_NOT_SATISFIABLE = "416 Requested Range Not Satisfiable",
            HTTP_REDIRECT = "301 Moved Permanently",
            HTTP_FORBIDDEN = "403 Forbidden",
            HTTP_NOTFOUND = "404 Not Found",
            HTTP_BADREQUEST = "400 Bad Request",
            HTTP_INTERNALERROR = "500 Internal Server Error",
            HTTP_NOTIMPLEMENTED = "501 Not Implemented";

    public static final String
            MIME_PLAINTEXT = "text/plain",
            MIME_HTML = "text/html",
            MIME_DEFAULT_BINARY = "application/octet-stream",
            MIME_XML = "text/xml";

    private static java.text.SimpleDateFormat gmtFrmt;

    static {
        gmtFrmt = new java.text.SimpleDateFormat("E, d MMM yyyy HH:mm:ss 'GMT'", Locale.US);
        gmtFrmt.setTimeZone(TimeZone.getTimeZone("GMT"));
    }

    public static final int FILE_IGNORE_LENGTH = 32;
    public static final int FILE_ENCRYPT_LENGTH = 16;

    protected class HTTPSession extends Thread {

        protected Socket mySocket;
        int itemId;
        volatile boolean quit = false;
        volatile boolean reuseSocket = false;
        String myUrl;
        boolean isEncrypt = true;
        int encryptTppe = 0;
        int version = 0;
        int collectId = 0;

        String cancelFlag = "";

        String securityKey = "";

        HttpGet httpGetRemote = null;

        public String getMyUrl() {
            return myUrl;
        }

        public HTTPSession(Socket s) {
            mySocket = s;
        }

        public void closeSession() {
            quit = true;

            try {
                if (httpGetRemote != null) {
                    httpGetRemote.abort();
                    httpGetRemote = null;
                }
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            if (mySocket != null) {
                try {
                    LogHelper.d(TAG, ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> close socket in closeSession");
                    mySocket.close();
                } catch (IOException e) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("close socket in closeSession err ："+e.toString()),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    LogHelper.printStackTrace(e);
                }
            }
            interrupt();
        }

        public void closeSessionAndWait() {
            closeSession();
            doWait();
        }

        synchronized void doWait() {
            try {
                wait(20);
            } catch (InterruptedException e) {
                LogHelper.printStackTrace(e);
            }
        }

        synchronized void doNotifyAll() {
            notifyAll();
        }

        public void setSocketForReuse(boolean reuseSocket) {
            this.reuseSocket = reuseSocket;
        }

        public Socket getMySocket() {
            return mySocket;
        }


        @Override
        public void run() {
            LogHelper.d(TAG, ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> HTTPSession run.");

//            Looper.prepare();
            RandomAccessFile cachedAccessFile = null;
            String realUri = null;
            DefaultHttpClient httpClient = null;

            try {
                LogHelper.d(TAG, "1: client connected, 0)");

                InputStream is = mySocket.getInputStream();
                if (is == null) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("mySocket.getInputStream() == null, : localPort:"+mySocket.getLocalPort()+",port:"+mySocket.getPort()),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    return;
                }

                //Apache's default header limit is 8KB.
                int bufsize = 8192;
                byte[] buf = new byte[bufsize];
                int rlen = is.read(buf, 0, bufsize);
                if (rlen <= 0) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("failed to read head"),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    return;
                }

                Properties pre = new Properties();
                Properties params = new Properties();
                Properties header = new Properties();

                BufferedReader bufferedReader = null;
                try {
                    // Create a BufferedReader for parsing the header.
                    ByteArrayInputStream hbis = new ByteArrayInputStream(buf, 0, rlen);
                    bufferedReader = new BufferedReader(new InputStreamReader(hbis));

                    // Decode the header into params and header java properties
                    decodeHeader(bufferedReader, pre, params, header); // 里面做了decode，下面在使用的时候就不能在URLDecode了。
                } catch (Throwable e) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("failed to create input stream or reader:"+e.toString()),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    LogHelper.printStackTrace(e);
                } finally {
                    try {
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                }

                String method = pre.getProperty("method");
                String uri = pre.getProperty("uri");

                LogHelper.d(TAG, "1: client connected, 1)");

                if (params.get("itemId") != null) {
                    itemId = Integer.valueOf(params.get("itemId").toString());
                }

                LogHelper.d(TAG, "1: client connected, 2)itemId:" + itemId);

                realUri = params.getProperty("url");
                if (realUri == null || realUri.length() == 0) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("can't get realUri"),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    return;
                }

                LogHelper.d(TAG, "1: client connected, 3)realUri:" + realUri);

                if (params.get(KEY_ENCRYPT) != null && Integer.valueOf(params.get(KEY_ENCRYPT).toString()) == 0) {
                    isEncrypt = false;
                }

                LogHelper.d(TAG, "1: client connected, 4)isEncrypt:" + isEncrypt);

                if (params.get(KEY_ENCRYPT_TYPE) != null) {
                    encryptTppe = Integer.valueOf(params.get(KEY_ENCRYPT_TYPE).toString());
                }

                LogHelper.d(TAG, "1: client connected, 5)encryptTppe:" + encryptTppe);

                if (params.get(KEY_VERSION) != null) {
                    version = Integer.valueOf(params.get(KEY_VERSION).toString());
                }

                LogHelper.d(TAG, "1: client connected, 6)version:" + version);

                if (params.get(KEY_COLLECT_ID) != null) {
                    collectId = Integer.valueOf(params.get(KEY_COLLECT_ID).toString());
                }

                LogHelper.d(TAG, "1: client connected, 7)collectId:" + collectId);

                String AESST = params.getProperty(KEY_AESST);

                LogHelper.d(TAG, "2:getSecurityKey:" + securityKey + " isEncrypt:" + isEncrypt + " version:" + version);

                LogHelper.d(TAG, URLDecoder.decode(new String(buf, 0, rlen), "UTF-8"));

                myUrl = realUri;
                addSession(this);

                LogHelper.d(TAG, "0: isEncrypt && version:" + isEncrypt + " " + version);

                if (isEncrypt && version > 0) {
                    if (AESST != null && AESST.length() > 0) {
                        securityKey = AESST;
                    }

                    if (securityKey == null || securityKey.length() == 0) {
                        LogHelper.d(TAG, "1: client connected, 6.1)version:" + version);

                        cancelFlag = "MediaServer-AESST-" + System.currentTimeMillis();

                        securityKey = CryptoKadaLib.getInstance().getAESST(itemId, encryptTppe, version, collectId, cancelFlag);

                        LogHelper.d(TAG, "1: client connected, 6.2)version:" + version);

                        if (securityKey == null || securityKey.length() == 0) {
                            quit = true;
//                            UserHabitService.getInstance().trackHabit2Umeng(
//                                    UserHabitService.newUserHabit(packageString("exit for none of securityKey"),
//                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                        }
                    }
                }

                if (quit) {
                    return;
                }

                cancelFlag = null;

                String mime = "audio/mpeg";
                String fileName = Md5Util.getStringMD5("/" + itemId + "/" + realUri) + "_" + version + ".mp3";
                String mediaTargetDir = "";

                String targetFilePath = params.getProperty(KEY_TARGET_FILE_PATH);
                if (targetFilePath != null) {
                    fileName = targetFilePath.substring(targetFilePath.lastIndexOf("/") + 1);
                    mediaTargetDir = targetFilePath.substring(0, targetFilePath.lastIndexOf("/"));
                } else {
                    mediaTargetDir = params.getProperty(KEY_TARGET_DIR);
                }

                String storeFilePath = getRootPath() + File.separator + fileName;

                if (mediaTargetDir != null && mediaTargetDir.length() > 0) {
                    //创建文件夹
                    mediaTargetDir = FileUtils.makeDirIfNoExist(mediaTargetDir);

                    storeFilePath = mediaTargetDir + File.separator + fileName;

                    if (!FileUtils.fileExist(storeFilePath)) {

                        String storeFilePathOld = getRootPath() + File.separator + fileName;

                        if (FileUtils.fileExist(storeFilePathOld)) {
                            FileUtils.copyTo(storeFilePathOld, storeFilePath);
                            FileUtils.removeFile(storeFilePathOld);
                        }
                    }
                }

                String storeFilePathTempBase = new StringBuffer(getRootPathTemp()).append(File.separator).append(fileName).append("_").append(version).toString();
                String storeFilePathTemp = storeFilePathTempBase + "_.tmp";
                String storeFilePathTempSize = storeFilePathTempBase + "_.size";

                File storeFile = new File(storeFilePath);

                if (storeFile.isFile() && storeFile.exists()) {

                    LogHelper.d(TAG, "3:storeFile.isFile() && storeFile.exists()==true");

                    FileUtils.removeFile(storeFilePathTemp);
                    FileUtils.removeFile(storeFilePathTempSize);

                    Response response = null;
                    try {
                        // Support (simple) skipping:
                        long startFrom = 0;
                        long endAt = -1;

                        String range = header.getProperty(KEY_HEADER_RANGE);

                        if (range != null) {
                            if (range.startsWith("bytes=")) {
                                range = range.substring("bytes=".length());
                                int minus = range.indexOf('-');
                                try {
                                    if (minus > 0) {
                                        String start = range.substring(0, minus);
                                        String end = range.substring(minus + 1);

                                        if (!StringUtil.isEmpty(start)) {
                                            startFrom = Long.parseLong(start);
                                        }
                                        if (!StringUtil.isEmpty(end)) {
                                            endAt = Long.parseLong(end);
                                        }
                                    }
                                } catch (NumberFormatException nfe) {
//                                    UserHabitService.getInstance().trackHabit2Umeng(
//                                            UserHabitService.newUserHabit(packageString("failed to calculate bytes offset(1) : " +nfe.toString()),
//                                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                                    LogHelper.printStackTrace(nfe);
                                }
                            }
                        }

                        // Change return code and add Content-Range header when skipping is requested
                        long fileLen = storeFile.length();
                        if (isEncrypt) {
                            if (version > 0) {
                                fileLen = storeFile.length();
                            } else {
                                fileLen = storeFile.length() - FILE_IGNORE_LENGTH;
                            }
                        }

                        if (startFrom >= fileLen) {
                            response = new Response(HTTP_RANGE_NOT_SATISFIABLE, MIME_PLAINTEXT, "");
                            response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes 0-0/" + fileLen);
//                            response.addHeader( "Accept-Ranges", "bytes");
//                            response.addHeader( "Connection", "Keep-Alive");
//                            UserHabitService.getInstance().trackHabit2Umeng(
//                                    UserHabitService.newUserHabit(packageString("欲读取的字节超过了原始文件长度(1)"),
//                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                            LogHelper.d(TAG, "4:storeFile.isFile() && storeFile.exists()==true, 1)startFrom>= fileLen");
                        } else if (startFrom > 0) {
                            if (endAt < 0) {
                                endAt = fileLen - 1;
                            }

                            long newLen = endAt - startFrom + 1;
                            if (newLen < 0) {
                                newLen = 0;
                            }

                            final long dataLen = newLen;

                            FileInputStream fis = isEncrypt ? new DecryptFileInputStream(storeFile, dataLen, itemId, version, securityKey) {
                                @Override
                                public int available() throws IOException {
                                    return (int) dataLen;
                                }
                            } : new FileInputStream(storeFile);

//                            fis.skip( startFrom );

                            long at = startFrom;
                            while (at > 0) {
                                long amt = fis.skip(at);
                                if (amt == -1) {
//                                    throw new RuntimeException(file + ": unexpected EOF");
//                                    UserHabitService.getInstance().trackHabit2Umeng(
//                                            UserHabitService.newUserHabit(packageString("字节跳过时出错"),
//                                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                                    LogHelper.d(TAG, "skip not right");
                                }
                                at -= amt;
                            }

                            response = new Response(HTTP_PARTIALCONTENT, mime, fis);
                            response.addHeader(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + dataLen);
                            response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAt + "/" + fileLen);
                            response.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                            response.addHeader(KEY_HTTP_HEADER_CONNECTION, "Keep-Alive");

                            LogHelper.d(TAG, "4:storeFile.isFile() && storeFile.exists()==true, 2)startFrom:" + startFrom + "endAt:" + endAt);
                        } else {

                            if (endAt < 0) {
                                endAt = fileLen - 1;
                            }

                            long newLen = endAt - startFrom + 1;

                            if (newLen < 0) {
                                newLen = 0;
                            }

                            final long dataLen = newLen;
                            response = new Response(HTTP_OK, mime, isEncrypt ? new DecryptFileInputStream(storeFile, dataLen, itemId, version, securityKey) {

                                @Override
                                public int available() throws IOException {
                                    return (int) dataLen;
                                }
                            } : new FileInputStream(storeFile));

                            response.addHeader(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + dataLen);
                            response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAt + "/" + fileLen);
                            response.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                            response.addHeader(KEY_HTTP_HEADER_CONNECTION, "Keep-Alive");

                            LogHelper.d(TAG, "4:storeFile.isFile() && storeFile.exists()==true, 3)else");
                        }
                    } catch (IOException e) {
//                        UserHabitService.getInstance().trackHabit2Umeng(
//                                UserHabitService.newUserHabit(packageString("failed to operate local audio file : " +e.toString()),
//                                        UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                        LogHelper.printStackTrace(e);

                        try {
                            // 出现异常 关闭文件流
                            if (response != null && response.data != null) {
                                response.data.close();
                            }
                        } catch (Throwable e1) {
//                            UserHabitService.getInstance().trackHabit2Umeng(
//                                    UserHabitService.newUserHabit(packageString("failed to close reponse : " +e1.toString()),
//                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                            LogHelper.printStackTrace(e1);
                        }

                        // 重新创建 response
                        response = new Response(HTTP_FORBIDDEN, MIME_PLAINTEXT, "FORBIDDEN: Reading file failed.");
                    }

                    Response r = response;
                    if (r == null) {
                        sendError(HTTP_INTERNALERROR, "SERVER INTERNAL ERROR: Serve() returned a null response.");
                    } else {
                        sendResponse(r.status, r.mimeType, r.header, r.data);
                    }

                    return;
                } else {
                    long startFrom = 0;
                    long endAt = -1;

                    String range = header.getProperty(KEY_HEADER_RANGE);
                    if (range != null) {
                        if (range.startsWith("bytes=")) {
                            range = range.substring("bytes=".length());
                            int minus = range.indexOf('-');
                            try {
                                if (minus > 0) {
                                    String start = range.substring(0, minus);
                                    String end = range.substring(minus + 1);

                                    if (!StringUtil.isEmpty(start)) {
                                        startFrom = Long.parseLong(start);
                                    }
                                    if (!StringUtil.isEmpty(end)) {
                                        endAt = Long.parseLong(end);
                                    }
                                }
                            } catch (NumberFormatException nfe) {
//                                UserHabitService.getInstance().trackHabit2Umeng(
//                                        UserHabitService.newUserHabit(packageString("failed to calculate bytes offset(2) : " +nfe.toString()),
//                                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                                LogHelper.printStackTrace(nfe);
                            }
                        }
                    }

                    LogHelper.d(TAG, "3:storeFile.isFile() && storeFile.exists()==false, startFrom:" + startFrom + " endAt:" + endAt);

                    long fileLen = 0;
                    if (FileUtils.fileExist(storeFilePathTempSize)) {
                        String fileLenString = FileUtils.readStringFromFile(storeFilePathTempSize);
                        if (fileLenString != null && fileLenString.length() > 0 && PatternUtil.isInteger(fileLenString)) {
                            fileLen = Long.valueOf(fileLenString);
                        }
                    }

                    //保证本地已经缓存的数据长度cachedFileLen为16的倍数，
                    cachedAccessFile = new RandomAccessFile(storeFilePathTemp, "rw");
                    long cachedFileLen = 0;
                    if (fileLen > 0) {
                        cachedFileLen = cachedAccessFile.length();
                        if (fileLen < cachedFileLen) {
                            cachedFileLen = 0;
                        }
                        if (isEncrypt && version > 0 && cachedFileLen % FILE_ENCRYPT_LENGTH > 0) {
                            cachedFileLen = cachedFileLen - (cachedFileLen % FILE_ENCRYPT_LENGTH);
                        }
                    }
                    cachedAccessFile.seek(cachedFileLen);

                    //0.检查是否超出范围
                    if (fileLen > 0 && startFrom >= fileLen) {
                        Response r = new Response(HTTP_RANGE_NOT_SATISFIABLE, MIME_PLAINTEXT, "");
                        r.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes 0-0/" + fileLen);
                        r.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                        r.addHeader(KEY_HTTP_HEADER_CONNECTION, "Keep-Alive");

                        sendResponse(r.status, r.mimeType, r.header, r.data);
                        return;
                    }

                    //1). 把本地已经有的返回给客户端
                    if (fileLen > 0
                            && cachedFileLen > 0
                            && cachedFileLen > endAt
                            && startFrom >= 0
                            && endAt > startFrom) {
                        LogHelper.d(TAG, "writing to client 把本地已经有的返回给客户端");

                        long newLen = endAt - startFrom + 1;
                        if (newLen < 0) {
                            newLen = 0;
                        }

                        final long dataLen = newLen;
                        FileInputStream fis = isEncrypt ? new DecryptFileInputStream(new File(storeFilePathTemp), dataLen, itemId, version, securityKey) : new FileInputStream(storeFilePathTemp);
//                        fis.skip(startFrom);

                        long at = startFrom;
                        while (at > 0) {
                            long amt = fis.skip(at);
                            if (amt == -1) {
//                                    throw new RuntimeException(file + ": unexpected EOF");
                                LogHelper.d(TAG, "skip not right");
                            }
                            at -= amt;
                        }

                        Response response = new Response(HTTP_PARTIALCONTENT, mime, fis);
                        response.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                        response.addHeader(KEY_HTTP_HEADER_CONNECTION, "keep-alive");
                        response.addHeader(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + dataLen);
                        response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAt + "/" + fileLen);

                        sendResponse(response.status, response.mimeType, response.header, response.data);
                        return;
                    }

//
                    //2). 把现有的全部返回给客户端
                    boolean hasSendHeaders = false;

                    if (fileLen > 0 && cachedFileLen > 0 && cachedFileLen > startFrom) {

                        long endAtNew = endAt;
                        if (endAtNew < 0) {
                            endAtNew = fileLen - 1;
                        }

                        if (startFrom > 0) {
                            LogHelper.d(TAG, "writing to client startFrom>0 把现有的全部返回给客户端,startFrom=" + startFrom + ";cachedFileLen=" + cachedFileLen);

                            final long dataLen = cachedFileLen - startFrom;
                            FileInputStream fis = isEncrypt ? new DecryptFileInputStream(new File(storeFilePathTemp), dataLen, itemId, version, securityKey) : new FileInputStream(storeFilePathTemp);
//                            fis.skip(startFrom);

                            long at = startFrom;
                            while (at > 0) {
                                long amt = fis.skip(at);
                                if (amt == -1) {
//                                    throw new RuntimeException(file + ": unexpected EOF");
                                    LogHelper.d(TAG, "skip not right");
                                }
                                at -= amt;
                            }

                            long newLen = endAtNew - startFrom + 1;
                            if (newLen < 0) {
                                newLen = 0;
                            }

                            Response response = new Response(HTTP_PARTIALCONTENT, mime, fis);
                            response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAtNew + "/" + fileLen);
                            response.addHeader(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + newLen);
                            response.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                            response.addHeader(KEY_HTTP_HEADER_CONNECTION, "keep-alive");

                            sendResponse(response.status, response.mimeType, response.header, response.data, false);

                        } else {
                            LogHelper.d(TAG, "writing to client startFrom==0把现有的全部返回给客户端,startFrom=" + startFrom + ";cachedFileLen=" + cachedFileLen);

                            final long dataLen = cachedFileLen;
                            FileInputStream fis = isEncrypt ? new DecryptFileInputStream(new File(storeFilePathTemp), dataLen, itemId, version, securityKey) : new FileInputStream(storeFilePathTemp);

                            long newLen = endAtNew - startFrom + 1;//startFrom==0
                            if (newLen < 0) {
                                newLen = 0;
                            }

                            Response response = new Response(HTTP_OK, mime, fis);
                            response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAtNew + "/" + fileLen);
                            response.addHeader(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + newLen);
                            response.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                            response.addHeader(KEY_HTTP_HEADER_CONNECTION, "keep-alive");

                            sendResponse(response.status, response.mimeType, response.header, response.data, false);
                        }

                        if (cachedFileLen >= fileLen && fileLen > 0) {
                            //下载完了已经
                            FileUtils.copyTo(storeFilePathTemp, storeFilePath);
                            return;
                        }

                        startFrom = cachedFileLen;
                        hasSendHeaders = true;
                    }

                    //如果请求超出本地缓存的数据直接请求服务器并返回
                    if (!hasSendHeaders && startFrom > cachedFileLen && cachedFileLen > 0) {

                        LogHelper.d(TAG, "超出本地缓存的数据直接请求服务器并返回,startFrom=" + startFrom + ";cachedFileLen=" + cachedFileLen);

                        long startFromOrgin = startFrom;
                        long startFromTemp = startFrom;
                        if (startFromOrgin % FILE_ENCRYPT_LENGTH > 0) {
                            startFromTemp = startFromOrgin - (startFromOrgin % FILE_ENCRYPT_LENGTH);
                        }
                        long endAtNew = endAt;
                        if (endAtNew < 0) {
                            endAtNew = fileLen - 1;
                        }

                        httpGetRemote = null;
                        HttpResponse realResponse = null;

                        {
                            URI originalURI = URI.create(realUri);
                            DefaultHttpClient seed = new DefaultHttpClient();
                            SchemeRegistry registry = new SchemeRegistry();
                            if (originalURI.getPort() != -1) {
                                registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), originalURI.getPort()));
                            } else {
                                registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
                            }

                            SingleClientConnManager mgr = new MyClientConnManager(seed.getParams(), registry);
                            httpClient = new DefaultHttpClient(mgr, seed.getParams());
                            httpGetRemote = new HttpGet(realUri);
                            httpGetRemote.addHeader(null);

                            if (header != null) {
                                Enumeration ele = header.keys();
                                while (ele.hasMoreElements()) {
                                    String key = (String) ele.nextElement();
                                    String value = header.getProperty(key);

                                    if (!TextUtils.equals(key.toLowerCase(), KEY_HEADER_HOST)) {
                                        if (isEncrypt && version > 0 && TextUtils.equals(key.toLowerCase(), KEY_HEADER_RANGE)) {
                                            String valueOld = new String(value);
                                            if (endAt > 0) {
                                                long endAtTemp = endAt;
                                                if (endAtTemp % FILE_ENCRYPT_LENGTH > 0) {
                                                    endAtTemp = endAtTemp + (FILE_ENCRYPT_LENGTH - (endAtTemp % FILE_ENCRYPT_LENGTH));
                                                }
                                                value = value.toLowerCase().replace("bytes=" + startFrom, "bytes=" + startFromTemp);
                                                value = value.toLowerCase().replace("-" + endAt, "-" + endAtTemp);
                                            } else {
                                                value = value.toLowerCase().replace("bytes=" + startFrom, "bytes=" + startFromTemp);
                                            }
                                            httpGetRemote.addHeader(key, value);
                                        } else {
                                            httpGetRemote.addHeader(key, value);
                                        }
                                    }
                                    //Range: bytes=0-801
                                }
                            }

                            try {
                                LogHelper.d(TAG, "starting download");
                                realResponse = httpClient.execute(httpGetRemote);
                                LogHelper.d(TAG, "downloaded");
                            } catch (ClientProtocolException e) {
//                                UserHabitService.getInstance().trackHabit2Umeng(
//                                        UserHabitService.newUserHabit(packageString("httpClient.execute() failed(1): " +e.toString()),
//                                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                                LogHelper.e(TAG, "Error downloading", e);
                                LogHelper.printStackTrace(e);
                            } catch (IOException e) {
//                                UserHabitService.getInstance().trackHabit2Umeng(
//                                        UserHabitService.newUserHabit(packageString("httpClient.execute() failed(1): " +e.toString()),
//                                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                                LogHelper.e(TAG, "Error downloading", e);
                                LogHelper.printStackTrace(e);
                            }
                        }

                        if (realResponse == null) {
                            return;
                        }

                        LogHelper.d(TAG, "downloading...");

                        if (realResponse.getEntity() == null) {
//                            UserHabitService.getInstance().trackHabit2Umeng(
//                                    UserHabitService.newUserHabit(packageString("response of httpClient is Incomplete : null entity"),
//                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                            return;
                        }

                        InputStream data = realResponse.getEntity().getContent();
                        StatusLine line = realResponse.getStatusLine();
                        HttpResponse response = new BasicHttpResponse(line);
                        response.setHeaders(realResponse.getAllHeaders());

                        LogHelper.d(TAG, "reading headers");

                        StringBuilder httpString = new StringBuilder();
                        httpString.append(response.getStatusLine().toString());

                        httpString.append("\r\n");
                        for (Header h : response.getAllHeaders()) {
                            httpString.append(h.getName()).append(": ").append(h.getValue()).append("\r\n");
                        }
                        httpString.append("\r\n");

                        LogHelper.d(TAG, "headers done");
//                        Log.d(TAG, httpString.toString());

//                        Content-Range: bytes 2793065-3906735/3906736

                        String httpStringTemp = new String(httpString.toString());
                        String httpStringTempOld = new String(httpString.toString());

                        int start = httpStringTemp.indexOf("Content-Range: bytes ");
                        if (start >= 0) {
                            int end = httpStringTemp.indexOf("\r\n", start);
                            httpStringTemp = httpStringTemp.replace(httpStringTemp.substring(start, end), "Content-Range: bytes " + startFrom + "-" + endAtNew + "/" + fileLen);
                        }

                        start = httpStringTemp.indexOf("Content-Length: ");
                        if (start >= 0) {
                            int end = httpStringTemp.indexOf("\r\n", start);
                            httpStringTemp = httpStringTemp.replace(httpStringTemp.substring(start, end), "Content-Length: " + (endAtNew - startFrom + 1));
                        }

                        LogHelper.d(TAG, "headers done2");
                        LogHelper.d(TAG, "httpStringTemp:" + httpStringTemp);
                        LogHelper.d(TAG, "httpStringTempOld:" + httpStringTempOld);
                        LogHelper.d(TAG, "headers done3");

                        byte[] buffer = httpStringTemp.getBytes();
                        mySocket.getOutputStream().write(buffer, 0, buffer.length);

                        // Start streaming content.
                        int readBytes = -1;
                        if (isEncrypt && version > 0) {
                            int startFromDiff = (int) (startFromOrgin - startFromTemp);
                            int byteOffsetTemp = 0;
                            int readBytesTemp = -1;
                            long totalReadBytes = 0;

                            long totalSendToClient = 0;
                            long totalClientWanted = endAtNew - startFrom + 1;
                            // Start streaming content.
                            byte[] buffTemp = new byte[1024 * 16 * 4]; //保证是16的倍数
                            byte[] buff = new byte[1024 * 16 * 4];
                            while ((readBytesTemp = data.read(buffTemp, byteOffsetTemp, buff.length - byteOffsetTemp)) != -1 && !quit && !mySocket.isClosed()) {

                                //确保为16的整数倍
                                readBytesTemp = readBytesTemp + byteOffsetTemp;

                                if (readBytesTemp < 16 || readBytesTemp < startFromDiff + FILE_ENCRYPT_LENGTH) {
                                    byteOffsetTemp = byteOffsetTemp + readBytesTemp;
                                    continue;
                                }

                                if (readBytesTemp % FILE_ENCRYPT_LENGTH > 0) {
                                    readBytes = readBytesTemp - (readBytesTemp % FILE_ENCRYPT_LENGTH);
                                } else {
                                    readBytes = readBytesTemp;
                                }

                                if (readBytesTemp > readBytes) {
                                    byteOffsetTemp = readBytesTemp - readBytes;
                                } else {
                                    byteOffsetTemp = 0;
                                }

                                totalReadBytes += readBytes;

                                int ret = CryptoKadaLib.getInstance().decrypt(version, securityKey, buffTemp, readBytes, buff, readBytes);


                                if (totalReadBytes > startFromDiff) {
                                    if (totalSendToClient + (readBytes - startFromDiff) <= totalClientWanted) {
                                        totalSendToClient += (readBytes - startFromDiff);
                                        mySocket.getOutputStream().write(buff, startFromDiff, readBytes - startFromDiff);
                                        mySocket.getOutputStream().flush();
                                    } else {
                                        mySocket.getOutputStream().write(buff, startFromDiff, (int) (totalClientWanted - totalSendToClient));
                                        mySocket.getOutputStream().flush();
                                        break;
                                    }
                                    startFromDiff = 0;
                                } else {
                                    startFromDiff -= totalReadBytes;
                                }

                                if (byteOffsetTemp > 0) {
                                    System.arraycopy(buffTemp, readBytes, buffTemp, 0, byteOffsetTemp);
                                }

                            }
                        } else {
                            // Start streaming content.
                            byte[] buff = new byte[1024 * 50];
                            while ((readBytes = data.read(buff, 0, buff.length)) != -1 && !quit && !mySocket.isClosed()) {
                                if (isEncrypt) {
                                    CryptoKadaLib.getInstance().decrypt(itemId, buff, readBytes);
                                }
                                mySocket.getOutputStream().write(buff, 0, readBytes);
                                mySocket.getOutputStream().flush();
                            }
                        }
                        return;
                    }

                    LogHelper.d(TAG, "从服务器下载并缓存到本地,startFrom=" + startFrom + "endAt:" + endAt + ";cachedFileLen=" + cachedFileLen);


                    Properties newHeaderRemote = new Properties();
                    if (cachedFileLen > 0) {
                        newHeaderRemote.put("Range", "bytes=" + cachedFileLen + "-");
                    }
                    httpGetRemote = null;
                    HttpResponse realResponse = null;

                    {
                        URI originalURI = URI.create(realUri);
                        DefaultHttpClient seed = new DefaultHttpClient();
                        SchemeRegistry registry = new SchemeRegistry();
                        if (originalURI.getPort() != -1) {
                            registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), originalURI.getPort()));
                        } else {
                            registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
                        }
                        SingleClientConnManager mgr = new MyClientConnManager(seed.getParams(), registry);
                        httpClient = new DefaultHttpClient(mgr, seed.getParams());
                        httpGetRemote = new HttpGet(realUri);
                        httpGetRemote.addHeader(null);
                        if (newHeaderRemote != null) {
                            Enumeration ele = newHeaderRemote.keys();
                            while (ele.hasMoreElements()) {
                                String key = (String) ele.nextElement();
                                String value = newHeaderRemote.getProperty(key);
                                httpGetRemote.addHeader(key, value);
                            }
                        }

                        try {
                            LogHelper.d(TAG, "starting download");
                            realResponse = httpClient.execute(httpGetRemote);
                            LogHelper.d(TAG, "downloaded");
                        } catch (ClientProtocolException e) {
//                            UserHabitService.getInstance().trackHabit2Umeng(
//                                    UserHabitService.newUserHabit(packageString("httpClient.execute() failed(2): " +e.toString()),
//                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                            LogHelper.e(TAG, "Error downloading", e);
                            LogHelper.printStackTrace(e);
                        } catch (IOException e) {
//                            UserHabitService.getInstance().trackHabit2Umeng(
//                                    UserHabitService.newUserHabit(packageString("httpClient.execute() failed(2): " +e.toString()),
//                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                            LogHelper.e(TAG, "Error downloading", e);
                            LogHelper.printStackTrace(e);
                        } catch (Exception e) {
//                            UserHabitService.getInstance().trackHabit2Umeng(
//                                    UserHabitService.newUserHabit(packageString("httpClient.execute() failed(2): " +e.toString()),
//                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                            LogHelper.e(TAG, "Error downloading", e);
                            LogHelper.printStackTrace(e);
                        }
                    }

                    if (realResponse == null) {
                        return;
                    }

                    InputStream data = realResponse.getEntity().getContent();
                    StatusLine line = realResponse.getStatusLine();
                    HttpResponse response = new BasicHttpResponse(line);
                    response.setHeaders(realResponse.getAllHeaders());
                    //保存返回的文件长度
                    if (fileLen == 0) {
                        for (Header h : response.getAllHeaders()) {
                            if (TextUtils.equals(h.getName().toLowerCase(), "content-length")) {
                                long size = 0x7FFFFFFFFFFFFFFFL;

                                String contentLength = h.getValue();
                                if (contentLength != null) {
                                    try {
                                        size = Integer.parseInt(contentLength);
                                        FileUtils.saveStringToFile(Long.valueOf(size).toString(), storeFilePathTempSize);
                                        fileLen = size;
                                    } catch (NumberFormatException ex) {
                                        LogHelper.printStackTrace(ex);
                                    }
                                }
                                break;
                            }
                        }
                    }

                    if (fileLen == 0) { //不合法
//                        UserHabitService.getInstance().trackHabit2Umeng(
//                                UserHabitService.newUserHabit(packageString("exit because of zero file length "),
//                                        UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                        return;
                    }

                    long endAtNew = endAt;
                    if (endAtNew < 0) {
                        endAtNew = fileLen - 1;
                    }

                    if (!hasSendHeaders) {
                        LogHelper.d(TAG, "reading headers");
                        Properties newHeader = new Properties();
                        for (Header h : response.getAllHeaders()) {
                            if (TextUtils.equals(h.getName().toLowerCase(), "content-type")) {
                                newHeader.put(h.getName().toLowerCase(), "audio/mpeg");
                            } else {
                                newHeader.put(h.getName().toLowerCase(), h.getValue());
                            }
                        }
                        newHeader.remove("content-range");
                        newHeader.remove("content-length");

                        long newLen = endAtNew - startFrom + 1;
                        if (newLen < 0) {
                            newLen = 0;
                        }

                        final long dataLen = newLen;

                        if (startFrom > 0) {
                            newHeader.put(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + dataLen);
                            newHeader.put(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAtNew + "/" + fileLen);
                            sendResponse(HTTP_PARTIALCONTENT, mime, newHeader, null, false);
                        } else {
                            newHeader.put(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + dataLen);
//                            newHeader.put(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAtNew + "/" + fileLen);
                            sendResponse(HTTP_OK, mime, newHeader, null, false);
                        }
                        LogHelper.d(TAG, "headers done");
                    }

                    LogHelper.d(TAG, "writing to client");

                    cachedAccessFile.seek(cachedFileLen);

//                    RandomAccessFile cachedAccessFileXXX = new RandomAccessFile(storeFilePathTemp+".XXX", "rw");
//                    cachedAccessFileXXX.seek(cachedFileLen);

                    if (isEncrypt && version > 0) {

                        long hasWriteBytes = 0;
                        int byteOffsetTemp = 0;
                        int readBytesTemp = -1;
                        int readBytes = -1;
                        // Start streaming content.
                        byte[] buffTemp = new byte[1024 * 16 * 4]; //保证是16的倍数
                        byte[] buff = new byte[1024 * 16 * 4];

                        while ((readBytesTemp = data.read(buffTemp, byteOffsetTemp, buffTemp.length - byteOffsetTemp)) != -1 && !quit && !mySocket.isClosed()) {

                            //确保为16的整数倍
                            readBytesTemp = readBytesTemp + byteOffsetTemp;

                            if (readBytesTemp < 16) {
                                byteOffsetTemp = byteOffsetTemp + readBytesTemp;
                                continue;
                            }

                            if (readBytesTemp % FILE_ENCRYPT_LENGTH > 0) {
                                readBytes = readBytesTemp - (readBytesTemp % FILE_ENCRYPT_LENGTH);
                            } else {
                                readBytes = readBytesTemp;
                            }

                            if (readBytesTemp > readBytes) {
                                byteOffsetTemp = readBytesTemp - readBytes;
                            } else {
                                byteOffsetTemp = 0;
                            }

                            cachedAccessFile.write(buffTemp, 0, readBytes);

                            if (endAtNew > startFrom) {
                                if (cachedFileLen + readBytes > startFrom && startFrom + hasWriteBytes < endAtNew + 1) {

                                    int ret = CryptoKadaLib.getInstance().decrypt(version, securityKey, buffTemp, readBytes, buff, readBytes);

                                    int toWriteOffset = 0;
                                    int toWriteCount = 0;
                                    if (cachedFileLen + readBytes >= endAtNew + 1) {
                                        if (startFrom > cachedFileLen) {
                                            toWriteOffset = (int) (startFrom - cachedFileLen);
                                            toWriteCount = (int) (endAtNew + 1 - cachedFileLen);
                                        } else {
                                            toWriteOffset = 0;
                                            toWriteCount = (int) (endAtNew + 1 - cachedFileLen);
                                        }
                                    } else {
                                        if (startFrom > cachedFileLen) {
                                            toWriteOffset = (int) (startFrom - cachedFileLen);
                                            toWriteCount = (int) (cachedFileLen + readBytes - startFrom);
                                        } else {
                                            toWriteOffset = 0;
                                            toWriteCount = readBytes;
                                        }
                                    }

                                    if (mySocket != null) {
                                        try {
                                            /**
                                             * 线上Bug：
                                             *
                                             java.lang.NullPointerException: throw with null exception
                                             at java.net.Socket.getOutputStream(Socket.java:940)
                                             at com.hhdd.kada.main.e.b$b.run(MediaServer2.java:1167)
                                             *
                                             * 这里添加try{}catch保护，防止程序崩溃
                                             */
                                            OutputStream outputStream = mySocket.getOutputStream();
                                            outputStream.write(buff, toWriteOffset, toWriteCount);
                                            hasWriteBytes += toWriteCount;
                                            outputStream.flush();
                                        } catch (Throwable e) {
//                                            UserHabitService.getInstance().trackHabit2Umeng(
//                                                    UserHabitService.newUserHabit(packageString("Media Player close the socket: "+e.toString()),
//                                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                                            LogHelper.printStackTrace(e);
                                            return;
                                        }
                                    }

//                                    cachedAccessFileXXX.write(buff, toWriteOffset, toWriteCount);

                                }
                            } else {
                                //Puzzled here : 算作异常吗？先放一边。
//                                UserHabitService.getInstance().trackHabit2Umeng(
//                                        UserHabitService.newUserHabit(packageString("error endAtNew<startFrom"),
//                                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                                LogHelper.d(TAG, "error endAtNew<startFrom");
                            }

                            cachedFileLen += readBytes;

                            if (byteOffsetTemp > 0) {
                                System.arraycopy(buffTemp, readBytes, buffTemp, 0, byteOffsetTemp);
                            }
                        }
                    } else {
                        long hasWriteBytes = 0;
                        int readBytes = -1;
                        // Start streaming content.
                        byte[] buff = new byte[1024 * 50];
                        while ((readBytes = data.read(buff, 0, buff.length)) != -1 && !quit && !mySocket.isClosed()) {
                            cachedAccessFile.write(buff, 0, readBytes);

                            if (endAtNew > startFrom) {
                                if (cachedFileLen + readBytes > startFrom && startFrom + hasWriteBytes < endAtNew + 1) {

                                    if (isEncrypt) {
                                        CryptoKadaLib.getInstance().decrypt(itemId, buff, readBytes);
                                    }

                                    int toWriteOffset = 0;
                                    int toWriteCount = 0;
                                    if (cachedFileLen + readBytes >= endAtNew + 1) {
                                        if (startFrom > cachedFileLen) {
                                            toWriteOffset = (int) (startFrom - cachedFileLen);
                                            toWriteCount = (int) (endAtNew + 1 - cachedFileLen);
                                        } else {
                                            toWriteOffset = 0;
                                            toWriteCount = (int) (endAtNew + 1 - cachedFileLen);
                                        }
                                    } else {
                                        if (startFrom > cachedFileLen) {
                                            toWriteOffset = (int) (startFrom - cachedFileLen);
                                            toWriteCount = (int) (cachedFileLen + readBytes - startFrom);
                                        } else {
                                            toWriteOffset = 0;
                                            toWriteCount = readBytes;
                                        }
                                    }

                                    mySocket.getOutputStream().write(buff, toWriteOffset, toWriteCount);
                                    hasWriteBytes += toWriteCount;
                                    mySocket.getOutputStream().flush();
                                }
                            } else {
                                LogHelper.d(TAG, "error endAtNew<startFrom");
                            }

                            cachedFileLen += readBytes;

                            try {
                                Thread.sleep(2);
                            } catch (InterruptedException e) {
                                LogHelper.printStackTrace(e);
                            }
                        }
                    }

                    if (cachedFileLen >= fileLen && fileLen > 0) {
                        FileUtils.copyTo(storeFilePathTemp, storeFilePath);
                    }

                    LogHelper.d(TAG, "writing done");
                }
            } catch (SocketTimeoutException e) {
                // Do nothing
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("Socket timeout : "+e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "Error timeout", e);
                LogHelper.printStackTrace(e);
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("error connect to client: "+e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "Error connecting to client", e);
                LogHelper.printStackTrace(e);
            } catch (InterruptedException ie) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("InterruptedException occurs :"+ie.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                // Thrown by sendError, ignore and exit the thread.
                LogHelper.e(TAG, "Error InterruptedException", ie);
                LogHelper.printStackTrace(ie);
            } catch (Throwable e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("unexpected exception occurs :"+e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "MediaServe Error", e);
                LogHelper.printStackTrace(e);
            } finally {
                try {
                    if (httpGetRemote != null) {
                        httpGetRemote.abort();
                        httpGetRemote = null;
                    }
                } catch (Throwable e) {
                    LogHelper.printStackTrace(e);
                }

                try {
                    if (httpClient != null) {
                        httpClient.getConnectionManager().closeIdleConnections(0, TimeUnit.SECONDS);
                    }
                } catch (Throwable e) {
                    LogHelper.printStackTrace(e);
                }

                try {
                    if (cachedAccessFile != null) {
                        cachedAccessFile.close();
                    }
                } catch (IOException e) {
                    LogHelper.printStackTrace(e);
                }

                try {
                    LogHelper.d(TAG, ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> close socket in finally");
                    if (mySocket != null) {
                        mySocket.close();
                    }
                } catch (Throwable t) {
                    LogHelper.printStackTrace(t);
                }

//                doNotifyAll();
                removeSession(this);
            }
        }

        private HttpResponse download(String url, Properties header) {
            URI originalURI = URI.create(url);
            DefaultHttpClient seed = new DefaultHttpClient();
            SchemeRegistry registry = new SchemeRegistry();
            if (originalURI.getPort() != -1) {
                registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), originalURI.getPort()));
            } else {
                registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
            }
            SingleClientConnManager mgr = new MyClientConnManager(seed.getParams(), registry);
            DefaultHttpClient http = new DefaultHttpClient(mgr, seed.getParams());
            HttpGet httpGet = new HttpGet(url);
            httpGet.addHeader(null);
            if (header != null) {
                Enumeration ele = header.keys();
                while (ele.hasMoreElements()) {
                    String key = (String) ele.nextElement();
                    String value = header.getProperty(key);
                    httpGet.addHeader(key, value);
                }
            }
            HttpResponse response = null;
            try {
                LogHelper.d(TAG, "starting download");
                response = http.execute(httpGet);
                LogHelper.d(TAG, "downloaded");
            } catch (ClientProtocolException e) {
                LogHelper.e(TAG, "Error downloading", e);
                LogHelper.printStackTrace(e);
            } catch (IOException e) {
                LogHelper.e(TAG, "Error downloading", e);
                LogHelper.printStackTrace(e);
            }
            return response;
        }

        protected void sendError(String status, String msg) throws InterruptedException, IOException {
            sendResponse(status, MIME_PLAINTEXT, null, new ByteArrayInputStream(msg.getBytes()));
            throw new InterruptedException();
        }

        protected void sendResponse(String status, String mime, Properties header, InputStream data) throws IOException {
            sendResponse(status, mime, header, data, true);
        }

        protected void sendResponse(String status, String mime, Properties header, InputStream data, boolean closeOutput) throws Error {
            if (status == null) {
                if (data != null) {
                    try {
                        data.close();
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                }

                throw new Error("sendResponse(): Status can't be null.");
            }

            OutputStream out = null;
            try {
                LogHelper.d(TAG, ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> socket is closed: " + mySocket.isClosed());
                out = mySocket.getOutputStream();
                PrintWriter pw = new PrintWriter(out);
                pw.print("HTTP/1.1 " + status + "\n");

                if (mime != null) {
                    pw.print("Content-Type: " + mime + "\n");
                }

                if (header == null || header.getProperty(KEY_HEADER_DATE) == null) {
                    pw.print("Date: " + gmtFrmt.format(new Date()) + "\n");
                }

                if (header != null) {
                    Enumeration e = header.keys();
                    while (e.hasMoreElements()) {
                        String key = (String) e.nextElement();
                        String value = header.getProperty(key);
                        pw.print(key + ": " + value + "\n");
                    }
                }

                pw.print("\n");
                pw.flush();

                if (data == null) {
                    return;
                }

                if (data instanceof DecryptFileInputStream) {
                    if (version > 0) {
                        DecryptFileInputStream decryptFileInputStream = (DecryptFileInputStream) data;
                        long skipByteCountOrig = decryptFileInputStream.getSkipByteCountOrig();

                        long skipByteCountTemp = skipByteCountOrig;
                        if (skipByteCountOrig % FILE_ENCRYPT_LENGTH > 0) {
                            skipByteCountTemp = skipByteCountOrig - (skipByteCountOrig % FILE_ENCRYPT_LENGTH);
                        }
                        decryptFileInputStream.doSkip(skipByteCountTemp);

                        int skipByteCountDiff = (int) (skipByteCountOrig - skipByteCountTemp);

                        int totalSendToClient = 0;
                        int pending = data.available();    // This is to support partial sends, see serveFile()

                        byte[] buffTemp = new byte[1024 * FILE_ENCRYPT_LENGTH * 5]; //保证是16的倍数，如果is是加密流，加密要求为16倍数
                        byte[] buff = new byte[1024 * FILE_ENCRYPT_LENGTH * 5]; //保证是16的倍数，如果is是加密流，加密要求为16倍数
                        while (!quit) {
                            int read = data.read(buff, 0, buff.length);
                            if (read <= 0 || read < skipByteCountDiff) {
                                break;
                            }

                            int ret = CryptoKadaLib.getInstance().decrypt(version, securityKey, buff, read, buffTemp, read);

                            if (totalSendToClient + (read - skipByteCountDiff) < pending) {
                                out.write(buffTemp, skipByteCountDiff, read - skipByteCountDiff);
                                out.flush();
                                totalSendToClient += (read - skipByteCountDiff);
                            } else {
                                out.write(buffTemp, skipByteCountDiff, pending - totalSendToClient);
                                out.flush();
                                break;
                            }
                            skipByteCountDiff = 0; //just use in first time

                            try {
                                Thread.sleep(5);
                            } catch (InterruptedException e) {
                                LogHelper.printStackTrace(e);
                            }
                        }
                    } else {
                        DecryptFileInputStream decryptFileInputStream = (DecryptFileInputStream) data;
                        decryptFileInputStream.doSkip(decryptFileInputStream.getSkipByteCountOrig());
                        int pending = data.available();    // This is to support partial sends, see serveFile()
                        byte[] buff = new byte[1024 * 16 * 5];
                        while (pending > 0 && !quit) {
                            int read = data.read(buff, 0, ((pending > 1024 * 16 * 5) ? 1024 * 16 * 5 : pending));
                            if (read <= 0) {
                                break;
                            }

                            CryptoKadaLib.getInstance().decrypt(itemId, buff, read);
                            out.write(buff, 0, read);
                            out.flush();
                            pending -= read;

                            try {
                                Thread.sleep(5);
                            } catch (InterruptedException e) {
                                LogHelper.printStackTrace(e);
                            }
                        }
                    }
                } else {
                    int pending = data.available();    // This is to support partial sends, see serveFile()
                    byte[] buff = new byte[1024 * 16 * 5];
                    while (pending > 0 && !quit) {
                        int read = data.read(buff, 0, ((pending > 1024 * 16 * 5) ? 1024 * 16 * 5 : pending));
                        if (read <= 0) {
                            break;
                        }

                        out.write(buff, 0, read);
                        out.flush();
                        pending -= read;
                        try {
                            Thread.sleep(5);
                        } catch (InterruptedException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                }
            } catch (Throwable e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("sendResponse() exception : "+e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            } finally {
                if (closeOutput) {
                    try {
                        out.close();
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                }

                if (data != null) {
                    try {
                        data.close();
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                }
            }
        }

        protected void decodeHeader(BufferedReader in, Properties pre, Properties parms, Properties header) throws InterruptedException, IOException {
            try {
                // Read the request line
                String inLine = in.readLine();
                if (inLine == null) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("readLine == null in decodeHeader()"),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    return;
                }

                StringTokenizer st = new StringTokenizer(inLine);
                if (!st.hasMoreTokens()) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("BAD REQUEST: Syntax error ; null tokens in Tokenizer."),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    sendError(HTTP_BADREQUEST, "BAD REQUEST: Syntax error. Usage: GET /example/file.html");
                }

                String method = st.nextToken();
                pre.put("method", method);

                if (!st.hasMoreTokens()) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("BAD REQUEST: Syntax error ; hasMoreTokens() == false"),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    sendError(HTTP_BADREQUEST, "BAD REQUEST: Missing URI. Usage: GET /example/file.html");
                }

                String uri = st.nextToken();

                // Decode parameters from the URI
                int qmi = uri.indexOf('?');
                if (qmi >= 0) {
                    decodeParms(uri.substring(qmi + 1), parms);
                    uri = decodePercent(uri.substring(0, qmi));
                } else {
                    uri = decodePercent(uri);
                }

                // If there's another token, it's protocol version,
                // followed by HTTP headers. Ignore version but parse headers.
                // NOTE: this now forces header names lowercase since they are
                // case insensitive and vary by client.
                if (st.hasMoreTokens()) {
                    String line = in.readLine();
                    while (line != null && line.trim().length() > 0) {
                        int p = line.indexOf(':');
                        if (p >= 0) {
                            header.put(line.substring(0, p).trim().toLowerCase(), line.substring(p + 1).trim());
                        }

                        line = in.readLine();
                    }
                }

                pre.put("uri", uri);
            } catch (IOException ioe) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("SERVER INTERNAL ERROR: IOException: " + ioe.getMessage()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                sendError(HTTP_INTERNALERROR, "SERVER INTERNAL ERROR: IOException: " + ioe.getMessage());
                LogHelper.printStackTrace(ioe);
            }
        }

        /**
         * Decodes the percent encoding scheme. <br/>
         * For example: "an+example%20string" -> "an example string"
         */
        private String decodePercent(String str) throws InterruptedException, IOException {
            try {
                StringBuffer sb = new StringBuffer();
                for (int i = 0; i < str.length(); i++) {
                    char c = str.charAt(i);
                    switch (c) {
                        case '+':
                            sb.append(' ');
                            break;
                        case '%':
                            sb.append((char) Integer.parseInt(str.substring(i + 1, i + 3), 16));
                            i += 2;
                            break;
                        default:
                            sb.append(c);
                            break;
                    }
                }
                return sb.toString();
            } catch (Exception e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("BAD REQUEST: Bad percent-encoding:"+e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                sendError(HTTP_BADREQUEST, "BAD REQUEST: Bad percent-encoding.");
                LogHelper.printStackTrace(e);
                return null;
            }
        }

        /**
         * Decodes parameters in percent-encoded URI-format
         * ( e.g. "name=Jack%20Daniels&pass=Single%20Malt" ) and
         * adds them to given Properties. NOTE: this doesn't support multiple
         * identical keys due to the simplicity of Properties -- if you need multiples,
         * you might want to replace the Properties with a Hashtable of Vectors or such.
         */
        private void decodeParms(String parms, Properties p)
                throws InterruptedException, IOException {
            if (parms == null) {
                return;
            }

            StringTokenizer st = new StringTokenizer(parms, "&");
            while (st.hasMoreTokens()) {
                String e = st.nextToken();
                int sep = e.indexOf('=');
                if (sep >= 0) {
                    p.put(decodePercent(e.substring(0, sep)).trim(), decodePercent(e.substring(sep + 1)));
                }
            }
        }
    }

    private class IcyLineParser extends BasicLineParser {
        private static final String ICY_PROTOCOL_NAME = "ICY";

        private IcyLineParser() {
            super();
        }

        @Override
        public boolean hasProtocolVersion(CharArrayBuffer buffer, ParserCursor cursor) {
            boolean superFound = super.hasProtocolVersion(buffer, cursor);
            if (superFound) {
                return true;
            }

            int index = cursor.getPos();

            final int protolength = ICY_PROTOCOL_NAME.length();

            if (buffer.length() < protolength) {
                return false; // not long enough for "HTTP/1.1"
            }

            if (index < 0) {
                // end of line, no tolerance for trailing whitespace
                // this works only for single-digit major and minor version
                index = buffer.length() - protolength;
            } else if (index == 0) {
                // beginning of line, tolerate leading whitespace
                while ((index < buffer.length()) && HTTP.isWhitespace(buffer.charAt(index))) {
                    index++;
                }
            } // else within line, don't tolerate whitespace

            if (index + protolength > buffer.length()) {
                return false;
            }

            return buffer.substring(index, index + protolength).equals(ICY_PROTOCOL_NAME);
        }

        @Override
        public Header parseHeader(CharArrayBuffer buffer) throws ParseException {
            return super.parseHeader(buffer);
        }

        @Override
        public ProtocolVersion parseProtocolVersion(CharArrayBuffer buffer,
                                                    ParserCursor cursor) throws ParseException {

            if (buffer == null) {
                throw new IllegalArgumentException("Char array buffer may not be null");
            }

            if (cursor == null) {
                throw new IllegalArgumentException("Parser cursor may not be null");
            }

            final int protolength = ICY_PROTOCOL_NAME.length();

            int indexFrom = cursor.getPos();
            int indexTo = cursor.getUpperBound();

            skipWhitespace(buffer, cursor);

            int i = cursor.getPos();

            // long enough for "HTTP/1.1"?
            if (i + protolength + 4 > indexTo) {
                throw new ParseException("Not a valid protocol version: " + buffer.substring(indexFrom, indexTo));
            }

            // check the protocol name and slash
            if (!buffer.substring(i, i + protolength).equals(ICY_PROTOCOL_NAME)) {
                return super.parseProtocolVersion(buffer, cursor);
            }

            cursor.updatePos(i + protolength);

            return createProtocolVersion(1, 0);
        }

        @Override
        public RequestLine parseRequestLine(CharArrayBuffer buffer, ParserCursor cursor) throws ParseException {
            return super.parseRequestLine(buffer, cursor);
        }

        @Override
        public StatusLine parseStatusLine(CharArrayBuffer buffer, ParserCursor cursor) throws ParseException {
            StatusLine superLine = super.parseStatusLine(buffer, cursor);
            return superLine;
        }
    }

    class MyClientConnection extends DefaultClientConnection {
//        @Override
//        protected HttpMessageParser<HttpResponse> createResponseParser(SessionInputBuffer buffer,
//                                                                       HttpResponseFactory responseFactory,
//                                                                       HttpParams params) {
//            return super.createResponseParser(buffer, responseFactory, params);
//        }

        //        @Override
//        protected HttpMessageParser createResponseParser(
//                final SessionInputBuffer buffer,
//                final HttpResponseFactory responseFactory, final HttpParams params) {
//            return new DefaultResponseParser(buffer, new IcyLineParser(),
//                    responseFactory, params);
//        }
    }

    class MyClientConnectionOperator extends DefaultClientConnectionOperator {
        public MyClientConnectionOperator(final SchemeRegistry sr) {
            super(sr);
        }

        @Override
        public OperatedClientConnection createConnection() {
            return new MyClientConnection();
        }
    }

    class MyClientConnManager extends SingleClientConnManager {
        private MyClientConnManager(HttpParams params, SchemeRegistry schreg) {
            super(params, schreg);
        }

        @Override
        protected ClientConnectionOperator createConnectionOperator(final SchemeRegistry sr) {
            return new MyClientConnectionOperator(sr);
        }
    }

    /**
     * HTTP response.
     * Return one of these from serve().
     */
    public class Response {
        /**
         * Default constructor: response = HTTP_OK, data = mime = 'null'
         */
        public Response() {
            this.status = HTTP_OK;
        }

        /**
         * Basic constructor.
         */
        public Response(String status, String mimeType, InputStream data) {
            this.status = status;
            this.mimeType = mimeType;
            this.data = data;
        }

        /**
         * Convenience method that makes an InputStream out of given text.
         */
        public Response(String status, String mimeType, String txt) {
            this.status = status;
            this.mimeType = mimeType;
            try {
                this.data = new ByteArrayInputStream(txt.getBytes("UTF-8"));
            } catch (java.io.UnsupportedEncodingException uee) {
                LogHelper.printStackTrace(uee);
            }
        }

        /**
         * Adds given line to the header.
         */
        public void addHeader(String name, String value) {
            header.put(name, value);
        }

        /**
         * HTTP status code after processing, e.g. "200 OK", HTTP_OK
         */
        public String status;

        /**
         * MIME type of content, e.g. "text/html"
         */
        public String mimeType;

        /**
         * Data of the response, may be null.
         */
        public InputStream data;

        /**
         * Headers for the HTTP response. Use addHeader() to add lines.
         */
        public Properties header = new Properties();
    }

    class DecryptFileInputStream extends FileInputStream {
        final int itemId;
        final int version;
        final String SST;
        final int dataRealLen;

        long skipByteCountOrig = 0;
        boolean isFirstRead = true;

        public DecryptFileInputStream(File file, long dataRealLen, int itemId, int version, String SST) throws FileNotFoundException {
            super(file);
            this.itemId = itemId;
            this.version = version;
            this.SST = SST;
            this.dataRealLen = (int) dataRealLen;
        }

        @Override
        public long skip(long byteCount) throws IOException {
            skipByteCountOrig = byteCount;
            return byteCount;
        }

        public void doSkip(long byteCount) {
            try {
                long at = byteCount;
                int safeToken = 100;//确保会退出循环，不会卡死在这里
                while (at > 0 && --safeToken > 0) {
                    long amt = super.skip(at);
                    if (amt == -1) {
//                                    throw new RuntimeException(file + ": unexpected EOF");
//                        UserHabitService.getInstance().trackHabit2Umeng(
//                                UserHabitService.newUserHabit(packageString("字节跳过时出错"),
//                                        UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                        LogHelper.d(TAG, "skip not right");
                    }
                    at -= amt;
                }
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("close socket in closeSession err ："+e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));

                LogHelper.printStackTrace(e);
            }
        }

        @Override
        public int available() throws IOException {
            return dataRealLen;
        }

        public long getSkipByteCountOrig() {
            return skipByteCountOrig;
        }

        @Override
        public int read(byte[] buffer, int byteOffset, int byteCount) throws IOException {

            int bytesRead = super.read(buffer, byteOffset, byteCount);
//            CryptoKadaLib.getInstance().decrypt(this.itemId,buffer,bytesRead);

//            byte offset = (byte) (this.itemId % 100);
//            if (offset == 0)
//                offset = 1;
//
//            byte c;
//            for (int i = 0; i < bytesRead; i++) {
//                c = buffer[i];
//                if (c == 0) {
//
//                } else if (c == -offset) {
//                    c = offset;
//                } else {
//                    c = (byte) (c + offset);
//                }
//                buffer[i] = c;
//            }

            return bytesRead;
        }
    }

//    public static String packageString(String content){
//        StringBuilder sb = new StringBuilder();
//        sb.append(content)
//                .append("uid:").append(UserService.getInstance().getUserLoginName())
//                .append("device sys:").append(Build.VERSION.RELEASE)
//                .append("device model:").append(Build.MODEL);
//        return sb.toString();
//    }
}
