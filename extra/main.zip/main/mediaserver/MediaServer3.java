package com.hhdd.kada.main.mediaserver;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.Log;

import com.hhdd.core.service.BookService;
import com.hhdd.cryptokada.CryptoKadaLib;
import com.hhdd.kada.BuildConfig;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.main.utils.DebugUtils;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.Md5Util;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.logger.LogHelper;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.SingleClientConnManager;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.UnsupportedEncodingException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.TreeSet;
import java.util.concurrent.TimeUnit;

/**
 * Created by simon on 13/11/15.
 * <p>
 * Restructured by Xiaoyu on 2018/6/29.
 * <p>
 * 注：
 * 1. 一个空的RandomAccessFile文件，打开后seek到x位置，写入一个字节，那么length()为x+1，即文件长度为x+1。
 * 2. 音频文件的加密方式：从文件头部开始，每16个字节进行一次AES加密。
 * 3. 本版本只处理version==1的情况，其它情况不处理
 * 所以，如果从下标（x != 16的整数倍）开始截取16个字节传进JNI解密，就会出错。
 * <p>
 * <p>
 * 重构报告：
 * 一、可观测的：
 * 1、老版本不论用户拖动到第几页（或听书的时候直接拖动到后面），总是会从头开始、线性缓存，导致用户可能要等待很久才开始播放。新版本会及时响应用户的拖动操作，比如直接拖动到第18页，则立即开始取18页及以后的数据。这不止解决了等待过长的问题，还可能解决了：拖动到后面，太久没数据，播放器认为超时（或出错），直接跳过了本段音频进行下一段。
 * 2、老版本在整个流程的任何环节出错，都会退出并提示出错。新版本细化并分离了各个环节，比如磁盘不可访问时（不能读写缓存）、或缓存写入的某个环节出错时，依然不影响网络加载播放（而不是出错退出）。
 * 3、新版本缓存完整时会校验MD5，并将MD5以文件的形式保存在本地，以保证缓存的可用性。（以解决线上的问题：“清缓存之后就正常了”问题）
 * 4、老版本：当本地已有部分缓存时（比如已缓存2分钟），用户拖动在2分钟内的时候，不会发起网络请求去缓存其它部分。
 * 新版本：当本地缓存不完整时不会进行使用，会走网络。
 * 5、播放时如果本地已有缓存文件，会校验MD5（离线校验、通过本地保存的MD5文件）。当本地MD5文件不存在时，会认为校验通过（以兼容老版本没有缓存文件的情况）
 * 二、不容易观测的、代码上的优化：
 * 1、 代码结构调整。老版本不易读、不宜调整。新版本方法抽取、各个模块分离。
 * 2、 MediaPlayer偶尔会用当前建立链接的socket的inputStream发送新的Http请求头，所以新版本的每次播放都比老版本多了一个线程。
 * 3、 老版本没有处理完善系统的skip()操作。该API不一定会skip到期望值，可能需要多次skip操作（可能导致拖动播放的位置不准确）。而且老版本没有处理skip()死循环的情况（理论上分析会有用户卡在播放那里，一直没有声音）。
 * 4、 通过代码分析老版本的一些逻辑会导致：出错时不会主动关闭本地Socket连接。新版本有做及时关闭的逻辑，以保证MediaPlayer会主动重连。
 *
 * 其它：
 *  本地没有MD5文件、网络也不可访问（或者网络可以访问但是无法获取Content-MD5），会尝试信任本地缓存文件，如果这时候缓存文件出错，上层MeidaPlayer会爆出一个通用错误-217xxxxx。
 *  A可以导致B，但是B不一定全由A导致 ----> 所以无法通过MediaPlayer出错的错误码来判断缓存文件是否出错。
 *  但是这种情况可以通过以下3种方法排除：
 *      1. 有网络、能获取content-md5，就能纠错。
 *      2. 如果没有content-md5字段，会打点上报，然后让后台加上即可。下次再播放，就能获取Content-MD5来纠错。
 *      3. 无网络、本地也没有md5文件时，不能纠错。所以，要尽量保证本地有md5文件。这就需要下载模块要尽快做MD5校验并保存下来MD5
 */
public class MediaServer3 {

    public static String TAG = "MediaServer3";

//    public static final String UMENG_TAG_AUDIODECRYPTPLAY = "AudioDecryptPlay";

    private static final String KEY_ENCRYPT = "encrypt";
    private static final String KEY_ENCRYPT_TYPE = "encryptTppe";
    private static final String KEY_VERSION = "version";
    private static final String KEY_COLLECT_ID = "collectId";
    private static final String KEY_AESST = "AESST";
    private static final String KEY_TARGET_FILE_PATH = "targetFilePath";
    private static final String KEY_TARGET_DIR = "targetDir";

    private static final String KEY_HEADER_RANGE = "range";
    private static final String KEY_HEADER_DATE = "Date";

    private static final String KEY_HTTP_HEADER_CONTENT_LENGTH = "Content-Length";
    private static final String KEY_HTTP_HEADER_CONTENT_RANGE = "Content-Range";
    private static final String KEY_HTTP_HEADER_ACCEPT_RANGES = "Accept-Ranges";
    private static final String KEY_HTTP_HEADER_CONNECTION = "Connection";
    private static final int FILE_ENCRYPT_LENGTH = 16;

    private static String ROOT_PATH = "media";

    private static MediaServer3 mediaServer;

    public static MediaServer3 getInstance() {
        if (mediaServer == null) {
            synchronized (MediaServer3.class) {
                if (mediaServer == null) {
                    mediaServer = new MediaServer3();
                }
            }
        }
        return mediaServer;
    }

    public static MediaServer3 getMediaServer() {
        return mediaServer;
    }

    private int myTcpPort = 0;
    private ServerSocket myServerSocket;
    private Thread myThread;
    private final Map<String, List<CacheHelper>> multiThreadCacheHelpers = new HashMap<>();

    /*package*/ MediaServer3() {
        StringBuilder errContent = null;
        try {
            myServerSocket = new ServerSocket(myTcpPort);
        } catch (IOException e) {
            errContent = new StringBuilder();
            errContent.append("failed to create serverSocket : auto").append(e.toString());
            LogHelper.printStackTrace(e);

            myTcpPort = 16823;
            int count = 5;
            while (count > 0) {
                count--;
                try {
                    myServerSocket = new ServerSocket(myTcpPort);
                    break;
                } catch (IOException e2) {
                    errContent.append("failed to create serverSocket:").append(myTcpPort).append(e2.toString());
                    LogHelper.e(TAG, "创建ServerSocket失败：" + e.toString());
                    LogHelper.printStackTrace(e2);
                }
                myTcpPort += 2;
            }
        }

        if (myServerSocket != null) {
            myTcpPort = myServerSocket.getLocalPort();
            myThread = new Thread(new Runnable() {

                @Override
                public void run() {
                    try {
                        //noinspection InfiniteLoopStatement
                        while (true) {
                            Socket client = myServerSocket.accept();
                            if (client == null) {
                                continue;
                            }
                            handleAccept(client);
                        }
                    } catch (IOException ioe) {
//                        UserHabitService.getInstance().trackHabit2Umeng(
//                                UserHabitService.newUserHabit(packageString("ServerSocket分发出错：" + ioe.toString()),
//                                        UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                        LogHelper.e(TAG, "Error Server", ioe);
                        LogHelper.printStackTrace(ioe);
                    }
                }
            });

            myThread.start();
        } else {
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(packageString("创建ServerSocket失败!:" + errContent.toString()),
//                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
//            LogHelper.e(TAG, "创建ServerSocket失败!");
        }
    }

    protected int getLocalPort() {
        return myTcpPort;
    }

    public void stop() {
        try {
            if (myServerSocket != null) {
                myServerSocket.close();
            }
            if (myThread != null) {
                myThread.join();
            }
        } catch (Throwable t) {
            LogHelper.e(TAG, "Error stop", t);
            LogHelper.printStackTrace(t);
        }
    }

    public static String getRootPath() {
        String root = Dirs.getCachePath(KaDaApplication.getInstance());
        if (!TextUtils.isEmpty(root)) {
            return FileUtils.makeDirIfNoExist(root + File.separator + MediaServer3.ROOT_PATH);
        }
        return "";
    }

    public static boolean cachedFileExist(String origUrl, int itemId, int version) {
        String fileName = cachedFileName(origUrl, itemId, version);
        String storeFilePath = BookService.getBookCachePath(itemId) + File.separator + fileName;
        return FileUtils.fileExist(storeFilePath);
    }

    public static String cachedFileNameForBookQuestionSound(String origUrl, int itemId) {
        int version = 0; //对于问题声音不加密强制为零
        return Md5Util.getStringMD5("/" + itemId + "/" + origUrl) + "_" + version + ".mp3";
    }

    public static String cachedFileName(String origUrl, int itemId, int version) {
        if (version == 0) {
            version = 1; //从v2.1开始默认为1
        }

        return Md5Util.getStringMD5("/" + itemId + "/" + origUrl) + "_" + version + ".mp3";
    }

    //type=1：绘本、2：故事
    public static String prepareBook(String origUrl, int itemId, int version, String mediaTargetDir, String AESST) {
        if (version == 0) {
            version = 1; //从v2.1开始默认为1
        }

        return prepare(origUrl, itemId, true, CryptoKadaLib.SourceType_Book, version, 0, mediaTargetDir, AESST);
    }

    public static String prepareStory(String origUrl, int itemId, int version, int collectId, String mediaTargetDir, String AESST) {
        if (version == 0) {
            version = 1; //从v2.1开始默认为1
        }

        return prepare(origUrl, itemId, true, CryptoKadaLib.SourceType_Story, version, collectId, mediaTargetDir, AESST);
    }

    //used for DebugActivity
    public static String prepareDebug(String oriUrl) {
        return "http://127.0.0.1" +
                ":" +
                MediaServer3.getInstance().getLocalPort() +
                "?url=" + oriUrl +
                "&debug=1" +
                "&itemId=1" +
                "&encrypt=1" +
                "&version=1" +
                "&collectId=1";
    }

    public static String prepare(String origUrl, int itemId, boolean encrypt, int type, int version, int collectId, String mediaTargetDir, String AESST) {
        StringBuilder encodedParams = new StringBuilder();
        encodedParams.append("http://127.0.0.1");
        encodedParams.append(":");
        encodedParams.append(MediaServer3.getInstance().getLocalPort());
        try {
            String paramOrigUrl = URLEncoder.encode(origUrl, "UTF-8");
            encodedParams.append("?url=").append(paramOrigUrl);
            encodedParams.append("&itemId=").append(itemId);
            if (encrypt) {
                encodedParams.append("&encrypt=1");
            } else {
                encodedParams.append("&encrypt=0");
            }
            encodedParams.append("&targetDir=").append(URLEncoder.encode(mediaTargetDir, "UTF-8"));
            encodedParams.append("&encryptTppe=").append(type);
            encodedParams.append("&version=").append(version);
            encodedParams.append("&AESST=").append(URLEncoder.encode(AESST, "UTF-8"));
            encodedParams.append("&collectId=").append(collectId);
        } catch (UnsupportedEncodingException e) {
            LogHelper.printStackTrace(e);
        }
        return encodedParams.toString();
    }

    public static String prepare(String origUrl, String mediaTargetFilePath) {
        StringBuilder encodedParams = new StringBuilder();
        encodedParams.append("http://127.0.0.1");
        encodedParams.append(":");
        encodedParams.append(MediaServer3.getInstance().getLocalPort());
        try {
            String paramOrigUrl = URLEncoder.encode(origUrl, "UTF-8");
            encodedParams.append("?url=").append(paramOrigUrl);
            encodedParams.append("&encrypt=0");
            encodedParams.append("&targetFilePath=").append(URLEncoder.encode(mediaTargetFilePath, "UTF-8"));
        } catch (UnsupportedEncodingException e) {
            LogHelper.printStackTrace(e);
        }
        return encodedParams.toString();
    }

    private void handleAccept(Socket s) {
        Thread t = new HTTPSession(s);
        t.setDaemon(true);
        t.start();
    }

    private final List<HTTPSession> sessions = new ArrayList<>();

    public void removeSession(String url) {
        if (url != null) {
            synchronized (sessions) {
                List<HTTPSession> sessionsRemoved = new ArrayList<>();
                for (HTTPSession session : sessions) {
                    if (TextUtils.equals(session.getMyUrl(), url)) {
                        session.closeSession();
                        sessionsRemoved.add(session);
                    }
                }
                for (HTTPSession session : sessionsRemoved) {
                    sessions.remove(session);
                }
            }
        }
    }

    private void addSession(HTTPSession session) {
        synchronized (sessions) {
            for (HTTPSession sessionTmp : sessions) {
                sessionTmp.closeSession();
            }
            sessions.clear();
            if (!sessions.contains(session)) {
                sessions.add(session);
            }
        }
    }

    private void removeSession(HTTPSession session) {
        synchronized (sessions) {
            if (sessions.contains(session)) {
                sessions.remove(session);
            }
        }
    }


    @Nullable
    @SuppressWarnings("WeakerAccess")
    public String getSavedMD5(String audioFilePath) {
        return FileUtils.readStringFromFile(audioFilePath + ".md5");
    }

    /**
     * @param audioFilePath 缓存文件的路径
     */
    @SuppressWarnings("WeakerAccess")
    public void saveMD5ToFile(String oriMD5, String audioFilePath) {
        FileUtils.saveStringToFile(oriMD5, audioFilePath + ".md5");
    }

    private static final String
            HTTP_OK = "200 OK",
            HTTP_PARTIALCONTENT = "206 Partial Content",
            HTTP_RANGE_NOT_SATISFIABLE = "416 Requested Range Not Satisfiable",
            HTTP_FORBIDDEN = "403 Forbidden",
            HTTP_BADREQUEST = "400 Bad Request",
            HTTP_INTERNALERROR = "500 Internal Server Error";
    //            HTTP_NOTFOUND = "404 Not Found",
    //            HTTP_REDIRECT = "301 Moved Permanently",
//            HTTP_NOTIMPLEMENTED = "501 Not Implemented",


    private static final String
            MIME_PLAINTEXT = "text/plain";
//            MIME_HTML = "text/html",
//            MIME_DEFAULT_BINARY = "application/octet-stream",
//            MIME_XML = "text/xml",


    private static java.text.SimpleDateFormat gmtFrmt;

    static {
        gmtFrmt = new java.text.SimpleDateFormat("E, d MMM yyyy HH:mm:ss 'GMT'", Locale.US);
        gmtFrmt.setTimeZone(TimeZone.getTimeZone("GMT"));
    }

    protected class HTTPSession extends Thread {

        private Socket mySocket;
        int itemId;
        volatile boolean quit = false;
        String myUrl;
        boolean isEncrypt = true;
        int encryptTppe = 0;
        int collectId = 0;
        int version = 1;

        String cancelFlag = "";
        String securityKey = "";

        HttpGet httpGetRemote = null;
        private byte[] cmdBuff;
        private int cmdBuffLen;
        private final int bufSize = 8192;
        private boolean haveNewCmd = false;
        private long startFrom;
        private DefaultHttpClient httpClient;
        //注释掉，因为：每次MediaPlayer发起新的http请求时，会有新的HttpSession进行相应。
//        private int MD5CheckedThrough = 0;//对比md5比较耗时，用以节约时间。0:尚未检查过； 1：通过； -1：不通过
        private CacheHelper cacheHelper;

        private String getMyUrl() {
            return myUrl;
        }

        public HTTPSession(Socket s) {
            mySocket = s;
            //Apache's default header limit is 8KB.
            cmdBuff = new byte[bufSize];
        }

        private void closeSession() {
            quit = true;

            try {
                if (httpGetRemote != null) {
                    httpGetRemote.abort();
                    httpGetRemote = null;
                }
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            if (mySocket != null) {
                try {
                    LogHelper.d(TAG, "session closed");
                    mySocket.close();
                } catch (IOException e) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("close socket in closeSession err ：" + e.toString()),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    LogHelper.printStackTrace(e);
                }
            }
            interrupt();
        }

        @Override
        public void run() {
            try {
                LogHelper.d(TAG, "client connected,session started");

                final InputStream socketInputStream = mySocket.getInputStream();
                if (socketInputStream == null) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("mySocket.getInputStream() == null, : localPort:" + mySocket.getLocalPort() + ",port:" + mySocket.getPort()),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    return;
                }

                int rlen = socketInputStream.read(cmdBuff, 0, bufSize);
                if (rlen <= 0) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("failed to read head"),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    return;
                }
                haveNewCmd = true;
                cmdBuffLen = rlen;

                parseCommandAndStart();

            } catch (SocketTimeoutException e) {
                // Do nothing
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("Socket timeout : " + e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "Error timeout", e);
                LogHelper.printStackTrace(e);
            } catch (IOException e) {
                if (!e.toString().contains("closed")) {//socket closed 不上报，seek操作一般都会触发。
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("error connect to client: " + e.toString()),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    LogHelper.e(TAG, "Error IO :" + e.toString());
                    LogHelper.printStackTrace(e);
                }
            } catch (Throwable e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("unexpected exception occurs :" + Log.getStackTraceString(e)),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "MediaServe Error", e);
                LogHelper.printStackTrace(e);
            } finally {
                try {
                    if (httpGetRemote != null) {
                        httpGetRemote.abort();
                        httpGetRemote = null;
                    }
                } catch (Throwable e) {
                    LogHelper.printStackTrace(e);
                }

                try {
                    if (mySocket != null) {
                        mySocket.close();
                    }
                } catch (Throwable t) {
                    LogHelper.printStackTrace(t);
                }

//                doNotifyAll();
                removeSession(this);
            }
        }

        private void parseCommandAndStart() throws IOException {
            if (!haveNewCmd) {
                return;
            }

            haveNewCmd = false;

            Properties pre = new Properties();
            Properties params = new Properties();
            Properties header = new Properties();

            BufferedReader bufferedReader = null;
            try {
                // Create a BufferedReader for parsing the header.
                ByteArrayInputStream hbis = new ByteArrayInputStream(cmdBuff, 0, cmdBuffLen);
                bufferedReader = new BufferedReader(new InputStreamReader(hbis));

                // Decode the header into params and header java properties
                decodeHeader(bufferedReader, pre, params, header); // 里面做了decode，下面在使用的时候就不能在URLDecode了。
            } catch (Throwable e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("failed to create input stream or reader:" + e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            } finally {
                try {
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                } catch (Throwable e) {
                    LogHelper.printStackTrace(e);
                }
            }

            /*
             * Created by Xiaoyu on 2018/6/26 下午3:26
             */
            if (BuildConfig.DEBUG && params.keySet().contains("debug")) {
                String debug = params.getProperty("debug");
                if (!TextUtils.isEmpty(debug) && debug.contains("1")) {
                    //命中Debug模式还原出音频文件
                    String filePath = params.getProperty("url");
                    securityKey = DebugUtils.getAESSForDebug(filePath);
                    decodeFromFileForDebug(filePath);
                    return;
                }
            }

            if (params.get("itemId") != null) {
                itemId = Integer.valueOf(params.get("itemId").toString());
            }

            String realUri = params.getProperty("url");
            if (realUri == null || realUri.length() == 0) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("can't get realUri"),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                return;
            }

            if (params.get(KEY_ENCRYPT) != null && Integer.valueOf(params.get(KEY_ENCRYPT).toString()) == 0) {
                isEncrypt = false;
            }

            if (params.get(KEY_ENCRYPT_TYPE) != null) {
                encryptTppe = Integer.valueOf(params.get(KEY_ENCRYPT_TYPE).toString());
            }

            //SoundPlayback.java 会传version=0进来。
//            if (params.get(KEY_VERSION) != null) {
//                int ver = Integer.valueOf(params.get(KEY_VERSION).toString());
//                if (ver != 1) {
//                    LogHelper.e(TAG, "加密的version != 1，just return : "+ver);
//                    return;
//                }
//            }

            if (params.get(KEY_COLLECT_ID) != null) {
                collectId = Integer.valueOf(params.get(KEY_COLLECT_ID).toString());
            }

            String AESST = params.getProperty(KEY_AESST);
            myUrl = realUri;
            addSession(this);

            if (isEncrypt) {
                if (AESST != null && AESST.length() > 0) {
                    securityKey = AESST;
                }

                if (securityKey == null || securityKey.length() == 0) {
                    cancelFlag = "MediaServer-AESST-" + System.currentTimeMillis();
                    securityKey = CryptoKadaLib.getInstance().getAESST(itemId, encryptTppe, version, collectId, cancelFlag);

                    if (securityKey == null || securityKey.length() == 0) {
                        quit = true;
//                        UserHabitService.getInstance().trackHabit2Umeng(
//                                UserHabitService.newUserHabit(packageString("exit for none of securityKey,itemId = "+itemId+",encryptTppe="+encryptTppe),
//                                        UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                        LogHelper.e(TAG,"exit for none of securityKey");
                    }
                }
            }

            if (quit) {
                return;
            }

            cancelFlag = null;

            String mime = "audio/mpeg";
            String fileName = cachedFileName(realUri, itemId, version);
            String mediaTargetDir;

            String targetFilePath = params.getProperty(KEY_TARGET_FILE_PATH);
            if (targetFilePath != null) {
                fileName = targetFilePath.substring(targetFilePath.lastIndexOf("/") + 1);
                mediaTargetDir = targetFilePath.substring(0, targetFilePath.lastIndexOf("/"));
            } else {
                mediaTargetDir = params.getProperty(KEY_TARGET_DIR);
            }

            String storeFilePath = getRootPath() + File.separator + fileName;

            if (mediaTargetDir != null && mediaTargetDir.length() > 0) {
                //创建文件夹
                FileUtils.makeDirIfNoExist(mediaTargetDir);
                storeFilePath = mediaTargetDir + File.separator + fileName;
            }

            //监听MediaPlayer传来的操作
            listenCmdFromMediaPlayer(mySocket);

            LogHelper.d(TAG, "realUri = " + realUri);

            File storeFile;
            //避免上个线程正在copyTo，这里就开始检查MD5了。
            synchronized (multiThreadCacheHelpers) {
                storeFile = new File(storeFilePath);
            }

            boolean playFromLocal;
            HttpResponse realResponse = null;
            if (storeFile.exists() && storeFile.isFile()) {
                //校验md5完整性
                String oriMD5 = getSavedMD5(storeFilePath);
                if (TextUtils.isEmpty(oriMD5)) {
                    LogHelper.e(TAG, "没有成功获取本地MD5，尝试从OSS获取");
                    //联网获取MD5
                    realResponse = requestServer(realUri, header);
                    if (realResponse == null) {
                        closeHttpConnection(httpClient);
                    }
                    oriMD5 = getOriMD5(realResponse);
                    if(!TextUtils.isEmpty(oriMD5)){
                        //从OSS获取到了md5，本地存一份，方便下次使用
                        saveMD5ToFile(oriMD5,storeFilePath);
                        LogHelper.d(TAG, "联网得到了MD5，已存储在本地");
                    }
                }
                if (TextUtils.isEmpty(oriMD5)) {
                    LogHelper.e(TAG, "本地和远端都没有获取MD5，尝试信任缓存文件");
                    playFromLocal = true;
                } else {
                    String localMD5 = Md5Util.getMD5EncryptedByBase64(storeFilePath);
                    if (TextUtils.equals(localMD5, oriMD5)) {
                        playFromLocal = true;
                        LogHelper.d(TAG, "本地缓存MD5检查通过");
                    } else {
                        LogHelper.d(TAG, "本地缓存MD5检查不通过，已删掉缓存文件");
                        LogHelper.d(TAG, "remote MD5= " + oriMD5);
                        LogHelper.d(TAG, "local  MD5= " + localMD5);
                        //删掉本地缓存的文件
                        //noinspection ResultOfMethodCallIgnored
                        storeFile.delete();
                        playFromLocal = false;
                    }
                }
            }else{
                playFromLocal = false;
            }

            if (playFromLocal) {
                //决定从本地播放。有可能发生过联网从OSS获取MD5，有的话就关闭一下。
                if (realResponse != null) {
                    closeHttpConnection(httpClient);
                }
                sendResponseFormLocalFile(header, mime, storeFile);
            } else {
                if(realResponse == null){
                    //上面的代码逻辑如果没有请求到远端，这里算作一次重试
                    realResponse = requestServer(realUri, header);
                    if (realResponse == null) {
                        closeHttpConnection(httpClient);
                    }
                }
                if (realResponse != null) {
                    sendResponseFromNetwork(realResponse, storeFilePath, fileName, mime);
                } else {
                    LogHelper.e(TAG, "本地缓存不可用，网络也不可访问");
                    try {
                        sendError(HTTP_INTERNALERROR, "Network is not reachable");
                    } catch (InterruptedException ignored) {
                    }
                }
            }
        }

        private String getOriMD5(HttpResponse realResponse) {
            String md5 = null;
            if (realResponse != null) {
                Header[] allHeaders = realResponse.getAllHeaders();
                for (Header h : allHeaders) {
                    if (h.getName().equalsIgnoreCase("Content-MD5")) {
                        md5 = h.getValue();
                    }
                }
                if(TextUtils.isEmpty(md5)){
                    //上报统计
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("音频文件的Content-MD5为空,这种情况下可能无法处理本地缓存文件出错的情况。real url = "+myUrl+".itemId="+itemId+",collectId="+collectId),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                }
            }
            return md5;
        }

        private HttpResponse requestServer(String realUri, Properties header) {
            startFrom = 0;
            if (!NetworkUtils.isReachable()) {
                LogHelper.d(TAG, "网络不可访问");
                return null;
            }

            String range = header.getProperty(KEY_HEADER_RANGE);
            if (range != null) {
                if (range.startsWith("bytes=")) {
                    range = range.substring("bytes=".length());
                    int minus = range.indexOf('-');
                    try {
                        if (minus > 0) {
                            String start = range.substring(0, minus);

                            if (!StringUtil.isEmpty(start)) {
                                startFrom = Long.parseLong(start);
                            }
                        }
                    } catch (NumberFormatException nfe) {
//                        UserHabitService.getInstance().trackHabit2Umeng(
//                                UserHabitService.newUserHabit(packageString("failed to calculate bytes offset(2) : " + nfe.toString()),
//                                        UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                        LogHelper.printStackTrace(nfe);
                    }
                }
            }

            //见文件顶部详解
            if (startFrom > 0) {
                startFrom = startFrom - (startFrom % FILE_ENCRYPT_LENGTH);
            }

            httpGetRemote = null;
            HttpResponse realResponse = null;
            URI originalURI = URI.create(realUri);
            SchemeRegistry registry = new SchemeRegistry();
            if (originalURI.getPort() != -1) {
                registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), originalURI.getPort()));
            } else {
                registry.register(new Scheme("http", PlainSocketFactory.getSocketFactory(), 80));
            }
            SingleClientConnManager mgr = new SingleClientConnManager(null, registry);
            BasicHttpParams httpParams = new BasicHttpParams();
            HttpConnectionParams.setConnectionTimeout(httpParams, 20 * 1000);
            HttpConnectionParams.setSoTimeout(httpParams, 20 * 1000);
            httpClient = new DefaultHttpClient(mgr, httpParams);
            httpGetRemote = new HttpGet(realUri);
            httpGetRemote.addHeader(KEY_HTTP_HEADER_CONNECTION, "Keep-Alive");
            String userAgent = header.getProperty("user-agent");
            httpGetRemote.addHeader("user-agent", userAgent);
            if (startFrom > 0) {
                httpGetRemote.addHeader("range", "bytes=" + startFrom + "-");
            }

            try {
                LogHelper.d(TAG, "real server socket connecting..");
                realResponse = httpClient.execute(httpGetRemote);
                LogHelper.d(TAG, "real server socket connected");
            } catch (ClientProtocolException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("httpClient.execute() failed(2): " + e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "Error get response from real server", e);
                LogHelper.printStackTrace(e);
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("httpClient.execute() failed(2): " + e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "Error get response from real server", e);
                LogHelper.printStackTrace(e);
            } catch (Exception e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("httpClient.execute() failed(2): " + e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "Error get response from real server", e);
                LogHelper.printStackTrace(e);
            }
            return realResponse;
        }

        //大部分情况下，MediaPlayer会发起新的http请求，而不是用当前的socket进行再次交互。但是测试时偶尔出现这种情况。
        private void listenCmdFromMediaPlayer(final Socket mySocke) {
            new Thread() {
                @Override
                public void run() {
                    int rlen;
                    LogHelper.d(TAG, "start listening command from media player..");
                    try {
                        //不用循环读取，因为：读取到新的range指令之后，会重新走run()里面的code，里面会开心的监听
                        if ((rlen = mySocke.getInputStream().read(cmdBuff, 0, bufSize)) > 0) {
                            haveNewCmd = true;
                            cmdBuffLen = rlen;
                            LogHelper.d(TAG, "=====----> receive command from media player, reparse.");
                        }

                    } catch (Throwable ignored) {
//                        ignored.printStackTrace();
                    } finally {
                        LogHelper.d(TAG, "command listener stop ");
                    }
                }
            }.start();
        }

        private void closeHttpConnection(DefaultHttpClient httpClient) {
            try {
                if (httpClient != null) {
                    httpClient.getConnectionManager().closeIdleConnections(0, TimeUnit.SECONDS);
                }
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        }

        // 从网络下载、并缓存
        private void sendResponseFromNetwork(@NonNull HttpResponse realResponse, String storeFilePath, String fileName, String mime) throws IOException {

            try {
                InputStream data = realResponse.getEntity().getContent();

                LogHelper.d(TAG, "load from network. startFrom=" + startFrom);

                long realFileLength = 0;

                //处理header
                Properties newHeader = new Properties();
                for (Header h : realResponse.getAllHeaders()) {
                    //替换协议，来自老版本
                    if (TextUtils.equals(h.getName().toLowerCase(), "content-type")) {
                        newHeader.put(h.getName().toLowerCase(), "audio/mpeg");
                    } else {
                        newHeader.put(h.getName().toLowerCase(), h.getValue());
                    }
                    //找到原始文件长度
                    if (startFrom == 0) {
                        if (TextUtils.equals(h.getName().toLowerCase(), "content-length")) {
                            try {
                                realFileLength = Long.parseLong(h.getValue());
                            } catch (Throwable ignored) {
                            }
                        }
                    } else {
                        if (TextUtils.equals(h.getName().toLowerCase(), "content-range")) {
                            //Content-Range: bytes 19223584-24240111/24240112
                            String rangeValue = h.getValue();
                            int lengthStringStart;
                            if (!TextUtils.isEmpty(rangeValue) && (lengthStringStart = rangeValue.indexOf("/")) != -1) {
                                try {
                                    String lengthString = rangeValue.substring(lengthStringStart + 1);
                                    realFileLength = Long.parseLong(lengthString);
                                } catch (Throwable ignored) {
                                }
                            }
                        }
                    }
                }

                if (startFrom > 0) {
                    sendResponse(HTTP_PARTIALCONTENT, mime, newHeader, null, false);
                } else {
                    sendResponse(HTTP_OK, mime, newHeader, null, false);
                }

                LogHelper.d(TAG, "load from network. headers send，start writing to client");

                //初始化缓存
                if (realFileLength > 0) {
                    cacheHelper = new CacheHelper(storeFilePath, fileName, realFileLength, startFrom, securityKey, getOriMD5(realResponse));
                } else {
                    LogHelper.e(TAG, "OSS没有返回文件长度，或总文件长度 <= 0, 不启用缓存本地");
                }

                if (isEncrypt) {
                    writeOutDataWithDecrypt(data, true, 0);
                } else {
                    int readBytes;
                    byte[] buff = new byte[1024 * 50];
                    while ((readBytes = data.read(buff, 0, buff.length)) > 0 && !quit) {

                        //写入缓存
                        if (cacheHelper != null) {
                            cacheHelper.writeCache(buff, 0, readBytes);
                        }

                        if (quit) {
                            break;
                        }

                        mySocket.getOutputStream().write(buff, 0, readBytes);
                        mySocket.getOutputStream().flush();

                        try {
                            Thread.sleep(2);
                        } catch (InterruptedException e) {
                            LogHelper.printStackTrace(e);
                        }
                    }
                }
            } catch (IOException e) {
                //出现异常就关掉与MediaPlayer的链接，MediaPlayer会重连。不关掉可能会有：
                // seekTo到一个位置，这里发生了异常，但是MediaPlayer以为是正常的，会认为seekTo成功，从而出现seek不准确
                LogHelper.e(TAG, "send resp from network err : " + e.toString() + ", now close socket which connected to MediaPlayer");
                mySocket.close();
                throw e;
            } finally {
                closeHttpConnection(httpClient);

                //判断是否缓存完成
                if (cacheHelper != null) {
                    cacheHelper.saveCacheIfComplete();
                }

                LogHelper.d(TAG, "load from network and writing to media player done");
            }

        }

        private void sendResponseFormLocalFile(Properties header, String mime, final File storeFile) {
            long fileLen = storeFile.length();
            LogHelper.d(TAG, "load from local file,length="+fileLen);
            Response response;
            startFrom = 0;
            long endAt = -1;
            try {
                String range = header.getProperty(KEY_HEADER_RANGE);
                if (range != null) {
                    if (range.startsWith("bytes=")) {
                        range = range.substring("bytes=".length());
                        int minus = range.indexOf('-');
                        try {
                            if (minus > 0) {
                                String start = range.substring(0, minus);
                                String end = range.substring(minus + 1);

                                if (!StringUtil.isEmpty(start)) {
                                    startFrom = Long.parseLong(start);
                                }
                                if (!StringUtil.isEmpty(end)) {
                                    endAt = Long.parseLong(end);
                                }
                            }
                        } catch (NumberFormatException nfe) {
//                            UserHabitService.getInstance().trackHabit2Umeng(
//                                    UserHabitService.newUserHabit(packageString("failed to calculate bytes offset(1) : " + nfe.toString()),
//                                            UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                            LogHelper.printStackTrace(nfe);
                        }
                    }
                }

                //见文件顶部详解
                if (startFrom > 0) {
                    startFrom = startFrom - (startFrom % FILE_ENCRYPT_LENGTH);
                }

                // Change return code and add Content-Range header when skipping is requested

                if (startFrom >= fileLen) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("欲读取的字节超过了原始文件长度 "),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    response = new Response(HTTP_RANGE_NOT_SATISFIABLE, MIME_PLAINTEXT, "");
                    response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes 0-0/" + fileLen);
//                            response.addHeader( "Accept-Ranges", "bytes");
//                            response.addHeader( "Connection", "Keep-Alive");

                    LogHelper.e(TAG, "load form local file. Error with (startFrom>= fileLen)");
                } else if (startFrom > 0) {
                    if (endAt < 0) {
                        endAt = fileLen - 1;
                    }

                    long contentLength = endAt - startFrom + 1;
                    if (contentLength < 0) {
                        contentLength = 0;
                    }

                    FileInputStream fis = isEncrypt ? new DecryptFileInputStream(storeFile, contentLength) : new FileInputStream(storeFile);

                    long at = startFrom;
                    int safe = 20;//避免死循环
                    while (at > 0 && --safe > 0) {
                        long amt = fis.skip(at);
                        if (amt == -1) {
                            LogHelper.e(TAG, "skip not right");
                        }
                        at -= amt;
                    }

                    response = new Response(HTTP_PARTIALCONTENT, mime, fis);
                    response.addHeader(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + contentLength);
                    response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAt + "/" + fileLen);
                    response.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                    response.addHeader(KEY_HTTP_HEADER_CONNECTION, "Keep-Alive");

                    LogHelper.d(TAG, "load form local file. write partial. startFrom : " + startFrom + "，endAt : " + endAt);
                } else {

                    if (endAt < 0) {
                        endAt = fileLen - 1;
                    }

                    if (fileLen < 0) {
                        fileLen = 0;
                    }

                    response = new Response(HTTP_OK, mime, isEncrypt ? new DecryptFileInputStream(storeFile, fileLen) : new FileInputStream(storeFile));

                    response.addHeader(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + fileLen);
                    response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAt + "/" + fileLen);
                    response.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                    response.addHeader(KEY_HTTP_HEADER_CONNECTION, "Keep-Alive");

                    LogHelper.d(TAG, "load from local file. write whole file");
                }
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("failed to operate local audio file : " + e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG, "load form local file。 ERROR with : " + e.toString());
                LogHelper.printStackTrace(e);
                // 重新创建 response
                response = new Response(HTTP_FORBIDDEN, MIME_PLAINTEXT, "FORBIDDEN: Reading file failed.");
            }
            //send
            sendResponse(response.status, response.mimeType, response.header, response.data);
        }

        private void decodeFromFileForDebug(String storeFilePath) {
            File storeFile = new File(storeFilePath);
            String mime = "audio/mpeg";

            if (storeFile.isFile() && storeFile.exists()) {

                LogHelper.d(TAG, "debug还原音频文件");

                Response response;
                try {
                    // Support (simple) skipping:
//                    long startFrom = 0;

                    // Change return code and add Content-Range header when skipping is requested
                    long fileLen = storeFile.length();
                    if (isEncrypt) {
                        fileLen = storeFile.length();
                    }

                    response = new Response(HTTP_OK, mime, isEncrypt ? new DecryptFileInputStream(storeFile, fileLen) : new FileInputStream(storeFile));
                    response.addHeader(KEY_HTTP_HEADER_CONTENT_LENGTH, "" + fileLen);
                    //从0开始的请求，HTTP约定：返回HTTP_ok，此时“Content_Range”字段多余。“Content_Length”会指示文件长度
                    //从非0开始的请求，HTTP约定：返回HTTP_Partial，此时“Content-Length”指示当前Range的长度，必须带有“Content-Range”字段。文件长度在该字段的最后。
//                    response.addHeader(KEY_HTTP_HEADER_CONTENT_RANGE, "bytes " + startFrom + "-" + endAt + "/" + fileLen);
                    response.addHeader(KEY_HTTP_HEADER_ACCEPT_RANGES, "bytes");
                    response.addHeader(KEY_HTTP_HEADER_CONNECTION, "Keep-Alive");
                } catch (IOException e) {
                    LogHelper.d(TAG, "debug还原文件失败！：" + e.toString());
                    LogHelper.printStackTrace(e);
                    // 重新创建 response
                    response = new Response(HTTP_FORBIDDEN, MIME_PLAINTEXT, "FORBIDDEN: Reading file failed.");
                }

                sendResponse(response.status, response.mimeType, response.header, response.data);
                if (HTTP_OK.equals(response.status)) {
                    LogHelper.d(TAG, "debug还原文件完成");
                }
            }
        }

        void sendError(String status, String msg) throws InterruptedException {
            sendResponse(status, MIME_PLAINTEXT, null, new ByteArrayInputStream(msg.getBytes()));
            throw new InterruptedException();
        }

        void sendResponse(String status, String mime, Properties header, InputStream data) {
            sendResponse(status, mime, header, data, true);
        }

        void sendResponse(@NonNull String status, String mime, Properties header, InputStream data, boolean closeOutput) {
            OutputStream out;
            try {
                out = mySocket.getOutputStream();
            } catch (IOException e) {
                LogHelper.e(TAG, "can't get outputStream to write header and data");
                return;
            }
            writeOutHeaders(status, mime, header, out);
            if (data != null) {
                writeOutData(data, closeOutput, out);
            }
        }

        private void writeOutData(InputStream data, boolean closeOutput, OutputStream out) {
            try {
                //老版本遗留的代码逻辑：只有把本地文件输出给MediaPlayer时，才会走到这里。
                if (data instanceof DecryptFileInputStream) {
                    writeOutDataWithDecrypt(data, false, 5);
                } else {
                    writeOutDataWithoutDecrypt(data, out);
                }
            } catch (Throwable e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("sendResponse() exception : " + e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.e(TAG,"sendResponse() exception : " + e.toString());
                LogHelper.printStackTrace(e);
            } finally {
                if (closeOutput) {
                    try {
                        out.close();
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                }
                if (data != null) {
                    try {
                        data.close();
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                }
            }
            LogHelper.d(TAG, "output data write done.");
        }

        private void writeOutDataWithoutDecrypt(InputStream data, OutputStream out) throws IOException {
            int pending = data.available();    // This is to support partial sends, see serveFile()
            byte[] buff = new byte[1024 * 16 * 5];
            while (pending > 0 && !quit) {
                int read = data.read(buff, 0, ((pending > 1024 * 16 * 5) ? 1024 * 16 * 5 : pending));
                if (read <= 0) {
                    break;
                }
                out.write(buff, 0, read);
                out.flush();
                pending -= read;

                try {
                    Thread.sleep(5);
                } catch (InterruptedException e) {
                    LogHelper.printStackTrace(e);
                }
            }
        }


        private void writeOutDataWithDecrypt(InputStream data, boolean needCache, int sleepEachWhile) throws IOException {
            int byteOffsetTemp = 0;
            int readBytesTemp;
            int readBytes;
            // Start streaming content.
            byte[] buffTemp = new byte[1024 * 16 * 4]; //保证是16的倍数
            byte[] buff = new byte[1024 * 16 * 4];

            while ((readBytesTemp = data.read(buffTemp, byteOffsetTemp, buffTemp.length - byteOffsetTemp)) > 0 && !quit) {

                //刚经过一个阻塞方法，检查是否有了新的Range指令
                if (haveNewCmd) {
                    LogHelper.d(TAG, "MediaPlayer有新的Range指令");
                    parseCommandAndStart();
                    return;
                }

                //确保为16的整数倍
                readBytesTemp = readBytesTemp + byteOffsetTemp;

                if (readBytesTemp < 16) {
                    byteOffsetTemp = byteOffsetTemp + readBytesTemp;
                    continue;
                }

                if (readBytesTemp % FILE_ENCRYPT_LENGTH > 0) {
                    readBytes = readBytesTemp - (readBytesTemp % FILE_ENCRYPT_LENGTH);
                } else {
                    readBytes = readBytesTemp;
                }

                if (readBytesTemp > readBytes) {
                    byteOffsetTemp = readBytesTemp - readBytes;
                } else {
                    byteOffsetTemp = 0;
                }

                //写入缓存
                if (needCache && cacheHelper != null) {
                    cacheHelper.writeCache(buffTemp, 0, readBytes);
                }

                int ret = CryptoKadaLib.getInstance().decrypt(version, securityKey, buffTemp, readBytes, buff, readBytes);
                if (ret < 0) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("decrypt failed with ret = " + ret),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    try {
                        sendError(HTTP_INTERNALERROR, "decrypt failed with ret = " + ret);
                    } catch (InterruptedException ignored) {
                    }
                    return;
                }

                if (mySocket != null && !quit) {
                    try {
                        // 有可能写出过程中socket被远端关闭（比如一个长长的seekTo()操作），所以try catch
                        OutputStream outputStream = mySocket.getOutputStream();
                        outputStream.write(buff, 0, readBytes);
                        outputStream.flush();
                        //刚经过一个阻塞方法，检查是否有了新的Range指令
                        if (haveNewCmd) {
                            LogHelper.d(TAG, "MediaPlayer有新的Range指令");
                            parseCommandAndStart();
                            return;
                        }
                    } catch (Throwable e) {
                        LogHelper.e(TAG,"write to media player error :"+e.toString());
                        LogHelper.printStackTrace(e);
                        closeHttpConnection(httpClient);
                        return;
                    }
                }

                if (byteOffsetTemp > 0) {
                    System.arraycopy(buffTemp, readBytes, buffTemp, 0, byteOffsetTemp);
                }
                if (sleepEachWhile > 0) {
                    try {
                        Thread.sleep(sleepEachWhile);
                    } catch (InterruptedException ignored) {
                    }
                }
            }
        }

        private void writeOutHeaders(@Nullable String status, String mime, Properties header, OutputStream out) {
            PrintWriter pw = new PrintWriter(out);
            pw.print("HTTP/1.1 " + status + "\n");

            if (mime != null) {
                pw.print("Content-Type: " + mime + "\n");
            }
            if (header == null || header.getProperty(KEY_HEADER_DATE) == null) {
                pw.print("Date: " + gmtFrmt.format(new Date()) + "\n");
            }
            if (header != null) {
                Enumeration e = header.keys();
                while (e.hasMoreElements()) {
                    String key = (String) e.nextElement();
                    String value = header.getProperty(key);
                    pw.print(key + ": " + value + "\n");
                }
            }
            pw.print("\n");
            pw.flush();
        }

        private void decodeHeader(BufferedReader in, Properties pre, Properties parms, Properties header) throws InterruptedException {
            try {
                // Read the request line
                String inLine = in.readLine();
                if (inLine == null) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("readLine == null in decodeHeader()"),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    return;
                }

                StringTokenizer st = new StringTokenizer(inLine);
                if (!st.hasMoreTokens()) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("BAD REQUEST: Syntax error ; null tokens in Tokenizer."),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    sendError(HTTP_BADREQUEST, "BAD REQUEST: Syntax error. Usage: GET /example/file.html");
                }

                String method = st.nextToken();
                pre.put("method", method);

                if (!st.hasMoreTokens()) {
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("BAD REQUEST: Syntax error ; hasMoreTokens() == false"),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    sendError(HTTP_BADREQUEST, "BAD REQUEST: Missing URI. Usage: GET /example/file.html");
                }

                String uri = st.nextToken();

                // Decode parameters from the URI
                int qmi = uri.indexOf('?');
                if (qmi >= 0) {
                    decodeParams(uri.substring(qmi + 1), parms);
                    uri = decodePercent(uri.substring(0, qmi));
                } else {
                    uri = decodePercent(uri);
                }

                // If there's another token, it's protocol version,
                // followed by HTTP headers. Ignore version but parse headers.
                // NOTE: this now forces header names lowercase since they are
                // case insensitive and vary by client.
                if (st.hasMoreTokens()) {
                    String line = in.readLine();
                    while (line != null && line.trim().length() > 0) {
                        int p = line.indexOf(':');
                        if (p >= 0) {
                            header.put(line.substring(0, p).trim().toLowerCase(), line.substring(p + 1).trim());
                        }

                        line = in.readLine();
                    }
                }

                pre.put("uri", uri);
            } catch (IOException ioe) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("SERVER INTERNAL ERROR: IOException: " + ioe.getMessage()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                sendError(HTTP_INTERNALERROR, "SERVER INTERNAL ERROR: IOException: " + ioe.getMessage());
                LogHelper.e(TAG,"SERVER INTERNAL ERROR: IOException: " + ioe.getMessage());
                LogHelper.printStackTrace(ioe);
            }
        }

        /**
         * Decodes the percent encoding scheme. <br/>
         * For example: "an+example%20string" -> "an example string"
         */
        private String decodePercent(String str) throws InterruptedException {
            try {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < str.length(); i++) {
                    char c = str.charAt(i);
                    switch (c) {
                        case '+':
                            sb.append(' ');
                            break;
                        case '%':
                            sb.append((char) Integer.parseInt(str.substring(i + 1, i + 3), 16));
                            i += 2;
                            break;
                        default:
                            sb.append(c);
                            break;
                    }
                }
                return sb.toString();
            } catch (Exception e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(packageString("BAD REQUEST: Bad percent-encoding:" + e.toString()),
//                                UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                sendError(HTTP_BADREQUEST, "BAD REQUEST: Bad percent-encoding.");
                LogHelper.printStackTrace(e);
                return null;
            }
        }

        /**
         * Decodes parameters in percent-encoded URI-format
         * ( e.g. "name=Jack%20Daniels&pass=Single%20Malt" ) and
         * adds them to given Properties. NOTE: this doesn't support multiple
         * identical keys due to the simplicity of Properties -- if you need multiples,
         * you might want to replace the Properties with a Hashtable of Vectors or such.
         */
        private void decodeParams(String param, Properties p) throws InterruptedException {
            if (param == null) {
                return;
            }

            StringTokenizer st = new StringTokenizer(param, "&");
            while (st.hasMoreTokens()) {
                String e = st.nextToken();
                int sep = e.indexOf('=');
                if (sep >= 0) {
                    String s = decodePercent(e.substring(0, sep));
                    if (!TextUtils.isEmpty(s)) {
                        p.put(s.trim(), decodePercent(e.substring(sep + 1)));
                    }
                }
            }
        }
    }

    /**
     * HTTP response.
     * Return one of these from serve().
     */
    public class Response {
        /**
         * Default constructor: response = HTTP_OK, data = mime = 'null'
         */
        public Response() {
            this.status = HTTP_OK;
        }

        /**
         * Basic constructor.
         */
        public Response(String status, String mimeType, InputStream data) {
            this.status = status;
            this.mimeType = mimeType;
            this.data = data;
        }

        /**
         * Convenience method that makes an InputStream out of given text.
         */
        public Response(String status, String mimeType, String txt) {
            this.status = status;
            this.mimeType = mimeType;
            try {
                this.data = new ByteArrayInputStream(txt.getBytes("UTF-8"));
            } catch (java.io.UnsupportedEncodingException uee) {
                LogHelper.printStackTrace(uee);
            }
        }

        /**
         * Adds given line to the header.
         */
        public void addHeader(String name, String value) {
            header.put(name, value);
        }

        /**
         * HTTP status code after processing, e.g. "200 OK", HTTP_OK
         */
        public String status;

        /**
         * MIME type of content, e.g. "text/html"
         */
        public String mimeType;

        /**
         * Data of the response, may be null.
         */
        public InputStream data;

        /**
         * Headers for the HTTP response. Use addHeader() to add lines.
         */
        public Properties header = new Properties();
    }

    class DecryptFileInputStream extends FileInputStream {
        final int dataRealLen;

        public DecryptFileInputStream(File file, long dataRealLen) throws FileNotFoundException {
            super(file);
            this.dataRealLen = (int) dataRealLen;
        }

        @Override
        public int available() {
            return dataRealLen;
        }
    }

    /**
     * 数据结构：
     * 0-5234
     * 234-324562345
     * 345345-23456345
     * 2453-24545234535
     * <p>
     * 每一行的左边代表本次写入缓存时的开始位置，右边代表本次写入的结束位置。
     * （实际存文件时，会存储成一行字符串）
     * 存在从0到wholeFileLength的路径，就代表缓存完整了。
     */
    private final class CacheHelper {
        private TreeSet<CacheEntity> cacheEntities;
        private RandomAccessFile cacheFile;
        private File helperFile;
        private String destStoreFilePath;
        private final String cacheFilePath;
        private boolean validate;
        private long wholeLength;
        private long wroteBytes;
        private long startFrom;
        private String oriMD5;


        CacheHelper(String storeFile, String fileName, long wholeLength, long startFrom, String AESST, String oriMD5) {
            this.wholeLength = wholeLength;
            this.startFrom = startFrom;
            this.destStoreFilePath = storeFile;
            this.cacheFilePath = getRootPath() + File.separator + fileName + ".temp";
            this.cacheEntities = new TreeSet<>();
            this.wroteBytes = 0;
            this.oriMD5 = oriMD5;
            String cacheHelperFilePath = cacheFilePath + ".helper";
            LogHelper.d(TAG, "Cache init，whole file size : " + wholeLength);

            /*
             * Created by Xiaoyu on 2018/6/26 下午2:19
             * 调试模式下，存储每个下载的、和缓存的的音频的AESST，用于解密出原始文件。
             */
            if (BuildConfig.DEBUG) {
                DebugUtils.saveMp3AESSTForDebug(destStoreFilePath, cacheFilePath, AESST);
            }

            helperFile = new File(cacheHelperFilePath);
            validate = helperFile.exists();
            //初始化顶点
            if (validate) {
                String string = FileUtils.readStringFromFile(cacheHelperFilePath);
                if (TextUtils.isEmpty(string)) {
                    validate = false;
                }
                LogHelper.d(TAG, "helper file read :" + string);
                String[] positions = string.split("-");
                //必须是成对的
                if (positions.length % 2 != 0 || positions.length < 2) {
                    validate = false;
                }

                try {
                    for (int i = 0; i < positions.length - 1; i += 2) {
                        long start = Long.valueOf(positions[i]);
                        long end = Long.valueOf(positions[i + 1]);
                        if (start >= end) {
                            //文件异常
                            validate = false;
                            LogHelper.d(TAG, "helper文件异常，重新缓存");
                            break;
                        } else {
                            cacheEntities.add(new CacheEntity(start, end));
                        }
                    }
                } catch (NumberFormatException ignored) {
                    validate = false;
                }
            }

            File storeTemp = new File(cacheFilePath);
            if (!validate() || !storeTemp.exists()) {
                //noinspection ResultOfMethodCallIgnored
                storeTemp.delete();
                reCreate();
                LogHelper.d(TAG, "cache is invalidate, re-create a new cache file.(1)");
                validate = true;
            }

            //检查缓存文件的总长度是否大于了原始文件总长度
            cacheFile = openRandomAccessFile(cacheFilePath);
            if (cacheFile != null) {
                validate = true;
                try {
                    cacheFile.seek(startFrom);
                } catch (IOException e) {
                    validate = false;
                    LogHelper.d(TAG, "cannot seek cacheFile to :" + startFrom);
                }
                //处理多线程同时缓存的情况
                synchronized (multiThreadCacheHelpers) {
                    List<CacheHelper> cacheHelpers = multiThreadCacheHelpers.get(destStoreFilePath);
                    if (cacheHelpers == null) {
                        cacheHelpers = new LinkedList<>();
                    }
                    cacheHelpers.add(this);
                    multiThreadCacheHelpers.put(destStoreFilePath, cacheHelpers);
                }

            } else {
                validate = false;
            }
            LogHelper.d(TAG, "cache init done.");
        }

        @Nullable
        private RandomAccessFile openRandomAccessFile(String storeFileTemp) {
            RandomAccessFile cachedAccessFile = null;
            try {
                cachedAccessFile = new RandomAccessFile(storeFileTemp, "rw");
            } catch (FileNotFoundException e) {
                File tempFile = new File(storeFileTemp);
                if (tempFile.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    tempFile.delete();
//                    if (!delete) {
//                        //不可随机读写、也不可删除，就不需要做缓存了。
//                        UserHabitService.getInstance().trackHabit2Umeng(
//                                UserHabitService.newUserHabit(packageString("cannot random access,nor delete. Can't use cache. "),
//                                        UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
//                    }
                }
                try {
                    //noinspection ResultOfMethodCallIgnored
                    tempFile.createNewFile();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }
                try {
                    cachedAccessFile = new RandomAccessFile(storeFileTemp, "rw");
                } catch (FileNotFoundException e1) {
                    //不可随机读写、也不可删除，就不需要做缓存了。
//                    UserHabitService.getInstance().trackHabit2Umeng(
//                            UserHabitService.newUserHabit(packageString("cannot cache because can create RandomAccessFile"),
//                                    UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                    e1.printStackTrace();
                }

                e.printStackTrace();
            }
            return cachedAccessFile;
        }

        void reCreate() {
            cacheEntities.clear();
            //noinspection ResultOfMethodCallIgnored
            helperFile.delete();
        }

        void addEntity(long start, long end) {
            if (end > start) {
                if (end > wholeLength - 1) {
                    validate = false;
                    LogHelper.e(TAG, "写入的结束位置大于了文件总长度");
                }
                cacheEntities.add(new CacheEntity(start, end));
            }
        }

        void saveHelperToFile() {
            if (validate() && cacheEntities.size() > 0) {
                StringBuilder sb = new StringBuilder();
                for (CacheEntity e : cacheEntities) {
                    sb.append(e.start).append("-").append(e.end).append("-");
                }
                sb.deleteCharAt(sb.length() - 1);
                String savedString = sb.toString();
                FileUtils.saveStringToFile(savedString, helperFile);
                LogHelper.d(TAG, "helper file saved : " + savedString);
            } else {
                LogHelper.d(TAG, "can't save helper file because cache function is invalidate");
            }
        }

        //检查是否完整
        boolean complete() {
            if (!validate()) {
                return false;
            }

            boolean c = true;
            long pointer = 0;
            for (CacheEntity e : cacheEntities) {
                if (e.start > pointer + 1) {
                    c = false;
                    break;
                }
                if (e.end > pointer) {
                    pointer = e.end;
                    if (pointer == wholeLength - 1) {
                        c = true;
                        break;
                    }
                }
            }
            if (pointer != wholeLength - 1) {
                c = false;
            }
            return c;
        }

        //检查是否可用
        boolean validate() {
            return validate;
        }

        public void saveCacheIfComplete() {
            if (validate()) {
                long end = startFrom + wroteBytes - 1;
                addEntity(startFrom, end);
                //处理多线程同时缓存的情况
                synchronized (multiThreadCacheHelpers) {
                    List<CacheHelper> cacheHelpers = multiThreadCacheHelpers.get(destStoreFilePath);
                    if (cacheHelpers != null) {
                        cacheHelpers.remove(this);
                    }

                    try {
                        //关掉输出的缓存文件
                        cacheFile.close();
                    } catch (IOException e) {
                        LogHelper.e(TAG, "关闭缓存文件失败");
                    }

                    if (cacheHelpers == null || cacheHelpers.size() == 0) {
                        //最后一个处理线程，清理全局变量
                        multiThreadCacheHelpers.remove(destStoreFilePath);
                        //缓存完整，进行保存
                        if (complete()) {
                            //走到这里，说明文件已经完整的保存好了，接下来验证MD5
                            boolean realComplete;
                            if (!TextUtils.isEmpty(oriMD5)) {
                                String localMD5 = Md5Util.getMD5EncryptedByBase64(cacheFilePath);
                                //重命名为正式缓存文件
                                if (TextUtils.equals(oriMD5, localMD5)) {
                                    realComplete = true;
                                } else {
                                    //MD5校验不通过，删掉缓存
                                    realComplete = false;
                                    LogHelper.d(TAG, "缓存过程出错，MD5不通过！Content-MD5=" + oriMD5 + ",localMD5=" + localMD5);
                                }
                            } else {
                                LogHelper.d(TAG, "cache is complete, but have no Content-MD5 to certify");
                                //统计 =======> 已经在getOriMD5()方法中做过了。
                                //获取不到原始MD5，通过文件长度判断缓存是否完整
                                long length;
                                File temp = new File(cacheFilePath);
                                length = temp.length();
                                if (length != 0 && length == wholeLength) {
                                    realComplete = true;
                                    LogHelper.d(TAG, "文件长度检查正常，算作缓存完整。");
                                } else {
                                    realComplete = false;
                                    LogHelper.d(TAG, "缓存逻辑认为文件完整，但是实际文件长度异常，file length=" + length + ",whole length=" + wholeLength);
                                }
                            }
                            if (realComplete) {
                                if (FileUtils.copyTo(cacheFilePath, destStoreFilePath)) {
                                    //删掉缓存文件和helper文件
                                    //noinspection ResultOfMethodCallIgnored
                                    helperFile.delete();
                                    FileUtils.removeFile(cacheFilePath);
                                    saveMD5ToFile(oriMD5, destStoreFilePath);
                                    LogHelper.d(TAG, "cache is complete");
                                    validate = false;
                                } else {
                                    LogHelper.d(TAG, "cache is complete, but copyTo() failed");
                                    FileUtils.removeFile(destStoreFilePath);
                                }
                            } else {
                                reCreate();
                                FileUtils.removeFile(cacheFilePath);
                            }
                        } else {
                            LogHelper.d(TAG, (validate ? "cache is still not complete" : "cache function is not validate,so can't make cache complete"));
                            //本线程是当前唯一处理本缓存的线程时，才写入文件
                            saveHelperToFile();
                        }
                    } else {
                        //更新其它Helper的cacheEntities
                        LogHelper.d(TAG, "send cache entities to other httpSessions");
                        for (CacheHelper ch : cacheHelpers) {
                            ch.addAllEntity(cacheEntities);
                        }
                    }
                }
            } else {
                //
                LogHelper.e(TAG, "cache总结过程中：validate == false");
            }
        }

        private void addAllEntity(TreeSet<CacheEntity> cacheEntities) {
            this.cacheEntities.addAll(cacheEntities);
            LogHelper.d(TAG, "cache entities update by others");
        }

        public void writeCache(byte[] buff, int offset, int length) {
            if (validate()) {
                try {
                    cacheFile.write(buff, offset, length);
                    wroteBytes += length;
//                    LogHelper.d(TAG,"cache write : "+length+",total:"+wroteBytes);
                } catch (IOException e) {
                    LogHelper.e(TAG, "写入缓存失败：" + e.toString());
                    saveCacheIfComplete();
                    validate = false;//先把之前写的进行保存，然后再置为不可用

                }
            } else {
                LogHelper.e(TAG, "准备写入缓存时，validate==false");
            }
        }

        class CacheEntity implements Comparable<CacheEntity> {
            long start;
            long end;

            CacheEntity(long start, long end) {
                this.start = start;
                this.end = end;
            }

            @Override
            @SuppressWarnings("UseCompareMethod")
            public int compareTo(@NonNull CacheEntity o) {
                if (start == o.start) {
                    if (end < o.end) {
                        return -1;
                    } else if (end > o.end) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
                if (start < o.start) {
                    return -1;
                } else if (start > o.start) {
                    return 1;
                } else {
                    return 0;
                }
            }
        }

    }

//    public static String packageString(String content) {
//        return content +
//                "uid:" + UserService.getInstance().getUserLoginName() +
//                "device sys:" + Build.VERSION.RELEASE +
//                "device model:" + Build.MODEL;
//    }
}
