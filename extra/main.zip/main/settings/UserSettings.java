package com.hhdd.kada.main.settings;


import android.content.Context;
import android.content.SharedPreferences;

import com.hhdd.core.service.UserService;
import com.hhdd.kada.KaDaApplication;

/**
 * 与userId关联的设置，v3.7.0添加
 */
public class UserSettings {

    /**
     * 临时修改变量 v3.7.0增加 主要是为了初始化一下isBookFragmentShowTalentPlan字段
     * 仅需初始化一次，故增加此变量
     */
    private final String INITISBOOKFRAGMENTSHOWTALENTPLAN = "initIsBookFragmentShowTalentPlan";

    private String ISBOOKFRAGMENTSHOWTALENTPLAN = "isBookFragmentShowTalentPlan"; //用户设置是否在绘本首页展示优才计划模块

    private String BOOKSUBSCRIBEDCOLLECTIONIDS = "bookSubscribeCollectionIds";   //我的书架新订阅的绘本合辑id

    private String STORYSUBSCRIBEDCOLLECTIONIDS = "storySubscribeCollectionIds";   //我的书架新订阅的听书合辑id

    private SharedPreferences preferences;

    private static UserSettings sInstance;

    public UserSettings() {
        if (UserService.getInstance().getUserInfo() != null) {
            preferences = KaDaApplication.getInstance().getSharedPreferences("setting_" + UserService.getInstance().getUserInfo().getUserId(), Context.MODE_PRIVATE);
        }
    }

    public synchronized static UserSettings getInstance() {
        if (sInstance == null) {
            sInstance = new UserSettings();
        }
        return sInstance;
    }

    /**
     * 重置用户设置状态，当切换用户时需要重置
     */
    public void resetUserSetting() {
        if (sInstance != null) {
            sInstance = null;
        }
    }

    public boolean isInitIsBookFragmentShowTalentPlan() {
        return preferences != null && preferences.getBoolean(INITISBOOKFRAGMENTSHOWTALENTPLAN, false);
    }

    public void setInitIsBookFragmentShowTalentPlan(boolean initIsBookFragmentShowTalentPlan) {
        syncPreferences(INITISBOOKFRAGMENTSHOWTALENTPLAN, initIsBookFragmentShowTalentPlan);
    }

    public boolean isBookFragmentShowTalentPlan() {
        return preferences != null && preferences.getBoolean(ISBOOKFRAGMENTSHOWTALENTPLAN, false);
    }

    public void setBookFragmentShowTalentPlan(boolean bookFragmentShowTalentPlan) {
        syncPreferences(ISBOOKFRAGMENTSHOWTALENTPLAN, bookFragmentShowTalentPlan);
    }

    public String getBookSubscribedCollectionIds() {
        if (preferences == null) {
            return null;
        }
        return preferences.getString(BOOKSUBSCRIBEDCOLLECTIONIDS, "");
    }

    public void setBookSubscribedCollectionIds(String subscribedCollectionIds) {
        syncPreferences(BOOKSUBSCRIBEDCOLLECTIONIDS, subscribedCollectionIds);
    }

    public String getStorySubscribedCollectionIds() {
        if (preferences == null) {
            return null;
        }
        return preferences.getString(STORYSUBSCRIBEDCOLLECTIONIDS, "");
    }

    public void setStorySubscribedCollectionIds(String subscribedCollectionIds) {
        syncPreferences(STORYSUBSCRIBEDCOLLECTIONIDS, subscribedCollectionIds);
    }

    private void syncPreferences(String key, Object value) {
        if (preferences == null) {
            return;
        }
        if (value instanceof Boolean) {
            preferences.edit().putBoolean(key, (Boolean) value).apply();
        } else if (value instanceof String) {
            preferences.edit().putString(key, String.valueOf(value)).apply();
        } else if (value instanceof Integer) {
            preferences.edit().putInt(key, (Integer) value).apply();
        }
    }


    /**
     * 从长远来看，UserSettings业务字段会很多，为了避免一个字段改变就影响到所有字段的相关业务，这里需要注意的是：
     * 相同业务下的字段定义统一的通知事件，不同业务下，都定义各自的通知事件
     * 当整个UserSetting需要改变时，使用UserSettingsChangedEvent，其他情况下均使用各自定义的事件
     */
    public static class UserSettingsChangedEvent {

    }

    public static class TalentPlanShowPositionChangeEvent {}

    public static class SubscribedCollectionIdChangedEvent {

        public SubscribedCollectionIdChangedEvent(int type) {
            this.type = type;
        }

        public int type;   //  1 绘本合辑   2  听书合辑
    }

}
