package com.hhdd.kada.main.settings;

import com.google.gson.reflect.TypeToken;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.kada.Constants;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.PrefsManager;

import java.io.File;


/**
 * Created by simon on 28/6/15.
 * <p>
 * APP全局相关的设置属性，与用户无关，持久化于sharedPreference
 */
public class Settings {

    public static final String BOOK_AGE_TYPE = "bookAgeType";
    public static final String STORY_AGE_TYPE = "storyAgeType";

    private boolean isFirstSetting;
    private String birthday;
    private int usingDuration; //用户设置的使用时长，以分钟为单位
    private boolean isNoLimitUsing;

    private boolean isDownloadWhenNoWifi;
    private int runTimes;
    private int avatarChangeTimes;
    private boolean isShowSetting;//显示家长控制界面
    private String verName;

    private boolean isFlipByUser; //绘本阅读是否开启手动翻书模式
    private boolean isSoundEnable; //绘本阅读是否开启静音模式
    private boolean isTranslation; //绘本阅读英文绘本是否开启翻译
    private boolean isShowQuestion; //绘本阅读是否显示问答
    private int useTime = -1; //使用时长 分钟 v3.5.3默认改为无限制使用时长
    //    private int useTime = 30; //使用时长 秒
    private int restTime = 5 * 60; //休息时长 分钟
    //    private int restTime = 10; //休息时长 秒
    private int sleepTime = 23; //入睡时间
    private int wakeUpTime = 6; //起床时间

    /**
     * 临时修改变量 v3.5.3增加 主要是为了修改v3.5.3之前定时锁默认使用时长30分钟，需要更改默认值为无限制
     * 由于需要更改本地缓存数据，且仅更改一次，故增加此变量
     */
    private boolean temporaryModify = true;

    public String storyAgeType;
    public String bookAgeType;

    /**
     * 绘本是否支持自动播放
     * tapd需求：1001279 绘本自动连播值只存储在内存中，不做持久化存储；这里将isBookContinuePlay标记为static，在{@link #refreshToCache()}的时候 将不会被存储到文件
     */
    public static boolean isBookContinuePlay;

    public Settings() {
        isBookContinuePlay = false;

        isFirstSetting = true;
        isDownloadWhenNoWifi = true;
        birthday = "";
        isShowSetting = false;

        usingDuration = 90;
        isNoLimitUsing = true;
        verName = "";
        isFlipByUser = false;
        isSoundEnable = true;
        isTranslation = true;
        isShowQuestion = true;
        bookAgeType = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).getString(BOOK_AGE_TYPE);
        if (bookAgeType == null || bookAgeType.equals("")) {
            setBookAgeType("我的年龄");
        }
        storyAgeType = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER)).getString(STORY_AGE_TYPE);
        if (storyAgeType == null || storyAgeType.equals("")) {
            setStoryAgeType("我的年龄");
        }
    }

    private static PrefsManager getPrefsManager() {
        return ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
    }

    public int getUseTime() {
        return useTime;
    }

    public void setUseTime(int useTime) {
        this.useTime = useTime;
        getPrefsManager().putInt(Constants.KEY_USE_TIME, useTime);
    }

    public int getRestTime() {
        return restTime;
    }

    public void setRestTime(int restTime) {
        this.restTime = restTime;
        getPrefsManager().putInt(Constants.KEY_REST_TIME, restTime);
    }

    public int getSleepTime() {
        return sleepTime;
    }

    public void setSleepTime(int sleepTime) {
        this.sleepTime = sleepTime;
        getPrefsManager().putInt(Constants.KEY_SLEEP_TIME, sleepTime);
    }

    public int getWakeUpTime() {
        return wakeUpTime;
    }

    public void setWakeUpTime(int wakeUpTime) {
        this.wakeUpTime = wakeUpTime;
        getPrefsManager().putInt(Constants.KEY_WAKEUP_TIME, wakeUpTime);
    }

    public boolean isBookContinuePlay() {
        return isBookContinuePlay;
    }

    public void setBookContinuePlay(boolean bookContinuePlay) {
        isBookContinuePlay = bookContinuePlay;
    }

    public String getVerName() {
        return verName;
    }

    public void setVerName(String verName) {
        this.verName = verName;
        getPrefsManager().putString(Constants.KEY_VER_NAME, verName);
    }

    public void setUsingDuration(int usingDuration) {
        this.usingDuration = usingDuration;
        getPrefsManager().putInt(Constants.KEY_USING_DURATION, usingDuration);
    }

    public int getUsingDuration() {
        return usingDuration;
    }

    public boolean isNoLimitUsing() {
        return isNoLimitUsing;
    }

    public void setNoLimitUsing(boolean isNoLimitUsing) {
        this.isNoLimitUsing = isNoLimitUsing;
        getPrefsManager().putBoolean(Constants.KEY_IS_NO_LIMITING_USING, isNoLimitUsing);
    }

    public boolean isShowQuestion() {
        return isShowQuestion;
    }

    public void setShowQuestion(boolean showQuestion) {
        isShowQuestion = showQuestion;
        getPrefsManager().putBoolean(Constants.KEY_IS_SHOW_QUESTION, showQuestion);
    }

    public boolean isFlipByUser() {
        return isFlipByUser;
    }

    public void setFlipByUser(boolean flipByUser) {
        isFlipByUser = flipByUser;
        getPrefsManager().putBoolean(Constants.KEY_IS_FLIP_BY_USER, flipByUser);
    }

    public boolean isSoundEnable() {
        return isSoundEnable;
    }

    public void setSoundEnable(boolean soundEnable) {
        isSoundEnable = soundEnable;
        getPrefsManager().putBoolean(Constants.KEY_IS_SOUND_ENABLE, soundEnable);
    }

    public boolean isTranslation() {
        return isTranslation;
    }

    public void setTranslation(boolean translation) {
        isTranslation = translation;
        getPrefsManager().putBoolean(Constants.KEY_IS_TRANSLATION, translation);
    }

    public void setTemporaryModify(boolean temporaryModify) {
        this.temporaryModify = temporaryModify;
        getPrefsManager().putBoolean(Constants.KEY_TEMPORARY_MODIFY, temporaryModify);
    }

    private static Settings sInstance;

    public static synchronized Settings getInstance() {
        if (sInstance == null) {
            PrefsManager pm = getPrefsManager();
            //是否转移过数据
            boolean isTransfer = pm.getBoolean(Constants.KEY_TRANSFER, false);
            if (!isTransfer) {
                //如果未转移过数据，则从老的设置缓存文件中获取用户设置数据，存入sharePreference
                sInstance = FileUtils.loadFromFileT(settingsCacheFile(), new TypeToken<Settings>() {
                });
                if(sInstance == null) {
                    sInstance = new Settings();
                }
                transfer(pm);
            } else {
                //如果转移过数据，则从sharePreference中获取设置信息初始化
                sInstance = new Settings();
                init(pm);
            }

            //v3.5.3将默认时长为无限制，由于默认时长30分钟可能是用户手动设置的，故更改且仅一次将30分钟改成无限制
            if (sInstance.temporaryModify) {
                if (sInstance.useTime == 30 * 60) {
                    sInstance.setUseTime(-1);
                }
                sInstance.setTemporaryModify(false);
            }

            //v3.6.0需要将使用时长更改为30分钟，45分钟，60分钟，无限制，之前设置的15分钟要统一修改为30分钟
            if(sInstance.useTime == 15 * 60) {
                sInstance.setUseTime(30 * 60);
            }

            sInstance.setTranslation(true);
            sInstance.setFlipByUser(false);
            sInstance.setSoundEnable(true);//app重启后 播放控制重置
        }
        return sInstance;
    }

    /**
     * 数据转移，v3.6.0将settings数据从file中转移到sharePreference中
     * @param pm
     */
    private static void transfer(PrefsManager pm) {
        pm.putBoolean(Constants.KEY_TRANSFER, true);
        pm.putString(Constants.KEY_BOOK_AGE_TYPE, sInstance.bookAgeType);
        pm.putString(Constants.KEY_STORY_AGE_TYPE, sInstance.storyAgeType);
        pm.putInt(Constants.KEY_USING_DURATION, sInstance.usingDuration);
        pm.putBoolean(Constants.KEY_IS_NO_LIMITING_USING, sInstance.isNoLimitUsing);
        pm.putInt(Constants.KEY_RUN_TIMES, sInstance.runTimes);
        pm.putInt(Constants.KEY_AVATAR_CHANGE_TIMES, sInstance.avatarChangeTimes);
        pm.putBoolean(Constants.KEY_IS_FLIP_BY_USER, sInstance.isFlipByUser);
        pm.putBoolean(Constants.KEY_IS_SOUND_ENABLE, sInstance.isSoundEnable);
        pm.putBoolean(Constants.KEY_IS_TRANSLATION, sInstance.isTranslation);
        pm.putBoolean(Constants.KEY_IS_SHOW_QUESTION, sInstance.isShowQuestion);
        pm.putString(Constants.KEY_VER_NAME, sInstance.verName);
        pm.putInt(Constants.KEY_USE_TIME, sInstance.useTime);
        pm.putInt(Constants.KEY_REST_TIME, sInstance.restTime);
        pm.putInt(Constants.KEY_SLEEP_TIME, sInstance.sleepTime);
        pm.putInt(Constants.KEY_WAKEUP_TIME, sInstance.wakeUpTime);
        pm.putBoolean(Constants.KEY_TEMPORARY_MODIFY, sInstance.temporaryModify);
    }

    /**
     * 初始化数据
     * @param pm
     */
    private static void init(PrefsManager pm) {
        sInstance.bookAgeType = pm.getString(Constants.KEY_BOOK_AGE_TYPE);
        sInstance.storyAgeType = pm.getString(Constants.KEY_STORY_AGE_TYPE);
        sInstance.usingDuration = pm.getInt(Constants.KEY_USING_DURATION);
        sInstance.isNoLimitUsing = pm.getBoolean(Constants.KEY_IS_NO_LIMITING_USING);
        sInstance.runTimes = pm.getInt(Constants.KEY_RUN_TIMES);
        sInstance.avatarChangeTimes = pm.getInt(Constants.KEY_AVATAR_CHANGE_TIMES);
        sInstance.isFlipByUser = pm.getBoolean(Constants.KEY_IS_FLIP_BY_USER);
        sInstance.isSoundEnable = pm.getBoolean(Constants.KEY_IS_SOUND_ENABLE);
        sInstance.isTranslation = pm.getBoolean(Constants.KEY_IS_TRANSLATION);
        sInstance.isShowQuestion = pm.getBoolean(Constants.KEY_IS_SHOW_QUESTION);
        sInstance.verName = pm.getString(Constants.KEY_VER_NAME);
        sInstance.useTime = pm.getInt(Constants.KEY_USE_TIME);
        sInstance.restTime = pm.getInt(Constants.KEY_REST_TIME);
        sInstance.sleepTime = pm.getInt(Constants.KEY_SLEEP_TIME);
        sInstance.wakeUpTime = pm.getInt(Constants.KEY_WAKEUP_TIME);
        sInstance.temporaryModify = pm.getBoolean(Constants.KEY_TEMPORARY_MODIFY);
    }

    public void refreshToCache() {
//        FileUtils.saveToFileT(this, settingsCacheFile());
//        EventBus.getDefault().post(new Settings.SettingsChangedEvent());
    }

    private static String settingsCacheFile() {
        String filePath = Dirs.getUserCachePath();
        if (filePath.length() > 0) {
            return filePath + File.separator + "settings.dat";
        }
        return "";
    }

    public void addRunTimes() {
        runTimes += 1;
        getPrefsManager().putInt(Constants.KEY_RUN_TIMES, runTimes);
    }

    public static void addChangeAvatarTimes() {
        sInstance.avatarChangeTimes += 1;
        getPrefsManager().putInt(Constants.KEY_AVATAR_CHANGE_TIMES, sInstance.avatarChangeTimes);
    }

    public String getBookAgeType() {
        return bookAgeType;
    }

    public String getStoryAgeType() {
        return storyAgeType;
    }

    public void setStoryAgeType(String storyAgeType) {
        this.storyAgeType = storyAgeType;
        getPrefsManager().putString(Constants.KEY_STORY_AGE_TYPE, storyAgeType);
    }

    public void setBookAgeType(String bookAgeType) {
        this.bookAgeType = bookAgeType;
        getPrefsManager().putString(Constants.KEY_BOOK_AGE_TYPE, bookAgeType);
    }

}
