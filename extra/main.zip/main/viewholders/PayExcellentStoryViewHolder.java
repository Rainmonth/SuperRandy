package com.hhdd.kada.main.viewholders;

import android.view.View;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.PayExcellentStoryMoreItemView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

import static com.hhdd.kada.R.id.position;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.viewholders
 */
public class PayExcellentStoryViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.payExcellentStoryMoreItemView)
    PayExcellentStoryMoreItemView payExcellentStoryMoreItemView;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_pay_excellent_story;
    }

    @Override
    public void showData(final int position, BaseModelListVO itemData) {
        if (itemData != null && itemData.getItemList() != null && itemData.getItemList().size() > 0) {
            BaseModel model = itemData.getItemList().get(0);
            if (model instanceof StoryCollectionInfo) {
                final StoryCollectionInfo info = (StoryCollectionInfo) model;
                payExcellentStoryMoreItemView.update(info);
                payExcellentStoryMoreItemView.setTag(R.id.container, info);
                payExcellentStoryMoreItemView.setOnClickListener(listener);
            }
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            StoryCollectionInfo info = (StoryCollectionInfo) v.getTag(R.id.container);
            FragmentUtil.presentFragment(StoryCollectionFragment.class, info.getSourceId(), true);
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("2," + info.getSourceId(),
                    "recommended_purchase_content_click_" + position, TimeUtil.currentTime()));
        }
    };
}
