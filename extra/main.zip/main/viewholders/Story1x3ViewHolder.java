package com.hhdd.kada.main.viewholders;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import java.util.List;

/**
 * Created by lj on 17/4/26.
 */

public class Story1x3ViewHolder extends BaseViewHolder<BaseModelListVO> {

    int mItemWidth;
    int coverItemWidth;
    View view;
    ViewGroup container;

    public Story1x3ViewHolder() {

        int itemMarginLeft = LocalDisplay.dp2px(10);
        int itemMarginRight = LocalDisplay.dp2px(10);

        int itemSpacing = LocalDisplay.dp2px(5);
        int screenWidth = ScreenUtil.getScreenWidth();
        mItemWidth = (int) ((screenWidth - itemMarginLeft - itemMarginRight - 2 * itemSpacing) / 3.0f);
        coverItemWidth = mItemWidth;
    }


    @Override
    public View createView(final ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_story_1x3, parent, false);
        container = (ViewGroup) view.findViewById(R.id.container);

        container.getLayoutParams().height = mItemWidth + LocalDisplay.dp2px(55);
        container.getLayoutParams().width = ScreenUtil.getScreenWidth();
        for (int index = 0; index < container.getChildCount(); index++) {

            final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(index));
            final FrameLayout coverContainer = (FrameLayout) frameLayout.getChildAt(0);
//            final SimpleDraweeView cover = (SimpleDraweeView) (coverContainer.getChildAt(0));

            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) frameLayout.getLayoutParams();
            FrameLayout.LayoutParams coverParams = (FrameLayout.LayoutParams) coverContainer.getLayoutParams();

            params.width = mItemWidth;
            params.height = mItemWidth + LocalDisplay.dp2px(50);
            coverParams.width = coverItemWidth;
            coverParams.height = coverItemWidth;

            if ((index + 1) % 3 == 0) {
                params.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
            } else if ((index + 1) % 3 == 1) {
                params.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
            } else {
                params.gravity = Gravity.CENTER;
            }

            frameLayout.setLayoutParams(params);


            frameLayout.setOnClickListener(listener);
        }
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {

        List<BaseModel> list = itemData.getItemList();
        if (list != null && list.size() > 0) {
            int count = list.size() > 3 ? 3 : list.size();
            for (int i = 0; i < count; i++) {
                final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(i));
                final CustomStoryView customStoryView = (CustomStoryView) frameLayout.getChildAt(0);
                customStoryView.setPlaceHolder(R.drawable.books_two_square);
                frameLayout.setVisibility(View.VISIBLE);
                if (list.get(i) != null && list.get(i) instanceof StoryListItem) {
                    StoryListItem item = (StoryListItem) list.get(i);

                    if (item.getData() != null && item.getData() instanceof StoryCollectionInfo) {
                        StoryCollectionInfo info = (StoryCollectionInfo) item.getData();
                        customStoryView.showCollectionBg(R.drawable.bg_story_collect);
                        customStoryView.showBottomShadow();

                        String coverUrl = info.getCoverUrl();
                        boolean needResetImageUrl = true;
                        if (customStoryView.getTag(R.id.book_list_item_image_url) != null) {
                            String url = (String) customStoryView.getTag(R.id.book_list_item_image_url);
                            if (TextUtils.equals(url, coverUrl)) {
                                needResetImageUrl = false;
                            }
                        }
                        if (needResetImageUrl) {
                            customStoryView.setTag(R.id.book_list_item_image_url, coverUrl);
                            customStoryView.showUrl(coverUrl, coverItemWidth, coverItemWidth);
                        }

//                        TextView clickCount = (TextView) frameLayout.getChildAt(1);
//                        clickCount.setText(StringUtil.formatClickCount(info.getClickCount()));

                        TextView name = (TextView) frameLayout.findViewById(R.id.name);
                        name.setText(info.getName());

                        View newFlag = frameLayout.findViewById(R.id.new_flag);
                        View charge = frameLayout.findViewById(R.id.charge);
                        View freeFlag = frameLayout.findViewById(R.id.free_flag);
//                        View serialize = frameLayout.findViewById(R.id.serialize);
                        //new标志
                        if((info.getExtFlag() & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4){
                            newFlag.setVisibility(View.VISIBLE);
                        }else{
                            newFlag.setVisibility(View.GONE);
                        }
                        //收费标志
                        boolean isCharge = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32;
                        boolean isFree = ((info.getExtFlag() & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW) ||
                                ((info.getExtFlag() & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL);
                        if(isFree) {
                            freeFlag.setVisibility(View.VISIBLE);
                            charge.setVisibility(View.GONE);
                        } else {
                            if(isCharge) {
                                charge.setVisibility(View.VISIBLE);
                            } else {
                                charge.setVisibility(View.GONE);
                            }
                        }
//                        customStoryView.showGoldBorder(isCharge);
                        //连载中标志
//                        if((info.getExtFlag() & Extflag.STORY_EXT_FLAG_16) == Extflag.STORY_EXT_FLAG_16){
//                            serialize.setVisibility(View.VISIBLE);
//                        }else{
//                            serialize.setVisibility(View.GONE);
//                        }
                        customStoryView.showSerialize((info.getExtFlag() & Extflag.STORY_EXT_FLAG_16) == Extflag.STORY_EXT_FLAG_16);

                        frameLayout.setTag(R.id.view_holder_item, item);
                    }
                } else {
                    frameLayout.setVisibility(View.GONE);
                }
            }

            for (int i = count; i < 3; i++) {
                final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(i));
                frameLayout.setVisibility(View.GONE);
                frameLayout.setTag(R.id.view_holder_item, null);
            }
        }

    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            Object object = v.getTag(R.id.view_holder_item);
            if (object != null && object instanceof StoryListItem) {
                StoryListItem item = (StoryListItem) object;
                if (item.getData() != null && item.getData() instanceof StoryCollectionInfo) {
                    StoryCollectionInfo storyCollectionInfo = (StoryCollectionInfo) item.getData();
                    FragmentUtil.presentFragment(StoryCollectionFragment.class, storyCollectionInfo.getCollectId(), true);
                    if (!TextUtils.isEmpty(storyCollectionInfo.getSourceKey())) {
                        RedirectInfo.SourceKeyStatInfo statInfo = RedirectInfo.SourceKeyStatInfo.parse(storyCollectionInfo.getSourceKey());
                        if (statInfo != null) {
                            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(statInfo.getContent(), statInfo.getName(), TimeUtil.currentTime()));
                        }
                    }
                }
            }
        }
    };


}
