package com.hhdd.kada.main.viewholders;

import android.graphics.Color;
import android.view.View;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;

/**
 * Created by lj on 16/10/11.
 */

public class SeparatorViewHolder_15 extends SeparatorBigViewHolder {

    @Override
    protected void initView() {
        super.initView();
        View layout = view.findViewById(R.id.layout);
        layout.getLayoutParams().height = LocalDisplay.dp2px(15);
        view.setBackgroundColor(Color.TRANSPARENT);
    }
}
