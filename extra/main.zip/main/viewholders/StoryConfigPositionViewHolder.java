package com.hhdd.kada.main.viewholders;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectPositionSubjectInfo;
import com.hhdd.kada.main.views.ConfigPositionTitleView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

/**
 * @autor Randy
 * @created 2018/9/6
 * @desc 精选页 - 可配位置的标题栏样式
 */
public class StoryConfigPositionViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.motherExcellentPositionSubjectView)
    ConfigPositionTitleView configPositionTitleView;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_config_position_title;
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = configPositionTitleView.getLayoutParams();
        params.height = (int) (LocalDisplay.SCREEN_WIDTH_PIXELS * Constants.MOTHER_SUBJECT_RATIO);
        params.width = LocalDisplay.SCREEN_WIDTH_PIXELS;
        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData != null && itemData.getItemList().size() > 0) {
            BaseModel baseModel = itemData.getItemList().get(0);
            if (baseModel instanceof RedirectPositionSubjectInfo) {
                RedirectPositionSubjectInfo redirectPositionInfo = (RedirectPositionSubjectInfo) baseModel;
                if (!TextUtils.isEmpty(itemData.getStyle()) && null != itemData.getStyleVO())//如果style字段获取异常，采用默认居左显示
                    configPositionTitleView.setCenter(itemData.getStyleVO().isAlignMiddle());
                else {
                    configPositionTitleView.setCenter(redirectPositionInfo.getPosition() == 0);
                }
                configPositionTitleView.isShowLeftTitleIcon(false);
                configPositionTitleView.isShowMidTitleIcon(false);
//                configPositionTitleView.setTitleBackgroundColor(R.color.transparent);
                if (configPositionTitleView.isCenter()) {
                    configPositionTitleView.setMidTitleTextColor(R.color.white);
                    configPositionTitleView.setMidSubTitleTextColor(R.color.alphawhite_70);
                } else {
                    configPositionTitleView.setLeftTitleTextColor(R.color.white);
                    configPositionTitleView.setLeftSubTitleTextColor(R.color.alphawhite_70);
                }
                configPositionTitleView.setMoreTextColor(R.color.white);
                configPositionTitleView.setMoreContainerBg(0);
                configPositionTitleView.setMoreIconImageResource(R.drawable.btn_more_content);
                configPositionTitleView.update(redirectPositionInfo);
            }
        }
    }
}
