package com.hhdd.kada.main.viewholders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.vo.BaseModelVO;

/**
 * Created by lj on 2017/6/5.
 */

public class StoryCollectResumeViewHolder extends BaseViewHolder<BaseModelVO> {

    public static final int TYPE_STORY_RESUME_CLICKED = 300;

    TextView name;

    @Override
    public View createView(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.view_holder_story_collect_resume, parent, false);

        name = (TextView) view.findViewById(R.id.name);
        view.findViewById(R.id.container).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mOnEventProcessor == null) {
                    return;
                }

                mOnEventProcessor.process(TYPE_STORY_RESUME_CLICKED);
            }
        });
        return view;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        if(itemData.getModel() != null && itemData.getModel() instanceof StoryInfo){
            StoryInfo info = (StoryInfo) itemData.getModel();
            if(name != null){
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("继续播放：《");
                stringBuilder.append(info.getName());
                stringBuilder.append("》");
                name.setText(stringBuilder.toString());
            }
        }

    }
}
