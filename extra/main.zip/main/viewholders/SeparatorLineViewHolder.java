package com.hhdd.kada.main.viewholders;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.R;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.main.vo.StyleVO;

/**
 * Created by simon on 10/9/16.
 */

public class SeparatorLineViewHolder extends BaseViewHolder<BaseVO> {

    View view;
    StyleVO styleVO;

    @Override
    public View createView(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_datalist_separator_line, null);
        return view;
    }

    @Override
    public void showData(int position, BaseVO itemData) {
        if(itemData == null) return;

        styleVO = itemData.getStyleVO();
        if (styleVO!=null&&styleVO.getBg()!=null&&styleVO.getBg().length()>0) {
            view.setBackgroundColor(Color.parseColor(styleVO.getBg()));
        } else {
            view.setBackgroundResource(R.color.transparent);
        }

        if(itemData instanceof SeparatorViewHolder.SeparatorVO){
            SeparatorViewHolder.SeparatorVO separatorVO = (SeparatorViewHolder.SeparatorVO)itemData;
            if (separatorVO.color!=0) {
                view.setBackgroundColor(separatorVO.color);
            }
        }
    }
}
