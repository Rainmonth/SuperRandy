package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.views.MyGridView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * @autor lazys
 * @created 2018/5/28 13:49
 * @desc 妈妈精选 - 2x2纯大图样式 基本单位  1x2 如果配置2x2中间分隔线勿忘配置@运营
 */
public class MotherExcellentBigImage1x2ViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.big_image_grid_view)
    MyGridView gridView;

    private GridViewAdapter adapter;
    private int itemWidth = 0;
    private int itemHeight = 0;
    private int margins = 10;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_mother_excellent_big_image_1x2;
    }

    @Override
    public View createView(ViewGroup parent) {
        adapter = new GridViewAdapter(parent.getContext(), R.layout.view_holder_mother_excellent_big_image_item);
        gridView.setNumColumns(2);

        itemWidth = (
                ScreenUtil.getScreenWidth()
                - gridView.getHorizontalSpacing() * 1//列 间隔宽度
                - margins * 2 * 2 // 所有子item占用的margins值（仅计算宽度）2==gridView.getNumColumns()
                - gridView.getPaddingLeft() //父布局左边距
                - gridView.getPaddingRight() // 父布局右边距
                ) / 2;
        itemHeight = (int) (itemWidth * Constants.MOTHER_TOW_COVER_RATIO);

        gridView.setAdapter(adapter);
        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null) return;
        if (itemData.getItemList().size() == 0) return;
        List<RedirectInfo> listItems = new ArrayList<>();

//        if(itemData.getItemList().size() % 2 == 1)// (可扩展)保证一行两列为基本单位，根据需求选择注释该限制 1*2 2*2 3*2....
//            itemData.getItemList().remove(itemData.getItemList().size() - 1);

        List<BaseModel> tempList = new ArrayList<>();

        if (itemData.getItemList().size() >= 3) {//以1x2为单位显示 只显示2个
            tempList.add(itemData.getItemList().get(0));
            tempList.add(itemData.getItemList().get(1));
        } else {
            tempList = itemData.getItemList();
        }


        for (BaseModel baseModel : tempList) {
            if (baseModel instanceof RedirectInfo) {
                listItems.add((RedirectInfo) baseModel);
            }
        }

        adapter.replaceAll(listItems);

    }

    private class GridViewAdapter extends QuickAdapter<RedirectInfo> {

        public GridViewAdapter(Context context, int layoutResId) {
            super(context, layoutResId);
        }

        @Override
        protected void convert(final BaseAdapterHelper helper, final RedirectInfo item) {
            if (!TextUtils.isEmpty(item.getImageUrl())) {
                SimpleDraweeView simpleDraweeView = helper.getView(R.id.bigImageView);

                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(itemWidth, itemHeight);
                layoutParams.setMargins(margins, 0, margins, 0);

                simpleDraweeView.setLayoutParams(layoutParams);

                String imgUrl = CdnUtils.getImgCdnUrl(item.getImageUrl(), CdnUtils.getTwoCoverImgSize());
                FrescoUtils.showImg(simpleDraweeView, imgUrl);

                simpleDraweeView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                    @Override
                    public void OnClickWithAnim(View v) {
                        RedirectActivity.startActivity(context, item);
                    }
                });
            }
        }
    }
}
