package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author: Randy Zhang
 * @description: 听书合集两栏ViewHolder
 * @created: 2018/8/30
 **/
public class StoryCollectionTwoColViewHolder extends BaseViewHolder<BaseModelListVO> {
    Context context;
    View view;

    GridView gridView;
    private StoryCollectionTwoColAdapter adapter;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_story_collection_two_col;
    }

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_story_collection_two_col, parent,
                false);
        gridView = (GridView) view.findViewById(R.id.gridview);
        gridView.setNumColumns(2);
        adapter = new StoryCollectionTwoColAdapter(context);
        gridView.setAdapter(adapter);
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null) return;
        if (itemData.getItemList().size() == 0) return;
        List<StoryCollectionInfo> storyCollectionInfos = new ArrayList<>();
        for (int i = 0; i < itemData.getItemList().size(); i++) {
            BaseModel baseModel = itemData.getItemList().get(i);
            if (baseModel != null && baseModel instanceof StoryCollectionInfo) {
                storyCollectionInfos.add((StoryCollectionInfo) baseModel);
            }
            if (i >= 3) break;
        }
        gridView.setAdapter(adapter);
        adapter.replaceAll(storyCollectionInfos);
    }

    /**
     * GridView对应的Adapter
     */
    private class StoryCollectionTwoColAdapter extends QuickAdapter<StoryCollectionInfo> {
        int storyCoverWidth = 0;
        int storyCoverHeight = 0;

        public StoryCollectionTwoColAdapter(Context context) {
            super(context, R.layout.view_holder_story_collection_two_col_item);
            storyCoverWidth = (ScreenUtil.getScreenWidth() - LocalDisplay.dp2px(10 + 10 + 10)) / 2;
            storyCoverHeight = storyCoverWidth;
        }

        @Override
        protected void convert(BaseAdapterHelper helper, StoryCollectionInfo item) {

            if (item != null) {
                View view = helper.getView(R.id.item_container);
                view.getLayoutParams().width = storyCoverHeight;
                view.getLayoutParams().height = storyCoverHeight + LocalDisplay.dp2px(60);


                view.setTag(R.id.item_container, item);
                view.setOnClickListener(onClickWithAnimListener);

                TextView tvName = helper.getView(R.id.name);
                tvName.setGravity(Gravity.CENTER_HORIZONTAL);
                tvName.setGravity(Gravity.CENTER);
                tvName.setText(item.getName());

                TextView tvDetail = helper.getView(R.id.detail);
                tvDetail.setText(item.getRecommend());

//                TextView clickCount = helper.getView(R.id.click_count);
//                clickCount.setText(StringUtil.formatClickCount(item.getClickCount()));

                View newFlag = helper.getView(R.id.new_flag);
                View charge = helper.getView(R.id.charge);
                View freeFlag = helper.getView(R.id.free_flag);
                View serialize = helper.getView(R.id.serialize);
                TextView countFlag = helper.getView(R.id.count);
                //new标志
                if ((item.getExtFlag() & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4) {
                    newFlag.setVisibility(View.VISIBLE);
                } else {
                    newFlag.setVisibility(View.GONE);
                }
                boolean isCharge = (item.getExtFlag() & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32;
                boolean isFree = ((item.getExtFlag() & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW) ||
                        ((item.getExtFlag() & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL);
                if(isFree) {
                    freeFlag.setVisibility(View.VISIBLE);
                    charge.setVisibility(View.GONE);
                } else {
                    if(isCharge) {
                        charge.setVisibility(View.VISIBLE);
                    } else {
                        charge.setVisibility(View.GONE);
                    }
                }
                //连载中标志
                boolean isSerialize = (item.getExtFlag() & Extflag.STORY_EXT_FLAG_16)
                        == Extflag.STORY_EXT_FLAG_16;
                serialize.setVisibility(isSerialize ? View.VISIBLE : View.GONE);

                //集数标志
                if (item.getCount() > 0) {
                    countFlag.setVisibility(View.VISIBLE);
                    if (isSerialize && item.getOnlineCount() > 0) {
                        countFlag.setText(KaDaApplication.getInstance().getResources()
                                .getString(R.string.excellent_story_collection_item_count,
                                        item.getOnlineCount(), item.getCount()));
                    } else {
                        countFlag.setText(item.getCount() + "集");
                    }
                } else {
                    countFlag.setVisibility(View.GONE);
                }

                CustomStoryView customStoryView = helper.getView(R.id.cover_container);
                customStoryView.cancelCoverHorizontalMargin();
                customStoryView.getLayoutParams().width = storyCoverWidth;
                customStoryView.getLayoutParams().height = storyCoverHeight;
                customStoryView.setRound();

                customStoryView.showCollectionBg(R.drawable.bg_story_collect2);
                customStoryView.showBottomShadow();
                customStoryView.setPlaceHolder(R.drawable.books_two);

                int width = storyCoverWidth;//view.getWidth();
                int height = storyCoverHeight;//view.getHeight();

                if (item.getBannerUrl() != null && item.getBannerUrl().length() > 0) {
                    String coverUrl = CdnUtils.getImgCdnUrl(item.getBannerUrl(),
                            CdnUtils.getTwoCoverImgSize());
                    boolean needResetImageUrl = true;
                    if (customStoryView.getTag(R.id.list_item_image_url) != null) {
                        String url = (String) customStoryView.getTag(R.id.list_item_image_url);
                        if (TextUtils.equals(url, coverUrl)) {
                            needResetImageUrl = false;
                        }
                    }
                    if (needResetImageUrl) {
                        customStoryView.setTag(R.id.list_item_image_url, coverUrl);
                        customStoryView.showUrlWithCdn(coverUrl, width, height);
                    }
                } else {
                    if (item.getCoverUrl() != null && item.getCoverUrl().length() > 0) {
                        String coverUrl = item.getCoverUrl();
                        boolean needResetImageUrl = true;
                        if (customStoryView.getTag(R.id.list_item_image_url) != null) {
                            String url = (String) customStoryView.getTag(R.id.list_item_image_url);
                            if (TextUtils.equals(url, coverUrl)) {
                                needResetImageUrl = false;
                            }
                        }
                        if (needResetImageUrl) {
                            customStoryView.setTag(R.id.list_item_image_url, coverUrl);
                            customStoryView.showUrl(coverUrl, width, height);
                        }
                    }
                }
                newFlag.setVisibility(View.VISIBLE);
                charge.setVisibility(View.VISIBLE);
                serialize.setVisibility(View.VISIBLE);
            }
        }

        KaDaApplication.OnClickWithAnimListener onClickWithAnimListener = new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                StoryCollectionInfo item = (StoryCollectionInfo) v.getTag(R.id.item_container);
                if (item != null) {
                    int collectId = item.getCollectId();
                    FragmentUtil.presentFragment(StoryCollectionFragment.class, collectId,
                            true);
                    if (!TextUtils.isEmpty(item.getSourceKey())) {
                        RedirectInfo.SourceKeyStatInfo statInfo = RedirectInfo.SourceKeyStatInfo
                                .parse(item.getSourceKey());
                        if (statInfo != null) {
                            UserHabitService.getInstance().trackHabit(UserHabitService
                                    .newUserHabit(statInfo.getContent(), statInfo.getName(),
                                            TimeUtil.currentTime()));
                        }
                    }
                }
            }
        };
    }
}
