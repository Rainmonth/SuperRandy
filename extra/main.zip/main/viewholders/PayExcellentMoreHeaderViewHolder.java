package com.hhdd.kada.main.viewholders;

import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.views.PayExcellentMoreHeaderView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/2
 * @describe : com.hhdd.kada.main.viewholders
 */
public class PayExcellentMoreHeaderViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.payExcellentMoreHeaderView)
    PayExcellentMoreHeaderView payExcellentMoreHeaderView;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_pay_excellent_header;
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams layoutParams = payExcellentMoreHeaderView.getLayoutParams();
        layoutParams.height = (int) (LocalDisplay.SCREEN_WIDTH_PIXELS * Constants.IMG_PAY_EXCELLENT_HEADER_RATIO);

        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if(itemData != null && itemData.getItemList() != null && itemData.getItemList().size() > 0){
            BaseModel model = itemData.getItemList().get(0);
            if(model instanceof RedirectInfo){
                RedirectInfo info = (RedirectInfo) model;
                payExcellentMoreHeaderView.update(info);
            }
        }
    }
}
