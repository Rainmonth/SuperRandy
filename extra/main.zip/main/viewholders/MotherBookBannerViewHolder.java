package com.hhdd.kada.main.viewholders;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.utils.TimeUtil;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/29
 * @describe : com.hhdd.kada.main.viewholders
 */
public class MotherBookBannerViewHolder extends CommonBannerViewHolder {

    @Override
    protected void doBannerClick(int position) {
        super.doBannerClick(position);
        if (position < bannerInfos.size()) {
            BannerInfo info = bannerInfos.get(position);
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getId()), "mom_home_book_banner_click", TimeUtil.currentTime()));
        }
    }
}
