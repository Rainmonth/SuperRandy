package com.hhdd.kada.main.viewholders;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.utils.LocalSubscribeUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.views.SubscribeCustomStoryView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.module.userhabit.StaCtrName;

import java.util.List;

import butterknife.BindView;

/**
 * Created by lj on 2017/6/5.
 */

public class SubscribeListViewHolder extends BaseViewHolder<BaseModelListVO> {

    public static final int TYPE_STORY_SHELF_CLICKED = 501;
    public static final int TYPE_STORY_SUBSCRIBE_LIST_ITEM_CLICKED = 502;

    int mItemWidth;
    int mItemHeight;

    @BindView(R.id.main_container)
    LinearLayout mainContainer;
    @BindView(R.id.subscribeCustomView1)
    SubscribeCustomStoryView subscribeCustomView1;
    @BindView(R.id.subscribeCustomView2)
    SubscribeCustomStoryView subscribeCustomView2;
    @BindView(R.id.subscribeCustomView3)
    SubscribeCustomStoryView subscribeCustomView3;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_subscribe_list;
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(params);
        mItemWidth = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(42)) / 3;
        mItemHeight = mItemWidth;
        return rootView;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null) {
            return;
        }

        List<BaseModel> list = itemData.getItemList();
        if (list == null || list.isEmpty()) {
            return;
        }

        int size = list.size();
        final int count = size > 3 ? 3 : size;
        for (int i = 0; i < count; i++) {
            SubscribeCustomStoryView subscribeCustomStoryView = (SubscribeCustomStoryView) mainContainer.getChildAt(i);
            subscribeCustomStoryView.setVisibility(View.VISIBLE);
            CustomStoryView customStoryView = subscribeCustomStoryView.getCustomStoryView();
            customStoryView.getLayoutParams().width = mItemWidth;
            customStoryView.getLayoutParams().height = mItemHeight;
            BaseModel model = list.get(i);
            if (model instanceof StoryListItem) {
                StoryListItem item = (StoryListItem) model;
                subscribeCustomStoryView.updateView(item, mItemWidth/2, mItemHeight/2);
                subscribeCustomStoryView.setTag(R.id.view_holder_item, item);
                subscribeCustomStoryView.setOnClickListener(listener);
            } else if (model instanceof RedirectInfo) {
                RedirectInfo info = (RedirectInfo) model;
                subscribeCustomStoryView.updateView(info, mItemWidth/2, mItemHeight/2);
                subscribeCustomStoryView.setTag(R.id.view_holder_item, info);
                subscribeCustomStoryView.setOnClickListener(listener);
            }
        }

        for (int i = count; i < 3; i++) {
            final FrameLayout frameLayout = ((FrameLayout) mainContainer.getChildAt(i));
            frameLayout.setVisibility(View.INVISIBLE);
            frameLayout.setTag(R.id.view_holder_item, null);
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            ImageView newFlag = (ImageView) v.findViewById(R.id.new_flag);
            if (newFlag != null && newFlag.getVisibility() == View.VISIBLE) {
                newFlag.setVisibility(View.GONE);
            }

            Object object = v.getTag(R.id.view_holder_item);
            if (object == null) {
                return;
            }

            if (object instanceof StoryListItem) {
                StoryListItem item = (StoryListItem) object;
                BaseModel baseModel = item.getData();
                if (baseModel != null && baseModel instanceof StoryCollectionInfo) {
                    StoryCollectionInfo info = (StoryCollectionInfo) baseModel;
                    if (LocalSubscribeUtil.containStorySubscribeId(info.getCollectId())) {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.story_home_bookshelf_new_subscribed_click, TimeUtil.currentTime()));
                        ((SubscribeCustomStoryView) v).stopSubscribedAnim();
                    }
                }
                if (mOnEventProcessor != null) {
                    mOnEventProcessor.process(TYPE_STORY_SUBSCRIBE_LIST_ITEM_CLICKED, item);
                }
            } else if (object instanceof RedirectInfo) {
                RedirectInfo info = (RedirectInfo) object;
                if (mOnEventProcessor != null) {
                    mOnEventProcessor.process(TYPE_STORY_SHELF_CLICKED, info);
                }
            }
        }
    };

    @Override
    public void onRecycled() {
        super.onRecycled();
        if (subscribeCustomView1.getVisibility() == View.VISIBLE) {
            subscribeCustomView1.stopSubscribedAnim();
        }
        if (subscribeCustomView2.getVisibility() == View.VISIBLE) {
            subscribeCustomView2.stopSubscribedAnim();
        }
        if (subscribeCustomView3.getVisibility() == View.VISIBLE) {
            subscribeCustomView3.stopSubscribedAnim();
        }
    }
}