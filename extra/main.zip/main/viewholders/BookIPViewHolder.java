package com.hhdd.kada.main.viewholders;

import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/7
 * @describe : com.hhdd.kada.main.viewholders
 */
public class BookIPViewHolder extends OrgSlideViewHolder {

    @Override
    protected void doItemClick(int position) {
        if (position < adapter.getCount()) {
            RedirectInfo redirectInfo = adapter.getItem(position);
            RedirectActivity.startActivity(context, redirectInfo);
        }
    }
}
