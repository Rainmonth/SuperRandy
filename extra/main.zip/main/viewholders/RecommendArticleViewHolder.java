package com.hhdd.kada.main.viewholders;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.animator.ScaleAnimator;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.nineoldandroids.view.ViewHelper;

/**
 * Created by simon on 29/11/2016.
 */

public class RecommendArticleViewHolder extends BaseViewHolder<BaseModelListVO> {

    Context context;
    View view;

    SimpleDraweeView cover;
    ViewGroup container;

    RedirectInfo redirectInfo;

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_datalist_recommend_article, null);
        cover = (SimpleDraweeView)view.findViewById(R.id.datalist_recommend_article_cover);
        container=(ViewGroup)view.findViewById(R.id.datalist_recommend_articles_container);

        container.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (redirectInfo!=null) {
                    RedirectActivity.startActivity(context,redirectInfo);
                }
            }
        });
        cover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ViewHelper.setPivotX(view,0.5f);
                ViewHelper.setPivotY(view,0.5f);
                ScaleAnimator scaleAnimator = new ScaleAnimator(0.8f);
                scaleAnimator.setTarget(view).setDuration(100).animate();
                scaleAnimator.addAnimatorListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        if (redirectInfo!=null) {
                            RedirectActivity.startActivity(context,redirectInfo);
                        }
                    }
                });
            }
        });
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData==null||itemData.getItemList()==null)return;
        if (itemData.getItemList().size()==0)return;

        redirectInfo = null;

        BaseModel baseModel = itemData.getItemList().get(0);
        if (baseModel instanceof RedirectInfo) {
            RedirectInfo redirectInfo = (RedirectInfo)baseModel;
            this.redirectInfo = redirectInfo;
            if (redirectInfo.getImageUrl()!=null&&redirectInfo.getImageUrl().length()>0) {
                FrescoUtils.showUrl(redirectInfo.getImageUrl(),cover, LocalDisplay.dp2px(100),LocalDisplay.dp2px(75));
            }
        }

        for (int i=0;i<container.getChildCount();i++) {
            container.getChildAt(i).setVisibility(View.GONE);
        }

        int index = 0;
        for (int i=0;i<itemData.getItemList().size();i++) {
            if (itemData.getItemList().get(i) instanceof RedirectInfo) {
                final RedirectInfo redirectInfo = (RedirectInfo)itemData.getItemList().get(i);
                if (index<container.getChildCount()) {

                    ViewGroup viewGroup = (ViewGroup)container.getChildAt(i);
                    viewGroup.setVisibility(View.VISIBLE);
                    TextView textViewName = (TextView)viewGroup.getChildAt(0);
                    TextView textViewTime = (TextView)viewGroup.getChildAt(1);
                    textViewName.setText(redirectInfo.getTitle());
                    textViewTime.setText(redirectInfo.getSubTitle());
                    index++;

                    viewGroup.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
                        @Override
                        public void onNoDoubleClick(View v) {
                            RedirectActivity.startActivity(context,redirectInfo);
                        }
                    });
                }
            }
        }
    }

}
