package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.generic.GenericDraweeHierarchy;
import com.facebook.drawee.generic.RoundingParams;
import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

/**
 * @author: Randy Zhang
 * @description: 听书合集一栏ViewHolder
 * @created: 2018/8/30
 **/
public class StoryCollectionOneColViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.single_image_ll)
    LinearLayout singleLinearLayout;

    @BindView(R.id.motherExcellentSingleImage)
    SimpleDraweeView simpleDraweeView;

    @BindView(R.id.bottom_shadow)
    ImageView bottomShadow;

    @BindView(R.id.motherExcellentSingleTitleTextView)
    TextView titleTextView;

    @BindView(R.id.motherExcellentSingleTitleDescTextView)
    TextView descTextView;

    @BindView(R.id.motherExcellentSingleNewTextView)
    TextView newFlagTextView;

    @BindView(R.id.motherExcellentSinglePayStatueIv)
    View payFlagView;
    @BindView(R.id.count)
    TextView count;
    @BindView(R.id.free_flag)
    ImageView freeFlag;

    private Context context;

    private int margin = 0;
    private int radius = 0;

    @Override
    protected int getLayoutId() {
        return R.layout.layout_story_collection_one_col;
    }

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();

        LocalDisplay.init(context);
        margin = LocalDisplay.dp2px(10);
        radius = LocalDisplay.dp2px(10);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams
                (LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        layoutParams.leftMargin = margin;
        layoutParams.rightMargin = margin;
        layoutParams.topMargin = margin / 2;
        layoutParams.bottomMargin = margin / 2;

        singleLinearLayout.setLayoutParams(layoutParams);

        ViewGroup.LayoutParams imgLayoutParams = simpleDraweeView.getLayoutParams();
        imgLayoutParams.height = (int) ((LocalDisplay.SCREEN_WIDTH_PIXELS - margin * 2)
                * Constants.MOTHER_SINGLE_IMG_TEXT_RATIO);

        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (null == itemData || itemData.getItemList().size() <= 0) return;

        BaseModel model = itemData.getItemList().get(0);

        if (model instanceof StoryCollectionInfo) {
            bottomShadow.setVisibility(View.VISIBLE);
            final StoryCollectionInfo info = (StoryCollectionInfo) model;

            String imgUrl = CdnUtils.getImgCdnUrl(info.getBannerUrl(), CdnUtils.getSingleImgSize());
            FrescoUtils.showImg(simpleDraweeView, imgUrl);
            //第三方控件设置圆角需要通过代码实现，防止因为矩形图片显示不出圆角效果
            setCoverRadius(simpleDraweeView, radius, radius, radius, radius);

            titleTextView.setText(info.getName());
            descTextView.setText(info.getRecommend());

            //new标志
            if ((info.getExtFlag() & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4) {
                newFlagTextView.setVisibility(View.VISIBLE);
            } else {
                newFlagTextView.setVisibility(View.GONE);
            }
            boolean isFree = ((info.getExtFlag() & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL)
                    || ((info.getExtFlag() & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW);
            //收费标志
            boolean isPay = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32;
            if (isFree) {
                freeFlag.setVisibility(View.VISIBLE);
                payFlagView.setVisibility(View.GONE);
            } else {
                if (isPay) {
                    payFlagView.setVisibility(View.VISIBLE);
                } else {
                    payFlagView.setVisibility(View.GONE);
                }
                freeFlag.setVisibility(View.GONE);
            }

            //集数标志
            boolean isSerialize = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_16) == Extflag.STORY_EXT_FLAG_16;
            if (info.getCount() > 0) {
                count.setVisibility(View.VISIBLE);
                if (isSerialize && info.getOnlineCount() > 0) {
                    count.setText(KaDaApplication.getInstance().getResources().getString(R.string.excellent_story_collection_item_count, info.getOnlineCount(), info.getCount()));
                } else {
                    count.setText(info.getCount() + "集");
                }
            } else {
                count.setVisibility(View.GONE);
            }
            singleLinearLayout.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(View v) {
                    if (info != null) {
                        FragmentUtil.presentFragment(StoryCollectionFragment.class, info.getCollectId(), true);
                        if (!TextUtils.isEmpty(info.getSourceKey())) {
                            RedirectInfo.SourceKeyStatInfo statInfo = RedirectInfo.SourceKeyStatInfo.parse(info.getSourceKey());
                            if (statInfo != null) {
                                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(statInfo.getContent(), statInfo.getName(), TimeUtil.currentTime()));
                            }
                        }
                    }

                }
            });
        }

    }

    //大图设置圆角
    protected void setCoverRadius(SimpleDraweeView simpleDraweeView, int leftTopRadius, int rightTopRadius, int rightBottomRadius, int leftBottomRadius) {
        GenericDraweeHierarchy hierarchy = simpleDraweeView.getHierarchy();
        RoundingParams params = hierarchy.getRoundingParams();
        if (params == null) {
            params = new RoundingParams();
        }
        params.setCornersRadii(leftTopRadius, rightTopRadius, rightBottomRadius, leftBottomRadius);
        hierarchy.setRoundingParams(params);
    }
}