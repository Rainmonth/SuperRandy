package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.store.utils.PriceUtil;

/**
 * Created by sxh on 2017/5/2.
 */

public class StoryCollectionPayViewHolder extends BaseViewHolder<BaseModelVO> {

    private View view;
    private TextView name;
    private TextView des;
    private SimpleDraweeView cover;
    //    private TextView listenCount;
    private TextView subscribeCount;
    private TextView price;
    private TextView updateTime;
    private View container;
    private ImageView ivSerialize;
    private TextView countFlag;
    private ImageView ivNew;
    private TextView status;
    private Context context;

    @Override
    public View createView(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_collection_pay_list, parent, false);
        context = parent.getContext();

        name = (TextView) view.findViewById(R.id.tv_name);
        des = (TextView) view.findViewById(R.id.tv_des);
        cover = (SimpleDraweeView) view.findViewById(R.id.cover);
//        listenCount = (TextView) view.findViewById(R.id.tv_listen_count);
        subscribeCount = (TextView) view.findViewById(R.id.tv_subscribe_count);
        price = (TextView) view.findViewById(R.id.tv_price);
        ivNew = (ImageView) view.findViewById(R.id.iv_new);
        ivSerialize = (ImageView) view.findViewById(R.id.iv_serialize);
        countFlag = (TextView) view.findViewById(R.id.count);
        updateTime = (TextView) view.findViewById(R.id.tv_update_time);
        container = view.findViewById(R.id.ll_collection_container);
        status = (TextView) view.findViewById(R.id.status);

        int coverWidth = LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(28);
        int coverHeight = (int) (coverWidth * Constants.GOOD_LIST_COVER_RATIO);
        ViewGroup.LayoutParams coverLayoutParams = cover.getLayoutParams();
        coverLayoutParams.height = coverHeight;
        return view;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        BaseModel baseModel = itemData.getModel();
        if (baseModel != null && baseModel instanceof StoryCollectionInfo) {
            final StoryCollectionInfo info = (StoryCollectionInfo) baseModel;
            name.setText(info.getName());
            des.setText(info.getRecommend());
            price.setText(PriceUtil.formatPrice(info.getPrice() / 100 + "") + "元");
            if (info.getSubscribe() == 1) {
                status.setVisibility(View.VISIBLE);
                status.setText("已订阅");
                status.setTextColor(context.getResources().getColor(R.color.text_story_collection_price));
            } else {
                status.setVisibility(View.INVISIBLE);
                status.setTextColor(context.getResources().getColor(R.color.text_story_orderlist_tab));
            }

            subscribeCount.setText(StringUtil.subformatClickCount(info.getSubscribeCount()) + "人订阅");
            updateTime.setText(info.getSerialize());
//            listenCount.setText(info.getClickCount()+"");
            String bannerImg = CdnUtils.getImgCdnUrl(info.getBannerUrl(), CdnUtils.getGoodCoverSize());
            FrescoUtils.showImg(cover, bannerImg);

            //new标志
            if ((info.getExtFlag() & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4) {
                ivNew.setVisibility(View.VISIBLE);
            } else {
                ivNew.setVisibility(View.GONE);
            }
            //连载中标志
            boolean isSerialize = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_16) == Extflag.STORY_EXT_FLAG_16;
            if (isSerialize) {
                ivSerialize.setVisibility(View.VISIBLE);
                updateTime.setVisibility(View.VISIBLE);
            } else {
                ivSerialize.setVisibility(View.GONE);
                updateTime.setVisibility(View.GONE);
            }
            if (info.getCount() > 0) {
                countFlag.setVisibility(View.VISIBLE);
                if (isSerialize && info.getOnlineCount() > 0) {
                    countFlag.setText(KaDaApplication.getInstance().getResources()
                            .getString(R.string.excellent_story_collection_item_count,
                                    info.getOnlineCount(), info.getCount()));
                } else {
                    countFlag.setText(info.getCount() + "集");
                }
            } else {
                countFlag.setVisibility(View.GONE);
            }
            container.setTag(R.id.container, info);
            container.setOnClickListener(listener);
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            StoryCollectionInfo info = (StoryCollectionInfo) v.getTag(R.id.container);
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(info.getCollectId() + "," + info.getIndex(), "story_premium_list_click", TimeUtil.currentTime()));
            FragmentUtil.presentFragment(StoryCollectionFragment.class, info.getCollectId(), true);
        }
    };
}
