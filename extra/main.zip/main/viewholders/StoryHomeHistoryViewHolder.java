package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryHistoryInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.viewholders.mvc.BaseMvcViewHolder;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.views.HorizontialListView;
import com.hhdd.kada.main.views.OnItemScaleClickListener;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lj on 16/12/13.
 */

public class StoryHomeHistoryViewHolder extends BaseMvcViewHolder<BaseModelListVO> {

    public static final int TYPE_STORY_HOME_HISTORY_ITEM_CLICKED = 500;

    Context context;
    View view;
    HorizontialListView listView;
    MyAdapter adapter;

    int itemSize = 0;

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_compat_story_home_histories, parent, false);
        listView = (HorizontialListView) view.findViewById(R.id.story_home_histories_listview);

        itemSize = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(10 + 20)) / 4;
//        itemSize = LocalDisplay.dp2px(80);
        listView.getLayoutParams().height = itemSize;//+LocalDisplay.dp2px(20);

//        listView.setDividerWidth(LocalDisplay.dp2px(4));

        adapter = new MyAdapter(parent.getContext());
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new OnItemScaleClickListener() {
            @Override
            public void onItemClickScaled(AdapterView<?> parent, View view, int position, long id) {
                super.onItemClickScaled(parent, view, position, id);
                if (position < adapter.getCount()) {
                    StoryListItem item = adapter.getItem(position);

                    if (mOnEventProcessor != null) {
                        mOnEventProcessor.process(TYPE_STORY_HOME_HISTORY_ITEM_CLICKED, position, item);
                    }
                }
            }
        });
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO baseVOList) {
        if (baseVOList == null || baseVOList.getItemList() == null || baseVOList.getItemList().size() == 0)
            return;

        List<StoryListItem> historyList = new ArrayList<>();
        for (int i = 0; i < baseVOList.getItemList().size(); i++) {
            BaseModel model = baseVOList.getItemList().get(i);
            if (model instanceof StoryListItem) {
                model.setIndex(i);
                historyList.add((StoryListItem) model);
            }
            if (historyList.size() >= 3) break;
        }

        if (historyList.size() >= 3) {
            StoryListItem item = new StoryListItem();
            StoryHistoryInfo info = new StoryHistoryInfo(-1);
            info.setCoverUrl("res://" + context.getPackageName() + "/" + R.drawable.story_history_add);
            item.setData(info);
            historyList.add(item);
        }
        adapter.replaceAll(historyList);
    }

    class MyAdapter extends QuickAdapter<StoryListItem> {

        public MyAdapter(Context context) {
            super(context, R.layout.view_holder_story_item);
        }

        @Override
        protected void convert(BaseAdapterHelper helper, StoryListItem item) {

            CustomStoryView customStoryView = helper.getView(R.id.cover_container);
            customStoryView.convertToHistoryCustomerView();
            customStoryView.getLayoutParams().width = itemSize;
            customStoryView.getLayoutParams().height = itemSize;
            customStoryView.setPlaceHolder(R.drawable.books_two_square);

            if (item.getData() != null && item.getData() instanceof StoryHistoryInfo) {
                StoryHistoryInfo info = (StoryHistoryInfo) item.getData();
                if (info.getStoryId() == -1) {
                    customStoryView.hideCollectionBg();
                    customStoryView.hideBottomShadow();
                    customStoryView.cancelRound();
                    String coverUrl = "res://" + context.getPackageName() + "/" + R.drawable.story_history_add;
                    customStoryView.showUrl(coverUrl);
                } else {
                    customStoryView.showBottomShadow();
                    if (info.getType() == Constants.TYPE_STORY_SINGLE) {
                        customStoryView.hideCollectionBg();
//                        customStoryView.showStoryTitle(info.getName());
                    } else {
                        customStoryView.hideStoryTitle();
                        customStoryView.showCollectionBg(R.drawable.bg_story_collect);
                    }
                    customStoryView.setRound();
                    String coverUrl = info.getCoverUrl();
                    boolean needResetImageUrl = true;
                    if (customStoryView.getTag(R.id.list_item_image_url) != null) {
                        String url = (String) customStoryView.getTag(R.id.list_item_image_url);
                        if (TextUtils.equals(url, coverUrl)) {
                            needResetImageUrl = false;
                        }
                    }
                    if (needResetImageUrl) {
                        customStoryView.setTag(R.id.list_item_image_url, coverUrl);
                        customStoryView.showUrl(coverUrl, itemSize, itemSize);
                    }
                }
            } else {
                customStoryView.hideStoryTitle();
                customStoryView.hideBg();
                customStoryView.hideBottomShadow();
                customStoryView.cancelRound();
            }
            customStoryView.setMode(item.getPlayMode(), itemSize / 2,
                    itemSize / 2);
        }
    }
}