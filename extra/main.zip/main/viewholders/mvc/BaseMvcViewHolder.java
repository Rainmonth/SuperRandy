package com.hhdd.kada.main.viewholders.mvc;

import com.hhdd.kada.android.library.views.list.ViewHolderBase;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseVO;

/**
 * Created by bjx on 2017/11/25.
 */

public abstract class BaseMvcViewHolder<ItemDataType extends BaseVO> extends ViewHolderBase<ItemDataType> {

    protected OnEventProcessor mOnEventProcessor;

    public void setOnEventProcessor(OnEventProcessor onEventProcessor) {
        mOnEventProcessor = onEventProcessor;
    }
}
