package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.OnItemScaleClickListener;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by simon on 9/20/16.
 */
public class OrgSlideViewHolder extends BaseViewHolder<BaseModelListVO> {

    Context context;
    View view;
    //    MyAdapter adapter;
    //    HorizontialListView listView;
    GridView gridView;
    GridViewAdapter adapter;

    int itemSize = 0;
    protected List<RedirectInfo> redirectInfos;

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_datalist_orgslide, parent, false);
//        listView = (HorizontialListView)view.findViewById(R.id.datalist_ord_slide_listview);

        itemSize = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(5)) / 3;
        gridView = (GridView) view.findViewById(R.id.gridview);
        gridView.setNumColumns(3);
        adapter = new GridViewAdapter(context);
        gridView.setAdapter(adapter);
        gridView.setOnItemClickListener(new OnItemScaleClickListener() {
            @Override
            public void onItemClickScaled(AdapterView<?> parent, View view, int position, long id) {
                super.onItemClickScaled(parent, view, position, id);
                doItemClick(position);
            }
        });
//        listView.getLayoutParams().height=itemSize+LocalDisplay.dp2px(20);
//        listView.setDividerWidth(LocalDisplay.dp2px(7));
//        adapter = new MyAdapter(parent.getContext());
//        listView.setAdapter(adapter);
//        listView.setOnItemClickListener(new OnItemScaleClickListener() {
//            @Override
//            public void onItemClickScaled(AdapterView<?> parent, View view, int position, long id) {
//                super.onItemClickScaled(parent, view, position, id);
//                if (position<adapter.getCount()) {
//                    RedirectInfo redirectInfo = adapter.getItem(position);
//                    RedirectActivity.startActivity(context,redirectInfo);
//
//                    if (redirectInfo.getRedirectId()==-1) {
//                        UserHabitService.getInstance().track(UserHabitService.newUserHabit("",
//                                "click_more_orgbutton", TimeUtil.currentMiliTime()));
//                        //
//                    }
//                }
//            }
//        });

        return view;
    }

    protected void doItemClick(int position){
        if (position < adapter.getCount()) {
            String string = redirectInfos.get(position).getRedirectUri();
//                    https://cdn.hhdd.com/frontend/author/index.html#/author-detail/1365
            String[] redirectId = string.split("author-detail/");

            RedirectInfo redirectInfo = adapter.getItem(position);
            RedirectActivity.startActivity(context, redirectInfo);
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(redirectId[1]+","+position + "","story_home_all_host_list_click",  TimeUtil.currentTime()));
        }
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null) return;
        if (itemData.getItemList().size() == 0) return;

        redirectInfos = new ArrayList<>();
        for (BaseModel baseModel : itemData.getItemList()) {
            if (baseModel instanceof RedirectInfo) {
                redirectInfos.add((RedirectInfo) baseModel);
            }
            if (redirectInfos.size() >= 6) break;
        }
//        RedirectInfo moreOrgs = new RedirectInfo();
//        moreOrgs.setImageUrl( "res://"+context.getPackageName()+"/"+R.drawable.btn_slide_more);
//        moreOrgs.setRedirectUri("kada://openorglisthome");
//        moreOrgs.setRedirectId(-1);
//        redirectInfos.add(moreOrgs);
        //解决华为手机更新数目，高度没有刷新问题
        adapter = new GridViewAdapter(context);
        adapter.replaceAll(redirectInfos);
        gridView.setAdapter(adapter);
    }

//    class MyAdapter extends QuickAdapter<RedirectInfo> {
//
//        public MyAdapter(Context context) {
//            super(context, R.layout.view_holder_datalist_orgslide_item);
//        }
//
//        @Override
//        protected void convert(BaseAdapterHelper helper, RedirectInfo item) {
//
//            View view = helper.getView(R.id.item_container);
//            view.getLayoutParams().width=itemSize;
////            view.getLayoutParams().height=itemSize;
//
//            SimpleDraweeView draweeView = helper.getView(R.id.cover);
//            draweeView.getLayoutParams().width=itemSize;
//            draweeView.getLayoutParams().height=itemSize;
//
//            TextView title = helper.getView(R.id.title);
//            title.setText(item.getTitle());
//
//            if (item.getImageUrl()!=null ) {
//                FrescoUtils.showUrl(item.getImageUrl(),draweeView,itemSize,itemSize);
//            }
//        }
//    }

    class GridViewAdapter extends QuickAdapter<RedirectInfo> {

        public GridViewAdapter(Context context) {
            super(context, R.layout.view_holder_datalist_storycate_page_item);
        }

        @Override
        protected void convert(BaseAdapterHelper helper, RedirectInfo item) {

            View view = helper.getView(R.id.item_container);
            view.getLayoutParams().width = itemSize;
            view.getLayoutParams().height = itemSize+LocalDisplay.dp2px(2);

            TextView title = helper.getView(R.id.title);
            title.setText(item.getTitle());


            int width = itemSize - LocalDisplay.dp2px(40);//view.getWidth();
            int height = itemSize - LocalDisplay.dp2px(40);//view.getHeight();
            SimpleDraweeView draweeView = helper.getView(R.id.cover);
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) draweeView.getLayoutParams();
            params.width = width;
            params.height = height;

            if (item.getImageUrl() != null) {
                String coverUrl = CdnUtils.getImgCdnUrl(item.getImageUrl(), CdnUtils.SIZE_320x320);
                boolean needResetImageUrl = true;
                if (draweeView.getTag(R.id.list_item_image_url) != null) {
                    String url = (String) draweeView.getTag(R.id.list_item_image_url);
                    if (TextUtils.equals(url, coverUrl)) {
                        needResetImageUrl = false;
                    }
                }
                if (needResetImageUrl) {
                    draweeView.setTag(R.id.list_item_image_url, coverUrl);
//                    FrescoUtils.showUrl(coverUrl, draweeView, width, height);
                    FrescoUtils.showImg(draweeView, coverUrl, width, height);
                }
            }

        }
    }
}