package com.hhdd.kada.main.viewholders;

import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.MotherExcellentStoryItemView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.viewholders
 */
public class MotherExcellentStoryViewHolder extends BaseViewHolder<BaseModelListVO> implements OnChildViewClickListener{

    @BindView(R.id.layout)
    LinearLayout layout;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_mother_excellent_story;
    }

    @Override
    public void showData(final int position, BaseModelListVO itemData) {
        if(itemData != null && itemData.getItemList().size() > 0){
            layout.setVisibility(View.VISIBLE);
            for (int i = 0; i < itemData.getItemList().size(); i++){
                if(itemData.getItemList().get(i) instanceof StoryCollectionInfo){
                    StoryCollectionInfo storyCollectionInfo = (StoryCollectionInfo) itemData.getItemList().get(i);
                    if(layout.getChildCount() > i && layout.getChildAt(i) instanceof MotherExcellentStoryItemView){
                        MotherExcellentStoryItemView motherExcellentStoryItemView = (MotherExcellentStoryItemView) layout.getChildAt(i);
                        motherExcellentStoryItemView.setVisibility(View.VISIBLE);
                        motherExcellentStoryItemView.update(storyCollectionInfo);
                        motherExcellentStoryItemView.setOnChildViewClickListener(this);
                    }
                }
            }
            if(layout.getChildCount() > itemData.getItemList().size()){
                for (int i = itemData.getItemList().size(); i < layout.getChildCount(); i++){
                    layout.getChildAt(i).setVisibility(View.INVISIBLE);
                }
            }
        }else {
            layout.setVisibility(View.GONE);
        }
    }

    /**
     * 点击听书合集
     * @param obj
     */
    private void doStoryCollectionClick(Object obj) {
        if (obj != null && obj instanceof StoryCollectionInfo) {
            StoryCollectionInfo collectionInfo = (StoryCollectionInfo) obj;
            FragmentUtil.presentFragment(StoryCollectionFragment.class, collectionInfo.getCollectId(), true);
            if (!TextUtils.isEmpty(collectionInfo.getSourceKey())) {
                RedirectInfo.SourceKeyStatInfo statInfo = RedirectInfo.SourceKeyStatInfo.parse(collectionInfo.getSourceKey());
                if (statInfo != null) {
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(statInfo.getContent(), statInfo.getName(), TimeUtil.currentTime()));
                }
            }
        }
    }

    @Override
    public void onChildViewClick(View childView, int action, Object obj) {
        doStoryCollectionClick(obj);
    }
}
