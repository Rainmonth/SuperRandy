package com.hhdd.kada.main.viewholders;

import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import java.util.List;

/**
 * Created by simon on 9/20/16.
 */
public class StoryListViewHolder extends BaseViewHolder<BaseModelListVO> {

    public static final int TYPE_STORY_LIST_ITEM_CLICKED = 1000;

    int mItemWidth;
    int coverItemWidth;
    View view;
    ViewGroup container;

    public StoryListViewHolder() {

        int itemMarginLeft = LocalDisplay.dp2px(11);
        int itemMarginRight = LocalDisplay.dp2px(11);

//        int itemSpacing = LocalDisplay.dp2px(2);
        int screenWidth = ScreenUtil.getScreenWidth();
        mItemWidth = (int) ((screenWidth - itemMarginLeft - itemMarginRight
//                - 2 * itemSpacing
        ) / 3.0f);
        coverItemWidth = mItemWidth;//- LocalDisplay.dp2px(3);

    }

    @Override
    public View createView(final ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_story_list, parent, false);
        container = (ViewGroup) view.findViewById(R.id.main_container);

        container.getLayoutParams().height = mItemWidth;
        container.getLayoutParams().width = ScreenUtil.getScreenWidth();
        for (int index = 0; index < container.getChildCount(); index++) {

            final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(index));
            final CustomStoryView customStoryView = (CustomStoryView) frameLayout.getChildAt(0);
//            final TextView clickCount = (TextView) frameLayout.getChildAt(2);

//            Drawable drawable = parent.getContext().getResources().getDrawable(R.drawable.icon_discover_relisten);
//            drawable.setBounds(0, 0, drawable.getMinimumWidth(), drawable.getMinimumHeight());
//            clickCount.setCompoundDrawables(drawable, null, null, null);

            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) frameLayout.getLayoutParams();
            FrameLayout.LayoutParams coverParams = (FrameLayout.LayoutParams) customStoryView.getLayoutParams();

            params.width = mItemWidth;
            params.height = mItemWidth;
            coverParams.width = coverItemWidth;
            coverParams.height = coverItemWidth;

            if ((index + 1) % 3 == 0) {
                params.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
            } else if ((index + 1) % 3 == 1) {
                params.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
            } else {
                params.gravity = Gravity.CENTER;
            }

            coverParams.gravity = Gravity.LEFT | Gravity.BOTTOM;
            customStoryView.setLayoutParams(coverParams);
            customStoryView.setPlaceHolder(R.drawable.books_two_square);
            frameLayout.setLayoutParams(params);

            frameLayout.setOnClickListener(listener);
        }
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {

        List<BaseModel> list = itemData.getItemList();
        if (list != null && list.size() > 0) {
            int count = list.size() > 3 ? 3 : list.size();
            for (int i = 0; i < count; i++) {

                final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(i));
                CustomStoryView customStoryView = (CustomStoryView) frameLayout.getChildAt(0);
                ImageView flag = (ImageView) frameLayout.getChildAt(1);
                ImageView newFlag = (ImageView) frameLayout.findViewById(R.id.new_flag);
                ImageView freeFlag = (ImageView) frameLayout.findViewById(R.id.free_flag);
                View charge = frameLayout.findViewById(R.id.charge);
                newFlag.setVisibility(View.GONE);
                charge.setVisibility(View.GONE);
                freeFlag.setVisibility(View.GONE);
//                customStoryView.showGoldBorder(false);
                customStoryView.showBottomShadow();
                frameLayout.setVisibility(View.VISIBLE);
                if (list.get(i) instanceof StoryListItem) {
                    StoryListItem item = (StoryListItem) list.get(i);
                    if (item.getData() != null && item.getData() instanceof StoryInfo) {
                        StoryInfo info = (StoryInfo) item.getData();
                        customStoryView.hideCollectionBg();
                        customStoryView.showStoryTitle(info.getName());
                        customStoryView.setStoryTitleHeight((mItemWidth - LocalDisplay.dp2px(6) * 2) / 2);
                        dealWithIconFlags(info.getExtFlag(), flag, newFlag, freeFlag, charge);

                        if (info.getStoryId() == 0) {
                            customStoryView.cancelRound();
                            String coverUrl = "res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.icon_story_add;

                            customStoryView.showUrl(coverUrl, coverItemWidth, coverItemWidth);
                            customStoryView.setTag(R.id.book_list_item_image_url, coverUrl);

//                            clickCount.setVisibility(View.GONE);
                        } else {
                            customStoryView.setRound();
                            String coverUrl = info.getCoverUrl();
                            boolean needResetImageUrl = true;
                            if (customStoryView.getTag(R.id.book_list_item_image_url) != null) {
                                String url = (String) customStoryView.getTag(R.id.book_list_item_image_url);
                                if (TextUtils.equals(url, coverUrl)) {
                                    needResetImageUrl = false;
                                }
                            }
                            if (needResetImageUrl) {
                                customStoryView.setTag(R.id.book_list_item_image_url, coverUrl);
                                customStoryView.showUrl(coverUrl, coverItemWidth, coverItemWidth);
                            }

//                            clickCount.setVisibility(View.VISIBLE);
//                            clickCount.setText(StringUtil.formatClickCount(info.getClickCount()));
                        }

                        frameLayout.setTag(R.id.view_holder_item, item);
                    } else if (item.getData() != null && item.getData() instanceof StoryCollectionInfo) {
                        StoryCollectionInfo info = (StoryCollectionInfo) item.getData();
                        customStoryView.showCollectionBg(R.drawable.bg_story_collect);
                        customStoryView.hideStoryTitle();
//                        coverContainer.setBackgroundResource(R.drawable.bg_story_collect);
//                        cover.getLayoutParams().width = coverItemWidth - LocalDisplay.dp2px(4);
//                        cover.getLayoutParams().height = coverItemWidth - LocalDisplay.dp2px(6);
                        dealWithIconFlags(info.getExtFlag(), flag, newFlag, freeFlag, charge);
//                        customStoryView.showGoldBorder(isCharge);
                        String coverUrl = info.getCoverUrl();
                        boolean needResetImageUrl = true;
                        if (customStoryView.getTag(R.id.book_list_item_image_url) != null) {
                            String url = (String) customStoryView.getTag(R.id.book_list_item_image_url);
                            if (TextUtils.equals(url, coverUrl)) {
                                needResetImageUrl = false;
                            }
                        }
                        if (needResetImageUrl) {
                            customStoryView.setTag(R.id.book_list_item_image_url, coverUrl);
                            customStoryView.showUrl(coverUrl, coverItemWidth, coverItemWidth);
                        }
                        customStoryView.setRound();

//                        clickCount.setVisibility(View.VISIBLE);
//                        clickCount.setText(StringUtil.formatClickCount(info.getClickCount()));

                        frameLayout.setTag(R.id.view_holder_item, item);
                    } else {
                        frameLayout.setVisibility(View.GONE);
                    }

                    customStoryView.setMode(item.getPlayMode());
                }
            }

            for (int i = count; i < 3; i++) {
                final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(i));
                frameLayout.setVisibility(View.GONE);
                frameLayout.setTag(R.id.view_holder_item, null);
            }
        }

    }

    /**
     * 处理各种标记的显示
     *
     * @param extFlag  标记对应的值
     * @param flag     官方推荐
     * @param newFlag  最新
     * @param freeFlag 限免（客户端对全用户限免和新用户限免不予区分统一处理）
     * @param charge   付费
     */
    private void dealWithIconFlags(long extFlag, ImageView flag,
                                   ImageView newFlag,
                                   ImageView freeFlag,
                                   View charge) {
        if ((extFlag & Extflag.STORY_EXT_FLAG_8) == Extflag.STORY_EXT_FLAG_8) {
            flag.setVisibility(View.VISIBLE);
            flag.setImageResource(R.drawable.icon_hot_flag);
        } else {
            if ((extFlag & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4) {
                newFlag.setVisibility(View.VISIBLE);
                newFlag.setImageResource(R.drawable.icon_story_new_flag);
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) newFlag.getLayoutParams();
                params.setMargins(0, 0, LocalDisplay.dp2px(7), 0);
                newFlag.setLayoutParams(params);
            } else {
                newFlag.setVisibility(View.GONE);
            }
            flag.setVisibility(View.GONE);
        }
        boolean isLimitFree = ((extFlag & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW) ||
                ((extFlag & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL);
        //收费标志
        boolean isCharge = (extFlag & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32;
        if (isLimitFree) {
            freeFlag.setVisibility(View.VISIBLE);
            charge.setVisibility(View.GONE);
        } else {
            freeFlag.setVisibility(View.GONE);
            if (isCharge) {
                charge.setVisibility(View.VISIBLE);
            } else {
                charge.setVisibility(View.GONE);
            }
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            mOnEventProcessor.process(TYPE_STORY_LIST_ITEM_CLICKED, v.getTag(R.id.view_holder_item));
        }
    };

}
