package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.Transformer;
import com.youth.banner.listener.OnBannerListener;
import com.youth.banner.loader.ImageLoaderInterface;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by simon on 5/4/16.
 */
public class BannerViewHolder extends BaseViewHolder<BaseModelListVO> {

    View view;
    Banner banner;
    int height;
    int width;
    Context mContext;

//    List<RedirectInfo> redirectInfos = new ArrayList<>();

    @Override
    public View createView(ViewGroup parent) {
        mContext = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_datalist_banner, parent, false);

        banner = (Banner) view.findViewById(R.id.banner);
        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());

        if (componentContainer!=null) {
            EventCenter.bindContainerAndHandler(componentContainer, new SimpleEventHandler() {

                @Override
                public void onBecomesVisible() {
                    super.onBecomesVisible();
                    banner.startAutoPlay();
                }

                @Override
                public void onBecomesTotallyInvisible() {
                    super.onBecomesTotallyInvisible();
                    banner.stopAutoPlay();
                }

                @Override
                public void onBecomesVisibleFromTotallyInvisible() {
                    super.onBecomesVisibleFromTotallyInvisible();
                    banner.startAutoPlay();
                }

            }).tryToRegisterIfNot();
        }
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null) return;
        if (itemData.getItemList().size() == 0) return;

        final List<RedirectInfo> redirectInfos = new ArrayList<>();

        for (BaseModel baseModel : itemData.getItemList()) {
            if (baseModel instanceof RedirectInfo) {
                redirectInfos.add((RedirectInfo) baseModel);
            }
        }

        if (redirectInfos.size() > 0) {
            RedirectInfo redirectInfo = redirectInfos.get(0);
            if (redirectInfo.getHeight() > 0) {
                height = (int) (redirectInfo.getHeight() * LocalDisplay.SCREEN_WIDTH_PIXELS / 320);
                banner.getLayoutParams().height = height;
            }
        }

        banner.setOnBannerListener(new OnBannerListener() {
            @Override
            public void OnBannerClick(int position) {
                if (position < redirectInfos.size() && mContext != null) {
                    RedirectActivity.startActivity(mContext, redirectInfos.get(position));
                }
            }
        });
        //设置图片集合
        banner.setImages(redirectInfos);
        //设置banner动画效果
        banner.setBannerAnimation(Transformer.Default);
        //设置banner样式
        banner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
        //设置自动轮播，默认为true
        banner.isAutoPlay(true);
        //设置轮播时间
        banner.setDelayTime(4000);
        //设置指示器位置（当banner模式中有指示器时）
        banner.setIndicatorGravity(BannerConfig.CENTER);
        //banner设置方法全部调用完毕时最后调用
        banner.start();

    }


    public class GlideImageLoader implements ImageLoaderInterface<ScaleDraweeView> {
        @Override
        public void displayImage(Context context, Object path, ScaleDraweeView imageView) {
            /**
             注意：
             1.图片加载器由自己选择，这里不限制，只是提供几种使用方法
             2.返回的图片路径为Object类型，由于不能确定你到底使用的那种图片加载器，
             传输的到的是什么格式，那么这种就使用Object接收和返回，你只需要强转成你传输的类型就行，
             切记不要胡乱强转！
             */


            //用fresco加载图片简单用法，记得要写下面的createImageView方法
            if (path != null && path instanceof RedirectInfo) {
                FrescoUtils.showUrl(((RedirectInfo) path).getImageUrl(), imageView, width, height);
            }
        }

        //提供createImageView 方法，如果不用可以不重写这个方法，主要是方便自定义ImageView的创建
        @Override
        public ScaleDraweeView createImageView(Context context) {
            //使用fresco，需要创建它提供的ImageView，当然你也可以用自己自定义的具有图片加载功能的ImageView
            View view = View.inflate(context, R.layout.view_holder_datalist_banner_item, null);
            ScaleDraweeView simpleDraweeView = (ScaleDraweeView) view.findViewById(R.id.datalist_banner_item_cover);
            return simpleDraweeView;
        }
    }
}
