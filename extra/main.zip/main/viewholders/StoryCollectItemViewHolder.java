package com.hhdd.kada.main.viewholders;

import android.graphics.Color;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.download.DownloadItemType;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.download.DownloadStatusVO;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.ui.story.CircleProgressBar;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.views.VisualizerView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import java.util.List;

import static com.hhdd.kada.Constants.PAUSE_MODE;
import static com.hhdd.kada.Constants.PLAY_MODE;

/**
 * Created by lj on 17/4/25.
 */

public class StoryCollectItemViewHolder extends BaseViewHolder<BaseModelListVO> {

    public static final int TYPE_STORY_COLLECT_TIEM_CLICKED = 200;

    int mItemWidth;
    int coverItemWidth;
    int itemSpacing;
    View view;
    ViewGroup container;

    public StoryCollectItemViewHolder() {

        int itemMarginLeft = LocalDisplay.dp2px(16);
        int itemMarginRight = LocalDisplay.dp2px(16);

        itemSpacing = LocalDisplay.dp2px(12);
        int screenWidth = ScreenUtil.getScreenWidth();
        mItemWidth = (int) ((screenWidth - itemMarginLeft - itemMarginRight - 2 * itemSpacing) / 3.0f);
        coverItemWidth = mItemWidth;
    }

    @Override
    public View createView(final ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_story_collect_list, parent, false);
        container = (ViewGroup) view.findViewById(R.id.main_container);
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {

        List<BaseModel> list = itemData.getItemList();
        if (list != null && list.size() > 0) {
            int count = list.size() > 3 ? 3 : list.size();

            for (int i = 0; i < count; i++) {
                final FrameLayout layout = ((FrameLayout) container.getChildAt(i));
                final View container = layout.findViewById(R.id.main_container);
                SimpleDraweeView cover = (SimpleDraweeView) layout.findViewById(R.id.cover);
                final TextView name = (TextView) layout.findViewById(R.id.name);
                TextView clickCount = (TextView) layout.findViewById(R.id.click_count);
                TextView date = (TextView) layout.findViewById(R.id.date);
                TextView storyTitle = (TextView) layout.findViewById(R.id.story_title);
                View listenFlagView = layout.findViewById(R.id.listen_flag); //是否已听
                View downloadFlagView = layout.findViewById(R.id.has_downloaded);
                View alphaContainer = layout.findViewById(R.id.alpha_container); //加锁
                View progressContainer = layout.findViewById(R.id.alpha_container2);   //单本下载进度
                View newFlag = layout.findViewById(R.id.new_flag);
                ImageView lock = (ImageView) layout.findViewById(R.id.lock_view);
                TextView countLeft = (TextView) layout.findViewById(R.id.tv_count_left); //还剩多少集未更新
                CircleProgressBar progressBar = (CircleProgressBar) layout.findViewById(R.id.download_progress_per);

                downloadFlagView.setVisibility(View.GONE);
                listenFlagView.setVisibility(View.GONE);
                newFlag.setVisibility(View.GONE);

                container.setOnClickListener(onContainerClicked);

                if (list.get(i) instanceof StoryListItem) {
                    final StoryListItem item = (StoryListItem) list.get(i);

                    FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) layout.getLayoutParams();
                    FrameLayout.LayoutParams containerLayoutParams = (FrameLayout.LayoutParams) container.getLayoutParams();

                    params.width = mItemWidth;
                    params.height = mItemWidth;

                    containerLayoutParams.width = coverItemWidth;
                    containerLayoutParams.height = coverItemWidth;

                    if ((i + 1) % 3 == 0) {
                        params.gravity = Gravity.RIGHT;
                    } else if ((i + 1) % 3 == 1) {
                        params.gravity = Gravity.LEFT;
                    } else {
                        params.gravity = Gravity.CENTER;
                    }
                    layout.setLayoutParams(params);

                    if (item.getData() != null && item.getData() instanceof StoryInfo) {
                        layout.setVisibility(View.VISIBLE);
                        StoryInfo info = (StoryInfo) item.getData();
                        // 显示标题
                        if (!TextUtils.isEmpty(info.getName())) {
                            storyTitle.setText(info.getName());
                        }
                        boolean isHideLock = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_256) == Extflag.STORY_EXT_FLAG_256 ||
                                item.getSubscribeStatus() == 1;
                        boolean isDownloadFinish = false;
                        //已听标志 加锁不显示已听标志
                        if (isHideLock && DatabaseManager.getInstance().listenhistoryDB().exist(info.getStoryId(), info.getCollectId())) {
                            listenFlagView.setVisibility(View.VISIBLE);
                        } else {
                            listenFlagView.setVisibility(View.GONE);
                        }

                        //已下载标志
                        if (((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).isStoryDownloadCompletion(info.getStoryId())) {
                            // 1、检查单本下载表记录
                            downloadFlagView.setVisibility(View.VISIBLE);
                            isDownloadFinish = true;
                        } else if (DatabaseManager.getInstance().collectionItemStatusDB().isDownloadFinish(info.getStoryId())) {
                            // 2、检查合辑状态表
                            downloadFlagView.setVisibility(View.VISIBLE);
                            isDownloadFinish = true;
                        } else {
                            downloadFlagView.setVisibility(View.GONE);
                        }

                        if (item.getCollectStatus() == StoryListItem.STATUS_FREE) {
                            alphaContainer.setVisibility(View.GONE);
                            DownloadStatusVO downloadStatusVO = item.getDownloadStatusVO();
                            if (downloadStatusVO != null) {
                                if (downloadStatusVO.isDownloadedComplete() || isDownloadFinish) {
                                    progressContainer.setVisibility(View.GONE);
                                    progressBar.setVisibility(View.GONE);
                                } else if (downloadStatusVO.isDownloading()) {
                                    progressContainer.setVisibility(View.VISIBLE);
                                    progressBar.setVisibility(View.VISIBLE);
                                } else {
                                    progressContainer.setVisibility(View.GONE);
                                    progressBar.setVisibility(View.GONE);
                                }
                            } else {
                                progressContainer.setVisibility(View.GONE);
                                progressBar.setVisibility(View.GONE);
                            }
                        } else {
                            //试听
                            if (isHideLock) {
                                alphaContainer.setVisibility(View.GONE);
                            } else {
                                alphaContainer.setVisibility(View.VISIBLE);
                            }
                        }
                        String coverUrl = info.getCoverUrl();
                        if (info.isPlaceholder()) {
                            container.setBackgroundResource(R.drawable.icon_last_holder);
                            cover.setPadding(0, LocalDisplay.dp2px(5), LocalDisplay.dp2px(5), 0);
                            alphaContainer.setVisibility(View.VISIBLE);
                        } else {
                            container.setBackgroundResource(R.color.transparent);
                            cover.setPadding(0, 0, 0, 0);

                        }
                        boolean needResetImageUrl = true;
                        if (cover.getTag(R.id.book_list_item_image_url) != null) {
                            String url = (String) cover.getTag(R.id.book_list_item_image_url);
                            if (TextUtils.equals(url, coverUrl)) {
                                needResetImageUrl = false;
                            }
                        }
                        if (needResetImageUrl) {
                            cover.setTag(R.id.book_list_item_image_url, coverUrl);

                            String imgUrl = CdnUtils.getImgCdnUrl(coverUrl, CdnUtils.getStoryCoverSize(), true);
                            FrescoUtils.showImg(cover, imgUrl, coverItemWidth, coverItemWidth);
                        }

                        if (info.isPlaceholder()) {
                            name.setText("未完待续");
                            countLeft.setText(info.getLeftCount() + "集\n待更新");
                            countLeft.setVisibility(View.VISIBLE);
                        } else {
                            name.setText(info.getName());
                            countLeft.setVisibility(View.GONE);
                        }

//                        if (item.isFromUser() || item.getSubscribeStatus() == 1) {
                        if (item.getSubscribeStatus() == 1) {
                            name.setTextColor(Color.WHITE);
                        } else {
                            name.setTextColor(Color.BLACK);
                        }

                        if (item.getSubscribeStatus() == 1) {
                            lock.setVisibility(View.GONE);
                        } else {
                            lock.setVisibility(View.VISIBLE);
                        }

                        boolean isLimitFree = (info.getCollectExtFlag() & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL ||  // 全用户限免           // 全用户限免
                                (info.getCollectExtFlag() & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW;                  // 新用户限免

                        if (isLimitFree) {
                            alphaContainer.setVisibility(View.GONE);
                        }

                        clickCount.setText(StringUtil.formatClickCount(info.getClickCount()));

                        if ((info.getExtFlag() & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4) {
                            newFlag.setVisibility(View.VISIBLE);
                        } else {
                            newFlag.setVisibility(View.GONE);
                        }

                        container.setTag(R.id.view_holder_item, info);

                        String tag = "" + info.getStoryId() + "_" + DownloadItemType.STORY;
                        layout.setTag(tag);
                    } else {
                        layout.setVisibility(View.GONE);
                    }

                    item.setItemView(layout);

                    setMode(item.getPlayMode(), layout);
                } else {
                    layout.setVisibility(View.GONE);
                }
            }


            for (int i = count; i < 3; i++) {
                final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(i));
                frameLayout.setVisibility(View.GONE);
                frameLayout.setTag(R.id.view_holder_item, null);
            }
        }

    }


    public void setMode(int mode, FrameLayout view) {
        VisualizerView mVisualView = null;
        Object o = view.getTag(R.id.listen_visualview);
        if (o != null && o instanceof VisualizerView) {
            mVisualView = (VisualizerView) o;
        }
        if (mode == PLAY_MODE) {
            if (mVisualView == null) {
                mVisualView = new VisualizerView(container.getContext());
                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(coverItemWidth / 2, coverItemWidth / 2);
                params.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                mVisualView.setBackgroundResource(R.drawable.round_corner_visual_view);
                params.setMargins(0, LocalDisplay.dp2px(coverItemWidth / 10), 0, 0);
                view.addView(mVisualView, params);
                view.setTag(R.id.listen_visualview, mVisualView);
            }
            mVisualView.setVisibility(View.VISIBLE);
            mVisualView.setDrawing(true);
        } else if (mode == PAUSE_MODE) {
            if (mVisualView != null) {
                mVisualView.setDrawing(false);
            }
        } else {
            if (mVisualView != null) {
                mVisualView.setDrawing(false);
                mVisualView.setVisibility(View.GONE);
            }
        }
    }

    private KaDaApplication.OnClickWithAnimListener onContainerClicked = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            Object object = v.getTag(R.id.view_holder_item);
            mOnEventProcessor.process(TYPE_STORY_COLLECT_TIEM_CLICKED, object);
        }
    };
}