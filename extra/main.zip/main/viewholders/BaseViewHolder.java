package com.hhdd.kada.main.viewholders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.android.library.app.lifecycle.IComponentContainer;
import com.hhdd.kada.main.viewholders.mvc.BaseMvcViewHolder;
import com.hhdd.kada.main.vo.BaseVO;

import butterknife.ButterKnife;

/**
 * Created by simon on 6/13/16.
 */
public abstract class BaseViewHolder<ItemDataType extends BaseVO> extends BaseMvcViewHolder<ItemDataType> {

    protected IComponentContainer componentContainer;
    protected View rootView;

    public BaseViewHolder() {
        int layoutId = getLayoutId();
        if (layoutId > 0) {
            rootView = LayoutInflater.from(KaDaApplication.applicationContext()).inflate(layoutId, null);
            ButterKnife.bind(this, rootView);
        }
    }

    protected int getLayoutId() {
        return 0;
    }

    @Override
    public View createView(ViewGroup parent) {
        return rootView;
    }

    public void setComponentContainer(IComponentContainer componentContainer) {
        this.componentContainer = componentContainer;
    }
}
