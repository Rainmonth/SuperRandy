package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.LinearLayout;

import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author: Randy Zhang
 * @description: 听书协议跳转ViewHolder（两张大图）
 * @created: 2018/8/30
 **/
public class StorySchemaTwoColViewHolder extends BaseViewHolder<BaseModelListVO> {
    private Context context;
    private GridView gridView;
    private StorySchemaTwoColAdapter adapter;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_story_schema_two_col;
    }

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.view_holder_story_schema_two_col, parent, false);
        gridView = (GridView) view.findViewById(R.id.gridview);
        gridView.setNumColumns(2);
        adapter = new StorySchemaTwoColAdapter(context);
        gridView.setAdapter(adapter);
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null) return;
        if (itemData.getItemList().size() == 0) return;
        List<RedirectInfo> listItems = new ArrayList<>();

//        if(itemData.getItemList().size() % 2 == 1)// (可扩展)保证一行两列为基本单位，根据需求选择注释该限制 1*2 2*2 3*2....
//            itemData.getItemList().remove(itemData.getItemList().size() - 1);

        List<BaseModel> tempList = new ArrayList<>();

        if (itemData.getItemList().size() >= 3) {//以1x2为单位显示 只显示2个
            tempList.add(itemData.getItemList().get(0));
            tempList.add(itemData.getItemList().get(1));
        } else {
            tempList = itemData.getItemList();
        }


        for (BaseModel baseModel : tempList) {
            if (baseModel instanceof RedirectInfo) {
                listItems.add((RedirectInfo) baseModel);
            }
        }

        gridView.setAdapter(adapter);
        adapter.replaceAll(listItems);
    }

    private class StorySchemaTwoColAdapter extends QuickAdapter<RedirectInfo> {
        private int itemWidth, itemHeight;

        public StorySchemaTwoColAdapter(Context context) {
            super(context, R.layout.view_holder_story_schema_two_col_item);
            itemWidth = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(10 + 10 + 10)) / 2;
            itemHeight = itemWidth;
        }

        @Override
        protected void convert(BaseAdapterHelper helper, final RedirectInfo redirectInfo) {
            // View初始化相关工作
            ScaleDraweeView cover = helper.getView(R.id.cover);
            // 数据初始化相关工作
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(itemWidth, itemHeight);
            cover.setLayoutParams(layoutParams);

            String imgUrl = CdnUtils.getImgCdnUrl(redirectInfo.getImageUrl(), CdnUtils.getTwoCoverImgSize());
            FrescoUtils.showImg(cover, imgUrl);

            cover.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(View v) {
                    // 协议跳转处理
                    RedirectActivity.startActivity(context, redirectInfo);
                }
            });
        }

    }
}
