package com.hhdd.kada.main.viewholders;

import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.widget.CollectionRecommendView;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/3/23
 * @describe : com.hhdd.kada.main.viewholders
 */
public class CollectionRecommendViewHolder extends BaseViewHolder<BaseModelVO> {

    @BindView(R.id.collectionRecommendView)
    CollectionRecommendView collectionRecommendView;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_collection_recommend;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        if (itemData != null) {
            BaseModel model = itemData.getModel();
            collectionRecommendView.update(model);
        }
    }
}
