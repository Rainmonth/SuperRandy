package com.hhdd.kada.main.viewholders;

import com.hhdd.kada.main.vo.BaseModelListVO;

/**
 * @author: Randy Zhang
 * @description: 听书标题ViewHolder（带子标题和URL Schema跳转）
 * @created: 2018/8/30
 **/
public class StoryComplexTitleViewHolder extends BaseViewHolder<BaseModelListVO> {
    @Override
    public void showData(int position, BaseModelListVO itemData) {

    }
}
