package com.hhdd.kada.main.viewholders;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryHistoryInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.vo.BaseModelVO;

/**
 * Created by lj on 17/2/8.
 */

public class StoryHistoryViewHolder extends BaseViewHolder<BaseModelVO> {

    public static final int TYPE_STORY_HISTORY_ITEM_CLICKED = 100;

    CustomStoryView customStoryView;
    int mItemWidth;

    public StoryHistoryViewHolder() {

        int itemSpacing = LocalDisplay.dp2px(3);
        int screenWidth = ScreenUtil.getScreenWidth();
        mItemWidth = (int) ((screenWidth - 2 * itemSpacing) / 3.0f);
    }

    @Override
    public View createView(final ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.view_holder_story_item, parent, false);

        View container = view.findViewById(R.id.container);
        container.getLayoutParams().height = mItemWidth;

        customStoryView = (CustomStoryView) view.findViewById(R.id.cover_container);
        customStoryView.getLayoutParams().height = mItemWidth;
        customStoryView.getLayoutParams().width = mItemWidth;
        customStoryView.setPlaceHolder(R.drawable.books_two_square);
        customStoryView.setOnClickListener(listener);

//        if (componentContainer != null) {
//            EventCenter.bindContainerAndHandler(componentContainer, new SimpleEventHandler() {
//
//                public void onEvent(StoryService.StartReadingEvent event) {
//                    setPlayMode(event.getStoryInfo(),PLAY_MODE);
//                }
//
//                public void onEvent(StoryService.PauseReadingEvent event) {
//                    setMode(STOP_MODE, -1);
//                }
//
//                public void onEvent(StoryService.StopReadingEvent event) {
//                    setMode(STOP_MODE, -1);
//                }
//            }).tryToRegisterIfNot();
//        }

        return view;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {

        BaseModel model = itemData.getModel();

        if (model instanceof StoryListItem) {
            StoryListItem item = (StoryListItem) model;
            if (item.getData() != null && item.getData() instanceof StoryHistoryInfo) {
                StoryHistoryInfo info = (StoryHistoryInfo) item.getData();
                String coverUrl = info.getCoverUrl();
                boolean needResetImageUrl = true;
                if (customStoryView.getTag(R.id.list_item_image_url) != null) {
                    String url = (String) customStoryView.getTag(R.id.list_item_image_url);
                    if (TextUtils.equals(url, coverUrl)) {
                        needResetImageUrl = false;
                    }
                }
                if (needResetImageUrl) {
                    customStoryView.setTag(R.id.list_item_image_url, coverUrl);
                    customStoryView.showUrl(coverUrl, mItemWidth, mItemWidth);
                }
                customStoryView.showBottomShadow();
                if (info.getType() == Constants.TYPE_STORY_SINGLE) {
                    customStoryView.hideCollectionBg();
                } else {
                    customStoryView.showCollectionBg(R.drawable.bg_story_collect);
                }
                customStoryView.setRound();

                customStoryView.setMode(item.getPlayMode(), mItemWidth/2,
                        mItemWidth /2);

                customStoryView.setTag(R.id.view_holder_item, info);
            }

        } else {
            customStoryView.setVisibility(View.GONE);
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            Object object = v.getTag(R.id.view_holder_item);
            mOnEventProcessor.process(TYPE_STORY_HISTORY_ITEM_CLICKED, object);
        }
    };
}