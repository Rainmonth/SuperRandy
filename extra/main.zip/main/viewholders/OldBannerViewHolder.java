package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.model.RecommendVO;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.ui.book.BookCollectionListFragment;
import com.hhdd.kada.main.ui.book.BookFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionListFragment;
import com.hhdd.kada.main.ui.story.StoryFragment;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.SafeHandler;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.module.exposure.ExposureTracker;
import com.hhdd.kada.module.exposure.OldBannerShownOnScreenEvent;
import com.hhdd.kada.module.userhabit.bannerstatic.BannerStaticManager;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.Transformer;
import com.youth.banner.listener.OnBannerListener;
import com.youth.banner.loader.ImageLoaderInterface;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;

/**
 * Created by lj on 16/12/13.
 */

public class OldBannerViewHolder extends BaseViewHolder<BaseModelListVO> {

    Context mContext;
    View view;
    Banner banner;

    private static int width, height;

    List<BannerInfo> bannerInfos = new ArrayList<>();

    private SafeHandler mHandler = new SafeHandler();

    private Runnable mSetOnPageChangeListenerRunnable = new Runnable() {
        @Override
        public void run() {
            if (banner != null) {
                if (!bannerInfos.isEmpty()) {
                    BannerInfo bannerInfo = bannerInfos.get(0);
                    BannerStaticManager bannerStaticManager = (BannerStaticManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.BANNER_STATIC_MANAGER);
                    bannerStaticManager.increment(String.valueOf(bannerInfo.getId()));

                    if(mCurrentRealPosition == 0){
                        return;
                    }
                    mCurrentRealPosition = 0;
                    if (!TextUtils.isEmpty(mExposureScene)) {
                        ExposureTracker.getInstance().trackBanner(mExposureScene, bannerInfo);
                    }

                }

                banner.setOnPageChangeListener(mOnPageChangeListener);
            }
        }
    };

    private ViewPager.OnPageChangeListener mOnPageChangeListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            int count = bannerInfos.size();
            if (position <= 0 || position > count) {
                return;
            }

            /**
             * Banner展示统计打点
             */
            int realPosition = banner.toRealPosition(position);
            BannerInfo bannerInfo = bannerInfos.get(realPosition);
            BannerStaticManager bannerStaticManager = (BannerStaticManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.BANNER_STATIC_MANAGER);
            bannerStaticManager.increment(String.valueOf(bannerInfo.getId()));

            if(mCurrentRealPosition == realPosition){
                return;
            }
            mCurrentRealPosition = realPosition;
            if (!TextUtils.isEmpty(mExposureScene) && mShownOnScreen) {
                ExposureTracker.getInstance().trackBanner(mExposureScene, bannerInfo);
            }
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };
    private int mCurrentRealPosition = -1;
    private boolean mShownOnScreen = true;

    public void trackBannerManual() {
        if (mCurrentRealPosition != -1 && mShownOnScreen) {
            BannerInfo bannerInfo = bannerInfos.get(mCurrentRealPosition);
            ExposureTracker.getInstance().trackBanner(mExposureScene, bannerInfo);
        }
    }

    public void onEvent(OldBannerShownOnScreenEvent event) {
        if (event.fromScene.equals(mExposureScene)) {
            if(!mShownOnScreen && event.shown){
                //即将从不可见变为可见
                mShownOnScreen = true;
                trackBannerManual();
            }
            mShownOnScreen = event.shown;
//            if(!mShownOnScreen){
//                mCurrentRealPosition = -1;
//            }
        }
    }

    private OnBannerListener mOnBannerListener = new OnBannerListener() {
        @Override
        public void OnBannerClick(int position) {
            if (position < 0 || position > bannerInfos.size()) {
                return;
            }

            BannerInfo info = bannerInfos.get(position);
            if (info.getKind() == RecommendVO.STORY_BANNER) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "child_story_home_banner_click", TimeUtil.currentTime()));
                if (info.getType() == 1) {
                    if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                        UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openstory", TimeUtil.currentTime()));
                        ListenActivity.startActivity(mContext, Integer.parseInt(info.getContent().trim()));
                    }
                } else if (info.getType() == 4) {
                    if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                        UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openstory_collect", TimeUtil.currentTime()));
                        //新合集
                        FragmentUtil.presentFragment(StoryCollectionFragment.class, Integer.parseInt(info.getContent().trim()), true);
                    }
                } else if (info.getType() == 2) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openhtml", TimeUtil.currentTime()));
                    RedirectActivity.startActivity(mContext, info.getContent());
                } else if (info.getType() == 3) {
                    if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                        UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openstory_category", TimeUtil.currentTime()));
                        //离线下载跳转
//                                if (TextUtils.equals(info.getContent(), "-1")) {
//                                    DownloadListFragment.DownloadListVO vo = new DownloadListFragment.DownloadListVO(DownloadListFragment.STORY_TYPE, null);
//                                    FragmentUtil.pushFragment(DownloadListFragment.class, vo, true);
//                                } else {
//                                    FragmentUtil.pushFragment(CateStoryListFragment.class, new Category(Integer.parseInt(info.getContent().trim()), info.getName()), true);
//                                }
                    }

                } else if (info.getType() == 6) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(String.valueOf(info.getId()), "clickbanner", TimeUtil.currentTime()));
                    RedirectActivity.startActivity(mContext, info.getContent());
                }
            } else if (info.getKind() == RecommendVO.BOOK_BANNER) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "child_book_home_banner_click", TimeUtil.currentTime()));
                if (info.getType() == 1) {
                    if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                        UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openbook", TimeUtil.currentTime()));
                        PlaybackActivity.startActivity(mContext, Integer.parseInt(info.getContent().trim()));
                    }
                } else if (info.getType() == 3) {//type为3后台控制不允许配置年龄分类
                    if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                        UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openbook_category", TimeUtil.currentTime()));
                        BookCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(
                                BookCollectionListFragment.COLLECTION_TYPE_CATEGORY, info.getName(), Integer.parseInt(info.getContent().trim()), 0, 0));
                    }
                } else if (info.getType() == 4) {
                    if (info.getContent() != null && StringUtil.isNumeric(info.getContent())) {
                        UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openbook_collect", TimeUtil.currentTime()));
                        FragmentUtil.pushFragment(BookCollectionFragment.class, Integer.parseInt(info.getContent()), true);
                    }
                } else if (info.getType() == 2) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openhtml", TimeUtil.currentTime()));
                    RedirectActivity.startActivity(mContext, info.getContent());
                } else if (info.getType() == 6) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner", TimeUtil.currentTime()));
                    RedirectActivity.startActivity(mContext, info.getContent());
                }
            } else if (info.getKind() == RecommendVO.MOTHER_EXCELLENT_BANNER || info.getKind() == RecommendVO.MOTHER_BOOK_BANNER || info.getKind() == RecommendVO.MOTHER_STORY_BANNER) {
                if (info.getType() == 6) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner", TimeUtil.currentTime()));
                    RedirectActivity.startActivity(mContext, info.getContent());
                }
            }
        }
    };
    private String mExposureScene = "";

    @Override
    public View createView(ViewGroup parent) {
        EventBus.getDefault().register(this);
        mContext = parent.getContext();

        LayoutInflater layoutInflater = LayoutInflater.from(mContext);
        view = layoutInflater.inflate(R.layout.view_holder_datalist_banner, parent, false);

        banner = (Banner) view.findViewById(R.id.banner);
        width = ScreenUtil.getScreenWidth();
        height = (int) (width * Constants.CHILDREN_BANNER_RATIO);
        banner.getLayoutParams().height = height;

        /**
         * 延时2秒开始接收banner轮训切换
         * 因为首次加载BookFragment的时候{@link #showData(int, BaseModelListVO)}会有多次调用，每次showData->banner.start()方法里面都会调用一次viewPager.setCurrentItem(1);
         * 这样会导致多次统计第一张banner，
         * 这里做延时2秒开始监听banner切换，并在第一次补充丢失的第一张banner图片统计打点
         */
        mHandler.postDelayed(mSetOnPageChangeListenerRunnable, 2000);

        if (componentContainer != null) {
            EventCenter.bindContainerAndHandler(componentContainer, new SimpleEventHandler() {
                @Override
                public void onBecomesVisible() {
                    super.onBecomesVisible();

                    if (banner != null && !bannerInfos.isEmpty()) {
                        banner.startAutoPlay();
                    }
                }

                @Override
                public void onBecomesTotallyInvisible() {
                    super.onBecomesTotallyInvisible();

                    if (banner != null && !bannerInfos.isEmpty()) {
                        banner.stopAutoPlay();
                    }
                }

                @Override
                public void onBecomesVisibleFromTotallyInvisible() {
                    super.onBecomesVisibleFromTotallyInvisible();

                    if (banner != null && !bannerInfos.isEmpty()) {
                        banner.startAutoPlay();
                    }
                }
            }).tryToRegisterIfNot();
        }

        return view;
    }

    @Override
    public void onRecycled() {
        EventBus.getDefault().unregister(this);
        super.onRecycled();

        if (banner != null) {
            banner.stopAutoPlay();
        }

    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {

        if (itemData == null || itemData.getItemList() == null || itemData.getItemList().size() == 0) {
            return;
        }
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }

        final int viewType = itemData.getViewType();
        if (viewType == StoryFragment.View_Type_DataList_Old_Banner) {
            mExposureScene = ExposureTracker.SCENE_STORY_HOME_BANNER;
        } else if (viewType == BookFragment.View_Type_Banner) {
            mExposureScene = ExposureTracker.SCENE_BOOK_HOME_BANNER;
        }

        bannerInfos.clear();

        for (BaseModel baseModel : itemData.getItemList()) {
            if (baseModel instanceof BannerInfo) {
                bannerInfos.add((BannerInfo) baseModel);
            }
        }

        banner.setOnBannerListener(mOnBannerListener);
        //设置图片加载器
        banner.setImageLoader(new GlideImageLoader());
        //设置图片集合
        banner.setImages(bannerInfos);
        //设置banner动画效果
        banner.setBannerAnimation(Transformer.Default);
        //设置banner样式
        banner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
        //设置自动轮播，默认为true
        banner.isAutoPlay(true);
        //设置轮播时间
        banner.setDelayTime(4000);
        //设置指示器位置（当banner模式中有指示器时）
        banner.setIndicatorGravity(BannerConfig.CENTER);
        //banner设置方法全部调用完毕时最后调用
        banner.start();

    }

    public static class GlideImageLoader implements ImageLoaderInterface<ScaleDraweeView> {
        @Override
        public void displayImage(Context context, Object path, ScaleDraweeView imageView) {
            /**
             注意：
             1.图片加载器由自己选择，这里不限制，只是提供几种使用方法
             2.返回的图片路径为Object类型，由于不能确定你到底使用的那种图片加载器，
             传输的到的是什么格式，那么这种就使用Object接收和返回，你只需要强转成你传输的类型就行，
             切记不要胡乱强转！
             */


            //用fresco加载图片简单用法，记得要写下面的createImageView方法
            if (path != null && path instanceof BannerInfo) {
                String imgUrl = CdnUtils.getImgCdnUrl(((BannerInfo) path).getBannerUrl(), CdnUtils.getBannerSize());
                FrescoUtils.showImg(imageView, imgUrl, width, height);
            }
        }

        //提供createImageView 方法，如果不用可以不重写这个方法，主要是方便自定义ImageView的创建
        @Override
        public ScaleDraweeView createImageView(Context context) {
            //使用fresco，需要创建它提供的ImageView，当然你也可以用自己自定义的具有图片加载功能的ImageView
            View view = LayoutInflater.from(context).inflate(R.layout.view_holder_datalist_banner_item, null);
            ScaleDraweeView simpleDraweeView = (ScaleDraweeView) view.findViewById(R.id.datalist_banner_item_cover);


            return simpleDraweeView;

        }
    }
}

