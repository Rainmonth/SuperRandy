package com.hhdd.kada.main.viewholders;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.vo.BaseModelVO;

/**
 * Created by sxh on 2017/5/2.
 */

public class StoryCollectionListItemViewHolder extends BaseViewHolder<BaseModelVO> {

    public static final int TYPE_STORY_COLLECTION_LIST_CLICKED = 100;

    private View holderView;

    int itemWidth = 0;
    int itemHeight = 0;
    private View view;
    private TextView tvName;
    private TextView tvDetail;
    private ImageView newFlag;
    private View charge;
    private ImageView serialize;
    private TextView countFlag;
    private CustomStoryView customStoryView;

    @Override
    public View createView(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        holderView = layoutInflater.inflate(R.layout.view_holder_story_collect_item, parent, false);
        itemWidth = (LocalDisplay.SCREEN_WIDTH_PIXELS - 2 * LocalDisplay.dp2px(10) - LocalDisplay.dp2px(5)) / 2;
        itemHeight = (int) (itemWidth * 28.0f / 45.0f);
        view = holderView.findViewById(R.id.item_container);
        tvName = (TextView) holderView.findViewById(R.id.name);
        tvDetail = (TextView) holderView.findViewById(R.id.detail);
        newFlag = (ImageView) holderView.findViewById(R.id.new_flag);
        charge = holderView.findViewById(R.id.charge);
        serialize = (ImageView) holderView.findViewById(R.id.serialize_iv);
        countFlag = (TextView) holderView.findViewById(R.id.count);
        customStoryView = (CustomStoryView) holderView.findViewById(R.id.cover_container);
        return holderView;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        BaseModel baseModel = itemData.getModel();
        if (baseModel != null && baseModel instanceof StoryCollectionInfo) {
            final StoryCollectionInfo info = (StoryCollectionInfo) baseModel;
            view.getLayoutParams().height = (int) (itemHeight + LocalDisplay.dp2px(50));
            view.setPadding(LocalDisplay.dp2px(6), 0, LocalDisplay.dp2px(3), 0);
            tvName.setText(info.getName());
            tvDetail.setText(info.getRecommend());
            //new标志
            if ((info.getExtFlag() & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4) {
                newFlag.setVisibility(View.VISIBLE);
            } else {
                newFlag.setVisibility(View.GONE);
            }
            //收费标志
            if ((info.getExtFlag() & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32) {
                charge.setVisibility(View.VISIBLE);
            } else {
                charge.setVisibility(View.GONE);
            }
            //连载中标志
            boolean isSerialize = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_16) == Extflag.STORY_EXT_FLAG_16;
            serialize.setVisibility(isSerialize ? View.VISIBLE: View.GONE);

            //集数标志
            if (info.getCount() > 0) {
                countFlag.setVisibility(View.VISIBLE);
                if (isSerialize && info.getOnlineCount() > 0) {
                    countFlag.setText(KaDaApplication.getInstance().getResources().getString(R.string.excellent_story_collection_item_count, info.getOnlineCount(), info.getCount()));
                } else {
                    countFlag.setText(info.getCount() + "集");
                }
            } else {
                countFlag.setVisibility(View.GONE);
            }

            view.setTag(R.id.container,info);

            view.setOnClickListener(listener);

            customStoryView.getLayoutParams().width = itemWidth;
            customStoryView.getLayoutParams().height = itemHeight;

            customStoryView.showBg(R.drawable.bg_story_collect2);
            customStoryView.setPlaceHolder(R.drawable.books_two);

            if (info.getBannerUrl() != null) {
                String coverUrl = CdnUtils.getImgCdnUrl(info.getBannerUrl(), CdnUtils.getTwoCoverImgSize());
                boolean needResetImageUrl = true;
                if (customStoryView.getTag(R.id.list_item_image_url) != null) {
                    String url = (String) customStoryView.getTag(R.id.list_item_image_url);
                    if (TextUtils.equals(url, coverUrl)) {
                        needResetImageUrl = false;
                    }
                }
                if (needResetImageUrl) {
                    customStoryView.setTag(R.id.list_item_image_url, coverUrl);
                    customStoryView.showUrl(coverUrl);
                }
            }
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            StoryCollectionInfo info = (StoryCollectionInfo) v.getTag(R.id.container);
            mOnEventProcessor.process(TYPE_STORY_COLLECTION_LIST_CLICKED, info);
        }
    };
}
