package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SimpleEventHandler;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.store.views.UPMarqueeView;

import java.util.List;

/**
 * Created by lj on 17/3/22.
 */

public class FlipTextViewHolder extends BaseViewHolder<BaseModelListVO> {

    Context mContext;
    ScaleDraweeView tbtv;
    UPMarqueeView viewFlipper;

    @Override
    public View createView(ViewGroup parent) {
        mContext = parent.getContext();
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_holder_flip_text, null);
        tbtv = (ScaleDraweeView) view.findViewById(R.id.tbtv);
        viewFlipper = (UPMarqueeView) view.findViewById(R.id.upview1);

        tbtv.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                if (v.getTag() != null && v.getTag() instanceof RedirectInfo
                        && mContext != null) {
                    RedirectActivity.startActivity(mContext, (RedirectInfo) v.getTag());
                }
            }
        });

        EventCenter.bindContainerAndHandler(componentContainer, new SimpleEventHandler() {
            @Override
            public void onBecomesVisible() {
                super.onBecomesVisible();
                if (!viewFlipper.isFlipping()) {
                    viewFlipper.startFlipping();
                }
            }

            @Override
            public void onBecomesTotallyInvisible() {
                super.onBecomesTotallyInvisible();
                if (viewFlipper.isFlipping()) {
                    viewFlipper.stopFlipping();
                }
            }

            @Override
            public void onBecomesVisibleFromTotallyInvisible() {
                super.onBecomesVisibleFromTotallyInvisible();
                if (!viewFlipper.isFlipping()) {
                    viewFlipper.startFlipping();
                }
            }

            @Override
            public void onBecomesPartiallyInvisible() {
                super.onBecomesPartiallyInvisible();
                if (viewFlipper.isFlipping()) {
                    viewFlipper.stopFlipping();
                }
            }
        }).tryToRegisterIfNot();
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData != null && itemData.getItemList() != null && itemData.getItemList().size() > 1) {

            List itemList = itemData.getItemList().subList(1,itemData.getItemList().size());
            viewFlipper.setData(itemList);
            viewFlipper.setOnItemClickListener(new UPMarqueeView.OnItemClickListener() {
                @Override
                public void onItemClick(RedirectInfo redirectInfo) {
                    if (mContext != null && redirectInfo != null) {
                        RedirectActivity.startActivity(mContext, redirectInfo);
                    }
                }
            });

            BaseModel model = itemData.getItemList().get(0);
            if(model instanceof RedirectInfo){
                RedirectInfo redirectInfo = (RedirectInfo) model;
                if(!TextUtils.isEmpty(redirectInfo.getImageUrl())){
                    FrescoUtils.showUrl(redirectInfo.getImageUrl(),tbtv, LocalDisplay.dp2px(60),LocalDisplay.dp2px(60));
                }
                tbtv.setTag(redirectInfo);
            }
        }
    }
}
