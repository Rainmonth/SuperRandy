package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionCategoryInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.Cn2Spell;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.List;

import butterknife.BindView;

/**
 * Created by mcx on 2017/8/7.
 */

public class BookCollectionCategoryViewHolder extends BaseViewHolder<BaseModelVO> {
    Context mContext;
    View view;
    int width;
    int height;

    @BindView(R.id.tv_cate)
    TextView tvCate;
    @BindView(R.id.gv_cate)
    GridView gvCate;

    @Override
    public View createView(ViewGroup parent) {
        mContext = parent.getContext();
        return rootView;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_story_collection_category;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        BaseModel baseModel = itemData.getModel();
        if (baseModel != null && baseModel instanceof BookCollectionCategoryInfo) {
            final BookCollectionCategoryInfo info = (BookCollectionCategoryInfo) baseModel;
            tvCate.setText(info.getType());
            GridViewAdapter adapter = new GridViewAdapter(mContext, info.getData());
            gvCate.setAdapter(adapter);
            gvCate.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    BookCollectionCategoryInfo.SubCategoryInfo subCategoryInfo = info.getData().get(i);
                    if (subCategoryInfo.getTitle() != null && subCategoryInfo.getTitle().length() > 0) {
                        String spell = Cn2Spell.getPinYin(subCategoryInfo.getTitle());
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "book_category_click_" + spell, TimeUtil.currentTime()));
                    }
                    RedirectActivity.startActivity(mContext, subCategoryInfo.getRedirectUri());
                }
            });
        }
    }

    class GridViewAdapter extends QuickAdapter<BookCollectionCategoryInfo.SubCategoryInfo> {

        public GridViewAdapter(Context context, List data) {
            super(context, R.layout.story_album_category_layout, data);
        }

        @Override
        protected void convert(BaseAdapterHelper helper, BookCollectionCategoryInfo.SubCategoryInfo item) {
            int width = ScreenUtil.getScreenWidth() / 5;
            int height = ScreenUtil.getScreenWidth() / 5;
            TextView title = helper.getView(R.id.tv_album_category_name);
            title.setText(item.getTitle());
            SimpleDraweeView cover = helper.getView(R.id.album_cover);
            FrescoUtils.showUrl(item.getIconUrl(), cover, width, height);
        }
    }

}
