package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.MyGridView;
import com.hhdd.kada.main.views.OnItemScaleClickListener;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;

/**
 * @author: Randy Zhang
 * @description: 听书圆形分类ViewHolder
 * @created: 2018/8/29
 **/
public class StoryCircleCateViewHolder extends BaseViewHolder<BaseModelListVO> {
    private Context context;

    @BindView(R.id.gv_cate)
    MyGridView gridView;

    private StoryCircleCateViewHolder.GridViewAdapter adapter;
    private int itemWidth;//功能图标宽、高
    private int itemHeight;

    @Override
    public View createView(ViewGroup parent) {

        context = parent.getContext();

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(params);

        adapter = new StoryCircleCateViewHolder.GridViewAdapter(context);

        gridView.setOnItemClickListener(new OnItemScaleClickListener() {
            @Override
            public void onItemClickScaled(AdapterView<?> parent, View view, int position, long id) {
                super.onItemClickScaled(parent, view, position, id);
                RedirectInfo redirectInfo = adapter.getItem(position);
                if (null != redirectInfo)
                    RedirectActivity.startActivity(context, redirectInfo);
            }
        });

        return rootView;
    }

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_story_circle_cate;
    }

    @Override
    public void showData(int position, BaseModelListVO data) {
        if (null == data || data.getItemList().size() <= 0) return;

        int len = data.getItemList().size();
        List<BaseModel> tempList;

        //最多只显示前五个
        if (len > 5) {
            tempList = data.getItemList().subList(0, 5);
        } else {
            tempList = data.getItemList();
        }

        itemWidth = LocalDisplay.dp2px(54f);
        itemHeight = itemWidth;

        List<RedirectInfo> redirectInfoList = new ArrayList<>();
        for (BaseModel baseModel : tempList) {
            if (baseModel instanceof RedirectInfo)
                redirectInfoList.add((RedirectInfo) baseModel);
        }
        //可以通过这个扩展行数展示 比如显示两行  Math.floor(len/2.0)
        gridView.setNumColumns(tempList.size());
        gridView.setAdapter(adapter);
        adapter.replaceAll(redirectInfoList);
    }

    class GridViewAdapter extends QuickAdapter<RedirectInfo> {

        public GridViewAdapter(Context context) {
            super(context, R.layout.layout_story_circle_cate_view_item);
        }

        @Override
        protected void convert(BaseAdapterHelper helper, RedirectInfo item) {
            SimpleDraweeView simpleDraweeView = helper.getView(R.id.cate_image);
            simpleDraweeView.setLayoutParams(new LinearLayout.LayoutParams(itemWidth, itemHeight));

            TextView textView = helper.getView(R.id.cate_title);

            String imgUrl = CdnUtils.getImgCdnUrl(item.getImageUrl(), CdnUtils.SIZE_160x160);
            FrescoUtils.showImg(simpleDraweeView, imgUrl);

            textView.setText(item.getTitle());
        }
    }
}