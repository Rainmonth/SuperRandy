package com.hhdd.kada.main.viewholders;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.adapter.Book2X2GridViewAdapter;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.OnItemScaleClickListener;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/3
 * @describe : com.hhdd.kada.main.viewholders
 */
public class Book2x2ViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.gridView)
    GridView gridView;

    private Book2X2GridViewAdapter adapter;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_book_2x2;
    }

    @Override
    public View createView(ViewGroup parent) {
        adapter = new Book2X2GridViewAdapter(gridView.getContext());
        gridView.setAdapter(adapter);
        gridView.setOnItemClickListener(new OnItemScaleClickListener() {
            @Override
            public void onItemClickScaled(AdapterView<?> parent, View view, int position, long id) {
                super.onItemClickScaled(parent, view, position, id);
                if (position < adapter.getCount()) {
                    if (adapter.getItem(position) instanceof BookCollectionInfo) {
                        BookCollectionInfo info = (BookCollectionInfo) adapter.getItem(position);
                        if (info != null) {
                            FragmentUtil.pushFragment(BookCollectionFragment.class, new BaseCollectionFragment.CollectionModel(info.getCollectId(), false), true);
                            if (!TextUtils.isEmpty(info.getSourceKey())) {
                                RedirectInfo.SourceKeyStatInfo statInfo = RedirectInfo.SourceKeyStatInfo.parse(info.getSourceKey());
                                if (statInfo != null) {
                                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(statInfo.getContent(), statInfo.getName(), TimeUtil.currentTime()));
                                }
                            }
                        }
                    }
                }
            }
        });
        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null || itemData.getItemList().size() == 0) {
            return;
        }

        gridView.setAdapter(adapter);
        adapter.replaceAll(itemData.getItemList());
    }
}
