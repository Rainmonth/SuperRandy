package com.hhdd.kada.main.viewholders;

import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.views.MotherExcellentSubjectView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.viewholders
 */
public class MotherExcellentSubjectViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.motherExcellentSubjectView)
    MotherExcellentSubjectView motherExcellentSubjectView;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_mother_excellent_subject;
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = motherExcellentSubjectView.getLayoutParams();
        params.height = (int) (LocalDisplay.SCREEN_WIDTH_PIXELS * Constants.MOTHER_SUBJECT_RATIO);
        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData != null && itemData.getItemList().size() > 0) {
            BaseModel baseModel = itemData.getItemList().get(0);
            if (baseModel instanceof RedirectInfo) {
                RedirectInfo redirectInfo = (RedirectInfo) baseModel;
                motherExcellentSubjectView.update(redirectInfo);
            }
        }
    }
}
