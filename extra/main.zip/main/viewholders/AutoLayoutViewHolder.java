package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.RectF;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AbsoluteLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.generic.RoundingParams;
import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.DataListItem;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.StyleVO;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * Created by simon on 18/11/2016.
 */

public class AutoLayoutViewHolder extends BaseViewHolder<BaseModelListVO> {

    Context context;
    View view;
    DataListItem itemData;

    StyleVO styleVO;

    private AbsoluteLayout mLayout;
    private List<Point> mPointList = new ArrayList<Point>();
    private List<RectF> mRectList = new ArrayList<RectF>();
    private int mScreenWidth;
    private final int precision = LocalDisplay.dp2px(2);

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_datalist_autolayout, parent, false);

        mScreenWidth = context.getResources().getDisplayMetrics().widthPixels;
        mLayout = (AbsoluteLayout) view.findViewById(R.id.datalist_autolayout);
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null || itemData.getItemList().size() == 0)
            return;

        styleVO = itemData.getStyleVO();
        if (styleVO != null && styleVO.getBg() != null && styleVO.getBg().length() > 0) {
            mLayout.setBackgroundColor(Color.parseColor(styleVO.getBg()));
        } else {
            mLayout.setBackgroundResource(R.color.white);
        }

        //mLayout.removeAllViews();
        mPointList.clear();
        mRectList.clear();
        mPointList.add(new Point(0, 0));
        List<BaseModel> list = itemData.getItemList();

        if (list != null && list.size() > 0) {
            int childCount = mLayout.getChildCount();
            if (childCount > list.size() && childCount > 0) {
                List<View> views = new ArrayList<>();
                for (int i = childCount - 1; i >= list.size(); i--) {
                    views.add(mLayout.getChildAt(i));
                }
                for (View view : views) {
                    mLayout.removeView(view);
                }
                views.clear();
            }
            mLayout.setVisibility(View.VISIBLE);
            int size = list.size();
            for (int i = 0; i < size; i++) {
                if (!(list.get(i) instanceof RedirectInfo)) {
                    continue;
                }
                RedirectInfo redirect = (RedirectInfo) list.get(i);
                //boolean isShowTitle = redirect.getTitle()!=null&&redirect.getTitle().length()>0?true:false;
                float factor = redirect.getWidth();
                float imageHeight = redirect.getHeight();
                if (factor == 0) {
                    factor = 1;
                } else {
                    factor = redirect.getWidth() / 320f;
                }
                if (factor > 1) {
                    factor = 1;
                }
                int width = (int) (mScreenWidth * factor);
                int height = (int) (imageHeight / 320f * mScreenWidth);

                for (Point point : mPointList) {
                    RectF reF = new RectF(point.x, point.y, point.x + width, point.y + height);
                    if (point.x + width > mScreenWidth + precision) {
                        continue;
                    }
                    if (!isRectIntersect(reF)) {
                        mPointList.remove(point);  //删除原点

                        Iterator<Point> iter = mPointList.iterator();   //删除所有小于右上角的点
                        while (iter.hasNext()) {
                            Point p = iter.next();
                            if (p.y <= point.y) {
                                iter.remove();
                            }
                        }
                        if (point.x + width < mScreenWidth) {  //加入右上角的点
                            Point point1 = new Point(point.x + width, point.y);
                            mPointList.add(point1);
                        }

                        boolean flag = false;   //若y+height值最大，加入(0,y+height)的点
                        for (Point p : mPointList) {
                            if (p.y >= point.y + height) {
                                flag = true;
                            }
                        }
                        if (!flag) {
                            Point point2 = new Point(0, point.y + height);
                            mPointList.add(point2);
                        }

                        Point point2 = new Point(point.x, point.y + height); //加入左下角的点
                        mPointList.add(point2);
                        Collections.sort(mPointList, pointComparator);  //排序
                        mRectList.add(reF);    //矩阵加入

                        AbsoluteLayout.LayoutParams params = new AbsoluteLayout.LayoutParams(width+1 , height+1, point.x, point.y);
                        if (i + 1 > childCount) {
                            AutoLayoutItemViewHolder viewHolder = new AutoLayoutItemViewHolder(context);
                            viewHolder.update(redirect, params, styleVO);
                            viewHolder.itemContainerView().setTag(R.id.auto_layout_item_view, viewHolder);
                            mLayout.addView(viewHolder.itemContainerView());
                        } else {
                            View view = mLayout.getChildAt(i);
                            view.setVisibility(View.VISIBLE);
                            AutoLayoutItemViewHolder viewHolder = (AutoLayoutItemViewHolder) view.getTag(R.id.auto_layout_item_view);
                            viewHolder.update(redirect, params, styleVO);
                        }
                        break;
                    }
                }
            }

            int maxHeight = mPointList.get(mPointList.size() - 1).y;
            AbsListView.LayoutParams params = new AbsListView.LayoutParams(mScreenWidth, maxHeight);
            mLayout.setLayoutParams(params);
        } else {
            mLayout.setVisibility(View.GONE);
        }
    }


    boolean isRectOverlap(RectF r1, RectF r2) {
        r1.right -= precision;
        r1.bottom -= precision;
        r2.right -= precision;
        r2.bottom -= precision;
        return !(r1.left >= r2.right || r1.top >= r2.bottom
                || r2.left >= r1.right || r2.top >= r1.bottom);
    }

    public boolean isRectIntersect(RectF origin) {
        for (RectF target : mRectList) {
            if (isRectOverlap(target, origin)) {
                return true;
            }
            if (isRectOverlap(origin, target)) {
                return true;
            }
        }
        return false;
    }


    public static class AutoLayoutItemViewHolder {
        View itemContainerView;
        Context context;
        TextView title;
        ScaleDraweeView draweeView;
        SimpleDraweeView iconView;
        RedirectInfo redirectInfo;

        public AutoLayoutItemViewHolder(Context context) {
            this.context = context;
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            itemContainerView = layoutInflater.inflate(R.layout.view_holder_datalist_autolayout_item, null, false);
            title = (TextView) itemContainerView.findViewById(R.id.datalist_autolayout_item_title);
            draweeView = (ScaleDraweeView) itemContainerView.findViewById(R.id.datalist_autolayout_item_image);
            iconView = (SimpleDraweeView) itemContainerView.findViewById(R.id.datalist_autolayout_item_icon);
        }

        public void update(RedirectInfo redirectInfoParm, AbsoluteLayout.LayoutParams params, StyleVO styleVO) {
            this.redirectInfo = redirectInfoParm;
            itemContainerView.setLayoutParams(params);
            itemContainerView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(View v) {
                    RedirectActivity.startActivity(context, redirectInfo);
                }
            });

            boolean isShowTitle = redirectInfo.getTitle() != null && redirectInfo.getTitle().length() > 0 ? true : false;

            int coverWidth = params.width;
            int coverHeight;
            if (isShowTitle) {
                coverHeight = params.height - LocalDisplay.dp2px(22);
            } else {
                coverHeight = params.height;
            }
            draweeView.getLayoutParams().width = coverWidth;
            draweeView.getLayoutParams().height = coverHeight;

            if (redirectInfo.getImageUrl() != null && redirectInfo.getImageUrl().length() > 0) {
                draweeView.setVisibility(View.VISIBLE);

                String imgUrl = CdnUtils.getImgCdnUrl(redirectInfo.getImageUrl());
                FrescoUtils.showImg(draweeView, imgUrl, coverWidth, coverHeight);
            } else {
                draweeView.setVisibility(View.INVISIBLE);
            }

            RoundingParams roundingParams = draweeView.getHierarchy().getRoundingParams();

            if (styleVO != null && styleVO.getCircle() > 0) {
                roundingParams.setRoundAsCircle(true);
                roundingParams.setCornersRadius(0);
            } else if (styleVO != null && styleVO.isRoundAsCorner()) {
                roundingParams.setRoundAsCircle(false);
                roundingParams.setCornersRadius(LocalDisplay.dp2px(5));
            } else {
                roundingParams.setRoundAsCircle(false);
                roundingParams.setCornersRadius(0);
            }

            if (styleVO != null && styleVO.getIcon() != null && styleVO.getIcon().length() > 0) {
                iconView.setVisibility(View.VISIBLE);

                int imageSize = 0;
                if (draweeView.getLayoutParams().width > draweeView.getLayoutParams().height) {
                    imageSize = draweeView.getLayoutParams().height;
                } else {
                    imageSize = draweeView.getLayoutParams().width;
                }
                int iconSize = imageSize / 2;
                ((RelativeLayout.LayoutParams) (iconView.getLayoutParams())).topMargin = (imageSize - iconSize) / 2;
                iconView.getLayoutParams().width = iconSize;
                iconView.getLayoutParams().height = iconSize;

                String iconUrl = CdnUtils.getImgCdnUrl(styleVO.getIcon());
                FrescoUtils.showImg(iconView, iconUrl, iconSize, iconSize);
            } else {
                iconView.setVisibility(View.INVISIBLE);
            }

            draweeView.getHierarchy().setRoundingParams(roundingParams);

            if (isShowTitle) {
                title.setVisibility(View.VISIBLE);
                title.setText(redirectInfo.getTitle());
            } else {
                title.setVisibility(View.GONE);
                title.setText("");
            }

            if (styleVO != null && styleVO.getTextColor() != null && styleVO.getTextColor().length() > 0) {
                title.setTextColor(Color.parseColor(styleVO.getTextColor()));
            } else {
                title.setTextColor(Color.parseColor("#555555"));
            }
        }

        public View itemContainerView() {
            return this.itemContainerView;
        }
    }


    /**
     * 比较接口实现，按拼音排序，#开头的在最后，内部排序用中文的编码排序
     */
    public static final Comparator<Point> pointComparator = new Comparator<Point>() {

        @Override
        public int compare(Point obj1, Point obj2) {
            if (obj1 == null) {
                if (obj2 == null) {
                    return 0;
                } else {
                    return 1;
                }
            } else {
                if (obj2 == null) {
                    return 0;
                } else {
                    if (obj2.y - obj1.y > 3) {
                        return -1;
                    } else if (Math.abs(obj2.y - obj1.y) < 3) {
                        if (obj1.x < obj2.x) {
                            return -1;
                        } else {
                            if (obj1.x == obj2.x) {
                                return 0;
                            } else {
                                return 1;
                            }
                        }
                    } else {
                        return 1;
                    }
                }
            }
        }
    };
}
