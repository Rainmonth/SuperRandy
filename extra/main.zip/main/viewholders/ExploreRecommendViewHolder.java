package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.facebook.drawee.generic.RoundingParams;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.StyleVO;

import java.util.List;

/**
 * Created by lj on 17/3/21.
 */

public class ExploreRecommendViewHolder extends BaseViewHolder<BaseModelListVO> {

    Context mContext;
    StyleVO styleVO;

    View container;
    View titleContainer;
    View coverContainer;
    ScaleDraweeView titleIcon;
    TextView title;
    ScaleDraweeView cover;
    ScaleDraweeView icon;
    TextView more;
    Context context;
    int radius = 10;


    @Override
    public View createView(ViewGroup parent) {
        mContext = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.view_holder_explore_recommend, parent, false);

        context = parent.getContext();
        container = view.findViewById(R.id.container);
        titleContainer = view.findViewById(R.id.title_container);
        coverContainer = view.findViewById(R.id.cover_container);
        titleIcon = (ScaleDraweeView) view.findViewById(R.id.datalist_title_icon);
        title = (TextView) view.findViewById(R.id.datalist_title_tv);
        cover = (ScaleDraweeView) view.findViewById(R.id.datalist_cover);
        icon = (ScaleDraweeView) view.findViewById(R.id.datalist_icon);
        more = (TextView) view.findViewById(R.id.more);

        titleContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getTag() != null && view.getTag() instanceof RedirectInfo) {
                    RedirectActivity.startActivity(mContext, (RedirectInfo) view.getTag());
                }
            }
        });

        cover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getTag() != null && view.getTag() instanceof RedirectInfo) {
                    RedirectActivity.startActivity(mContext, (RedirectInfo) view.getTag());
                }
            }
        });

        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (view.getTag() != null && view.getTag() instanceof RedirectInfo) {
                    RedirectActivity.startActivity(mContext, (RedirectInfo) view.getTag());
                }
            }
        });

        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null || itemData.getItemList().size() == 0) {
            return;
        }
        styleVO = itemData.getStyleVO();

        if (styleVO != null && styleVO.getGradient() != null
                && !TextUtils.isEmpty(styleVO.getGradient().getStartColor())
                && !TextUtils.isEmpty(styleVO.getGradient().getEndColor())) {
            try {
                int colors[] = {Color.parseColor(styleVO.getGradient().getStartColor()), Color.parseColor(styleVO.getGradient().getEndColor())};
                GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors);
                bg.setCornerRadius(LocalDisplay.dp2px(radius));
                container.setBackgroundDrawable(bg);
            } catch (Exception e) {

            }
        } else {
            container.setBackgroundDrawable(context.getResources().getDrawable(R.drawable.bg_daily_task));
        }

        List<BaseModel> list = itemData.getItemList();
        if (list.size() == 1) {
            coverContainer.setVisibility(View.GONE);
            more.setVisibility(View.GONE);
        } else if (list.size() == 2) {
            coverContainer.setVisibility(View.VISIBLE);
            more.setVisibility(View.GONE);
        } else {
            coverContainer.setVisibility(View.VISIBLE);
            more.setVisibility(View.VISIBLE);
        }

        for (int i = 0; i < list.size(); i++) {
            BaseModel baseModel = list.get(i);
            if (i == 0) {
                if (baseModel instanceof RedirectInfo) {
                    RedirectInfo redirectInfo = (RedirectInfo) baseModel;
                    String title = redirectInfo.getTitle();
                    String imageUrl = redirectInfo.getImageUrl();
                    if (title != null && title.length() > 0) {
                        this.title.setText(redirectInfo.getTitle());
                        if (styleVO != null && !TextUtils.isEmpty(styleVO.getTextColor())) {
                            this.title.setTextColor(Color.parseColor(styleVO.getTextColor()));
                        }
                    }
                    if (imageUrl != null && imageUrl.length() > 0) {
//                    int with = titleIcon.getWidth();
//                    int height = titleIcon.getHeight();
                        FrescoUtils.showUrl(redirectInfo.getImageUrl(), titleIcon, LocalDisplay.dp2px(20), LocalDisplay.dp2px(20));
                    }
                    if (title == null || imageUrl == null || title.isEmpty() || imageUrl.isEmpty()){
                        titleContainer.setVisibility(View.GONE);
                    }
                    titleContainer.setTag(redirectInfo);
                }
            } else if (i == 1) {
                if (baseModel instanceof RedirectInfo) {
                    RedirectInfo redirectInfo = (RedirectInfo) baseModel;
                    float factor = redirectInfo.getWidth();
                    float imageHeight = redirectInfo.getHeight();
                    if (factor == 0) {
                        factor = 1;
                    } else {
                        factor = redirectInfo.getWidth() / 320f;
                    }
                    if (factor > 1) {
                        factor = 1;
                    }
                    int width = (int) (LocalDisplay.SCREEN_WIDTH_PIXELS * factor - LocalDisplay.dp2px(20));
                    int height = (int) (imageHeight / 320f * LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(10));
                    FrameLayout.LayoutParams coverLayoutParams = (FrameLayout.LayoutParams) cover.getLayoutParams();
                    coverLayoutParams.width = width;
                    coverLayoutParams.height = height;
                    cover.setLayoutParams(coverLayoutParams);
                    String url = redirectInfo.getImageUrl();
                    FrescoUtils.showUrl(url, cover, width, height);

                    if (styleVO != null && !TextUtils.isEmpty(styleVO.getIcon())) {
                        icon.setVisibility(View.VISIBLE);
                        int size = (int) (width > height ? height / 2f : width / 2f);
                        icon.getLayoutParams().width = size;
                        icon.getLayoutParams().height = size;
                        FrescoUtils.showUrl(styleVO.getIcon(), icon, size, size);
                    } else {
                        icon.setVisibility(View.GONE);
                    }

                    RoundingParams roundingParams = cover.getHierarchy().getRoundingParams();
                    if (styleVO != null && styleVO.getCircle() > 0) {
                        roundingParams.setRoundAsCircle(true);
                        roundingParams.setCornersRadius(0);
                    } else if (styleVO != null && styleVO.isRoundAsCorner()) {
                        roundingParams.setRoundAsCircle(false);
                        roundingParams.setCornersRadius(LocalDisplay.dp2px(radius));
                    } else {
                        roundingParams.setRoundAsCircle(false);
                        roundingParams.setCornersRadius(0);
                    }
                    cover.getHierarchy().setRoundingParams(roundingParams);

                    cover.setTag(redirectInfo);
                }
            } else if (i == 2) {
                if (baseModel instanceof RedirectInfo) {
                    RedirectInfo info = (RedirectInfo) baseModel;
                    if (!TextUtils.isEmpty(info.getTitle())) {
                        more.setText(info.getTitle());
                        more.setTag(baseModel);
                    } else {
                        more.setVisibility(View.GONE);
                    }
                }
            }
        }
    }
}
