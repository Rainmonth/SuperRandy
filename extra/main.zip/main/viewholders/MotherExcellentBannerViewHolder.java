package com.hhdd.kada.main.viewholders;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.exposure.ExposureTracker;
import com.hhdd.kada.module.exposure.MotherExcellentBannerExposureTrackEvent;
import com.hhdd.logger.LogHelper;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/29
 * @describe : com.hhdd.kada.main.viewholders
 *
 * Edited by Xiaoyu on 2018/8/9 下午1:50
 * 增加曝光量统计代码
 */
public class MotherExcellentBannerViewHolder extends CommonBannerViewHolder {

    private int currentIndex = -1;

    @Override
    public View createView(ViewGroup parent) {
        isShowArc = true;//妈妈精选页 - Banner图显示圆弧
        return super.createView(parent);
    }

    @Override
    protected void doBannerClick(int position) {
        super.doBannerClick(position);
        if (position < bannerInfos.size()) {
            BannerInfo info = bannerInfos.get(position);
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(info.getId()), "mom_home_boutique_banner_click", TimeUtil.currentTime()));
        }
    }

    @Override
    protected void onPageSelected(int position) {
        super.onPageSelected(position);
        currentIndex = position;
//        Log.d(ExposureTracker.TAG,"banner onPageSelected : "+position);
        recordBannerExposure(position);
    }

    public void onEvent(MotherExcellentBannerExposureTrackEvent event){
        if(event.visible) {
            LogHelper.d(ExposureTracker.TAG, "页面可见性触发banner统计");
            recordBannerExposure(currentIndex);
        }else{
            currentIndex = -1;
        }
    }

//    @Override
//    public void showData(int position, BaseModelListVO itemData) {
//        super.showData(position, itemData);
//        if(position == currentIndex) {
//            Log.d(ExposureTracker.TAG,"banner showData");
//            recordBannerExposure(position);
//        }
//    }

    //记录：准备record，却发现不可见，可能的情况是：页面数据还没加载好。这时先把position记下来,等待Fragment的通知
    private void recordBannerExposure(int position) {
        if(position < 0 || bannerInfos == null || position >= bannerInfos.size()) return;
        BannerInfo bannerInfo = bannerInfos.get(position);
        if (bannerInfo != null) {
            //统计，方法内做了解析
//            Log.d(ExposureTracker.TAG,"精选banner曝光统计，position="+position);
            ExposureTracker.getInstance().trackBanner(ExposureTracker.SCENE_BOUTIQUE_HOME_BANNER,bannerInfo);
        }
        //实测：向上滑动RecyclerView，让banner的可见性从一丝缝隙(1个像素)变为不可见时，
        // getLocalVisibleRect()返回true、rect是完整的尺寸（系统bug），但是此时的shown()为false，所以两个API组合使用避免bug
//        Rect r = new Rect();
//        if(layout.isShown() && layout.getLocalVisibleRect(r)){
//            //计算面积比例，此时面积比例只跟显示高度有关
//            final int realH = layout.getHeight();
//            final float shownRate = (float) r.bottom / realH;
//            if(shownRate >= ExposureTracker.MIN_RATE){
//
//            }else{
//                Log.d(ExposureTracker.TAG,"精选banner面积小于30%不统计");
//            }
//        }else{
//            Log.d(ExposureTracker.TAG,"精选banner不可见或尚未加载好");
//        }
    }

}
