package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.CustomStoryView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lj on 17/4/26.
 */

public class Story2x2ViewHolder extends BaseViewHolder<BaseModelListVO> {

    Context context;
    View view;

    GridView gridView;
    GridViewAdapter adapter;

    int itemWidth = 0;
    int itemHeight = 0;

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_story_2x2, parent, false);

        itemWidth = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(10 + 10 + 10)) / 2;
        itemHeight = (int) (itemWidth * Constants.MOTHER_TOW_COVER_RATIO);
        gridView = (GridView) view.findViewById(R.id.gridview);
        gridView.setNumColumns(2);
        adapter = new GridViewAdapter(context);
        gridView.setAdapter(adapter);
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null) return;
        if (itemData.getItemList().size() == 0) return;
        List<StoryListItem> storyListItems = new ArrayList<>();
        for (int i = 0; i < itemData.getItemList().size(); i++) {
            BaseModel baseModel = itemData.getItemList().get(i);
            if (baseModel != null && baseModel instanceof StoryListItem) {
                storyListItems.add((StoryListItem) baseModel);
            }
            if (i >= 3) break;
        }
        gridView.setAdapter(adapter);
        adapter.replaceAll(storyListItems);
    }


    class GridViewAdapter extends QuickAdapter<StoryListItem> {

        public GridViewAdapter(Context context) {
            super(context, R.layout.view_holder_story_collect_item_2x2);
        }

        @Override
        protected void convert(BaseAdapterHelper helper, StoryListItem item) {

            if (item.getData() != null && item.getData() instanceof StoryCollectionInfo) {
                StoryCollectionInfo info = (StoryCollectionInfo) item.getData();
                View view = helper.getView(R.id.item_container);
                view.getLayoutParams().width = itemWidth;
                view.getLayoutParams().height = (int) (itemHeight + LocalDisplay.dp2px(60));


                view.setTag(R.id.item_container, info);
                view.setOnClickListener(onClickWithAnimListener);

                TextView tvName = helper.getView(R.id.name);
                tvName.setGravity(Gravity.CENTER_HORIZONTAL);
                tvName.setGravity(Gravity.CENTER);
                tvName.setText(info.getName());

                TextView tvDetail = helper.getView(R.id.detail);
                tvDetail.setText(info.getRecommend());

//                TextView clickCount = helper.getView(R.id.click_count);
//                clickCount.setText(StringUtil.formatClickCount(info.getClickCount()));

                View newFlag = helper.getView(R.id.new_flag);
                View charge = helper.getView(R.id.charge);
                View serialize = helper.getView(R.id.serialize);
                View freeFlag = helper.getView(R.id.free_flag);
                TextView countFlag = helper.getView(R.id.count);
                //new标志
                if ((info.getExtFlag() & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4) {
                    newFlag.setVisibility(View.VISIBLE);
                } else {
                    newFlag.setVisibility(View.GONE);
                }
                boolean isCharge = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32;
                boolean isFree = ((info.getExtFlag() & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW) ||
                        ((info.getExtFlag() & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL);
                if(isFree) {
                    freeFlag.setVisibility(View.VISIBLE);
                    charge.setVisibility(View.GONE);
                } else {
                    if(isCharge) {
                        charge.setVisibility(View.VISIBLE);
                    } else {
                        charge.setVisibility(View.GONE);
                    }
                }
                //连载中标志
                boolean isSerialize = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_16) == Extflag.STORY_EXT_FLAG_16;
                serialize.setVisibility(isSerialize ? View.VISIBLE : View.GONE);

                //集数标志
                if (info.getCount() > 0) {
                    countFlag.setVisibility(View.VISIBLE);
                    if (isSerialize && info.getOnlineCount() > 0) {
                        countFlag.setText(KaDaApplication.getInstance().getResources().getString(R.string.excellent_story_collection_item_count, info.getOnlineCount(), info.getCount()));
                    } else {
                        countFlag.setText(info.getCount() + "集");
                    }
                } else {
                    countFlag.setVisibility(View.GONE);
                }

                CustomStoryView customStoryView = helper.getView(R.id.cover_container);
                customStoryView.getLayoutParams().width = itemWidth;
                customStoryView.getLayoutParams().height = itemHeight;

                customStoryView.showBg(R.drawable.bg_story_collect2);
                customStoryView.setPlaceHolder(R.drawable.books_two);

                int width = itemWidth;//view.getWidth();
                int height = itemHeight;//view.getHeight();

                if (info.getBannerUrl() != null && info.getBannerUrl().length() > 0) {
                    String coverUrl = CdnUtils.getImgCdnUrl(info.getBannerUrl(), CdnUtils.getTwoCoverImgSize());
                    boolean needResetImageUrl = true;
                    if (customStoryView.getTag(R.id.list_item_image_url) != null) {
                        String url = (String) customStoryView.getTag(R.id.list_item_image_url);
                        if (TextUtils.equals(url, coverUrl)) {
                            needResetImageUrl = false;
                        }
                    }
                    if (needResetImageUrl) {
                        customStoryView.setTag(R.id.list_item_image_url, coverUrl);
                        customStoryView.showUrlWithCdn(coverUrl, width, height);
                    }
                } else {
                    if (info.getCoverUrl() != null && info.getCoverUrl().length() > 0) {
                        String coverUrl = info.getCoverUrl();
                        boolean needResetImageUrl = true;
                        if (customStoryView.getTag(R.id.list_item_image_url) != null) {
                            String url = (String) customStoryView.getTag(R.id.list_item_image_url);
                            if (TextUtils.equals(url, coverUrl)) {
                                needResetImageUrl = false;
                            }
                        }
                        if (needResetImageUrl) {
                            customStoryView.setTag(R.id.list_item_image_url, coverUrl);
                            customStoryView.showUrl(coverUrl, width, height);
                        }
                    }
                }
            }
        }
    }

    KaDaApplication.OnClickWithAnimListener onClickWithAnimListener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            StoryCollectionInfo info = (StoryCollectionInfo) v.getTag(R.id.item_container);
            if (info != null) {
                int collectId = info.getCollectId();
                FragmentUtil.presentFragment(StoryCollectionFragment.class, collectId, true);
                if (!TextUtils.isEmpty(info.getSourceKey())) {
                    RedirectInfo.SourceKeyStatInfo statInfo = RedirectInfo.SourceKeyStatInfo.parse(info.getSourceKey());
                    if (statInfo != null) {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(statInfo.getContent(), statInfo.getName(), TimeUtil.currentTime()));
                    }
                }
            }
        }
    };


}
