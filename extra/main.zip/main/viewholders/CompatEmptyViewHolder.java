package com.hhdd.kada.main.viewholders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.android.library.views.list.ViewHolderBase;
import com.hhdd.kada.main.vo.BaseVO;

/**
 * Created by simon on 4/6/16.
 */
public class CompatEmptyViewHolder extends BaseViewHolder<BaseVO> {

    @Override
    public View createView(ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = new View(layoutInflater.getContext());
        return view;
    }

    @Override
    public void showData(int position, BaseVO itemData) {
    }
}
