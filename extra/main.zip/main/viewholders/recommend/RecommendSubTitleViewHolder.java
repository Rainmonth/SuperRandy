package com.hhdd.kada.main.viewholders.recommend;

import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/23
 * @describe : com.hhdd.kada.main.viewholders.recommend
 */
public class RecommendSubTitleViewHolder extends BaseViewHolder<BaseModelVO> {

    @BindView(R.id.leftIconView)
    SimpleDraweeView leftIconView;
    @BindView(R.id.rightIconView)
    SimpleDraweeView rightIconView;
    @BindView(R.id.titleTextView)
    TextView titleTextView;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_recommend_sub_title;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        if (itemData.getModel() != null) {
            BaseModel baseModel = itemData.getModel();
            if (baseModel instanceof RedirectInfo) {
                RedirectInfo redirectInfo = (RedirectInfo) baseModel;
                if (redirectInfo.getTitle() != null && redirectInfo.getTitle().length() > 0) {
                    titleTextView.setText(redirectInfo.getTitle());
                }

                if (redirectInfo.getImageUrl() != null && redirectInfo.getImageUrl().length() > 0) {
                    FrescoUtils.showUrl(redirectInfo.getImageUrl(), leftIconView);
                }
                String rightIconUrl = "res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.icon_recommend_star;
                FrescoUtils.showUrl(rightIconUrl, rightIconView);
            }
        }
    }
}
