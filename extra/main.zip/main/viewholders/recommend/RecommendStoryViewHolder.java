package com.hhdd.kada.main.viewholders.recommend;

import android.view.View;
import android.widget.LinearLayout;

import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.widget.RecommendStoryItemView;

import java.util.List;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/23
 * @describe : com.hhdd.kada.main.viewholders.recommend
 */
public class RecommendStoryViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.layout)
    LinearLayout layout;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_recommend_story;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if(itemData != null && itemData.getItemList() != null) {
            List<BaseModel> itemList = itemData.getItemList();
            for (int i = 0; i < layout.getChildCount(); i++) {
                RecommendStoryItemView itemView = (RecommendStoryItemView) layout.getChildAt(i);
                if(itemList.size() > i) {
                    itemView.setVisibility(View.VISIBLE);
                    itemView.update(itemList.get(i));
                } else {
                    itemView.setVisibility(View.INVISIBLE);
                }
            }
        }
    }
}
