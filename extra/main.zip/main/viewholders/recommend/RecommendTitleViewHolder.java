package com.hhdd.kada.main.viewholders.recommend;

import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolder;
import com.hhdd.kada.main.vo.BaseModelVO;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/23
 * @describe : com.hhdd.kada.main.viewholders.recommend
 */
public class RecommendTitleViewHolder extends BaseViewHolder<BaseModelVO> {

    @BindView(R.id.titleTextView)
    TextView titleTextView;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_recommend_title;
    }

    @Override
    public View createView(ViewGroup parent) {
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) titleTextView.getLayoutParams();
        params.width = ScreenUtil.getScreenWidth();
        titleTextView.setLayoutParams(params);
        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {

    }
}
