package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.core.model.ReadingHistoryInfo;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.vo.BaseModelVO;

import butterknife.BindView;

/**
 * Created by lj on 17/2/8.
 */

public class BookHistoryViewHolder extends BaseViewHolder<BaseModelVO> {

    public static final int TYPE_BOOK_HISTORY_ITEM_CLICKED = 100;

    int mItemWidth;
    int mItemHeight;

    @BindView(R.id.container)
    FrameLayout container;
    @BindView(R.id.cover_contanier)
    FrameLayout coverContanier;
    @BindView(R.id.book_cover)
    SimpleDraweeView bookCover;

    private Context context;


    public BookHistoryViewHolder() {
        int itemSpacing = LocalDisplay.dp2px(3);
        int screenWidth = ScreenUtil.getScreenWidth();
        mItemWidth = (int) ((screenWidth - 8 * itemSpacing) / 4.0f);
        mItemHeight = (int) (mItemWidth * 32.0f / 25.0f) - LocalDisplay.dp2px(10);

    }

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_item;
    }

    @Override
    public View createView(final ViewGroup parent) {

        context = parent.getContext();
        FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.width = mItemWidth;
        params.height = mItemHeight;
        container.setLayoutParams(params);
        container.setOnClickListener(listener);
        return rootView;
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {

        BaseModel model = itemData.getModel();

        if (model instanceof ReadingHistoryInfo) {
            ReadingHistoryInfo info = (ReadingHistoryInfo) model;
            if (info.getCollectId() > 0) {
//                bookBg.setImageBitmap(BitmapUtils.readBitMap(context, R.drawable.book_collection_bg));
//                coverContanier.setPadding(LocalDisplay.dp2px(2), 0, LocalDisplay.dp2px(5), LocalDisplay.dp2px(7));
                bookCover.setBackgroundResource(R.drawable.bg_collect_book);
            } else {
//                bookBg.setImageBitmap(BitmapUtils.readBitMap(context, R.drawable.book_single_bg));
//                coverContanier.setPadding(LocalDisplay.dp2px(2), 0, LocalDisplay.dp2px(2), LocalDisplay.dp2px(2));
                bookCover.setBackgroundResource(R.drawable.bg_single_book);
            }
            String coverUrl = info.getCoverUrl();
            boolean needResetImageUrl = true;
            if (bookCover.getTag(R.id.list_item_image_url) != null) {
                String url = (String) bookCover.getTag(R.id.list_item_image_url);
                if (TextUtils.equals(url, coverUrl)) {
                    needResetImageUrl = false;
                }
            }
            if (needResetImageUrl) {
                bookCover.setTag(R.id.list_item_image_url, coverUrl);
//                FrescoUtils.showUrl(coverUrl, bookCover, mItemWidth, mItemHeight);

                String imgUrl = CdnUtils.getImgCdnUrl(coverUrl, CdnUtils.getBookCoverSize());
                FrescoUtils.showImg(bookCover, imgUrl, mItemWidth, mItemHeight);
            }
            container.setTag(R.id.view_holder_item, info);

        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            if (mOnEventProcessor == null) {
                return;
            }

            Object object = v.getTag(R.id.view_holder_item);
            mOnEventProcessor.process(TYPE_BOOK_HISTORY_ITEM_CLICKED, object);
        }
    };

}