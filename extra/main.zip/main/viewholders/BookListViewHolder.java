package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.model.BookListItem;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import java.util.List;

import static com.hhdd.kada.main.ui.viewholder.BaseViewHolder.getChildView;

/**
 * Created by lj on 16/11/25.
 */

public class BookListViewHolder extends BaseViewHolder<BaseModelListVO> {

    public static final int TYPE_BOOK_ITEM_CLICKED = 100;

    int mItemWidth;
    int mItemHeight;
    int mCoverWidth;
    int mCoverHeight;
    View view;
    ViewGroup container;

    Context mContext;

    public BookListViewHolder() {

        int viewMarginLeft = (int) KaDaApplication.getInstance().getResources().getDimension(
                R.dimen.grid_view_item_padding_left);
        int viewMarginRight = (int) KaDaApplication.getInstance().getResources().getDimension(
                R.dimen.grid_view_item_padding_right);

        int itemSpacing = (int) KaDaApplication.getInstance().getResources().getDimension(
                R.dimen.grid_view_spacing2);

        int screenWidth = ScreenUtil.getScreenSize(KaDaApplication.getInstance()).x < ScreenUtil.getScreenSize(KaDaApplication.getInstance()).y
                ? ScreenUtil.getScreenSize(KaDaApplication.getInstance()).x : ScreenUtil.getScreenSize(KaDaApplication.getInstance()).y;
        mItemWidth = (int) ((screenWidth - 2 * itemSpacing - viewMarginLeft - viewMarginRight) / 3);
        mItemHeight = (int) (mItemWidth / Constants.BOOK_COVER_RATIO);

        mCoverWidth = mItemWidth - (int) KaDaApplication.getInstance().getResources().getDimension(R.dimen.story_margin);
        mCoverHeight = mItemHeight - (int) KaDaApplication.getInstance().getResources().getDimension(R.dimen.story_margin);
    }

    @Override
    public View createView(final ViewGroup parent) {

        mContext = parent.getContext();
        view = View.inflate(mContext, R.layout.cate_book_list_layout, null);
        container = (ViewGroup) getChildView(view, R.id.container);

        AbsListView.LayoutParams groupParams = new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        container.setLayoutParams(groupParams);
        for (int index = 0; index < container.getChildCount(); index++) {
            final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(index));
            final ScaleDraweeView cover = (ScaleDraweeView) frameLayout.getChildAt(0);

            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) (frameLayout.getLayoutParams());
            FrameLayout.LayoutParams coverParams = (FrameLayout.LayoutParams) cover.getLayoutParams();
            params.width = mItemWidth;
            params.height = mItemHeight;
            coverParams.width = mCoverWidth;
            coverParams.height = mCoverHeight;

            if ((index + 1) % 3 == 0) {
                params.gravity = Gravity.RIGHT | Gravity.CENTER_VERTICAL;
            } else if ((index + 1) % 3 == 1) {
                params.gravity = Gravity.LEFT | Gravity.CENTER_VERTICAL;
            } else {
                params.gravity = Gravity.CENTER;
            }
            coverParams.gravity = Gravity.LEFT | Gravity.BOTTOM;
            cover.setLayoutParams(coverParams);
            frameLayout.setLayoutParams(params);
            frameLayout.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {

                @Override
                public void OnClickWithAnim(final View v) {

//                    frameLayout.getChildAt(1).setVisibility(View.GONE);
                    Object object = v.getTag(R.id.view_holder_item);
                    if (mOnEventProcessor != null) {
                        mOnEventProcessor.process(TYPE_BOOK_ITEM_CLICKED, object);
                    }
                    if (object != null && object instanceof BookInfo) {
                        BookInfo bookInfo = (BookInfo) object;

                        final int[] location = new int[2];
                        frameLayout.getLocationOnScreen(location);

                        if (bookInfo.getIndex() != -1) {
                            UserHabitService.getInstance().track(UserHabitService.newUserHabit("" + bookInfo.getBookId(), "click_mainbooklist_pos" + bookInfo.getIndex(), TimeUtil.currentTime()));
                        }
//                        KaDaApplication.getInstance().setBitmapList(null);
//                        final List<Bitmap> bitmapList = new ArrayList<Bitmap>();
//                        Bitmap bitmap = BitmapUtils.drawableToBitmap(cover.getDrawable(),cover.getWidth(),cover.getHeight());
//                        if (bitmap != null) {
//
//                            bitmapList.add(bitmap);
//                            KaDaApplication.getInstance().setBitmapList(bitmapList);
//                            BookService.saveBookInfoToLocal(BookListItem.createOldInfoByNewBook(bookInfo));
//
//                            PlaybackActivity.BookLocation bookLocation = new PlaybackActivity.BookLocation(location[0], location[1], cover.getWidth(), cover.getHeight());
//                            PlaybackActivity.startActivity(mContext, bookInfo.getBookId(), bookInfo.getExtFlag(), bookInfo.getVersion(), bookLocation);
//                        }else{
                        PlaybackActivity.startActivity(mContext, bookInfo.getBookId(), bookInfo.getExtFlag(), bookInfo.getVersion());
//                        }

                    } else if (object != null && object instanceof BookCollectionInfo) {
                        BookCollectionInfo info = (BookCollectionInfo) object;

                        if (info.getIndex() != -1) {
                            UserHabitService.getInstance().track(UserHabitService.newUserHabit("" + info.getCollectId(), "click_mainbooklist_pos" + info.getIndex(), TimeUtil.currentTime()));
                        }
                        FragmentUtil.pushFragment(BookCollectionFragment.class,info.getCollectId(),true);
                    }
                }
            });

        }
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        List<BaseModel> list = itemData.getItemList();
        if (list != null && list.size() > 0) {
            int count = list.size() > 3 ? 3 : list.size();
            for (int i = 0; i < count; i++) {

                final FrameLayout frameLayout = ((FrameLayout) container.getChildAt(i));
                SimpleDraweeView cover = (SimpleDraweeView) frameLayout.getChildAt(0);
                ImageView flag = (ImageView) frameLayout.getChildAt(1);
                frameLayout.setVisibility(View.VISIBLE);
                if (list.get(i) instanceof BookListItem) {
                    BookListItem item = (BookListItem) list.get(i);
                    if (item.getData() != null && item.getData() instanceof BookInfo) {
                        BookInfo bookInfo = (BookInfo) item.getData();

//                        cover.setBackgroundDrawable(null);
                        cover.setBackgroundResource(R.drawable.icon_book_collection_default);
//                        cover.setPadding(0, 0, 0, 0);

//                        if ((bookInfo.getExtFlag() & Extflag.EXT_FLAG_256) == Extflag.EXT_FLAG_256) {
//                            if (HistoryCache.getInstance().isContainBookId(bookInfo.getBookId())) {
//                                flag.setVisibility(View.GONE);
//                            } else {
//                                flag.setVisibility(View.VISIBLE);
//                                flag.setImageResource(R.drawable.icon_hot_flag);
//                            }
//                        } else {
//                            if ((bookInfo.getExtFlag() & Extflag.EXT_FLAG_64) == Extflag.EXT_FLAG_64) {
//                                if (HistoryCache.getInstance().isContainBookId(bookInfo.getBookId())) {
//                                    flag.setVisibility(View.GONE);
//                                } else {
//                                    flag.setVisibility(View.VISIBLE);
//                                    flag.setImageResource(R.drawable.icon_new_flag);
//                                }
//                            } else {
//                                flag.setVisibility(View.GONE);
//                            }
//                        }
                        flag.setVisibility(View.GONE);
                        String coverUrl = CdnUtils.getImgCdnUrl(bookInfo.getCoverUrl(), CdnUtils.getBookCoverSize());
                        boolean needResetImageUrl = true;
                        if (cover.getTag(R.id.book_list_item_image_url) != null) {
                            String url = (String) cover.getTag(R.id.book_list_item_image_url);
                            if (TextUtils.equals(url, coverUrl)) {
                                needResetImageUrl = false;
                            }
                        }
                        if (needResetImageUrl) {
                            cover.setTag(R.id.book_list_item_image_url, coverUrl);
                            FrescoUtils.showImg(cover, coverUrl, mCoverWidth, mCoverHeight);
                        }

                        TextView clickCount = (TextView) frameLayout.getChildAt(2);
                        clickCount.setText(StringUtil.formatClickCount(bookInfo.getClickCount()));
                        //3.3需求 播放量不再展示
                        clickCount.setVisibility(View.GONE);

                        frameLayout.setTag(R.id.view_holder_item, bookInfo);
                    } else if (item.getData() != null && item.getData() instanceof BookCollectionInfo) {
                        BookCollectionInfo info = (BookCollectionInfo) item.getData();

                        cover.setBackgroundResource(R.drawable.bg_collect_book);
//                        cover.setPadding(0, 0, KaDaApplication.getInstance().getResources().getDimensionPixelSize(R.dimen.view_padding_top),
//                                KaDaApplication.getInstance().getResources().getDimensionPixelSize(R.dimen.view_padding));
//
//                        if ((info.getExtFlag() & Extflag.EXT_FLAG_256) == Extflag.EXT_FLAG_256) {
//                            flag.setVisibility(View.VISIBLE);
//                            flag.setImageResource(R.drawable.icon_hot_flag);
//                        } else {
//                            if ((info.getExtFlag() & Extflag.EXT_FLAG_64) == Extflag.EXT_FLAG_64) {
//                                flag.setVisibility(View.VISIBLE);
//                                flag.setImageResource(R.drawable.icon_new_flag);
//                            } else {
//                                flag.setVisibility(View.GONE);
//                            }
//                        }
                        flag.setVisibility(View.GONE);

                        String coverUrl = CdnUtils.getImgCdnUrl(info.getCoverUrl(), CdnUtils.getBookCoverSize());
                        boolean needResetImageUrl = true;
                        if (cover.getTag(R.id.book_list_item_image_url) != null) {
                            String url = (String) cover.getTag(R.id.book_list_item_image_url);
                            if (TextUtils.equals(url, coverUrl)) {
                                needResetImageUrl = false;
                            }
                        }
                        if (needResetImageUrl) {
                            cover.setTag(R.id.book_list_item_image_url, coverUrl);
                            FrescoUtils.showImg(cover, coverUrl, mCoverWidth, mCoverHeight);
                        }

                        TextView clickCount = (TextView) frameLayout.getChildAt(2);
                        clickCount.setText(StringUtil.formatClickCount(info.getClickCount()));
                        clickCount.setVisibility(View.GONE);

                        frameLayout.setTag(R.id.view_holder_item, info);
                    } else {
                        frameLayout.setVisibility(View.GONE);
                    }
                }
            }

            for (int i = count; i < 3; i++) {
                final View layout = container.getChildAt(i);
                layout.setVisibility(View.GONE);
                layout.setTag(R.id.view_holder_item, null);
            }
        }
    }

}