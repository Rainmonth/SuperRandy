package com.hhdd.kada.main.viewholders;

import android.view.View;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.ui.book.BaseCollectionFragment;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.PayExcellentBookMoreItemView;
import com.hhdd.kada.main.vo.BaseModelListVO;

import butterknife.BindView;

import static com.hhdd.kada.R.id.position;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.viewholders
 */
public class PayExcellentBookViewHolder extends BaseViewHolder<BaseModelListVO> {

    @BindView(R.id.payExcellentBookMoreItemView)
    PayExcellentBookMoreItemView payExcellentBookMoreItemView;

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_pay_excellent_book;
    }

    @Override
    public void showData(final int position, BaseModelListVO itemData) {
        if (itemData != null && itemData.getItemList() != null && itemData.getItemList().size() > 0) {
            BaseModel model = itemData.getItemList().get(0);
            if (model instanceof BookCollectionInfo) {
                final BookCollectionInfo info = (BookCollectionInfo) model;
                payExcellentBookMoreItemView.update(info);
                payExcellentBookMoreItemView.setTag(R.id.container,info);
                payExcellentBookMoreItemView.setOnClickListener(listener);
            }
        }
    }

    KaDaApplication.OnClickWithAnimListener listener = new KaDaApplication.OnClickWithAnimListener() {
        @Override
        public void OnClickWithAnim(View v) {
            BookCollectionInfo info = (BookCollectionInfo) v.getTag(R.id.container);
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("1," + info.getSourceId(),
                    "recommended_purchase_content_click_" + position, TimeUtil.currentTime()));
            FragmentUtil.pushFragment(BookCollectionFragment.class, new BaseCollectionFragment.CollectionModel(info.getSourceId(), false), true);

        }
    };
}
