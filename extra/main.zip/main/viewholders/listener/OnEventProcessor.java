package com.hhdd.kada.main.viewholders.listener;

/**
 * 实现UI和业务逻辑分离
 * <p>
 * Created by bjx on 2017/11/21.
 */
public interface OnEventProcessor {

    /**
     * @param type 事件类型
     * @param args 事件参数
     * @return true：表示已处理 false：表示未处理
     */
    boolean process(int type, Object... args);

}
