package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.core.model.ReadingHistoryInfo;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.viewholders.mvc.BaseMvcViewHolder;
import com.hhdd.kada.main.views.HorizontialListView;
import com.hhdd.kada.main.views.OnItemScaleClickListener;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseVO;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

import static com.hhdd.kada.R.id.cover;

/**
 * Created by simon on 06/01/2017.
 */

public class BookHistoriesViewHolder extends BaseMvcViewHolder<BaseVO> {

    public static final int TYPE_BOOK_HISTORY_ITEM_CLICKED = 300;

    Context context;
    View view;
    HorizontialListView listView;
    MyAdapter adapter;

    int itemSize = 0;

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_compat_book_home_histories, parent, false);
        listView = (HorizontialListView) view.findViewById(R.id.book_home_histories_listview);

        itemSize = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(10 + 20 + 28)) / 5;
        listView.getLayoutParams().height = (int) (itemSize * 32.0f / 25.0f);

        listView.setDividerWidth(LocalDisplay.dp2px(7));

        adapter = new MyAdapter(parent.getContext());
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new OnItemScaleClickListener() {
            @Override
            public void onItemClickScaled(AdapterView<?> parent, View view, int position, long id) {
                super.onItemClickScaled(parent, view, position, id);
                if (mOnEventProcessor == null) {
                    return;
                }

                if (position < adapter.getCount()) {
                    ReadingHistoryInfo historyInfo = adapter.getItem(position);

                    mOnEventProcessor.process(TYPE_BOOK_HISTORY_ITEM_CLICKED, position, historyInfo);
                }
            }
        });

        return view;
    }

    @Override
    public void showData(int position, BaseVO baseVO) {
        if (!(baseVO instanceof BaseModelListVO)) return;

        BaseModelListVO baseVOList = (BaseModelListVO) baseVO;
        if (baseVOList.getItemList() == null || baseVOList.getItemList().size() == 0) return;

        List<ReadingHistoryInfo> historyInfoList = new ArrayList<>();
        final List<BaseModel> itemList = baseVOList.getItemList();
        for (int i = 0; i < itemList.size(); i++) {
            BaseModel model = itemList.get(i);
            if (model instanceof ReadingHistoryInfo) {
                historyInfoList.add((ReadingHistoryInfo) model);
            }
            if(i >= 4) break;//最多显示4个
        }
//        for (BaseModel model : baseVOList.getItemList()) {
//            if (model instanceof ReadingHistoryInfo) {
//                historyInfoList.add((ReadingHistoryInfo) model);
//            }
//            if (historyInfoList.size() >= 4) break;
//        }

        if (historyInfoList.size() >= 4) {
            ReadingHistoryInfo info = new ReadingHistoryInfo();
            info.setBookId(-1);
//            info.setCoverUrl("res://" + context.getPackageName() + "/" + R.drawable.datalist_book_history_more);
            historyInfoList.add(info);
        }
        adapter.replaceAll(historyInfoList);
    }

    class MyAdapter extends QuickAdapter<ReadingHistoryInfo> {

        public MyAdapter(Context context) {
            super(context, R.layout.view_holder_datalist_orgslide_item);
        }

        @Override
        protected void convert(BaseAdapterHelper helper, ReadingHistoryInfo item) {

            View view = helper.getView(R.id.item_container);
            view.getLayoutParams().width = itemSize;
            SimpleDraweeView draweeView = helper.getView(cover);

            int itemHeight = (int) (itemSize * 32.0f / 25.0f);

            draweeView.getLayoutParams().width = itemSize;
            draweeView.getLayoutParams().height = itemHeight;

            String coverUrl = item.getCoverUrl();
            boolean needResetImageUrl = true;
            if (draweeView.getTag(R.id.list_item_image_url) != null) {
                String url = (String) draweeView.getTag(R.id.list_item_image_url);
                if (TextUtils.equals(url, coverUrl)) {
                    needResetImageUrl = false;
                }
            }

            if (needResetImageUrl) {
                draweeView.setTag(R.id.list_item_image_url, coverUrl);
//                FrescoUtils.showUrl(coverUrl, draweeView, itemSize, itemHeight);

                String imgUrl = CdnUtils.getImgCdnUrl(coverUrl, CdnUtils.getBookCoverSize(), true);
                FrescoUtils.showImg(draweeView, imgUrl, itemSize, itemHeight);
            }

            if (helper.getPosition() != 4) {
                if (item.getCollectId() > 0) {
                    draweeView.setBackgroundResource(R.drawable.bg_collect_book);
//                    draweeView.setPadding(LocalDisplay.designedDP2px(0), 0, LocalDisplay.designedDP2px(4), LocalDisplay.designedDP2px(4));
                } else if (item.getCollectId() == 0) {
                    draweeView.setBackgroundResource(R.drawable.bg_single_book);
//                    draweeView.setPadding(LocalDisplay.designedDP2px(0), 0, LocalDisplay.designedDP2px(2), LocalDisplay.designedDP2px(2));
                }
            } else {
                draweeView.setBackgroundResource(R.drawable.datalist_book_history_more);
            }
        }
    }
}
