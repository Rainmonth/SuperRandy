package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.StyleVO;

/**
 * Created by simon on 9/20/16.
 */
public class TitleViewHolder extends BaseViewHolder<BaseModelListVO> {

    Context context;
    View view;
    View leftContainer;
    SimpleDraweeView titleIcon;
    TextView title;
    TextView subTitle;
    View subTitleIcon;
    RedirectInfo redirectInfo;

    StyleVO styleVO;

    @Override
    public View createView(ViewGroup parent) {
        context = parent.getContext();
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        view = layoutInflater.inflate(R.layout.view_holder_datalist_title, parent,false);
        titleIcon=(SimpleDraweeView)view.findViewById(R.id.datalist_title_icon);
        title = (TextView)view.findViewById(R.id.datalist_title_tv);
        subTitle = (TextView)view.findViewById(R.id.datalist_title_subtitle);
        subTitleIcon = (ImageView)view.findViewById(R.id.datalist_title_subtitle_icon);
        view.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (redirectInfo!=null) {
                    RedirectActivity.startActivity(context,redirectInfo);
                }
            }
        });
        leftContainer=view.findViewById(R.id.datalist_title_left_container);
        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData==null||itemData.getItemList()==null) return;
        if (itemData.getItemList().size()==0)return;

        styleVO = itemData.getStyleVO();
        if (styleVO!=null&&styleVO.getBg()!=null&&styleVO.getBg().length()>0) {
            view.setBackgroundColor(Color.parseColor(styleVO.getBg()));
        } else {
            view.setBackgroundResource(R.color.white);
        }

        if (styleVO!=null&&styleVO.isAlignMiddle()) {
            if (((RelativeLayout.LayoutParams)leftContainer.getLayoutParams()).getRules()[RelativeLayout.CENTER_HORIZONTAL]==0) {
                ((RelativeLayout.LayoutParams)leftContainer.getLayoutParams()).addRule(RelativeLayout.CENTER_HORIZONTAL);
            }
        } else {
            if (((RelativeLayout.LayoutParams)leftContainer.getLayoutParams()).getRules()[RelativeLayout.CENTER_HORIZONTAL]!=0) {
                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
                leftContainer.setLayoutParams(lp);
            }
        }

        this.redirectInfo=null;

        if (itemData.getItemList().size()>0) {
           BaseModel baseModel = itemData.getItemList().get(0);
            if (baseModel instanceof RedirectInfo) {
                RedirectInfo redirectInfo = (RedirectInfo)baseModel;
                this.redirectInfo=redirectInfo;
                if (redirectInfo.getTitle()!=null&&redirectInfo.getTitle().length()>0) {
                    title.setText(redirectInfo.getTitle());
                }
                if (redirectInfo.getSubTitle()!=null&&redirectInfo.getSubTitle().length()>0) {
                    subTitle.setText(redirectInfo.getSubTitle());
                    subTitleIcon.setVisibility(View.VISIBLE);
                    subTitle.setVisibility(View.VISIBLE);
                } else {
                    subTitleIcon.setVisibility(View.GONE);
                    subTitle.setVisibility(View.GONE);
                }

                if (redirectInfo.getImageUrl()!=null&&redirectInfo.getImageUrl().length()>0) {
//                    int with = titleIcon.getWidth();
//                    int height = titleIcon.getHeight();
                    FrescoUtils.showUrl(redirectInfo.getImageUrl(),titleIcon, LocalDisplay.dp2px(20),LocalDisplay.dp2px(20));
                }
            }
        }
    }
}
