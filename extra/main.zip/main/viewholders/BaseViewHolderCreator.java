package com.hhdd.kada.main.viewholders;

import com.hhdd.kada.android.library.app.lifecycle.IComponentContainer;
import com.hhdd.kada.android.library.views.list.ViewHolderBase;
import com.hhdd.kada.android.library.views.list.ViewHolderCreator;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.viewholders.mvc.BaseMvcViewHolder;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.main.vo.ViewTypes;
import com.hhdd.logger.LogHelper;

import java.util.Iterator;
import java.util.Map;

/**
 * Created by simon on 6/16/16.
 */
public class BaseViewHolderCreator<T> implements ViewHolderCreator<BaseVO> {

    Map<Integer,Class<?>> viewTypeMaps;
    IComponentContainer componentContainer;

    private OnEventProcessor mOnEventProcessor;

    public BaseViewHolderCreator(IComponentContainer componentContainer, Map<Integer,Class<?>> viewTypeMaps) {
        this.componentContainer = componentContainer;
        this.viewTypeMaps = viewTypeMaps;
    }

    public boolean isCompat(int viewType) {
        boolean compat = false;
        if (viewTypeMaps.get(viewType)!=null) {
            compat = true;
        }
        return compat;
    }

    public void setOnEventProcessor(OnEventProcessor onEventProcessor) {
        mOnEventProcessor = onEventProcessor;
    }

    @Override
    public ViewHolderBase<BaseVO> createViewHolder(int viewType) {
        ViewHolderBase<BaseVO> viewHolder = null;

        if (viewTypeMaps != null) {
            Class<?> cls = viewTypeMaps.get(viewType);
            if (cls != null) {
                try {
                    viewHolder = (ViewHolderBase<BaseVO>)cls.getConstructor().newInstance();
                    if (viewHolder instanceof BaseViewHolder) {
                        ((BaseViewHolder) viewHolder).setComponentContainer(componentContainer);
                    }

                    if (viewHolder instanceof BaseMvcViewHolder) {
                        ((BaseMvcViewHolder) viewHolder).setOnEventProcessor(mOnEventProcessor);
                    }
                } catch (Exception e) {
                    LogHelper.printStackTrace(e);
                }
            }
        }

        if (viewHolder == null) {
            viewHolder = new CompatEmptyViewHolder();
            ((CompatEmptyViewHolder)viewHolder).setComponentContainer(componentContainer);
        }

        return viewHolder;
    }

    @Override
    public int getItemViewType(int position, BaseVO itemData) {
        if (itemData != null) {
            int viewType = itemData.getViewType();
            if (viewTypeMaps.get(viewType)!=null) {
                return viewType;
            }
        }

        return ViewTypes.View_Type_CompatEmpty.getId();
    }

    private int View_Type_Count = 0;

    @Override
    public int getViewTypeCount() {
        if (View_Type_Count==0) {
            View_Type_Count = viewTypeMaps.size();
            Iterator<Integer> iterator = viewTypeMaps.keySet().iterator();
            while(iterator.hasNext()){
                int viewType = iterator.next();
                if (viewType>=View_Type_Count) {
                    View_Type_Count = viewType+1;
                }
            }
        }
        return View_Type_Count;
    }
}
