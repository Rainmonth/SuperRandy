package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.bigkoo.convenientbanner.holder.CBViewHolderCreator;
import com.bigkoo.convenientbanner.holder.Holder;
import com.bigkoo.convenientbanner.listener.OnItemClickListener;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.model.RecommendVO;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Constants;
import com.hhdd.kada.R;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.model.BannerInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.ui.book.BookCollectionListFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionFragment;
import com.hhdd.kada.main.ui.story.StoryCollectionListFragment;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.ScreenUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.views.ArcView;
import com.hhdd.kada.main.views.CommonBannerView;
import com.hhdd.kada.main.views.MyConvenientBanner;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.module.exposure.ExposureTracker;
import com.hhdd.kada.module.userhabit.bannerstatic.BannerStaticManager;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * Created by lj on 16/12/13.
 */

public class CommonBannerViewHolder extends BaseViewHolder<BaseModelListVO> {


    private static final int TURNING_INTERVAL = 4000;
    protected boolean isShowArc = false;

    @BindView(R.id.layout)
    View layout;
    @BindView(R.id.bannerView)
    CommonBannerView bannerView;
    @BindView(R.id.arc_view)
    ArcView arcView;

    protected Context mContext;
    List<BannerInfo> bannerInfos = new ArrayList<>();

    private int[] mIndicatorIds = new int[]{R.drawable.ic_page_indicator, R.drawable.ic_page_indicator_focused};

    private boolean isEventRegistered = false;

    private ViewPager.OnPageChangeListener mOnPageChangeListener = new ViewPager.OnPageChangeListener() {
        @Override
        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

        }

        @Override
        public void onPageSelected(int position) {
            if (position < 0 || position >= bannerInfos.size()) {
                return;
            }

            /**
             * Banner展示统计打点
             */
            BannerInfo bannerInfo = bannerInfos.get(position);
            BannerStaticManager bannerStaticManager = (BannerStaticManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.BANNER_STATIC_MANAGER);
            bannerStaticManager.increment(String.valueOf(bannerInfo.getId()));

            //曝光量。刚启动app、第一次展示精选页面，这里会回调，但是没数据，所以MotherExcellentFragment在数据加载好会发EventBus，再其事件通知中再统计
            CommonBannerViewHolder.this.onPageSelected(position);
        }

        @Override
        public void onPageScrollStateChanged(int state) {

        }
    };

    protected void onPageSelected(int position){

    }

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_datalist_banner_common;
    }

    @Override
    public View createView(ViewGroup parent) {
        mContext = parent.getContext();

        arcView.setVisibility(isShowArc ? View.VISIBLE : View.GONE);//是否显示圆弧效果

        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.height = (int) (ScreenUtil.getScreenWidth() * Constants.MOTHER_BANNER_RATIO);
        layout.setLayoutParams(params);

        layout.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
                registerEvent();
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                unregisterEvent();
            }
        });

        bannerView.setOnPageChangeListener(mOnPageChangeListener);

        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {

        if (itemData == null || itemData.getItemList() == null || itemData.getItemList().size() == 0) {
            return;
        }

        bannerInfos.clear();

        for (BaseModel baseModel : itemData.getItemList()) {
            if (baseModel instanceof BannerInfo) {
                bannerInfos.add((BannerInfo) baseModel);
            }
        }

        bannerView.setCanLoop(bannerInfos.size() > 1);
        bannerView.setPages(new MyCBViewHolderCreator(), bannerInfos)
                //设置两个点图片作为翻页指示器，不设置则没有指示器，可以根据自己需求自行配合自己的指示器,不需要圆点指示器可用不设
                .setPageIndicator(bannerInfos.size() <= 1 ? null : mIndicatorIds)
                //设置指示器的方向
                .setPageIndicatorAlign(MyConvenientBanner.PageIndicatorAlign.CENTER_HORIZONTAL)
                .setOnItemClickListener(mOnItemClickListener);

        startTurning();
    }

    static class BannerImageHolderView implements Holder<BannerInfo> {

        private ScaleDraweeView simpleDraweeView;

        @Override
        public View createView(Context context) {
            //你可以通过layout文件来创建，也可以像我一样用代码创建，不一定是Image，任何控件都可以进行翻页
            View rootView = LayoutInflater.from(context).inflate(R.layout.banner_image_holder_view, null);
            simpleDraweeView = (ScaleDraweeView) rootView.findViewById(R.id.banner);
            return simpleDraweeView;
        }

        @Override
        public void UpdateUI(Context context, int position, BannerInfo data) {
            String bannerImg = CdnUtils.getImgCdnUrl(data.getBannerUrl(), CdnUtils.getBannerSize());
            FrescoUtils.showImg(simpleDraweeView, bannerImg);
        }
    }

    protected void doBannerClick(int position) {
        if (position >= bannerInfos.size()) {
            return;
        }

        BannerInfo info = bannerInfos.get(position);

        if (info.getKind() == RecommendVO.STORY_BANNER) {
            if (info.getType() == 1) {
                if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openstory", TimeUtil.currentTime()));
                    ListenActivity.startActivity(mContext, Integer.parseInt(info.getContent().trim()));
                }
            } else if (info.getType() == 4) {
                if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openstory_collect", TimeUtil.currentTime()));
//                                    StoryCollectionActivity.startActivity(mContext, Integer.parseInt(info.getContent().trim()));
                    //新合集
                    FragmentUtil.presentFragment(StoryCollectionFragment.class, Integer.parseInt(info.getContent().trim()), true);
                }
            } else if (info.getType() == 2) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openhtml", TimeUtil.currentTime()));
                RedirectActivity.startActivity(mContext, info.getContent());
            } else if (info.getType() == 3) {
                if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openstory_category", TimeUtil.currentTime()));
                    //离线下载跳转
//                                if (TextUtils.equals(info.getContent(), "-1")) {
//                                    DownloadListFragment.DownloadListVO vo = new DownloadListFragment.DownloadListVO(DownloadListFragment.STORY_TYPE, null);
//                                    FragmentUtil.pushFragment(DownloadListFragment.class, vo, true);
//                                } else {
//                                    FragmentUtil.pushFragment(CateStoryListFragment.class, new Category(Integer.parseInt(info.getContent().trim()), info.getName()), true);
//                                }
                }

            } else if (info.getType() == 6) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit(String.valueOf(info.getId()), "clickbanner", TimeUtil.currentTime()));
                RedirectActivity.startActivity(mContext, info.getContent());
            }
        } else if (info.getKind() == RecommendVO.BOOK_BANNER) {
            if (info.getType() == 1) {
                if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openbook", TimeUtil.currentTime()));
//                                    info.setBookId(Integer.parseInt(recommendVO.getContent().trim()));
//                                    info.setName(recommendVO.getName());
//                                    info.setCoverUrl(recommendVO.getBannerUrl());
                    PlaybackActivity.startActivity(mContext, Integer.parseInt(info.getContent().trim()));
                }
            } else if (info.getType() == 3) {//type为3后台控制不允许配置年龄分类
                if (info.getContent() != null && StringUtil.isNumeric(info.getContent().trim())) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openbook_category", TimeUtil.currentTime()));
                    BookCollectionListFragment.pushFragment(new StoryCollectionListFragment.CollectionTypeInfo(
                            BookCollectionListFragment.COLLECTION_TYPE_CATEGORY, info.getName(), Integer.parseInt(info.getContent().trim()), 0, 0));
                }

            } else if (info.getType() == 4) {
                if (info.getContent() != null && StringUtil.isNumeric(info.getContent())) {
                    UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openbook_collect", TimeUtil.currentTime()));
//                                BookCollectionActivity.startActivity(mContext, Integer.parseInt(info.getContent()));
                    FragmentUtil.pushFragment(BookCollectionFragment.class, Integer.parseInt(info.getContent()), true);

                }
            } else if (info.getType() == 2) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner_openhtml", TimeUtil.currentTime()));
                RedirectActivity.startActivity(mContext, info.getContent());
            } else if (info.getType() == 6) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner", TimeUtil.currentTime()));
                RedirectActivity.startActivity(mContext, info.getContent());
            }
        } else if (info.getKind() == RecommendVO.MOTHER_EXCELLENT_BANNER || info.getKind() == RecommendVO.MOTHER_BOOK_BANNER || info.getKind() == RecommendVO.MOTHER_STORY_BANNER) {
            if (info.getType() == 6) {
                UserHabitService.getInstance().track(UserHabitService.newUserHabit(info.getId() + "", "clickbanner", TimeUtil.currentTime()));
                RedirectActivity.startActivity(mContext, info.getContent());
            }
        }
    }

    private OnItemClickListener mOnItemClickListener = new OnItemClickListener() {
        @Override
        public void onItemClick(int position) {
            doBannerClick(position);
        }
    };

    public void stopTurning() {
        if (bannerView == null) {
            return;
        }

        if (!bannerView.isTurning()) {
            return;
        }

        bannerView.stopTurning();
    }

    public void startTurning() {
        if (bannerView == null) {
            return;
        }

        if (bannerView.isTurning()) {
            return;
        }

        bannerView.startTurning(TURNING_INTERVAL);
    }

    private void registerEvent() {
        if (isEventRegistered) {
            return;
        }

        isEventRegistered = true;
        EventBus.getDefault().register(this);
    }

    private void unregisterEvent() {
        if (!isEventRegistered) {
            return;
        }

        isEventRegistered = false;
        EventBus.getDefault().unregister(this);
    }

    public void onEvent(UpdateBannerTurnStatusEvent event) {
        if (event == null) {
            return;
        }

        if (event.turn) {
            startTurning();
        } else {
            stopTurning();
        }
    }

    private static class MyCBViewHolderCreator implements CBViewHolderCreator<BannerImageHolderView> {
        @Override
        public BannerImageHolderView createHolder() {
            return new BannerImageHolderView();
        }
    }

    public static class UpdateBannerTurnStatusEvent {
        public boolean turn;

        public UpdateBannerTurnStatusEvent(boolean turn) {
            this.turn = turn;
        }
    }
}

