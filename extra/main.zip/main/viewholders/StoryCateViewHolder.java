package com.hhdd.kada.main.viewholders;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.widget.support.KdGridLayoutManager;
import com.joanzapata.android.BaseAdapterHelper;
import com.joanzapata.android.QuickAdapter;

import java.util.ArrayList;
import java.util.List;

import static com.hhdd.kada.R.id.cover;

/**
 * Created by simon on 9/20/16.
 */
public class StoryCateViewHolder extends BaseViewHolder<BaseModelListVO> {
    Context mContext;

    View view;

//    GridViewAdapter adapter;

    private RecyclerViewAdapter mRecyclerViewAdapter;
    private List<RedirectInfo> mRedirectInfos;

    int itemSize;

    @Override
    public View createView(ViewGroup parent) {
        mContext = parent.getContext();
        view = LayoutInflater.from(mContext).inflate(R.layout.view_holder_datalist_storycate_page, parent, false);

        itemSize = (LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(12)) / 5 - LocalDisplay.dp2px(12);

//        GridView gridView = (GridView) view.findViewById(R.id.gridview);
//        gridView.getLayoutParams().height = itemSize * 2 + LocalDisplay.dp2px(4 + 28);
//
//        adapter = new GridViewAdapter(mContext);
//        gridView.setAdapter(adapter);
//        gridView.setOnItemClickListener(new OnItemScaleClickListener() {
//            @Override
//            public void onItemClickScaled(AdapterView<?> parent, View view, int position, long id) {
//                super.onItemClickScaled(parent, view, position, id);
//                if (position < adapter.getCount()) {
//                    RedirectInfo redirectInfo = adapter.getItem(position);
//                    RedirectActivity.startActivity(mContext, redirectInfo);
//                }
//            }
//        });

        mRedirectInfos = new ArrayList<RedirectInfo>();
        mRecyclerViewAdapter = new RecyclerViewAdapter();

        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.gridView);
        GridLayoutManager gridLayoutManager = new KdGridLayoutManager(mContext, 5);
        gridLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.getLayoutParams().height = (itemSize + LocalDisplay.dp2px(40)) * 2;
        recyclerView.setAdapter(mRecyclerViewAdapter);

        return view;
    }

    @Override
    public void showData(int position, BaseModelListVO itemData) {
        if (itemData == null || itemData.getItemList() == null)
            return;
        if (itemData.getItemList().size() == 0)
            return;

        mRedirectInfos.clear();

        int size = Math.min(itemData.getItemList().size(), 10);
        for (int i = 0; i < size; i++){
            BaseModel baseModel = itemData.getItemList().get(i);
            if (baseModel instanceof RedirectInfo) {
                mRedirectInfos.add((RedirectInfo) baseModel);
            }
        }

        mRecyclerViewAdapter.notifyDataSetChanged();

//        adapter.replaceAll(listTemp);
//        adapter.notifyDataSetChanged();

    }

    class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewHolder> {

        public RecyclerViewAdapter() {
            super();
        }

        @Override
        public int getItemCount() {
            return mRedirectInfos.size();
        }

        @Override
        public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new RecyclerViewHolder(View.inflate(mContext, R.layout.view_holder_datalist_storycate_page_item, null));
        }

        @Override
        public void onBindViewHolder(RecyclerViewHolder holder, int position) {
            holder.bindData(position);
        }
    }

    class RecyclerViewHolder extends RecyclerView.ViewHolder {

        private TextView title;
        private SimpleDraweeView draweeView;

        public RecyclerViewHolder(View itemView) {
            super(itemView);
            View view = itemView.findViewById(R.id.item_container);
            view.setOnClickListener(onClickListener);

            draweeView = (SimpleDraweeView) itemView.findViewById(R.id.cover);
            ViewGroup.LayoutParams layoutParams = draweeView.getLayoutParams();
            layoutParams.width = itemSize;
            layoutParams.height = itemSize;

            title = (TextView) itemView.findViewById(R.id.title);
        }

        public void bindData(int position) {
            itemView.setTag(R.id.position, position);

            RedirectInfo item = mRedirectInfos.get(position);
            title.setText(item.getTitle());

            if (item.getImageUrl() == null) {
                return;
            }

            String coverUrl = item.getImageUrl();
            boolean needResetImageUrl = true;
            if (draweeView.getTag(R.id.list_item_image_url) != null) {
                String url = (String) draweeView.getTag(R.id.list_item_image_url);
                if (TextUtils.equals(url, coverUrl)) {
                    needResetImageUrl = false;
                }
            }
            if (needResetImageUrl) {
                draweeView.setTag(R.id.list_item_image_url, coverUrl);
                FrescoUtils.showUrl(coverUrl, draweeView, itemSize, itemSize);
            }


        }

        private View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRedirectInfos == null || mRedirectInfos.isEmpty()) {
                    return;
                }

                try {
                    Integer position =(Integer) v.getTag(R.id.position);
                    RedirectActivity.startActivity(mContext, mRedirectInfos.get(position));
                } catch (Throwable e){
                }
            }
        };
    }

    class GridViewAdapter extends QuickAdapter<RedirectInfo> {

        public GridViewAdapter(Context context) {
            super(context, R.layout.view_holder_datalist_storycate_page_item);
        }

        @Override
        protected void convert(BaseAdapterHelper helper, RedirectInfo item) {
            View view = helper.getView(R.id.item_container);
            view.getLayoutParams().width = itemSize;
            view.getLayoutParams().height = itemSize + LocalDisplay.dp2px(14);

            TextView title = helper.getView(R.id.title);
            title.setText(item.getTitle());

            SimpleDraweeView draweeView = helper.getView(cover);
            draweeView.getLayoutParams().width = itemSize * 4 / 5;
            draweeView.getLayoutParams().height = itemSize * 4 / 5;

            int width = itemSize;//view.getWidth();
            int height = itemSize;//view.getHeight();

            if (item.getImageUrl() != null) {
                String coverUrl = CdnUtils.getImgCdnUrl(item.getImageUrl(), CdnUtils.SIZE_160x160);
                boolean needResetImageUrl = true;
                if (draweeView.getTag(R.id.list_item_image_url) != null) {
                    String url = (String) draweeView.getTag(R.id.list_item_image_url);
                    if (TextUtils.equals(url, coverUrl)) {
                        needResetImageUrl = false;
                    }
                }
                if (needResetImageUrl) {
                    draweeView.setTag(R.id.list_item_image_url, coverUrl);
                    FrescoUtils.showImg(draweeView, coverUrl, width, height);
                }
            }

        }
    }
}


//http://cdn.hhdd.com/assets/file/BookViewConfigTest.json