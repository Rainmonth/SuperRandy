package com.hhdd.kada.main.viewholders;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.event.CollectionAnimStopEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LimitFreeEndedEvent;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.SafeHandler;
import com.hhdd.kada.main.views.ScaleDraweeView;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.widget.CollectionReadingModelView;
import com.hhdd.kada.widget.CollectionRecommendView;
import com.hhdd.logger.LogHelper;

import java.util.Timer;
import java.util.TimerTask;

import butterknife.BindView;
import cn.iwgang.countdownview.CountdownView;
import de.greenrobot.event.EventBus;

/**
 * Created by MCX on 2017/6/9.
 */

public class StoryCollectionBlurDetailViewHolder extends BaseViewHolder<BaseModelVO> {

    public static final int TYPE_SUBSCRIBE_CLICKED = 100;
    public static final int TYPE_INTRODUCATION_CLICKED = 101;

    @BindView(R.id.banner)
    ScaleDraweeView banner;
    @BindView(R.id.serialize)
    TextView serialize;
    @BindView(R.id.subscribed_ll)
    View subscribedLayout;
    @BindView(R.id.collectionRecommendView)
    CollectionRecommendView collectionRecommendView;
    @BindView(R.id.topLayout)
    View topLayout;
    @BindView(R.id.collectionReadingModelView)
    CollectionReadingModelView collectionReadingModelView;

    private CountdownView countdownView;
    //    private long time = (long) (24 * 60 * 60 * 1000  + 10 * 1000 + System.currentTimeMillis());
    private long time = (long) (20 * 1000 + 10 * 1000);
    private boolean isFirstAttached = true;                     // 区分第一次onViewAttachedToWindow
    private boolean isLimitEndEventFired = false;               // 倒计时是否结束

    @Override
    protected int getLayoutId() {
        return R.layout.view_holder_story_collect_detail_blur;
    }

    public StoryCollectionBlurDetailViewHolder() {
        EventBus.getDefault().register(this);
    }

    @Override
    public View createView(ViewGroup parent) {
        ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rootView.setLayoutParams(params);
        countdownView = (CountdownView) collectionRecommendView.findViewById(R.id.cvLimitFree);
        collectionRecommendView.setOnCountdownIntervalListener(1000, new CountdownView.OnCountdownIntervalListener() {
            @Override
            public void onInterval(CountdownView countdownView, long l) {
                collectionRecommendView.refreshTime(l);
                countdownRemainTime = l;
                LogHelper.d("Randy", "current time:"
                        + countdownView.getDay() + " days;"
                        + countdownView.getHour() + " hours;"
                        + countdownView.getMinute() + " minutes;"
                        + countdownView.getSecond() + " seconds;");
            }
        });

        collectionRecommendView.setOnCountdownEndListener(new CountdownView.OnCountdownEndListener() {
            @Override
            public void onEnd(CountdownView countdownView) {
                // fire event and update current view's status
                dealWithLimitFreeEnded();
            }
        });
        return super.createView(parent);
    }

    @Override
    public void showData(int position, BaseModelVO itemData) {
        LogHelper.d("Randy", "showData()");
        if (itemData != null && itemData.getModel() != null && itemData.getModel() instanceof StoryCollectionDetail) {
            StoryCollectionDetail item = (StoryCollectionDetail) itemData.getModel();
            String bannerImg = CdnUtils.getImgCdnUrl(item.getBannerUrl(), CdnUtils.SIZE_700x435, true);
            FrescoUtils.showImg(banner, bannerImg);
            serialize.setText(TextUtils.isEmpty(item.getSerialize()) ? item.getRecommend() : item.getSerialize());
            subscribedLayout.setVisibility(item.getSubscribe() == 1 ? View.VISIBLE : View.GONE);

            collectionRecommendView.setVisibility(View.GONE);
            boolean isSerialize = (item.getExtFlag() & Extflag.STORY_EXT_FLAG_16) == Extflag.STORY_EXT_FLAG_16;
            boolean isFree = ((item.getExtFlag() & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL) ||
                    ((item.getExtFlag() & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW);
            countdownRemainTime = item.getRemainingTime() * 1000;
            boolean subscribeIsShowRecommend = item.getSubscribe() == 1 && isSerialize && !TextUtils.isEmpty(item.getSerialize());
            if (subscribeIsShowRecommend || item.getSubscribe() != 1) {
                //已订阅 连载中且连载信息不为空 或未订阅 展示螃蟹连载语
                collectionRecommendView.setVisibility(View.VISIBLE);
                if (isFree) {
                    collectionRecommendView.showCountdownContainer();
                    // todo 处理showData多次调用的情况（只有第一次进入时采用）
                    collectionRecommendView.refreshTime(countdownRemainTime);
                } else {
                    collectionRecommendView.hideCountdownContainer();
                    collectionRecommendView.stopRefreshTime();
                }
                collectionRecommendView.update(item);
            }

            collectionReadingModelView.update(item.getDimensionIdList());
            subscribedLayout.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(View v) {
                    if (mOnEventProcessor == null) {
                        return;
                    }

                    mOnEventProcessor.process(TYPE_SUBSCRIBE_CLICKED);
                }
            });

            collectionReadingModelView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
                @Override
                public void OnClickWithAnim(View v) {
                    if (mOnEventProcessor == null) {
                        return;
                    }
                    mOnEventProcessor.process(TYPE_INTRODUCATION_CLICKED);
                }
            });
        }
    }

    public void onEvent(CollectionAnimStopEvent event) {
        if (collectionReadingModelView != null) {
            collectionReadingModelView.recycle();
        }
        EventBus.getDefault().unregister(this);
    }

    @Override
    public void onViewAttachedToWindow() {
        super.onViewAttachedToWindow();
        LogHelper.d("Randy", "onViewAttachedToWindow(), isFirstAttached:" +
                isFirstAttached);
        if (!isFirstAttached) {
            countdownRemainTime = localTimerRemainTime * 1000;
            LogHelper.d("Randy", "onViewAttachedToWindow(), countdownRemainTime:" + countdownRemainTime);
            LogHelper.d("Randy", "onViewAttachedToWindow(), localTimerRemainTime:" + localTimerRemainTime);
            collectionRecommendView.refreshTime(countdownRemainTime);
        }
        // 停止本地计时器相关逻辑处理
        if (!isFirstAttached) {// 第一次不用处理
            cancelLocalTimer();
        }
        isFirstAttached = false;
    }

    @Override
    public void onViewDetachedFromWindow() {
        super.onViewDetachedFromWindow();
        LogHelper.d("Randy", "onViewDetachedFromWindow()");
        collectionRecommendView.stopRefreshTime();
        // 开启本地计时器相关逻辑处理
        startLocalTimer();
    }

    @Override
    public void onRecycled() {
        super.onRecycled();
        LogHelper.d("Randy", "onRecycled()");
        collectionRecommendView.stopRefreshTime();
    }

    // 开启本地计时器
    private void startLocalTimer() {
        // 开启之前先取消之前的
        if(localTimer != null) {
            cancelLocalTimer();
        }
        if (null != countdownView && countdownView.getRemainTime() / 1000 > 0) {
            countdownRemainTime = countdownView.getRemainTime();
            localTimerRemainTime = countdownRemainTime / 1000;
            LogHelper.d("Randy", "startLocalTimer(), countdownRemainTime:" + countdownRemainTime);
            LogHelper.d("Randy", "startLocalTimer(), localTimerRemainTime:" + localTimerRemainTime);
        }
        if (!isLimitEndEventFired && localTimerRemainTime > 0) {
            if (null == localTimer) {
                localTimer = new Timer();
            }
            localTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    mHandler.post(refreshTimeRunnable);
                }
            }, 0, 1000);
        }
    }


    private static final int ONE_DAY = 24 * 60 * 60;
    private static final int ONE_HOUR = 60 * 60;
    private static final int ONE_MINUTE = 60;

    private long countdownRemainTime = 0;                // countdownView不可见或被销毁时剩余的时间
    private long localTimerRemainTime;
    private Timer localTimer;                               // 本地计时器
    private SafeHandler mHandler = new SafeHandler();
    private Runnable refreshTimeRunnable = new Runnable() { // 处理事件的发送
        @Override
        public void run() {
            localTimerRemainTime--;
            int days = (int) (localTimerRemainTime / ONE_DAY);
            int hours = (int) ((localTimerRemainTime - days * ONE_DAY) / ONE_HOUR);
            int minutes = (int) ((localTimerRemainTime - days * ONE_DAY - hours * ONE_HOUR) / 60);
            int seconds = (int) (localTimerRemainTime - days * ONE_DAY - hours * ONE_HOUR -
                    minutes * ONE_MINUTE);

            LogHelper.d("Randy", "remain time:"
                    + days + " days;"
                    + hours + " hours;"
                    + minutes + " minutes;"
                    + seconds + " seconds;");
            if (localTimerRemainTime == 0) {
                dealWithLimitFreeEnded();
            }
        }
    };

    private void cancelLocalTimer() {
        LogHelper.d("Randy", "cancelLocalTimer()");
        if (null != mHandler) {
            mHandler.removeCallbacks(refreshTimeRunnable);
        }
        if (null != localTimer) {
            localTimer.cancel();
            localTimer = null;
        }
        countdownRemainTime = 0;
        localTimerRemainTime = 0;
    }

    /**
     * 限免时间结束处理
     */
    private void dealWithLimitFreeEnded() {
        // 剩余时间归零
        isLimitEndEventFired = true;
        countdownRemainTime = 0;
        localTimerRemainTime = 0;
        // fire event to refresh StoryCollectionFragment's UI
        EventCenter.fireEvent(new LimitFreeEndedEvent());
        // refresh current viewHolder's UI
        if (null != collectionRecommendView) {
            collectionRecommendView.hideCountdownContainer();
            collectionRecommendView.stopRefreshTime();
        }
        // stop local timer
        cancelLocalTimer();
    }
}
