package com.hhdd.kada.main.viewholders;

import com.hhdd.kada.android.library.app.lifecycle.IComponentContainer;
import com.hhdd.kada.android.library.views.list.ViewHolderCreator;
import com.hhdd.kada.main.vo.ViewTypes;

/**
 * Created by simon on 4/6/16.
 */
public class MyViewHolderCreator extends BaseViewHolderCreator {

    public MyViewHolderCreator() {
        super(null, ViewTypes.viewTypeMapsData);
    }

    public MyViewHolderCreator(IComponentContainer componentContainer) {
        super(componentContainer, ViewTypes.viewTypeMapsData);
    }

    private static ViewHolderCreator instance;

    public static ViewHolderCreator create() {
        if (instance==null) {
            instance = new MyViewHolderCreator();
        }
        return instance;
    }

    public static BaseViewHolderCreator create(IComponentContainer componentContainer) {
        return new MyViewHolderCreator(componentContainer);
    }
}

//public class MyViewHolderCreator implements ViewHolderCreator<BaseVO> {
//
//    IComponentContainer componentContainer;
//
//    public MyViewHolderCreator() {
//
//    }
//
//    public MyViewHolderCreator(IComponentContainer componentContainer) {
//        this.componentContainer = componentContainer;
//    }
//
//    public static final Map<Integer,Class<?>> viewTypeMaps = new HashMap<Integer, Class<?>>();
//    static  {
//        for (ViewTypes type : ViewTypes.values()) {
//            viewTypeMaps.put(type.getId(),type.getCls());
//        }
//    };
//
//    public boolean isCompat(int viewType) {
//        boolean compat = false;
//        if (viewTypeMaps.get(viewType)!=null) {
//            compat = true;
//        }
//        return compat;
//    }
//
//    @Override
//    public ViewHolderBase<BaseVO> createViewHolder(int viewType) {
//        try {
//            ViewHolderBase<BaseVO> viewHolder =
//                    (ViewHolderBase<BaseVO>)viewTypeMaps.get(viewType).getConstructor().newInstance();
//            if (viewHolder instanceof BaseViewHolder) {
//                ((BaseViewHolder) viewHolder).setComponentContainer(componentContainer);
//            }
//            return viewHolder;
//        } catch (InstantiationException e) {
//            e.printStackTrace();
//        } catch (IllegalAccessException e) {
//            e.printStackTrace();
//        } catch (InvocationTargetException e) {
//            e.printStackTrace();
//        } catch (NoSuchMethodException e) {
//            e.printStackTrace();
//        }
//        return null;
//    }
//
//    @Override
//    public int getItemViewType(int position, BaseVO itemData) {
//        int viewType = itemData.getViewType();
//        if (viewTypeMaps.get(viewType)!=null) {
//            return viewType;
//        }
//        return ViewTypes.View_Type_CompatEmpty.getId();
//    }
//
//    private static int View_Type_Count = 0;
//
//    @Override
//    public int getViewTypeCount() {
//        if (View_Type_Count==0) {
//            View_Type_Count = viewTypeMaps.size();
//            Iterator<Integer> iterator = viewTypeMaps.keySet().iterator();
//            while(iterator.hasNext()){
//                int viewType = iterator.next();
//                if (viewType>View_Type_Count) {
//                    View_Type_Count = viewType+1;
//                }
//            }
//        }
//        return View_Type_Count;
//    }
//
//    private static ViewHolderCreator instance;
//
//    public static ViewHolderCreator create() {
//        if (instance==null) {
//            instance = new MyViewHolderCreator();
//        }
//        return instance;
//    }
//
//    public static ViewHolderCreator create(IComponentContainer componentContainer) {
//        return new MyViewHolderCreator(componentContainer);
//    }
//}
