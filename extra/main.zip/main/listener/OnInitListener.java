package com.hhdd.kada.main.listener;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/21
 * @describe : com.hhdd.kada.main.listener
 */
public interface OnInitListener {

    int getLayoutId();

    void doInitView();

    void doInitListener();

    void doInitData();
}
