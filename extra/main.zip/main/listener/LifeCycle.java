package com.hhdd.kada.main.listener;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.listener
 */
public interface LifeCycle {

    void initView();

    void initListener();

    void initData();

    void onStart();
    void onStop();

    void onResume() ;

    void onPause();

    void onDestroy();
}
