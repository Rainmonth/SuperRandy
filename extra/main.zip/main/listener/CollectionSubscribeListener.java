package com.hhdd.kada.main.listener;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/4/16
 * @describe : com.hhdd.kada.main.listener
 */
public interface CollectionSubscribeListener {

    /**
     * 订阅接口调用(status 1 为订阅  2为取消订阅)
     * @param status
     */
    void subscribe(int status);

    /**
     * 创建订单
     */
    void createOrder();
}
