package com.hhdd.kada.main.genius;

import com.hhdd.kada.R;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/1/11
 * @describe : com.hhdd.kada.main.genius
 */
public class GeniusConfig {

    /**
     * 水果图片id列表
     **/
    public static final String[] GENIUS_IMAGE_ID_NAME = {"icon_fruit_apple_", "icon_fruit_banana_",
            "icon_fruit_pitaya_", "icon_fruit_carambola_", "icon_fruit_peach_"};
    /**
     * 水果图片对应进度色值列表
     **/
    public static final int[] GENIUS_PROGRESS_COLOR = {R.color.color_fd6563, R.color.color_feec2f,
            R.color.color_ea88ff, R.color.color_ffb706, R.color.color_fea3eb};

    public static final int[] BANANA_VIDEO_ARR = {R.raw.banana_seed, R.raw.banana_young, R.raw.banana_adult, R.raw.banana_elves};
    public static final int[] APPLE_VIDEO_ARR = {R.raw.apple_seed, R.raw.apple_young, R.raw.apple_adult, R.raw.apple_elves};
    public static final int[] PEACH_VIDEO_ARR = {R.raw.peach_seed, R.raw.peach_young, R.raw.peach_adult, R.raw.peach_elves};
    public static final int[] PITAYA_VIDEO_ARR = {R.raw.pitaya_seed, R.raw.pitaya_young, R.raw.pitaya_adult, R.raw.pitaya_elves};
    public static final int[] CARAMBOLA_VIDEO_ARR = {R.raw.carambola_seed, R.raw.carambola_young, R.raw.carambola_adult, R.raw.carambola_elves};

    /**
     * 维度领域标签数组id列表
     */
    public static final int[] DIMENSION_LABEL_ID = {R.array.dimension_0, R.array.dimension_1, R.array.dimension_2, R.array.dimension_3, R.array.dimension_4};
}
