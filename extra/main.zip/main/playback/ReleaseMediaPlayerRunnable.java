package com.hhdd.kada.main.playback;

import android.media.MediaPlayer;

import com.hhdd.logger.LogHelper;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/10/19
 * @describe : com.hhdd.kada.main.playback
 */
public class ReleaseMediaPlayerRunnable implements Runnable {

    private MediaPlayer player;

    public ReleaseMediaPlayerRunnable(MediaPlayer player) {
        this.player = player;
    }

    @Override
    public void run() {
        try {
            player.release();
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }
}
