package com.hhdd.kada.main.playback;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;

import com.hhdd.kada.KaDaApplication;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by simon on 2/12/15.
 */
public abstract class PlaybackServiceBase extends Service {

    public static interface ServiceCallback {
        public void handleServiceInstanced(PlaybackServiceBase service);
    }

    public static interface PlayEventCallback {
        public void handleStateChanged(PlaybackServiceBase service, int state);
        public void handleErrorOccured(PlaybackServiceBase service);
    }

//    List<PlayEventCallback> mPlayEventCallbacks = new ArrayList<PlayEventCallback>(2);
    List<WeakReference<PlayEventCallback>> mPlayEventCallbacks = new ArrayList<WeakReference<PlayEventCallback>>();

    // Constants pulled into this class for convenience.
    public static final int STATE_IDLE = 1;//ExoPlayer.STATE_IDLE;
    public static final int STATE_PREPARING = 2;//ExoPlayer.STATE_PREPARING;
    public static final int STATE_BUFFERING = 3;//ExoPlayer.STATE_BUFFERING;
    public static final int STATE_READY = 4;//ExoPlayer.STATE_READY;
    public static final int STATE_ENDED = 5;//ExoPlayer.STATE_ENDED;
    public static final int STATE_PLAYING = 200;
    public static final int STATE_PAUSED = 300;

    public void addCallback(PlayEventCallback callback) {
        if (callback == null) {
            return;
        }

        for (WeakReference<PlayEventCallback> weakReference : mPlayEventCallbacks) {
            if (weakReference.get() == callback) {
                return;
            }
        }

        mPlayEventCallbacks.add(new WeakReference<PlayEventCallback>(callback));
    }

    public void removeCallback(PlayEventCallback callback) {
        if (callback == null) {
            return;
        }

        Iterator<WeakReference<PlayEventCallback>> iterator = mPlayEventCallbacks.iterator();
        while (iterator.hasNext()) {
            WeakReference<PlayEventCallback> weakReference = iterator.next();
            if (weakReference != null && weakReference.get() == callback) {
                iterator.remove();

                break;
            }
        }
    }

    public abstract void prepare(String soundFile, final int bookId, int version, String AESST, final PlayEventCallback callback);
    public abstract boolean isPlaying();
    public abstract boolean isCanPlay();
    public abstract void seek(int positionMs);
    public abstract void reset();
    public abstract void play();
    public abstract void pause();
    public abstract void stop();
    public abstract long getDuration();
    public abstract long getBufferPosition();
    public abstract long getCurrentPosition();
    public abstract void closeVolume();
    public abstract void openVolume();

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void get(final ServiceCallback callback) {
        PlaybackServiceMediaPlayer.get(callback);
    }

    public static void stopService() {
        Context context = KaDaApplication.getInstance();
        context.stopService(new Intent(context, PlaybackServiceMediaPlayer.class));
    }
}
