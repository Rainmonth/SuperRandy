package com.hhdd.kada.main.playback;

/**
 * Created by simon on 19/6/15.
 */
public interface Playback {

    interface Callback {
        void onCompletion();

        void onPlaybackStatusChanged(int state);

        void onError(String error);

        void onSoundFilePathChanged(String soundFilePath);
    }
}
