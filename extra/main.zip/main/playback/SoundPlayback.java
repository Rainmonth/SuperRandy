package com.hhdd.kada.main.playback;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.PowerManager;
import android.text.TextUtils;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.thread.IThread;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.mediaserver.MediaServer2;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.player.KdMediaPlayer;
import com.hhdd.logger.LogHelper;

import java.io.IOException;

/**
 * Created by simon on 12/1/16.
 */
public class SoundPlayback implements MediaPlayer.OnPreparedListener,
        MediaPlayer.OnErrorListener,
        MediaPlayer.OnBufferingUpdateListener,
        MediaPlayer.OnCompletionListener,
        MediaPlayer.OnSeekCompleteListener,
        MediaPlayer.OnInfoListener {


    public static interface Listener {
        public void handlePrepared(SoundPlayback playback);

        public void handleCompletion(SoundPlayback playback);
    }

    public static interface PlayBackListener{
        public void handlePrepared(SoundPlayback playback);

        public void handlePause(SoundPlayback playback);

        public void handleCompletion(SoundPlayback playback);
    }

    MediaPlayer mMediaPlayer;
    String url;
    Uri path;

    Listener listener;
    PlayBackListener playBackListener;
    boolean isPrepared = false;

    public SoundPlayback() {
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setPlayBackListener(PlayBackListener listener){
        this.playBackListener = listener;
    }

    public void prepare(Context context, String url, int itemId) {
        prepare(context, url, itemId, "");
    }


    public void prepare(Context context, String url, String mediaTargetFilePath) {
        if (TextUtils.equals(url, this.url) && this.path == null) {
            if (isPrepared) {
                if (listener != null) {
                    listener.handlePrepared(this);
                }
                if(playBackListener != null){
                    playBackListener.handlePrepared(this);
                }
            }
        } else {

            this.isPrepared = false;
            this.url = url;

            String soundUrl = MediaServer2.prepare(url, mediaTargetFilePath);

            releaseMediaPlayer();
            MediaServer2.getInstance().removeSession(soundUrl);

            mMediaPlayer = KdMediaPlayer.createMediaPlayer(context); // initialize it here
            mMediaPlayer.setLooping(false);
            mMediaPlayer.setWakeMode(KaDaApplication.getInstance(), PowerManager.PARTIAL_WAKE_LOCK);

            mMediaPlayer.setOnPreparedListener(this);
            mMediaPlayer.setOnErrorListener(this);
            mMediaPlayer.setOnBufferingUpdateListener(this);
            mMediaPlayer.setOnSeekCompleteListener(this);
            mMediaPlayer.setOnCompletionListener(this);

            try {
                mMediaPlayer.reset();
                mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mMediaPlayer.setDataSource(soundUrl);
                mMediaPlayer.prepareAsync();
            } catch (IllegalArgumentException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IllegalArgumentException in SoundPlayback when prepare() [1] : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            } catch (IllegalStateException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IllegalStateException in PlaybackServiceMediaPlayer when prepare()[1] : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IOException in PlaybackServiceMediaPlayer when prepare() [1]: "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            }
        }
    }
    public void prepare(Context context, String url, int itemId, String mediaTargetDir) {

        if (TextUtils.equals(url, this.url) && this.path == null) {
            if (isPrepared) {
                if (listener != null) {
                    listener.handlePrepared(this);
                }
                if(playBackListener != null){
                    playBackListener.handlePrepared(this);
                }
            }
        } else {

            this.isPrepared = false;
            this.url = url;

            String soundUrl = MediaServer2.prepare(url, itemId, false,0,0,0,mediaTargetDir,"");

            releaseMediaPlayer();
            MediaServer2.getInstance().removeSession(soundUrl);

            mMediaPlayer = KdMediaPlayer.createMediaPlayer(context); // initialize it here
            mMediaPlayer.setLooping(false);
            mMediaPlayer.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK);

            mMediaPlayer.setOnPreparedListener(this);
            mMediaPlayer.setOnErrorListener(this);
            mMediaPlayer.setOnBufferingUpdateListener(this);
            mMediaPlayer.setOnSeekCompleteListener(this);
            mMediaPlayer.setOnCompletionListener(this);

            try {
                mMediaPlayer.reset();
                mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mMediaPlayer.setDataSource(soundUrl);
                mMediaPlayer.prepareAsync();
            } catch (IllegalArgumentException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IllegalArgumentException in SoundPlayback when prepare() [2] : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            } catch (IllegalStateException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IllegalStateException in SoundPlayback when prepare() [2] : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IOException in SoundPlayback when prepare() [2] : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            }
        }
    }

    public void prepare(Context context, Uri path) {

//        if (path.equals(this.path)) {
//            if (isPrepared) {
//                if (listener != null) {
//                    listener.handlePrepared(this);
//                }
//            }
//        } else {

        this.isPrepared = false;
        this.path = path;

        releaseMediaPlayer();

        mMediaPlayer = KdMediaPlayer.createMediaPlayer(context); // initialize it here
        mMediaPlayer.setLooping(false);
        mMediaPlayer.setWakeMode(context, PowerManager.PARTIAL_WAKE_LOCK);

        mMediaPlayer.setOnPreparedListener(this);
        mMediaPlayer.setOnErrorListener(this);
        mMediaPlayer.setOnBufferingUpdateListener(this);
        mMediaPlayer.setOnSeekCompleteListener(this);
        mMediaPlayer.setOnCompletionListener(this);

        try {
            mMediaPlayer.reset();
            mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mMediaPlayer.setDataSource(context, path);
            mMediaPlayer.prepareAsync();
        } catch (IllegalArgumentException e) {
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(MediaServer2.packageString("IllegalArgumentException in SoundPlayback when prepare() [2] : "+e.toString()),
//                            MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
            LogHelper.printStackTrace(e);
        } catch (IllegalStateException e) {
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(MediaServer2.packageString("IllegalStateException in SoundPlayback when prepare() [2] : "+e.toString()),
//                            MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
            LogHelper.printStackTrace(e);
        } catch (IOException e) {
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(MediaServer2.packageString("IOException in SoundPlayback when prepare() [2] : "+e.toString()),
//                            MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
            LogHelper.printStackTrace(e);
        }
    }



    public void playFromBegin() {
        if (mMediaPlayer != null && isPrepared) {
            if (mMediaPlayer.getCurrentPosition() != 0) {
                mMediaPlayer.seekTo(0);
            } else {
                if (!mMediaPlayer.isPlaying()) {
                    mMediaPlayer.start();
                }
            }
        }
    }

    public void play() {
        if (mMediaPlayer != null && isPrepared) {
            if (!mMediaPlayer.isPlaying()) {
                mMediaPlayer.start();
            }
        }
    }

    public void pause() {
        if (mMediaPlayer != null
                && mMediaPlayer.isPlaying()) {
            mMediaPlayer.pause();
        }
        if(playBackListener != null){
            playBackListener.handlePause(this);
        }
    }

    public void seek(int position){
        if(mMediaPlayer != null){
            mMediaPlayer.seekTo(position);
        }
    }

    public boolean isPlaying(){
        if(mMediaPlayer != null){
            return mMediaPlayer.isPlaying();
        }
        return false;
    }

    public void releaseMediaPlayer() {
        if (mMediaPlayer != null) {
            mMediaPlayer.stop();
            ReleaseMediaPlayerRunnable runnable = new ReleaseMediaPlayerRunnable(mMediaPlayer);
            mMediaPlayer = null;
            ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE))
                    .postDaemonTask(runnable, "SoundPlaybackReleaseMediaPlayerJob");
        }
    }

    @Override
    public void onBufferingUpdate(MediaPlayer player, int i) {

    }

    @Override
    public void onCompletion(MediaPlayer player) {
        if (listener != null) {
            listener.handleCompletion(this);
        }
        if(playBackListener != null){
            playBackListener.handleCompletion(this);
        }
    }

    @Override
    public boolean onError(MediaPlayer player, int i, int i2) {
        return false;
    }

    @Override
    public boolean onInfo(MediaPlayer player, int i, int i2) {
        return false;
    }

    @Override
    public void onPrepared(MediaPlayer player) {
        isPrepared = true;
        if (listener != null) {
            listener.handlePrepared(this);
        }
        if(playBackListener != null){
            playBackListener.handlePrepared(this);
        }
    }

    @Override
    public void onSeekComplete(MediaPlayer player) {
        if (mMediaPlayer != null) {
            mMediaPlayer.start();
        }
    }


    public long getCurrentPosition() {
        if(mMediaPlayer != null){
            return mMediaPlayer.getCurrentPosition();
        }
        return 0;
    }

    public String getPath(){
        return path.toString();
    }

}
