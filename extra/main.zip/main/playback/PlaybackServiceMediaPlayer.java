package com.hhdd.kada.main.playback;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.PowerManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.thread.IThread;
import com.hhdd.core.service.BookService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.mediaserver.MediaServer2;
import com.hhdd.kada.main.mediaserver.MediaServer3;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.KdMediaPlayer;
import com.hhdd.kada.module.player.OnKdAudioFocusChangeListener;
import com.hhdd.logger.LogHelper;

import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by simon on 2/12/15.
 */
public class PlaybackServiceMediaPlayer extends PlaybackServiceBase implements
        MediaPlayer.OnPreparedListener,
        MediaPlayer.OnErrorListener,
        MediaPlayer.OnBufferingUpdateListener,
        MediaPlayer.OnCompletionListener,
        MediaPlayer.OnSeekCompleteListener,
        MediaPlayer.OnInfoListener {

    private static final List<ServiceCallback> sServiceCallbacks = new ArrayList<ServiceCallback>(2);
    private static PlaybackServiceMediaPlayer sInstance;

    private MediaPlayer mMediaPlayer;

    private boolean isAudioFocusLoss = false;
    private boolean isAudioFocusLossPaused = false; // 是否因音频资源抢占暂停播放

    private OnKdAudioFocusChangeListener mAudioFocusChangeListener = new OnKdAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            if(focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT){
                //失去焦点之后的操作
                isAudioFocusLoss = true;

                if(isPlaying()){
                    isAudioFocusLossPaused = true;
                    pause();
                }
            } else if(focusChange == AudioManager.AUDIOFOCUS_GAIN){
                //获得焦点之后的操作

                if (isAudioFocusLoss) {
                    isAudioFocusLoss = false;

                    if (isAudioFocusLossPaused) {
                        isAudioFocusLossPaused = false;
                        if (!isPlaying()) {
                            play();
                        }
                    }

                }
            }
        }
    };

    private long mBufferPosition;
    private String mCurrentSoundUrl;
    private String mDataSouce;

    public InCallListener mCallListener;

    public Context mContext;

    int mState = STATE_IDLE;
    int lastReportedPlaybackState;

    boolean isMute;//是否静音

    public static void stopService() {
        if (sInstance!=null) {
            sInstance.stop();
            sInstance.stopSelf();
            sInstance = null;
        }
    }

    public static void get(final ServiceCallback callback) {
        if (sInstance == null) {
            if (callback!=null) {
                synchronized (sServiceCallbacks) {
                    if (!sServiceCallbacks.contains(callback)) {
                        sServiceCallbacks.add(callback);
                    }
                }
            }
            Context context = KaDaApplication.getInstance();
            try{
                context.startService(new Intent(context, PlaybackServiceMediaPlayer.class));
            }catch (Exception e){

            }
        } else {
            if (callback!=null) {
                callback.handleServiceInstanced(sInstance);
            }
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;

        try {
            mCallListener = new InCallListener();
            TelephonyManager telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            telephonyManager.listen(mCallListener, PhoneStateListener.LISTEN_CALL_STATE);
        } catch (SecurityException e) {
            // don't have READ_PHONE_STATE
        }

        // initialize service instance
        sInstance = this;
        synchronized (sServiceCallbacks) {
            for (ServiceCallback callback : sServiceCallbacks) {
                callback.handleServiceInstanced(sInstance);
            }
            sServiceCallbacks.clear();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        stop();
        sInstance = null;
    }

    void maybeReportPlayerState() {
        maybeReportPlayerState(false);
    }
    void maybeReportPlayerState(boolean byForce) {
        if (lastReportedPlaybackState != mState || byForce) {
//            for (PlayEventCallback callbackTmp : mPlayEventCallbacks) {
//                callbackTmp.handleStateChanged(this,mState);
//            }

            for (WeakReference<PlayEventCallback> weakReference : mPlayEventCallbacks) {
                PlayEventCallback callback = weakReference.get();
                if (callback != null) {
                    callback.handleStateChanged(this, mState);
                }
            }

            lastReportedPlaybackState = mState;
        }
    }


    @Override
    public void prepare(String soundFile, int bookId, int version, String AESST, PlayEventCallback callback) {
        addCallback(callback);

        IMediaPlayer mediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
        mediaPlayer.addOnKdAudioFocusChangeListener(mAudioFocusChangeListener);

        if (mCurrentSoundUrl!=null && TextUtils.equals(soundFile, mCurrentSoundUrl)) {
            if (mState==STATE_READY) {
                LogHelper.d("MediaServer-playback", "prepare-Ready");
            } else {
                LogHelper.d("MediaServer-playback", "prepare-waiting");
            }
        } else if (mCurrentSoundUrl == null
                || !TextUtils.equals(soundFile, mCurrentSoundUrl)
                || (TextUtils.equals(soundFile, mCurrentSoundUrl) && mState!=STATE_PREPARING)) {

            LogHelper.d("MediaServer-playback", "prepare-start");
            mState = STATE_IDLE;
            lastReportedPlaybackState = STATE_IDLE;

            mCurrentSoundUrl = soundFile;

            String playUrl = soundFile;
            if (soundFile.contains("http://")) {

                playUrl = MediaServer2.prepareBook(soundFile, bookId, version, BookService.getBookCachePath(bookId),AESST);
            }


//            playUrl = "http://cdn.hhdd.com/medal/media/la_bi_zong_dong_yuan_2.mp3";
//            playUrl = "http://cdn.hhdd.com/assets/file/abe06408-662e-47d6-b37c-b39b13b83c8f.mp3";
//            playUrl = "http://cdn.hhdd.com/assets/file/63ee60ae-0e3d-4a93-b30c-77e698a60ae2.mp3";


//            playUrl = "http://music.baidu.com/data/music/file?link=http://yinyueshiting.baidu.com/data2/music/247912224/24791165410800064.mp3?xcode=539481595d702e1b718197b4a0f16666&song_id=247911654";
//            playUrl = "http://cdn.hhdd.com/assets/file/bbcc5ba3-3413-4567-ae7e-2ea8d2a146e0.mp3";
            releaseMediaPlayer();
            MediaServer2.getInstance().removeSession(soundFile);

            mDataSouce = playUrl;

//            String root = MediaServer2.getRootPath();
//            soundFile=root + File.separator + "wo_ai_baba.mp3";

            mMediaPlayer = KdMediaPlayer.createMediaPlayer(this); // initialize it here
            mMediaPlayer.setLooping(false);
            mMediaPlayer.setWakeMode(getApplicationContext(),PowerManager.PARTIAL_WAKE_LOCK);

            mMediaPlayer.setOnInfoListener(this);
            mMediaPlayer.setOnPreparedListener(this);
            mMediaPlayer.setOnErrorListener(this);
            mMediaPlayer.setOnBufferingUpdateListener(this);
            mMediaPlayer.setOnSeekCompleteListener(this);
            mMediaPlayer.setOnCompletionListener(this);

            stopForeground(true);

            try {
                mMediaPlayer.reset();
                if (soundFile.contains("http://")) {
                    mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                    mMediaPlayer.setDataSource(playUrl);
                    mMediaPlayer.prepareAsync();
                } else if(soundFile.length()>0) {
                    mMediaPlayer.setDataSource(soundFile);
                    mMediaPlayer.prepare();
                }else{
                    releaseMediaPlayer();
                }
            } catch (IllegalArgumentException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IllegalArgumentException in PlaybackServiceMediaPlayer : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            } catch (IllegalStateException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IllegalStateException in PlaybackServiceMediaPlayer : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IOException in PlaybackServiceMediaPlayer : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            }
            mState = STATE_PREPARING;

            maybeReportPlayerState();
        }
    }

    private void releaseMediaPlayer() {
        if (mMediaPlayer!=null) {
            mMediaPlayer.stop();
            ReleaseMediaPlayerRunnable runnable = new ReleaseMediaPlayerRunnable(mMediaPlayer);
            mMediaPlayer = null;
            ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE))
                    .postDaemonTask(runnable, "BookReleaseMediaPlayerJob");
        }
    }

    @Override
    public boolean isPlaying() {
        boolean isPlaying = mMediaPlayer != null ? (mMediaPlayer.isPlaying() && mState == STATE_PLAYING) : false;
        return isPlaying;
    }

    @Override
    public boolean isCanPlay() {
        return mState==STATE_READY||mState==STATE_PAUSED || mState == STATE_ENDED ||isPlaying();
    }

    @Override
    public void reset() {
        if (mMediaPlayer!=null && mDataSouce!=null) {
            if (mMediaPlayer.isPlaying()) {
                mMediaPlayer.pause();
            }
            mMediaPlayer.reset();
            try {
                mMediaPlayer.setDataSource(mDataSouce);
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IOException in PlaybackServiceMediaPlayer when reset() : "+e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            }
            mMediaPlayer.prepareAsync();
            mState = STATE_PREPARING;
            maybeReportPlayerState();
        }
    }

    @Override
    public void seek(int positionMs) {
        if (mMediaPlayer!=null) {
            if (mMediaPlayer.isPlaying()) {
                mState = STATE_BUFFERING;
                LogHelper.d("MediaServer-Playback","seek STATE_BUFFERING");
            }
            mMediaPlayer.seekTo((int)positionMs);
            maybeReportPlayerState();
        }
    }

    @Override
    public void play() {
        if (mMediaPlayer!=null && !isPlaying() && !isAudioFocusLoss) {
            LogHelper.d("MediaServer-Playback", "mMediaPlayer.start");
            if(isMute){
                mMediaPlayer.setVolume(0,0);
            }
            mMediaPlayer.start();
            mState = STATE_PLAYING;
            maybeReportPlayerState();
        }
    }

    @Override
    public void pause() {
        if (mMediaPlayer!=null && isPlaying()) {
            mMediaPlayer.pause();
            mState = STATE_PAUSED;
            maybeReportPlayerState();
        }
    }

    @Override
    public void stop() {
        if (mCurrentSoundUrl!=null && mCurrentSoundUrl.length()>0) {
            MediaServer2.getInstance().removeSession(mCurrentSoundUrl);
        }
        releaseMediaPlayer();
        mCurrentSoundUrl = null;
        mDataSouce = null;
        mPlayEventCallbacks.clear();

        IMediaPlayer mediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
        mediaPlayer.removeOnKdAudioFocusChangeListener(mAudioFocusChangeListener);
    }

    @Override
    public long getDuration() {
        if(mMediaPlayer!=null) {
            return mMediaPlayer.getDuration();
        } else {
            return 0;
        }
    }

    @Override
    public long getCurrentPosition() {
        if(mMediaPlayer!=null) {
            return mMediaPlayer.getCurrentPosition();
        } else {
            return 0;
        }
    }

    @Override
    public long getBufferPosition() {
        return mBufferPosition;
    }

    @Override
    public void onBufferingUpdate(MediaPlayer player, int percent) {
//        Log.d("MediaServer-playback",  "onBufferingUpdate percent=" + percent);
        if (mMediaPlayer!=null && (isCanPlay() || isPlaying())) {
            mBufferPosition = getDuration()*percent/100;
//            Log.d("MediaServer-playback",  "onBufferingUpdate mBufferPosition=" + mBufferPosition);
        }
    }

    public static final int MEDIA_INFO_BUFFERING_START = 701;
    public static final int MEDIA_INFO_BUFFERING_END = 702;
    public static final int MEDIA_INFO_NOT_SEEKABLE = 801;
    public static final int MEDIA_INFO_TIMED_TEXT_ERROR = 972;
    @Override
    public boolean onInfo(android.media.MediaPlayer mediaPlayer, int i, int i1) {
        //http://blog.csdn.net/wufen1103/article/details/8085541
        if (i==MEDIA_INFO_BUFFERING_START) {
            LogHelper.d("MediaServer-playback", "info-i STATE_BUFFERING:");
//            mState = STATE_BUFFERING;
//            maybeReportPlayerState();
        } else if (i==MEDIA_INFO_BUFFERING_END) {
//            mState = STATE_READY;
            LogHelper.d("MediaServer-playback", "info-i READY:");
//            maybeReportPlayerState();
        }else if(i == MEDIA_INFO_TIMED_TEXT_ERROR){
            LogHelper.d("MediaServer-playback", "info-i: MEDIA_INFO_TIMED_TEXT_ERROR");
            reset();
        } else {
            LogHelper.d("MediaServer-playback", "info-i:"+i);
        }
        return false;
    }

    @Override
    public void onCompletion(MediaPlayer player) {
        LogHelper.d("MediaServer-playback", "onCompletion");
        mState = STATE_ENDED;
        maybeReportPlayerState();
    }

    @Override
    public boolean onError(MediaPlayer mediaPlayer, int what, int extra) {
        LogHelper.d("MediaServer-playback",  "Media player error: what=" + what + ", extra=" + extra);
        //上报收集
//        UserHabitService.getInstance().trackHabit2Umeng(
//                UserHabitService.newUserHabit(MediaServer3.packageString("PlaybackServiceMediaPlayer. Media player error: what=" + what + ", extra=" + extra),
//                        MediaServer3.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
//        for (PlayEventCallback callback : mPlayEventCallbacks) {
//            callback.handleErrorOccured(this);
//        }

        for (WeakReference<PlayEventCallback> weakReference : mPlayEventCallbacks) {
            PlayEventCallback callback = weakReference.get();
            if (callback != null) {
                callback.handleErrorOccured(this);
            }
        }

        return true; // true indicates we handled the error
    }

    @Override
    public void onPrepared(MediaPlayer player) {
        LogHelper.d("MediaServer-playback", "onPrepared");
        mState = STATE_READY;
        maybeReportPlayerState();
    }

    @Override
    public void onSeekComplete(MediaPlayer player) {
        LogHelper.d("MediaServer-playback", "onSeekComplete from MediaPlayer:"+player.getCurrentPosition());
        if (mState == STATE_BUFFERING) {
            if(isMute){
                mMediaPlayer.setVolume(0,0);
            }
            mMediaPlayer.start();
            mState = STATE_PLAYING;
            maybeReportPlayerState();
        } else if (mState==STATE_READY) {
            maybeReportPlayerState(true);
        } else {
            LogHelper.d("MediaServer-playback", "SEEK READY:");
            mState = STATE_READY;
            maybeReportPlayerState();
        }
    }

    public static boolean mPlayingBeforeCall;
    private class InCallListener extends PhoneStateListener {
        @Override
        public void onCallStateChanged(int state, String incomingNumber)
        {
            switch (state) {
                case TelephonyManager.CALL_STATE_RINGING:
                case TelephonyManager.CALL_STATE_OFFHOOK: {
                    if (isPlaying()) {
                        mPlayingBeforeCall = true;
                        pause();
                    }
                    break;
                }
                case TelephonyManager.CALL_STATE_IDLE: {
                    if (mPlayingBeforeCall) {
                        mPlayingBeforeCall = false;
                        play();
                    }
                    break;
                }
            }
        }
    }

    @Override
    public void closeVolume(){
        isMute = true;
        if(mMediaPlayer != null){
            mMediaPlayer.setVolume(0, 0);
        }
    }

    @Override
    public void openVolume(){
        isMute = false;
        if(mMediaPlayer != null){
            mMediaPlayer.setVolume(1.0f,1.0f);
        }
    }
}
