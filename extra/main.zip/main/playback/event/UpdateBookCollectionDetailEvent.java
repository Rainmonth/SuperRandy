package com.hhdd.kada.main.playback.event;

import com.hhdd.kada.main.model.BookCollectionDetailInfo;

/**
 * Created by bjx on 2018/3/31.
 */

public class UpdateBookCollectionDetailEvent {

    public int type; // 1：继续订阅流程 2：已经订阅成功 刷新数据
    public BookCollectionDetailInfo bookCollectionDetailInfo;
}
