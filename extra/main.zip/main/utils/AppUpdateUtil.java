package com.hhdd.kada.main.utils;

import com.hhdd.core.model.SysConfigVO;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Created by lj on 16/7/18.
 */
public class AppUpdateUtil {

    /**
     * 检查是否有新版本更新(配置文件更新时)
     * @param update            配置里面的 update 配置
     * @param currentAppVersion 当前客户端的 app 版本
     * @return  返回当前支持的更新提醒级别
     */
    public static UpdateLevelEnum checkUpdate(SysConfigVO.Update update, String currentAppVersion) {
        if (update == null)
            return null;

        AppUpdateUtil.UpdateLevelEnum levelEnum = AppUpdateUtil.UpdateLevelEnum.remind; //有新版本默认进行普通提醒
        if (update.getLevel() == null || update.getLevel().size() == 0)
            return levelEnum;

        for (SysConfigVO.Level ver : update.getLevel()) {// 遍历特殊升级(强制、每次提醒等)配置列表
            if (isMatch(ver.getMatch(), currentAppVersion)){
                levelEnum = UpdateLevelEnum.getUpdateLevelEnum(ver.getType());
                break;
            }
        }

        return levelEnum;
    }

    /**
     * 配置版本是否否大于当前版本(不同环境字符序列比较方式可能稍微不同)
     * @param currentAppVersion 当前app 版本
     * @param lestVersion       配置文件指定的最新版本
     * @return  配置版本大于当前app版本返回 true
     */
    private static boolean greaterThanCurrentVersion(String currentAppVersion, String lestVersion) {
        if (StringUtil.isEmpty(currentAppVersion) || StringUtil.isEmpty(lestVersion))
            return false;

        return lestVersion.compareToIgnoreCase(currentAppVersion) > 0; //字符串函数 ">"返回:1、"="返回0、"<"返回-1
    }

    /**
     * 存在新版本时判断当前app版本是否属于特殊匹配版本
     * @param regex             配置匹配正则表达式
     * @param currentAppVersion 当前客户端app 版本
     * @return
     */
    private static boolean isMatch(String regex, String currentAppVersion) {
        if (StringUtil.isEmpty(regex) || StringUtil.isEmpty(currentAppVersion))
            return false;
        if (Pattern.matches(regex, currentAppVersion)){
            return true;
        }else {
            return false;
        }
//        return Pattern.matches(regex, currentAppVersion);
    }

    /**
     * 客户端当前支持的提醒基本(级别"level"对应于配置文件 提醒类型 type)
     */
    public enum UpdateLevelEnum {
        remind("remind"),       //正常更新提醒
        startUp("startUp"),     //每次启动提醒
        forcibly("forcibly");   //强制升级

        UpdateLevelEnum(String level) {
            this.level = level;
        }

        /* 升级级别描述 */
        private String level;
        /* 枚举静态表 */
        private static final Map<String, UpdateLevelEnum> levelMap = new HashMap<String, UpdateLevelEnum>() {
            {
                for (UpdateLevelEnum levelEnum : UpdateLevelEnum.values()) {
                    put(levelEnum.level, levelEnum);
                }
            }
        };

        public static UpdateLevelEnum getUpdateLevelEnum(String level) {
            UpdateLevelEnum levelEnum = levelMap.get(level);
            if (levelEnum == null)
                levelEnum = remind;

            return levelEnum;
        }
    }
}