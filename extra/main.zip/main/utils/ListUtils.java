package com.hhdd.kada.main.utils;


import com.hhdd.kada.main.model.BookInfo;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by sxh on 2017/8/3.
 */

public class ListUtils {

    /**
     * 根据bookId得到该bookinfo在列表的位置
     *
     * @param list
     * @param bookId
     * @return
     */
    public static int getPositionInCollection(final List<BookInfo> list, int bookId) {
        if (list == null || list.isEmpty()) {
            return 0;
        }

        int size = list.size();

        for (int i = 0; i < size; i++) {
            if (list.get(i).getBookId() == bookId) {
                return i;
            }
        }
        return -1;
    }

    /**
     * 将元素添加到list的最前面
     *
     * @param list
     * @param element
     * @return
     */
    public static List<String> addElementToFirst(List<String> list, String element) {
        if (list == null ) {
            return null;
        }
        List<String> resultList = new ArrayList<>();
        resultList.add(element);
        resultList.addAll(list);
        return resultList;
    }

    /**
     * 将某个元素移动到list的最前面
     *
     * @param list
     * @param element
     * @return
     */
    public static List<String> moveElementToFirst(List<String> list, String element) {
        if (list == null || list.isEmpty() || !list.contains(element)) {
            return null;
        }
        list.remove(element);
        return addElementToFirst(list, element);
    }

}
