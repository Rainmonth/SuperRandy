package com.hhdd.kada.main.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;

import com.hhdd.logger.LogHelper;

/**
 * Created by simon on 6/28/16.
 */
public class ConnectivityUtil {

//    private static class SingletonHolder {
//        private static final ConnectivityUtil instance = new ConnectivityUtil();
//    }
//
//    public static final ConnectivityUtil getInstance() {
//        return SingletonHolder.instance;
//    }

    public interface ConnectivityListener {
        public void handleStateChanged(boolean isConnected, boolean isConnectedWifi);
    }

    ConnectivityListener listener;

    Context context;
    ConnectivityBroadcastReceiver receiver;

    boolean isConnected = false;
    boolean isConnectedWifi = false;
    boolean isConnectedMobile = false;

    public ConnectivityUtil() {

    }

    public void initialize(Context context, ConnectivityListener listener) {
        this.listener = listener;
        this.context = context;
        this.receiver = new ConnectivityBroadcastReceiver();
        this.isConnected = NetworkUtils.isReachable();
        this.isConnectedWifi = NetworkUtils.isReachableViaWiFi();
        this.isConnectedMobile = NetworkUtils.isConnectedMobile(context);
        IntentFilter filter = new IntentFilter();
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        context.registerReceiver(this.receiver, filter);
    }

    public void cleanup() {
        if (context != null) {
            context.unregisterReceiver(receiver);
            receiver = null;
            context = null;
        }
    }

    public boolean isConnected() {
        isConnected = NetworkUtils.isReachable();
        return isConnected;
    }

    public boolean isConnectedWifi() {
        isConnectedWifi = NetworkUtils.isReachableViaWiFi();
        return isConnectedWifi;
    }

    private class ConnectivityBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (!action.equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
                return;
            }

            boolean isConnected = NetworkUtils.isReachable();
            boolean isConnectedWifi = NetworkUtils.isReachableViaWiFi();
            boolean isConnectedMobile = NetworkUtils.isConnectedMobile(context);
            LogHelper.d("ConnectivityUtil", isConnected + "");
            LogHelper.d("ConnectivityUtil", isConnectedWifi + "");

            boolean isStateChanged = false;
            boolean isWifiStateChanged = false;
            if (ConnectivityUtil.this.isConnected != isConnected) {
                isWifiStateChanged = true;
            }

            if (ConnectivityUtil.this.isConnectedWifi != isConnectedWifi) {
                isStateChanged = true;
            }

            ConnectivityUtil.this.isConnected = isConnected;
            ConnectivityUtil.this.isConnectedWifi = isConnectedWifi;
            ConnectivityUtil.this.isConnectedMobile = isConnectedMobile;

            if ((isStateChanged && ConnectivityUtil.this.listener != null)||(isWifiStateChanged&&ConnectivityUtil.this.listener!=null)) {
                ConnectivityUtil.this.listener.handleStateChanged(isConnected, isConnectedWifi);
            }
        }
    }
}
