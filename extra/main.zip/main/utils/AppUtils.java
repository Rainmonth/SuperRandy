package com.hhdd.kada.main.utils;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.text.TextUtils;

import com.hhdd.kada.BuildConfig;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.logger.LogHelper;

import java.io.File;
import java.io.FileFilter;
import java.util.List;
import java.util.regex.Pattern;


/**
 * Created by sxh on 2017/2/23.
 */

public class AppUtils {

    private static final String TAG = "AppUtils";

    public static String PROCESS_NAME = null;

    public static String CHANNEL_ID = null;

    // 坚果手机
    public static final boolean IS_MODEL_YQ601 = TextUtils.equals(KaDaApplication.PHONE_TYPE, "YQ601");

    /**
     * 返回资源文件Uri
     *
     * @param rawId
     * @return
     */
    public static Uri getRawUri(int rawId) {
        return Uri.parse("android.resource://" + KaDaApplication.getInstance().getPackageName() + "/" + rawId);
    }

    public static int getInteger(int resId) {
        return getInteger(resId, 0);
    }

    public static int getInteger(int resId, int defValue) {
        try {
            return KaDaApplication.getInstance().getResources().getInteger(resId);
        } catch (Throwable e) {
        }

        return defValue;
    }

    /**
     * @param resId
     * @return
     */
    public static boolean getBoolean(int resId) {
        try {
            return KaDaApplication.getInstance().getResources().getBoolean(resId);
        } catch (Throwable e) {
        }

        return false;
    }

    /**
     * @param resId
     * @return
     */
    public static String getString(int resId) {
        return getString(resId, "");
    }

    public static String getString(int resId, String defValue) {
        try {
            return KaDaApplication.getInstance().getResources().getString(resId);
        } catch (Throwable e) {
        }

        return defValue;
    }

    public static Uri getDrawable(int resId) {
        try {
            return new Uri.Builder().scheme("res").path(String.valueOf(resId)).build();
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return null;
    }

    public static int getColor(int resId) {
        try {
            return KaDaApplication.getInstance().getResources().getColor(resId);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return 0;
    }

    //应用程序是否在前台
    public static boolean isAppOnForeground() {

        ActivityManager activityManager = (ActivityManager) KaDaApplication.getInstance().getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager
                .getRunningAppProcesses();
        if (appProcesses == null)
            return false;
        for (ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.processName.equals(KaDaApplication.getInstance().getPackageName())) {
                if (appProcess.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return false;
    }

    /**
     * 跳转到权限设置界面
     */
    public static void gotoAppDetailSettingIntent(Context context) {
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (Build.VERSION.SDK_INT >= 9) {
            intent.setAction("android.settings.APPLICATION_DETAILS_SETTINGS");
            intent.setData(Uri.fromParts("package", context.getPackageName(), null));
        } else if (Build.VERSION.SDK_INT <= 8) {
            intent.setAction(Intent.ACTION_VIEW);
            intent.setClassName("com.android.settings", "com.android.settings.InstalledAppDetails");
            intent.putExtra("com.android.settings.ApplicationPkgName", context.getPackageName());
        }
        context.startActivity(intent);
    }

    /**
     * 判断app是否处于运行状态，不管处于前台还是后台
     *
     * @return
     */
    public static boolean isRunning() {
        return getAppRunningTaskInfo() != null;
    }

    /**
     * 回到APP
     */
    public static void moveToFront() {
        ActivityManager activityManager = (ActivityManager) KaDaApplication.applicationContext().getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.RunningTaskInfo info = getAppRunningTaskInfo();
        if (info != null) {
            activityManager.moveTaskToFront(info.id, 0);
        }
    }

    public static String getTopActivityClassName() {
        ActivityManager.RunningTaskInfo info = getAppRunningTaskInfo();
        if (info != null) {
            return info.topActivity.getClassName();
        }
        return null;
    }

    private static ActivityManager.RunningTaskInfo getAppRunningTaskInfo() {
        ActivityManager activityManager = (ActivityManager) KaDaApplication.applicationContext().getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningTaskInfo> recentList = activityManager.getRunningTasks(Integer.MAX_VALUE);
        for (ActivityManager.RunningTaskInfo info : recentList) {
            if (info.topActivity.getPackageName().equals(KaDaApplication.applicationContext().getPackageName())) {
                return info;
            }
        }
        return null;
    }

    public static String getProcessName() {
        if (TextUtils.isEmpty(PROCESS_NAME)) {
            ActivityManager activityManager = (ActivityManager) KaDaApplication.getInstance().getSystemService(Context.ACTIVITY_SERVICE);
            List<ActivityManager.RunningAppProcessInfo> list = null;
            if (activityManager != null) {
                list = activityManager.getRunningAppProcesses();
            }
            if (list == null) {
                return null;
            }

            int myPid = android.os.Process.myPid();
            for (ActivityManager.RunningAppProcessInfo appProcess : list) {
                if (appProcess.pid == myPid) {
                    PROCESS_NAME = appProcess.processName;
                    return PROCESS_NAME;
                }
            }
        }

        return PROCESS_NAME;
    }

    public static String getProcessSuffixName() {

        String processSuffixName = "main";

        String processName = getProcessName();

        if (processName != null && !BuildConfig.APPLICATION_ID.equals(processName)) {
            if (processName.contains(":")) {
                processSuffixName = processName.substring(processName.lastIndexOf(":") + 1);
            } else if (processName.contains(".")) {
                processSuffixName = processName.substring(processName.lastIndexOf(".") + 1);
            }
        }

        return processSuffixName;
    }

    public static String getVersionName() {
        return BuildConfig.VERSION_NAME;
    }

    public static int getVersionCode() {
        return BuildConfig.VERSION_CODE;
    }

    public static boolean isOnTop(Context context) {
        if (context == null) {
            return false;
        }
        android.app.ActivityManager activityManager = (android.app.ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> appProcesses = activityManager.getRunningAppProcesses();
        if (appProcesses == null) {
            return false;
        }
        String packageName = KaDaApplication.getInstance().getPackageName();
        for (android.app.ActivityManager.RunningAppProcessInfo appProcess : appProcesses) {
            if (appProcess.processName.equals(packageName)
                    && appProcess.importance == android.app.ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                return true;
            }
        }
        return false;
    }

    public static int getOritation() {
        return KaDaApplication.getInstance().getResources().getConfiguration().orientation;
    }

    //得到屏幕旋转的状态
    public static int getRotationStatus(Context context) {
        int status = 0;
        if (context == null) {
            return status;
        }

        try {
            status = android.provider.Settings.System.getInt(context.getContentResolver(), android.provider.Settings.System.ACCELEROMETER_ROTATION);
        } catch (android.provider.Settings.SettingNotFoundException e) {
            LogHelper.printStackTrace(e);
        }
        return status;
    }


    // ====================================
    // CPU核心数
    // ====================================
    private static boolean isGetCpuNember = false; // 是否获取或cpu数量
    private static int cpuNumber = 1;


    /**
     * Gets the number of cores available in this device, across all processors.
     * Requires: Ability to peruse the filesystem at "/sys/devices/system/cpu"
     *
     * @return The number of cores, or 1 if failed to get result
     */
    public static int getCpuNumber() {
        if (isGetCpuNember) {
            return cpuNumber;
        }
        isGetCpuNember = true;

        //Private Class to display only CPU devices in the directory listing
        class CpuFilter implements FileFilter {
            @Override
            public boolean accept(File pathname) {
                //Check if filename is "cpu", followed by a single digit number
                if (Pattern.matches("cpu[0-9]", pathname.getName())) {
                    return true;
                }
                return false;
            }
        }

        try {
            //Get directory containing CPU info
            File dir = new File("/sys/devices/system/cpu/");
            //Filter to only list the devices we care about
            File[] files = dir.listFiles(new CpuFilter());
            LogHelper.d(TAG, "CPU Count: " + files.length);
            cpuNumber = files.length;
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
            cpuNumber = 1;
        }

        return cpuNumber;
    }

    /**
     * 获取APK渠道号
     *
     * @param ctx
     * @return
     */
    public static String getChannelData(Context ctx) {
        if (TextUtils.isEmpty(CHANNEL_ID)) {
            if (ctx == null) {
                return null;
            }
            try {
                PackageManager packageManager = ctx.getPackageManager();
                if (packageManager != null) {
                    ApplicationInfo applicationInfo = packageManager.getApplicationInfo(ctx.getPackageName(), PackageManager.GET_META_DATA);
                    if (applicationInfo != null) {
                        if (applicationInfo.metaData != null) {
                            CHANNEL_ID = applicationInfo.metaData.getString("UMENG_CHANNEL");
                        }
                    }
                }
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
        }
        return CHANNEL_ID;
    }

}
