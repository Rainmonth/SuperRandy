package com.hhdd.kada.main.utils;

/**
 * Created by lj on 16/3/17.
 */
public class Extflag {

    /**
     * 绘本exflag
     */
    /* 1：表示已经获得版权(针对单绘本) */
    public static final long EXT_FLAG_1 = 1 << 0;
    /* 2：表示有中文字幕(针对单绘本) */
    public static final long EXT_FLAG_2 = 1 << 1;
    /* 4：表示有英文字幕(针对单绘本) */
    public static final long EXT_FLAG_4 = 1 << 2;
    /* 8：表示小编推荐 */
    public static final long EXT_FLAG_8 = 1 << 3;
    /* 16: 表示绘本有问答题(针对单绘本) */
    public static final long EXT_FLAG_16 = 1 << 4;
    /* 32: 表示合集绘本(针对单绘本) */
    public static final long EXT_FLAG_32 = 1 << 5;
    /* 64: 表示有上新标记 */
    public static final long EXT_FLAG_64 = 1 << 6;
    /* 128: 表示可以购买（在商城有对应商品） */
    public static final long EXT_FLAG_128 = 1 << 7;
    /* 256: 表示官方推荐 */
    public static final long EXT_FLAG_256 = 1 << 8;
    /* 512：表示普通绘本 */
    public static final long EXT_FLAG_512 = 1 << 9;
    /* 1024: 表示是否收费 */
    public static final long EXT_FLAG_1024 = 1 << 10;
    /* 2048：表示属于新上线内容（新绘本或合辑里面有新绘本） */
    public static final long EXT_FLAG_2048 = 1 << 11;
    /* 4096 热门经典（根据订阅数量降序）*/
    public static final long EXT_FLAG_4096 = 1 << 12;
    /* 8192: 表示付费合辑可以试听（针对单绘本） */
    public static final long EXT_FLAG_8192 = 1 << 13;
    /* 32768:促销标记*/
    public static final long EXT_FLAG_SALE = 1 << 15;


    /**
     * 听书exflag
     */
    /* 1：表示普通故事 */
    public static final long STORY_EXT_FLAG_1 = 1 << 0;
    /* 2：表示合集故事 */
    public static final long STORY_EXT_FLAG_2 = 1 << 1;
    /* 4：表示属于新上线内容（新故事或合集里面有新故事） */
    public static final long STORY_EXT_FLAG_4 = 1 << 2;
    /* 8：表示官方推荐 */
    public static final long STORY_EXT_FLAG_8 = 1 << 3;
    /* 16: 表示是否连载 */
    public static final long STORY_EXT_FLAG_16 = 1 << 4;
    /* 32: 表示是否收费 */
    public static final long STORY_EXT_FLAG_32 = 1 << 5;
    /* 64:  */
    public static final long STORY_EXT_FLAG_64 = 1 << 6;

    /* 128: 表示付费合辑需要订阅 */
    public static final long STORY_EXT_FLAG_128 = 1 << 7;
    /* 256: 表示付费合辑可以试听 */
    public static final long STORY_EXT_FLAG_256 = 1 << 8;

    /* 以下定义留作以后的业务需要 */
    /* 512: 表示收费会员可听 */
    public static final long STORY_EXT_FLAG_512 = 1 << 9;
    /* 1024: 表示购买了就可听 */
    public static final long STORY_EXT_FLAG_1024 = 1 << 10;
    /* 2048: 表示游客能听的免费故事 */
    public static final long STORY_EXT_FLAG_2048 = 1 << 11;

    /* 4096: 促销标记*/
    public static final long STORY_EXT_FLAG_SLAE = 1 << 12;
    /* 65536:全用户限免 */
    public static final long STORY_FLAG_FREE_ALL = 1 << 16;
    /* 131072:新用户限免 */
    public static final long STORY_FLAG_FREE_NEW = 1 << 17;

    /**
     * 优才计划extFlag
     */
    /* 1：促销标记 */
    public static final long TALENT_EXT_FLAG_1 = 1 << 0;
}