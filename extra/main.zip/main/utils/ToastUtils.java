package com.hhdd.kada.main.utils;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.api.API;
import com.hhdd.logger.LogHelper;

/**
 * Created by lj on 16/9/20.
 */
public class ToastUtils {

    private static Toast mToast = null;

    public static void showToast(int resId) {
        try {
            String text = KaDaApplication.getInstance().getString(resId);
            showToast(text);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }

    public static void showToast(int resId, int gravity) {
        try {
            String text = KaDaApplication.getInstance().getString(resId);
            showToast(text, gravity);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }

    public static void showToast(String text) {
        if (text == null || text.trim().length() == 0) {
            //测试环境弹出toast方便调试，正式环境不弹toast
            if (!API.IS_ONLINE()) {
                text = "发生未知错误";
            } else {
                return;
            }
        }
        if (mToast == null) {
            mToast = Toast.makeText(KaDaApplication.getInstance(), text, Toast.LENGTH_SHORT);
        } else {
            mToast.setText(text);
            mToast.setDuration(Toast.LENGTH_SHORT);
        }
        mToast.setGravity(Gravity.CENTER, 0, 0);
        mToast.show();
    }

    public static void showToast(String text, int gravity) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("  ");
        stringBuilder.append(text);
        stringBuilder.append("  ");
        if (mToast == null) {
            mToast = Toast.makeText(KaDaApplication.getInstance(), stringBuilder.toString(), Toast.LENGTH_SHORT);
        } else {
            mToast.setText(stringBuilder.toString());
            mToast.setDuration(Toast.LENGTH_SHORT);
        }
        mToast.setGravity(gravity, 0, 0);
        mToast.show();
    }

    public static void showToast(Context context, String text) {
        makeText(context, text).show();
    }

    private Context mContext;
    private WindowManager wm;
    private int mDuration;
    private View mNextView;
    public static final int LENGTH_SHORT = 1500;
    public static final int LENGTH_LONG = 3000;

    public ToastUtils() {
        mContext = KaDaApplication.getInstance().getApplicationContext();
        wm = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
    }

    public static ToastUtils makeText(Context context,
                                      CharSequence text,
                                      int duration) {
        ToastUtils result = new ToastUtils();
        LinearLayout ll = new LinearLayout(context);
        ll.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        ll.setBackgroundResource(R.drawable.bg_toast);
        TextView tv = new TextView(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(LocalDisplay.dp2px(15), LocalDisplay.dp2px(10), LocalDisplay.dp2px(15), LocalDisplay.dp2px(10));
        tv.setLayoutParams(params);
        tv.setText(text);
        tv.setTextColor(Color.WHITE);
        ll.addView(tv);

        result.mNextView = (View) ll;
        result.mDuration = duration;
        return result;
    }

    public static ToastUtils makeText(Context context, CharSequence text) {
        return makeText(context, text, LENGTH_SHORT);
    }

    public void show() {
        if (mNextView != null) {
            WindowManager.LayoutParams params = new WindowManager.LayoutParams();
            params.gravity = Gravity.CENTER_HORIZONTAL | Gravity.BOTTOM;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.width = WindowManager.LayoutParams.WRAP_CONTENT;
            params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            params.format = PixelFormat.TRANSLUCENT;
            params.windowAnimations = R.style.Animation_Toast;
            params.y = LocalDisplay.dp2px(64);
            params.type = WindowManager.LayoutParams.TYPE_TOAST;
            wm.addView(mNextView, params);

            KaDaApplication.mainLooperHandler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (mNextView != null) {
                        wm.removeView(mNextView);
                        mNextView = null;
                        wm = null;
                    }
                }
            }, mDuration);
        }
    }
}
