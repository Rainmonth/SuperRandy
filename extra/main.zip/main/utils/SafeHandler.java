package com.hhdd.kada.main.utils;

/**
 * Created by simon on 10/6/15.
 */

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.hhdd.logger.LogHelper;

/**
 * Created by simon on 10/31/14.
 */
public class SafeHandler extends Handler {

    private boolean isDestroyed = false;

    @Override
    public boolean sendMessageAtTime(Message msg, long uptimeMillis) {
        if(isDestroyed) {
            return false;
        }
        return super.sendMessageAtTime(msg, uptimeMillis);
    }

    public SafeHandler() {
        super();
    }

    public SafeHandler(Callback callback) {
        super(callback);
    }

    public SafeHandler(Looper looper, Callback callback) {
        super(looper, callback);
    }

    public SafeHandler(Looper looper) {
        super(looper);
    }

    @Override
    public void dispatchMessage(Message msg) {
        if(isDestroyed) {
            return;
        }
        try{
            super.dispatchMessage(msg);
        }catch(Exception e){
            LogHelper.printStackTrace(e);
        }
        clearMessage(msg);
    }

    public void clearMessage(Message msg){
        msg.what = msg.arg1 = msg.arg2 = 0;
        msg.obj = null;
        msg.replyTo = null;
        msg.setTarget(null);
    }

    public void destroy(){
        removeCallbacksAndMessages(null);
        isDestroyed = true;
    }
}
