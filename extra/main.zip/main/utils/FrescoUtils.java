package com.hhdd.kada.main.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;

import com.facebook.common.executors.CallerThreadExecutor;
import com.facebook.common.references.CloseableReference;
import com.facebook.datasource.BaseDataSubscriber;
import com.facebook.datasource.DataSource;
import com.facebook.datasource.DataSubscriber;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.controller.BaseControllerListener;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.common.ResizeOptions;
import com.facebook.imagepipeline.core.ImagePipeline;
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber;
import com.facebook.imagepipeline.image.CloseableImage;
import com.facebook.imagepipeline.image.ImageInfo;
import com.facebook.imagepipeline.request.BasePostprocessor;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.logger.LogHelper;

import java.util.concurrent.CountDownLatch;

/**
 * Created by simon on 6/20/16.
 */
//http://frescolib.org/docs/caching.html
public class FrescoUtils {


    static public boolean cachedInMemory(String url) {
        Uri uri = Uri.parse(url);
        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        boolean inMemoryCache = imagePipeline.isInBitmapMemoryCache(uri);
        return inMemoryCache;
    }

    static public void clearCaches() {
        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        imagePipeline.clearMemoryCaches();
        imagePipeline.clearDiskCaches();
        imagePipeline.clearCaches();
    }

    static public void evictFromCache(String url) {
        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        Uri uri = Uri.parse(url);
        imagePipeline.evictFromCache(uri);
    }

    public interface FetchImageCallback {
        public void handleResult(Bitmap bitmap);
    }

    static public void fetchDecodedImage(String url, Context context, final FetchImageCallback callback) {
        ImageRequest imageRequest = ImageRequestBuilder
                .newBuilderWithSource(Uri.parse(url))
                .setProgressiveRenderingEnabled(true)
                .build();
        ImagePipeline imagePipeline = Fresco.getImagePipeline();
        DataSource<CloseableReference<CloseableImage>>
                dataSource = imagePipeline.fetchDecodedImage(imageRequest, context);
        dataSource.subscribe(new BaseBitmapDataSubscriber() {
                                 @Override
                                 protected void onFailureImpl(DataSource<CloseableReference<CloseableImage>> dataSource) {
                                     if (callback != null) {
                                         callback.handleResult(null);
                                     }
                                 }

                                 @Override
                                 protected void onNewResultImpl(Bitmap bitmap) {
                                     if (callback != null) {
                                         callback.handleResult(bitmap);
                                     }
                                 }
                             },
                CallerThreadExecutor.getInstance());
    }

    public interface PrefetchCallback {
        public void handleResult(boolean isInDiskCache);
    }

    static public void prefetchToDiskCache(final String url, final PrefetchCallback callback) {
        IsInDiskCache isInDiskCache = new IsInDiskCache();
        String newUrl = CdnUtils.suitableImageUrl(url,90);
        isInDiskCache.fetch(newUrl, new IsInDiskCache.Listener() {
            @Override
            public void handleResult(boolean isInDiskCache) {
                if (isInDiskCache) {
                    if (callback != null) {
                        callback.handleResult(isInDiskCache);
                    }
                } else {
                    PrefetchToDiskCache prefetchToDiskCache = new PrefetchToDiskCache();
                    prefetchToDiskCache.fetch(url, new PrefetchToDiskCache.Listener() {
                        @Override
                        public void handleResult(boolean isInDiskCache) {
                            if (callback != null) {
                                callback.handleResult(isInDiskCache);
                            }
                        }
                    });
                }
            }
        });
    }

    public static boolean isInDisk(final String imageUrl) {
        final boolean[] doneDownloadMedalImage = {false};
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        IsInDiskCache isInDiskCache = new IsInDiskCache();
        isInDiskCache.fetch(imageUrl, new IsInDiskCache.Listener() {
            @Override
            public void handleResult(boolean isInDiskCache) {
                doneDownloadMedalImage[0] = isInDiskCache;
                countDownLatch.countDown();
            }
        });
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            LogHelper.printStackTrace(e);
        }
        return doneDownloadMedalImage[0];
    }

    public static boolean prefetchToDisk(final String imageUrl) {
        final boolean[] doneDownloadMedalImage = {false};
        final CountDownLatch countDownLatch = new CountDownLatch(1);
        FrescoUtils.prefetchToDiskCache(imageUrl, new FrescoUtils.PrefetchCallback() {
            @Override
            public void handleResult(boolean isInDiskCache) {
                if (isInDiskCache) {
                    doneDownloadMedalImage[0] = true;
                }
                countDownLatch.countDown();
            }
        });
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            LogHelper.printStackTrace(e);
        }
        return doneDownloadMedalImage[0];
    }


    public static class IsInDiskCache {

        public interface Listener {
            public void handleResult(boolean isInDiskCache);
        }

        Listener listener;
        DataSource<Boolean> dataSource;

        void fetch(String url, Listener l) {
            listener = l;
            ImageRequest imageRequest = ImageRequest.fromUri(Uri.parse(url));
            ImagePipeline imagePipeline = Fresco.getImagePipeline();
            dataSource = imagePipeline.isInDiskCache(imageRequest);
            DataSubscriber<Boolean> subscriber = new BaseDataSubscriber<Boolean>() {
                @Override
                protected void onNewResultImpl(DataSource<Boolean> dataSource) {
                    if (!dataSource.isFinished()) {
                        return;
                    }
                    if (listener != null) {
                        listener.handleResult(dataSource.getResult());
                    }
                    // your code here
                    dataSource = null;
                }

                @Override
                protected void onFailureImpl(DataSource<Boolean> dataSource) {
                    if (listener != null) {
                        listener.handleResult(false);
                    }
                }
            };
            dataSource.subscribe(subscriber, CallerThreadExecutor.getInstance());
        }

        void cancel() {
            if (dataSource != null) {
                dataSource.close();
            }
        }
    }

    public static class PrefetchToDiskCache {
        public interface Listener {
            public void handleResult(boolean isInDiskCache);
        }

        Listener listener;
        DataSource<Void> dataSource;

        void fetch(String url, Listener l) {
            listener = l;
            ImageRequest imageRequest = ImageRequest.fromUri(Uri.parse(url));
            ImagePipeline imagePipeline = Fresco.getImagePipeline();
            dataSource = imagePipeline.prefetchToDiskCache(imageRequest, null);
            DataSubscriber<Void> subscriber = new BaseDataSubscriber<Void>() {
                @Override
                protected void onNewResultImpl(DataSource<Void> dataSource) {
                    if (!dataSource.isFinished()) {
                        return;
                    }
                    if (listener != null) {
                        listener.handleResult(true);
                    }
                    // your code here
                    dataSource = null;
                }

                @Override
                protected void onFailureImpl(DataSource<Void> dataSource) {
                    if (listener != null) {
                        listener.handleResult(false);
                    }
                }

                @Override
                public void onNewResult(DataSource<Void> dataSource) {
                    super.onNewResult(dataSource);
                }
            };
            dataSource.subscribe(subscriber, CallerThreadExecutor.getInstance());
        }

        void cancel() {
            if (dataSource != null) {
                dataSource.close();
                dataSource = null;
            }
        }
    }

    @Deprecated
    public static void showUrl(String url, SimpleDraweeView draweeView, boolean isCdnSuit){
        String path = isCdnSuit ? CdnUtils.suitableImageUrl(url,90) : url;
        showUrl(path, draweeView, 0, 0);
    }

    @Deprecated
    public static void showUrl(String url, SimpleDraweeView draweeView) {
        showUrl(url, draweeView, true);
    }

    @Deprecated
    public static void showUrl(String url, SimpleDraweeView draweeView, int width, int height) {
        if (url != null && url.length() > 0 && draweeView != null) {
//            int width=draweeView.getWidth();
//            int height=draweeView.getHeight();

            url = CdnUtils.suitableImageUrl(url,width,height);

            if (draweeView.getTag(R.id.draweeview_image_url)!=null) {
                String cachedUrl = (String)draweeView.getTag(R.id.draweeview_image_url);
                if (cachedUrl.compareToIgnoreCase(url)==0) {
                    return;
                }
            }
            ResizeOptions resizeOptions = null;
            if (width > 0 && height > 0) {
                //坚果手机问题
                if(!AppUtils.IS_MODEL_YQ601){
                    width = (int) (width * 4 / 5f);
                    height = (int) (height * 4 / 5f);
                } else{
                    width = (int) (width /2f);
                    height = (int) (height /2f);
                }
                if (width > 0 && height > 0) {
                    resizeOptions = new ResizeOptions(width,height);
                }
            }

            ImageRequestBuilder imageRequestBuilder = ImageRequestBuilder.newBuilderWithSource(Uri.parse(url))
                    .setLocalThumbnailPreviewsEnabled(true)
                    .setResizeOptions(resizeOptions);
            if (width > 0 && width < 200) { // 小图
                imageRequestBuilder.setCacheChoice(ImageRequest.CacheChoice.SMALL);
            }
            ImageRequest imageRequest = imageRequestBuilder.build();

            DraweeController draweeController = Fresco.newDraweeControllerBuilder()
                    .setImageRequest(imageRequest)
                    .setOldController(draweeView.getController())
                    .setControllerListener(new BaseControllerListener<ImageInfo>())
                    .build();
            draweeView.setController(draweeController);

            draweeView.setTag(R.id.draweeview_image_url,url);
        }
    }

    public static void showGif(String url, SimpleDraweeView draweeView){
        DraweeController draweeController =
                Fresco.newDraweeControllerBuilder()
                        .setUri(Uri.parse(url))
                        .setAutoPlayAnimations(true) // 设置加载图片完成后是否直接进行播放
                        .build();


        draweeView.setController(draweeController);
    }

    public static void showImg(SimpleDraweeView draweeView, String imgUrl) {
        showImg(draweeView, imgUrl, 0, 0);
    }

    public static void showImg(SimpleDraweeView draweeView, String imgUrl, int vW, int vH) {
        showImg(draweeView, null, imgUrl, vW, vH);
    }

    public static void showImg(SimpleDraweeView draweeView, BasePostprocessor postprocessor, String imgUrl, int vW, int vH) {
        if (StringUtil.isEmpty(imgUrl)) {
            return;
        }

        showImg(draweeView, postprocessor, Uri.parse(imgUrl), vW, vH);
    }

    public static void showImg(SimpleDraweeView draweeView, int imgResId, int vW, int vH) {
        showImg(draweeView, null, AppUtils.getDrawable(imgResId), vW, vH);
    }

    public static void showImg(SimpleDraweeView draweeView, BasePostprocessor postprocessor, Uri uri, int vW, int vH) {
        if (draweeView == null || uri == null) {
            return;
        }

        ResizeOptions resizeOptions = null;
        if (vW > 0 && vH > 0) {
            if (AppUtils.IS_MODEL_YQ601) { // 坚果手机问题；不清楚这部手机上当时是什么问题 代码保持不要修改；
                vW = vW / 2;
                vH = vH / 2;
            } else {
                vW = vW * 9 / 10;
                vH = vH * 9 / 10;
            }

            if (vW > 0 && vH > 0) {
                resizeOptions = new ResizeOptions(vW, vH);
            }
        }

        ImageRequestBuilder imageRequestBuilder = ImageRequestBuilder.newBuilderWithSource(uri)
                .setLocalThumbnailPreviewsEnabled(true)
                .setResizeOptions(resizeOptions);
        if (postprocessor != null) {
            imageRequestBuilder.setPostprocessor(postprocessor);
        }
        if (vW >0 && vW < 200) { // 小图
            imageRequestBuilder.setCacheChoice(ImageRequest.CacheChoice.SMALL);
        }
        ImageRequest imageRequest = imageRequestBuilder.build();

        DraweeController draweeController = Fresco.newDraweeControllerBuilder()
                .setImageRequest(imageRequest)
                .setOldController(draweeView.getController())
                .setControllerListener(new BaseControllerListener<ImageInfo>())
                .build();
        draweeView.setController(draweeController);
    }

    private static boolean isImgLoadPaused = false;

    // 暂停图片请求
    public static void imagePause() {
        if (!isImgLoadPaused) {
            isImgLoadPaused = true;
            Fresco.getImagePipeline().pause();
        }
    }

    // 恢复图片请求
    public static void imageResume() {
        if (isImgLoadPaused) {
            Fresco.getImagePipeline().resume();
            isImgLoadPaused = false;
        }
    }

}
