package com.hhdd.kada.main.utils;

import android.text.TextUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/10/30
 * @describe : com.hhdd.kada.main.utils
 */
public class PatternUtil {

    public static final Pattern COOKIE_PATTERN = Pattern.compile("Set-Cookie.*?;");
    private static final Pattern MOBILE_PATTERN = Pattern.compile("^(1)\\d{10}$");
    private static final Pattern INTEGER_PATTERN = Pattern.compile("^[-\\+]?[\\d]*$");

    /**
     * 根据正则判断是否为手机号,该正则只是做个简单的判断，以1开头，11位
     * @param mobiles
     * @return
     */
    public static boolean isMobile(String mobiles) {
        boolean flag;
        try {
            Matcher m = MOBILE_PATTERN.matcher(mobiles);
            flag = m.matches();
        } catch (Exception e) {
            flag = false;
        }
        return flag;
    }

    /**
     * 判断是否为整数
     * @param str
     * @return
     */
    public static boolean isInteger(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        return INTEGER_PATTERN.matcher(str).matches();
    }
}
