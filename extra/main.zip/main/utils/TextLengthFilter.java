package com.hhdd.kada.main.utils;

import android.text.InputFilter;
import android.text.Spanned;

import com.hhdd.logger.LogHelper;

import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/11/22
 * @describe : com.hhdd.kada.main.utils
 */
public class TextLengthFilter implements InputFilter {

    int MAX_EN;
    String regEx = "[\\u4e00-\\u9fa5]";

    public static final String CHARSET_NAME = "GBK";

    public TextLengthFilter(int mAX_EN) {
        super();
        MAX_EN = mAX_EN;
    }

    @Override
    public CharSequence filter(CharSequence source, int start, int end,
                               Spanned dest, int dstart, int dend) {
        try {
            int destCount = dest.toString().getBytes(CHARSET_NAME).length;
            int sourceCount = source.toString().getBytes(CHARSET_NAME).length;
            if (destCount + sourceCount > MAX_EN) {
                ToastUtils.showToast("昵称最长支持6个汉字、12个英文或数字");

                int surplusCount = MAX_EN - destCount;
                String result = "";
                int index = 0;
                while (surplusCount > 0) {
                    char c = source.charAt(index);
                    if (isChinese(c + "")) {
                        if (surplusCount >= 2) {
                            result += c;
                        }
                        surplusCount = surplusCount - 2;
                    } else {
                        result += c;
                        surplusCount = surplusCount - 1;
                    }
                    index++;
                }
                return result;
            } else {

                return source;
            }
        } catch (UnsupportedEncodingException e) {
            LogHelper.printStackTrace(e);
        }
        return source;
    }

    private int getChineseCount(String str) {
        int count = 0;
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(str);
        while (m.find()) {
            for (int i = 0; i <= m.groupCount(); i++) {
                count = count + 1;
            }
        }
        return count;
    }

    private boolean isChinese(String source) {
        return Pattern.matches(regEx, source);
    }
}
