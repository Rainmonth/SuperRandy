package com.hhdd.kada.main.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import com.hhdd.kada.BuildConfig;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;

import java.io.File;


/**
 * Created by XiaoYu on 2018/6/26 下午1:58.
 * ilzq@foxmail.com
 * 开发人员调试相关类
 */
public class DebugUtils {
    public static void saveMp3AESSTForDebug(String filePath,String filePathTemp, String AESST){
        if(BuildConfig.DEBUG) {
            SharedPreferences debugAESS = KaDaApplication.getInstance().getSharedPreferences("AESSFORDEBUG", Context.MODE_PRIVATE);
            debugAESS.edit().putString(filePath, AESST).putString(filePathTemp,AESST).apply();
//            debugAESS = KaDaApplication.getInstance().getSharedPreferences("AESSFORDEBUG_VERSION", Context.MODE_PRIVATE);
//            debugAESS.edit().putInt(filePath+"_VERSION", version).putInt(filePathTemp+"_VERSION",version).apply();
        }
    }

    public static String getAESSForDebug(String filePath){
        if(BuildConfig.DEBUG) {
            SharedPreferences debugAESS = KaDaApplication.getInstance().getSharedPreferences("AESSFORDEBUG", Context.MODE_PRIVATE);
            return debugAESS.getString(filePath, null);
        }else{
            throw new RuntimeException("can't use debug method when release");
        }
    }

//    public static int getAESSVersionForDebug(String filePath){
//        if(BuildConfig.DEBUG) {
//            SharedPreferences debugAESS = KaDaApplication.getInstance().getSharedPreferences("AESSFORDEBUG_VERSION", Context.MODE_PRIVATE);
//            return debugAESS.getInt(filePath+"_VERSION", 0);
//        }else{
//            throw new RuntimeException("can't use debug method when release");
//        }
//    }
}
