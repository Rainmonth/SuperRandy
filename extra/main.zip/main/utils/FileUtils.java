package com.hhdd.kada.main.utils;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.logger.LogHelper;

import org.apache.http.util.EncodingUtils;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Created by simon on 16/6/15.
 */
public class FileUtils {

    private static final String TAG = "FileUtils";

    public static String makeDirIfNoExist(String fileDir) {
        // TODO: 2018/5/22 当下无法彻底修改所有getXXXPath方法，因此取消FileUtils里的线程检查，否则会造成主线程文件夹无法创建
//        if (Thread.currentThread().getId() == Looper.getMainLooper().getThread().getId()) {
//            throw new IOOnUiThreadException();
//        }
        if (fileDir.length() > 0) {
            File file = new File(fileDir);
            if (!file.exists()) {
                file.mkdir();
            }
        }
        return fileDir;
    }

    public static String makeDirsIfNoExist(String fileDir) {
        if (fileDir.length() > 0) {
            File file = new File(fileDir);
            if (!file.exists()) {
                file.mkdirs();
            }
        }
        return fileDir;
    }

    public static boolean fileExist(String filePath) {
        if (filePath.length() > 0) {
            File file = new File(filePath);
            if (file.exists()) {
                return true;
            }
        }
        return false;
    }

    public static void removeFile(String filePath) {
        if (filePath.length() > 0 && fileExist(filePath)) {
            File file = new File(filePath);
            file.delete();
        }
    }

    public static boolean renameFileTo(String filePath, String toFilePath) {
        if (filePath.length() > 0 && fileExist(filePath) && filePath.compareToIgnoreCase(toFilePath) != 0) {
            File file = new File(filePath);
            removeFile(toFilePath);
            return file.renameTo(new File(toFilePath));
        }
        return false;
    }

    public static void deleteFolderFile(String filePath, boolean deleteThisPath) {
        if (!TextUtils.isEmpty(filePath)) {
            try {
                File file = new File(filePath);
                if (file.isDirectory()) {// 处理目录
                    File files[] = file.listFiles();
                    for (int i = 0; i < files.length; i++) {
                        deleteFolderFile(files[i].getAbsolutePath(), true);
                    }
                }
                if (deleteThisPath) {
                    if (!file.isDirectory()) {// 如果是文件，删除
                        file.delete();
                    } else {// 目录
//                        if (file.listFiles().length == 0) {// 目录下没有文件或者目录，删除
//                            file.delete();
//                        }
                    }
                }
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    public static long getFolderSize(String filepath) throws Exception {
        long size = 0;
        try {
            File file = new File(filepath);
            File[] fileList = file.listFiles();
            for (int i = 0; i < fileList.length; i++) {
                // 如果下面还有文件
                if (fileList[i].isDirectory()) {
                    size = size + getFolderSize(fileList[i].getAbsolutePath());
                } else {
                    size = size + fileList[i].length();
                }
            }
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
        return size;
    }

    public static String getFormatSize(double size) {
        double kiloByte = size / 1024;
        double megaByte = kiloByte / 1024;
        double gigaByte = megaByte / 1024;
        BigDecimal result2 = new BigDecimal(Double.toString(megaByte));
        return result2.setScale(2, BigDecimal.ROUND_HALF_UP)
                .toPlainString() + "MB";
//        }
//
//        double teraBytes = gigaByte / 1024;
//        if (teraBytes < 1) {
//            BigDecimal result3 = new BigDecimal(Double.toString(gigaByte));
//            return result3.setScale(2, BigDecimal.ROUND_HALF_UP)
//                    .toPlainString() + "GB";
//        }
//        BigDecimal result4 = new BigDecimal(teraBytes);
//        return result4.setScale(2, BigDecimal.ROUND_HALF_UP).toPlainString()
//                + "TB";
    }

    public static File newTempImageFile() {
        String root = Dirs.getTmpCachePath();
        if (!TextUtils.isEmpty(root)) {
            return new File(Dirs.getTmpCachePath(), UUID.randomUUID().toString() + ".jpg");
        }
        return null;
    }

    public static boolean copyTo(String filePath, String toFilePath) {
        if (filePath.length() > 0 && fileExist(filePath) && filePath.compareToIgnoreCase(toFilePath) != 0) {
            removeFile(toFilePath);
            FileInputStream inStream = null;
            FileOutputStream fs = null;
            try {
                File oldfile = new File(filePath);
                if (oldfile.exists()) { //文件存在时
                    inStream = new FileInputStream(filePath); //读入原文件
                    fs = new FileOutputStream(toFilePath);
                    byte[] buffer = new byte[1024];
                    int byteread = 0;
                    while ((byteread = inStream.read(buffer)) != -1) {
                        fs.write(buffer, 0, byteread);
                    }
                }
                return true;
            } catch (Exception e) {
                System.out.println("复制单个文件操作出错");
                LogHelper.printStackTrace(e);

            } finally {
                if (inStream != null) {
                    try {
                        inStream.close();
                    } catch (IOException e) {
                        LogHelper.printStackTrace(e);
                    }
                }
                if (fs != null) {
                    try {
                        fs.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return false;
    }

    public static String readStringFromFile(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
//            FileWriter output = null;
//            BufferedWriter bw = null;
            String line;
            StringBuilder strBuild = new StringBuilder();
//            BufferedInputStream stream = null;
            BufferedReader stream = null;
            InputStreamReader reader = null;
            File fileReader = null;
            try {
//                output = new FileWriter(filePath);
//                bw = new BufferedWriter(output);

                fileReader = new File(filePath);
                FileInputStream fstream = new FileInputStream(fileReader);

//                stream = new BufferedInputStream(fstream, 2 * BUFFER_SIZE);
                reader = new InputStreamReader(fstream, "UTF-8");
                stream = new BufferedReader(reader);

                while ((line = stream.readLine()) != null) {
                    strBuild.append(line);
                }
//                byte[] byteArray = new byte[BUFFER_SIZE];
//                int tmp = 0;
//                while ((tmp = stream.read(byteArray)) != -1) {
//                    strBuild.append(new String(byteArray, 0, tmp));
//                }
                return strBuild.toString();
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            } finally {
                if (stream != null) {
                    try {
                        stream.close();
                    } catch (IOException e) {
                        LogHelper.printStackTrace(e);
                    }
                }
            }
        }
        return "";
    }

    public static String readStringFromInputStream(InputStream in) {
        String result = "";
        try {
            int lenght = in.available();
            //创建byte数组
            byte[] buffer = new byte[lenght];
            //将文件中的数据读到byte数组中
            in.read(buffer);
            result = EncodingUtils.getString(buffer, "UTF-8");
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
        return result;
    }


    public static boolean saveStringToFile(String data, String filePath) {
        if (data.length() > 0 && filePath.length() > 0) {

            //创建文件夹
            makeDirsIfNoExist(filePath.substring(0, filePath.lastIndexOf("/")));

            File fileWriter = new File(filePath);
            return saveStringToFile(data, fileWriter);
        }
        return false;
    }

    public static boolean saveStringToFile(String data, @NonNull File dest) {
        if(!TextUtils.isEmpty(data)) {
            //noinspection ResultOfMethodCallIgnored
            dest.delete();

            BufferedOutputStream stream = null;
            try {
                byte[] bytes = data.getBytes();
                FileOutputStream fstream = new FileOutputStream(dest);
                stream = new BufferedOutputStream(fstream);
                stream.write(bytes);
                return true;
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            } finally {
                if (stream != null) {
                    try {
                        stream.close();
                    } catch (IOException e) {
                        LogHelper.printStackTrace(e);
                    }
                }
            }
        }
        return false;
    }


    public static <T extends Object> void saveToFile(List<T> objList, String filePath) {
        if (objList != null) {
            if (FileUtils.fileExist(filePath)) {
                FileUtils.removeFile(filePath);
            }
            Gson gson = new Gson();
            String data = gson.toJson(objList, new TypeToken<List<T>>() {
            }.getType());
//            Log.d("jsonData", data);
            FileUtils.saveStringToFile(data, filePath);
        }
    }

    public static <T> void saveToFile(T obj, String filePath) {
        List<T> list = null;
        loadFromFile(filePath, new TypeToken<List<T>>() {
        });
        if (list != null) {
            list.add(0, obj);
        } else {
            list = new ArrayList<T>();
            list.add(obj);
        }
        if (list != null) {
            Gson gson = new Gson();
            String data = gson.toJson(list, new TypeToken<List<T>>() {
            }.getType());
            FileUtils.saveStringToFile(data, filePath);
        }
    }

    public static <T> List<T> loadFromInputStream(InputStream inputStream, TypeToken<List<T>> typeToken) {
        return loadFromInputStream(inputStream, typeToken.getType());
    }

    public static <T> List<T> loadFromInputStream(InputStream inputStream, java.lang.reflect.Type typeOfT) {
        List<T> list = null;
        try {
            String json = FileUtils.readStringFromInputStream(inputStream);
            if (json != null && json.length() > 0) {
                Gson gson = new Gson();
                list = gson.fromJson(json.toString(), typeOfT);
            }
        } catch (Exception e) {
            LogHelper.d("ecvsadf", e.toString());
        }
        return list;
    }

    public static <T> List<T> loadFromFile(String filePath, TypeToken<List<T>> typeToken) {
        return loadFromFile(filePath, typeToken.getType());
    }

    public static <T> List<T> loadFromFile(String filePath, java.lang.reflect.Type typeOfT) {
        List<T> list = null;
        try {
            String json = FileUtils.readStringFromFile(filePath);
            if (json != null && json.length() > 0) {
                Gson gson = new Gson();
                list = gson.fromJson(json.toString(), typeOfT);
            }
        } catch (Exception e) {
            FileUtils.removeFile(filePath);
        }
        return list;
    }


    public static <T> void saveToFileT(T obj, String filePath) {
        FileUtils.removeFile(filePath);
        Gson gson = new Gson();
        String data = gson.toJson(obj, new TypeToken<Settings>() {
        }.getType());
        FileUtils.saveStringToFile(data, filePath);
    }


    public static <T> T loadFromFileT(String filePath, TypeToken<T> typeToken) {
        T obj = null;
        try {
            String json = FileUtils.readStringFromFile(filePath);
            if (json != null && json.length() > 0) {
                Gson gson = new Gson();
                obj = gson.fromJson(json.toString(), typeToken.getType());
            }
        } catch (Exception e) {
            FileUtils.removeFile(filePath);
        }
        return obj;
    }

    private static final int BUFFER_SIZE = 2048;

    public static String readStreamToString(InputStream in) {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
        StringBuilder stringBuilder = new StringBuilder();
        try {
            char[] buffer = new char[BUFFER_SIZE];
            int num;
            while ((num = bufferedReader.read(buffer)) > 0) {
                stringBuilder.append(buffer, 0, num);
            }
            buffer = null;
        } catch (Exception e) {
            LogHelper.e("HHFileUtil", e.getMessage());
        } finally {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                LogHelper.e("HHFileUtil", e.getMessage());
            }
        }
        return stringBuilder.toString();
    }


    public static void UnZipFolder(String zipFileString, String outPathString) throws Exception {
        FileUtils.UnZipFolder(new FileInputStream(zipFileString), outPathString);
    }

    public static void UnZipFolder(InputStream inputStream, String outPathString) throws Exception {
        ZipInputStream inZip = new ZipInputStream(inputStream);
        ZipEntry zipEntry;
        String szName = "";
        while ((zipEntry = inZip.getNextEntry()) != null) {
            szName = zipEntry.getName();
            if (zipEntry.isDirectory()) {
                // get the folder name of the widget
                szName = szName.substring(0, szName.length() - 1);
                File folder = new File(outPathString + File.separator + szName);
                folder.mkdirs();
            } else {

                File file = new File(outPathString + File.separator + szName);
                file.createNewFile();
                // get the output stream of the file
                FileOutputStream out = new FileOutputStream(file);
                int len;
                byte[] buffer = new byte[1024];
                // read (len) bytes into buffer
                while ((len = inZip.read(buffer)) != -1) {
                    // write (len) byte from buffer at the position 0
                    out.write(buffer, 0, len);
                    out.flush();
                }
                out.close();
            }
        }
        inZip.close();
    }

    static public void deleteAllFiles(String path) {
        File file = new File(path);
        if (file.exists() && file.isDirectory()) {
            deleteAllFiles(file);
        }
    }

    static public void deleteAllFiles(File root) {
        File files[] = root.listFiles();
        if (files != null) {
            for (File f : files) {
                if (f.isDirectory()) { // 判断是否为文件夹
//                    deleteAllFiles(f);
//                    try {
//                        f.delete();
//                    } catch (Exception e) {
//                    }
                } else {
                    if (f.exists() && !f.getName().equalsIgnoreCase("settings.dat")) { // 判断是否存在
                        try {
                            f.delete();
                        } catch (Exception e) {
                        }
                    }
                }
            }
        }
    }

    public static String read(InputStream stream) {
        return read(stream, "utf-8");
    }

    public static String read(InputStream is, String encode) {
        if (is != null) {
            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(is, encode));
                StringBuilder sb = new StringBuilder();
                String line = null;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
                is.close();
                return sb.toString();
            } catch (UnsupportedEncodingException e) {
                LogHelper.printStackTrace(e);
            } catch (IOException e) {
                LogHelper.printStackTrace(e);
            }
        }
        return "";
    }
}
