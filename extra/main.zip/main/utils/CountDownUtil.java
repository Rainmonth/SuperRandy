package com.hhdd.kada.main.utils;

import android.os.Handler;
import android.os.Message;

import com.hhdd.kada.KaDaApplication;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/4
 * @describe : com.hhdd.kada.main.utils
 */
public class CountDownUtil {

    private int countDownTime;
    private CountDownCallback callback;
    private Handler handler;
    private ScheduledExecutorService service;
    private static final int DEFAULT_TIME = 60;//默认倒计时

    public CountDownUtil() {
        init();
    }

    /**
     * 初始化
     */
    private void init() {
        handler = new Handler(KaDaApplication.instance.getMainLooper()) {
            @Override
            public void handleMessage(Message msg) {
                if (callback != null) {
                    callback.countDown(msg.what);
                }
            }
        };
    }

    /**
     * 开始倒计时
     * @param callback
     */
    public void start(CountDownCallback callback) {
        start(DEFAULT_TIME, callback);
    }

    /**
     * 开始倒计时
     * @param callback
     */
    public void start(int countDownTime, CountDownCallback callback) {
        if (callback == null || countDownTime <= 0 || service != null) {
            return;
        }
        service = new ScheduledThreadPoolExecutor(1);
        this.countDownTime = countDownTime;
        this.callback = callback;
        handler.sendEmptyMessage(countDownTime);
        service.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                CountDownUtil.this.countDownTime--;
                handler.sendEmptyMessage(CountDownUtil.this.countDownTime);
                if (CountDownUtil.this.countDownTime <= 0) {
                    stop();
                }
            }
        }, 1000, 1000, TimeUnit.MILLISECONDS);
    }

    /**
     * 结束倒计时, 释放资源
     */
    public void stop() {
        if (service != null && !service.isShutdown()) {
            service.shutdownNow();
        }
        service = null;
    }

    public void release() {
        stop();
    }

    public interface CountDownCallback {
        void countDown(int time);
    }
}
