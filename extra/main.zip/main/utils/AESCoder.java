package com.hhdd.kada.main.utils;


import android.util.Base64;

import com.hhdd.kada.api.API;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AESCoder {

	private static final String ALGORITHM = "AES/ECB/PKCS7Padding";
	private static final byte[] keyValue = new byte[] {'A','b', 'c', 'd', 'E', 'f',
		'g', 'H', 'i', 'j', 'k', 'L', 'm', 'n', 'O', 'p'};

	private static final byte[] onlinekeyValue = new byte[]{'8','b','e','1','5','e','6','5','a','7','6','c','5','8','8','f'};

	public static String encrypt(String valueToEnc) throws Exception {
//		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGORITHM, "BC");
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encValue = c.doFinal(valueToEnc.getBytes("UTF8"));
		String encryptedValue = new String(Base64.encode(encValue,Base64.NO_WRAP)); //hhdd modify 2018-04-03 不要换行符
		return encryptedValue;
	}

	public static String decrypt(String encryptedValue) throws Exception {
//		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGORITHM, "BC");
		c.init(Cipher.DECRYPT_MODE, key);
		byte[] decordedValue = Base64.decode(encryptedValue.getBytes(),Base64.DEFAULT);
		byte[] decValue = c.doFinal(decordedValue);
		String decryptedValue = new String(decValue);
		return decryptedValue;
	}

	private static Key generateKey() throws Exception {
		// System.out.println(keyValue[0]);
		Key key = new SecretKeySpec(API.IS_ONLINE() ? onlinekeyValue : keyValue, ALGORITHM);
		// SecretKeyFactory keyFactory =
		// SecretKeyFactory.getInstance(ALGORITHM);
		// key = keyFactory.generateSecret(new DESKeySpec(keyValue));
		return key;
	}

}