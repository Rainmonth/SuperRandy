package com.hhdd.kada.main.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Proxy;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.logger.LogHelper;

import org.apache.http.HttpHost;

import java.util.HashMap;

/**
 * Created by simon on 23/6/15.
 */
public class NetworkUtils {
    public static final int CHINA_MOBILE = 1; // 中国移动
    public static final int CHINA_UNICOM = 2; // 中国联通
    public static final int CHINA_TELECOM = 3; // 中国电信

    public static final int SIM_OK = 0;
    public static final int SIM_NO = -1;
    public static final int SIM_UNKNOW = -2;

    public static boolean proxy = false;
    private static BroadcastReceiver connChangerRvr;

    public static final String CONN_TYPE_WIFI = "wifi";
    public static final String CONN_TYPE_GPRS = "gprs";
    public static final String CONN_TYPE_NONE = "none";

    public static boolean isReachable() {
        if (isNetworkAvailable(KaDaApplication.getInstance())) {
            return true;
        }
        return false;
    }

    public static boolean isReachableViaWiFi() {
        if (NetworkUtils.CONN_TYPE_WIFI.equals(getNetConnType(KaDaApplication.getInstance()))) {
            return true;
        }
        return false;
    }

    /**
     * 判断网络连接有效
     *
     * @param context Context对象
     * @return 网络处于连接状态（3g or wifi)
     */
    public static boolean isNetworkAvailable(Context context) {
        try {
            ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (manager == null) {
                return false;
            }

            NetworkInfo networkInfo = manager.getActiveNetworkInfo();
            if (networkInfo == null) {
                return false;
            }

            return networkInfo.isAvailable();
        } catch (Exception e) {
            LogHelper.printStackTrace(e);

            return false;
        }
    }

    /**
     * 获取网络类型
     *
     * @param context Context对象
     * @return 当前处于连接状态的网络类型
     */
    public static String getNetworkType(Context context) {
        String result = null;

        ConnectivityManager connectivity = (ConnectivityManager) (context.getSystemService(Context.CONNECTIVITY_SERVICE));

        if (connectivity == null) {
            result = null;
        } else {
            NetworkInfo[] info = null;
            try {
                info = connectivity.getAllNetworkInfo();
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }

            if (info != null) {
                for (int i = 0; i < info.length; i++) {
                    if (info[i] != null) {
                        NetworkInfo.State tem = info[i].getState();
                        if ((tem == NetworkInfo.State.CONNECTED || tem == NetworkInfo.State.CONNECTING)) {
                            String temp = info[i].getExtraInfo();

                            StringBuilder sb = new StringBuilder();
                            sb.append(info[i].getTypeName());
                            sb.append(" ");
                            sb.append(info[i].getSubtypeName());
                            sb.append(temp);

                            result = sb.toString();

                            break;
                        }
                    }
                }
            }

        }

        return result;
    }

    /**
     * 获取SIM卡状态
     *
     * @return SIM_OK sim卡正常
     * SIM_NO		不存在sim卡
     * SIM_UNKNOW	sim卡状态未知
     */
    public static int getSimState(Context context) {
        TelephonyManager telMgr = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

        if (telMgr == null) {
            return SIM_UNKNOW;
        }

        int simState = telMgr.getSimState();

        if (simState == TelephonyManager.SIM_STATE_READY) {
            return SIM_OK;
        } else if (simState == TelephonyManager.SIM_STATE_ABSENT) {
            return SIM_NO;
        } else {
            return SIM_UNKNOW;
        }
    }

    /**
     * 获取运营商类型,通过运营商类型和imsi判断
     *
     * @return CHINA_MOBILE    中国移动 CHINA_TELECOM	中国电信
     * CHINA_UNICOM	中国联通
     */
    public static int getNSP(Context context) {

        if (getSimState(context) == SIM_OK) {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            String operator = tm.getNetworkOperatorName().replaceAll(" ", "");    //honghua.jcc

            String numeric = tm.getNetworkOperator();

            //String test = tm.getSimOperator();
            LogHelper.d("NSP: ", "operator = " + operator + "  type = " + numeric);
            //operator 取不到数据时，numeric是有数据的可以用numeric做判断 2011 1022 byjiuwan
            if ((operator == null || "".equals("")) && numeric != null) {
                operator = numeric;
            }
            if (operator == null || operator.length() == 0) {
                return SIM_UNKNOW;
            }


            //honghua.jcc 获得的运营商字符串可能含有不确定个数的多个空格，会导致比较比对失败。故去掉空格后再比较
            if (operator.compareToIgnoreCase("中国移动") == 0 || operator.compareToIgnoreCase("CMCC") == 0 || operator.compareToIgnoreCase("ChinaMobile") == 0 || operator.compareToIgnoreCase("46000") == 0) {

                return CHINA_MOBILE;
            } else if (operator.compareToIgnoreCase("中国电信") == 0 || operator.compareToIgnoreCase("ChinaTelecom") == 0 || operator.compareToIgnoreCase("46003") == 0 || operator.compareToIgnoreCase("ChinaTelcom") == 0 || operator.compareToIgnoreCase("460003") == 0) {
                return CHINA_TELECOM;
            } else if (operator.compareToIgnoreCase("中国联通") == 0 || operator.compareToIgnoreCase("ChinaUnicom") == 0 || operator.compareToIgnoreCase("46001") == 0 || operator.compareToIgnoreCase("CU-GSM") == 0 || operator.compareToIgnoreCase("CHN-CUGSM") == 0 || operator.compareToIgnoreCase("CHNUnicom") == 0) {
                return CHINA_UNICOM;
            } else {
                String imsi = PhoneInfo.getImsi(context);
                if (imsi.startsWith("46000") || imsi.startsWith("46002") || imsi.startsWith("46007"))
                    return CHINA_MOBILE;
                else if (imsi.startsWith("46001"))
                    return CHINA_UNICOM;
                else if (imsi.startsWith("46003"))
                    return CHINA_TELECOM;
                else
                    return SIM_UNKNOW;
            }
        } else {
            return SIM_NO;
        }
    }

    /**
     * 使支持wap网络
     * 请再程序退出时调用unRegNetWorkRev方法
     */
    public static void supportWap(Context context) {
        supportWap(context, new DefaultApnUriGetter());

    }


    /**
     * 使客户端支持wap网络
     * 请在程序退出时调用unRegNetWorkRev方法
     *
     * @param context   Context实例
     * @param uriGetter 可采用DefaultApnUriGetter，对特定手机适配需自己实现
     */
    public static void supportWap(Context context, ApnUriGetter uriGetter) {
        LogHelper.d("supportWap", "supportWap");
        HashMap<String, String> param = null;
        Uri[] uris = uriGetter.getUriList();
        for (int i = 0; i < uris.length; i++) {
            LogHelper.d("supportWap", uris[i].toString());
            if (uris[i] != null)
                param = getProxyInfo(context, uris[i]);
            if (param != null) {
                LogHelper.d("supportWap", "finded the proxy param");
                setProxy(param.get("host"), param.get("port"));
                break;
            } else {
                NetworkUtils.setProxy(null, null);
            }
        }

        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        connChangerRvr = new ConnectionChangeReceiver(uriGetter);
        context.registerReceiver(connChangerRvr, filter);

    }

    /**
     * 清空wap代理设置
     * 注销广播回调
     *
     * @param context Context实例
     */
    public static void unRegNetWorkRev(Context context) {
        setProxy(null, null);
        try {
            if (connChangerRvr != null)
                context.unregisterReceiver(connChangerRvr);
        } catch (Exception e) {  //register未完成时调用此方法可能报错
            LogHelper.printStackTrace(e);
            return;
        }
    }

    /**
     * 设置代理服务器，在wap拨号网络时手动设定
     * if host == null or host's length is 0
     * set unuse proxy
     *
     * @param host 代理服务器地址
     * @param port 代理端口
     */
    public static void setProxy(String host, String port) {
        if (host == null || host.length() == 0) {
            System.getProperties().put("proxySet", "false");
            System.getProperties().remove("proxyHost"); //只设置ProxySet在某些系统上没有作用，需要删除对应host与port
            System.getProperties().remove("proxyPort"); //edit by 古朗 2013-3-3
            proxy = false;
        } else {
            proxy = true;
            System.getProperties().put("proxySet", "true");
            System.getProperties().put("proxyHost", host);
            if (port != null && port.length() > 0)
                System.getProperties().put("proxyPort", port);
            else
                System.getProperties().put("proxyPort", "80");
        }
    }

    /**
     * 获取当前网络的代理信息
     * 如果当前无网络 、网络为wifi 或mobile umts 则返回null
     * 如果当前apn找不到 则返回null
     */
    public static HashMap<String, String> getProxyInfo(Context context, Uri uri) {
        String result = NetworkUtils.getNetworkType(context);
        HashMap<String, String> proxy = new HashMap<String, String>();
        if (result == null)
            return null;
        LogHelper.d("getProxyInfo", "current network:" + result);
        if (result.indexOf("WIFI") != -1 || result.compareToIgnoreCase("MOBILE UMTS") == 0) {
            return proxy;
        }
        Cursor cr = null;
        try {

            cr = context.getContentResolver().query(uri, null, "mcc ='460'", null, null);
            if (cr.moveToFirst()) {
                do {
                    if (cr.getCount() > 0) {

                        // TaoHelper.APN apn = new TaoHelper.APN();
                        proxy.put("host", cr.getString(cr.getColumnIndex("proxy")));
                        proxy.put("port", cr.getString(cr.getColumnIndex("port")));
                        String apn = cr.getString(cr.getColumnIndex("apn"));
                        LogHelper.d("getProxyInfo", "apn:" + apn);
                        if (result.contains(apn)) {
                            return proxy;
                        }
                    }

                } while (cr.moveToNext());
            }
        } catch (Exception e) {

        } finally {
            if (cr != null) {
                try {
                    //这个地方有可能会抛出异常，捕获一下
                    cr.close();
                } catch (Exception e) {
                }
            }

        }
        return null;
    }


    /**
     * 获取当前网络的https代理信息
     * 如果无代理 则返回null
     */
    @SuppressWarnings("deprecation")
    public static HttpHost getHttpsProxyInfo(Context context) {

        HttpHost proxy = null;
        if (android.os.Build.VERSION.SDK_INT < 11) {
            NetworkInfo info = null;
            try {
                ConnectivityManager cm = (ConnectivityManager) context
                        .getSystemService(Context.CONNECTIVITY_SERVICE);
                info = cm.getActiveNetworkInfo();
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }

            if (info != null && info.isAvailable()
                    && info.getType() == ConnectivityManager.TYPE_MOBILE) {
                String proxyHost = Proxy.getDefaultHost();
                int port = Proxy.getDefaultPort();
                if (proxyHost != null)
                    proxy = new HttpHost(proxyHost, port);
            }

            return proxy;
        } else {

            String httpsproxyhost = System.getProperty("https.proxyHost");
            String proxyport = System.getProperty("https.proxyPort");

            if (!TextUtils.isEmpty(httpsproxyhost)) {

                int port = Integer.parseInt(proxyport);
                proxy = new HttpHost(httpsproxyhost, port);
            }

            return proxy;
        }
    }

    /**
     * 判断当前的网络状态 wifi或者gprs
     *
     * @param context
     * @return
     */
    public static String getNetConnType(Context context) {
        // 获得网络连接服务
        ConnectivityManager connManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (null == connManager) {
            LogHelper.w("Network", "can not get Context.CONNECTIVITY_SERVICE");
            return CONN_TYPE_NONE;
        }

        NetworkInfo info = null;
        // wifi的网络状态
        info = connManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        if (null != info) {
            NetworkInfo.State wifiState = info.getState();
            if (NetworkInfo.State.CONNECTED == wifiState) { // 判断是否正在使用WIFI网络
                return CONN_TYPE_WIFI;
            }
        } else {
            LogHelper.w("Network", "can not get ConnectivityManager.TYPE_WIFI");
        }

        // gprs的网络状态
        info = connManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        if (null != info) {
            NetworkInfo.State mobileState = info.getState();
            if (NetworkInfo.State.CONNECTED == mobileState) { // 判断是否正在使用GPRS网络
                return CONN_TYPE_GPRS;
            }
        } else {
            LogHelper.w("Network", "can not get ConnectivityManager.TYPE_MOBILE");
        }
        return CONN_TYPE_NONE;
    }

    /**
     * 接口，获取手机的uri列表，适配各手机的Uri列表不同，在设置wap代理时使用
     */
    public interface ApnUriGetter {
        /**
         * 获取所有的Uri列表
         *
         * @return Uri列表
         */
        public Uri[] getUriList();
    }

    public static class DefaultApnUriGetter implements ApnUriGetter {
        @Override
        public Uri[] getUriList() {
            // TODO Auto-generated method stub
            Uri[] uris = new Uri[2];
            uris[0] = Uri.parse("content://telephony/carriers/preferapn");
            uris[1] = Uri.parse("content://telephony/carriers/current");
            return uris;
        }
    }

    public static class ConnectionChangeReceiver extends BroadcastReceiver {

        private ApnUriGetter uriGetter;

        public ConnectionChangeReceiver(ApnUriGetter uriGetter) {
            this.uriGetter = uriGetter;
        }

        @Override
        public void onReceive(Context context, Intent intent) {
            // TODO Auto-generated method stub
            HashMap<String, String> param = null;
            Uri[] uris = uriGetter.getUriList();
            for (int i = 0; i < uris.length; i++) {
                if (uris[i] != null)
                    param = NetworkUtils.getProxyInfo(context, uris[i]);
                if (param != null) {
                    NetworkUtils.setProxy(param.get("host"), param.get("port"));
                    break;
                } else {
                    NetworkUtils.setProxy(null, null);
                }
            }
        }
    }

    /**
     * Get the network info
     *
     * @param context
     * @return
     */
    public static NetworkInfo getNetworkInfo(Context context) {
        if (context == null) {
            return null;
        }

        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            return cm.getActiveNetworkInfo(); // 线上环境 诺基亚 TA 1000 手机上 报过一次android.os.DeadSystemException
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return null;
    }

    /**
     * Check if there is any connectivity to a mobile network
     *
     * @param context
     * @param
     * @return
     */
    public static boolean isConnectedMobile(Context context) {
        NetworkInfo info = NetworkUtils.getNetworkInfo(context);
        return (info != null && info.isConnected() && info.getType() == ConnectivityManager.TYPE_MOBILE);
    }

    /**
     * Check if there is fast connectivity
     *
     * @param context
     * @return
     */
    public static boolean isConnectedFast(Context context) {
        NetworkInfo info = NetworkUtils.getNetworkInfo(context);
        return (info != null && info.isConnected() && NetworkUtils.isConnectionFast(info.getType(), info.getSubtype()));
    }

    /**
     * Check if the connection is fast
     *
     * @param type
     * @param subType
     * @return
     */
    public static boolean isConnectionFast(int type, int subType) {
        if (type == ConnectivityManager.TYPE_WIFI) {
            return true;
        } else if (type == ConnectivityManager.TYPE_MOBILE) {
            switch (subType) {
                case TelephonyManager.NETWORK_TYPE_1xRTT:
                    return false; // ~ 50-100 kbps
                case TelephonyManager.NETWORK_TYPE_CDMA:
                    return false; // ~ 14-64 kbps
                case TelephonyManager.NETWORK_TYPE_EDGE:
                    return false; // ~ 50-100 kbps
                case TelephonyManager.NETWORK_TYPE_EVDO_0:
                    return true; // ~ 400-1000 kbps
                case TelephonyManager.NETWORK_TYPE_EVDO_A:
                    return true; // ~ 600-1400 kbps
                case TelephonyManager.NETWORK_TYPE_GPRS:
                    return false; // ~ 100 kbps
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                    return true; // ~ 2-14 Mbps
                case TelephonyManager.NETWORK_TYPE_HSPA:
                    return true; // ~ 700-1700 kbps
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                    return true; // ~ 1-23 Mbps
                case TelephonyManager.NETWORK_TYPE_UMTS:
                    return true; // ~ 400-7000 kbps
            /*
             * Above API level 7, make sure to set android:targetSdkVersion
			 * to appropriate level to use these
			 */
                case TelephonyManager.NETWORK_TYPE_EHRPD: // API level 11
                    return true; // ~ 1-2 Mbps
                case TelephonyManager.NETWORK_TYPE_EVDO_B: // API level 9
                    return true; // ~ 5 Mbps
                case TelephonyManager.NETWORK_TYPE_HSPAP: // API level 13
                    return true; // ~ 10-20 Mbps
                case TelephonyManager.NETWORK_TYPE_IDEN: // API level 8
                    return false; // ~25 kbps
                case TelephonyManager.NETWORK_TYPE_LTE: // API level 11
                    return true; // ~ 10+ Mbps
                // Unknown
                case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                default:
                    return false;
            }
        } else {
            return false;
        }
    }

}
