package com.hhdd.kada.main.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

import java.util.HashMap;

/**
 * Created by simon on 18/6/15.
 */
public class PrefsManager {

    SharedPreferences preferences;
    HashMap<String, Object> hashData;

    public PrefsManager(Context context) {
        preferences = context.getSharedPreferences("com.hhdd.kada", Context.MODE_PRIVATE);
        hashData = (HashMap<String, Object>) preferences.getAll();
        if (hashData == null) {
            hashData = new HashMap<String, Object>();
        }
    }

    public synchronized void putBoolean(final String key, final boolean value) {
        if (TextUtils.isEmpty(key) || hashData == null || preferences == null) {
            return;
        }

        hashData.put(key, value);
        preferences.edit().putBoolean(key, value).apply();
    }

    public synchronized void putString(final String key, final String value) {
        if (TextUtils.isEmpty(key) || hashData == null || preferences == null) {
            return;
        }

        hashData.put(key, value);
        preferences.edit().putString(key, value).apply();
    }

    public synchronized void putInt(final String key, final int value) {
        if (TextUtils.isEmpty(key) || hashData == null || preferences == null) {
            return;
        }

        hashData.put(key, value);
        preferences.edit().putInt(key, value).apply();
    }

    public synchronized void putLong(final String key, final long value) {
        if (TextUtils.isEmpty(key) || hashData == null || preferences == null) {
            return;
        }

        hashData.put(key, value);
        preferences.edit().putLong(key, value).apply();
    }

    public long getLong(String key) {
        return getLong(key, 0);
    }

    public synchronized long getLong(String key, long defaultValue) {
        if (TextUtils.isEmpty(key) || hashData == null) {
            return defaultValue;
        }

        Object o = hashData.get(key);
        if (o != null && o instanceof Long) {
            return (Long) o;
        }
        return defaultValue;
    }

    public int getInt(String key) {
        return getInt(key, 0);
    }

    public synchronized int getInt(String key, int defaultValue) {
        if (TextUtils.isEmpty(key) || hashData == null) {
            return defaultValue;
        }

        Object o = hashData.get(key);
        if (o != null && o instanceof Integer) {
            return (Integer) o;
        }
        return defaultValue;
    }

    public String getString(String key) {
        return getString(key, "");
    }

    public synchronized String getString(String key, String defaultValue) {
        if (TextUtils.isEmpty(key) || hashData == null) {
            return defaultValue;
        }

        Object o = hashData.get(key);
        if (o != null && o instanceof String) {
            return (String) o;
        }
        return defaultValue;
    }

    public boolean getBoolean(String key) {
        return getBoolean(key, false);
    }

    public synchronized boolean getBoolean(String key, boolean defaultValue) {
        if (TextUtils.isEmpty(key) || hashData == null) {
            return defaultValue;
        }

        Object o = hashData.get(key);
        if (o != null && o instanceof Boolean) {
            return (Boolean) o;
        }
        return defaultValue;
    }

}
