package com.hhdd.kada.main.utils;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;

import com.hhdd.logger.LogHelper;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

/**
 * Created by simon on 30/6/15.
 */
public class CameraUtils {

    /**
     * 请求相机.
     */
    public static final int REQUEST_IMAGE_CAPTURE = 10000;

    /**
     * 请求相册.
     */
    public static final int REQUEST_PHOTO_LIBRARY = 10001;

    /**
     * 请求相册.
     */
    public static final int REQUEST_PHOTO_KITKAT = 10002;

    /**
     * 请求图片剪裁
     */
    public static final int REQUEST_CODE_IMAGE_CROP = 10003;

    public static void openPhotoLibrary(Activity activity) {
        openPhotoLibrary(activity, REQUEST_PHOTO_LIBRARY);
    }

    public static void openPhotoLibrary(Activity activity, int requestCode) {
        try {
            Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            intent.setType("image/*");
            intent.putExtra("return-data", false);
//            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);//ACTION_OPEN_DOCUMENT
//            intent.addCategory(Intent.CATEGORY_OPENABLE);
//            intent.setType("image/*");
//			if(android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.KITKAT){
//				activity.startActivityForResult(intent, REQUEST_PHOTO_KITKAT);
//			}else{
            activity.startActivityForResult(intent, requestCode);
//			}

        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }

    public static Uri showCamera(Activity activity, String mImageDir) {
        File dir = new File(mImageDir);
        if (!dir.exists()) {
            dir.mkdir();
        }
        FileUtils.deleteFolderFile(mImageDir, false);
        File imageFile = createFile(dir);
        return openCapture(activity, imageFile);
    }

    public static String showCamera2(Activity activity, String mImageDir) {
        File dir = new File(mImageDir);
        if (!dir.exists()) {
            dir.mkdir();
        }
        FileUtils.deleteFolderFile(mImageDir, false);
        File imageFile = createFile(dir);
        openCapture(activity, imageFile);
        if (imageFile != null) {
            return imageFile.getAbsolutePath();
        }
        return null;
    }

    static File createFile(File dir) {
        File image = null;
        try {
            image = File.createTempFile(
                    UUID.randomUUID().toString(),  /* 前缀 */
                    ".jpg",         /* 后缀 */
                    dir      /* 文件夹 */
            );
        } catch (IOException e) {
            LogHelper.printStackTrace(e);
        }
        return image;
    }

    public static Uri openCapture(Activity activity, File photoFile) {
        //FileProvider 是一个特殊的 ContentProvider 的子类，
        //它使用 content:// Uri 代替了 file:/// Uri. ，更便利而且安全的为另一个app分享文件

        if (activity == null || activity.isFinishing()) {
            return null;
        }

        if (photoFile == null) {
            return null;
        }

        Uri photoURI = getUriForFile(activity, photoFile);

        if (photoURI == null) {
            return null;
        }

        openCapture(activity, REQUEST_IMAGE_CAPTURE, photoURI);

        return photoURI;
    }

    public static void openCapture(Activity activity, int requestCode, Uri mImageUri) {
//        Uri mImageUri = null;
        try {
//                File mImageFile = FileUtils.newTempImageFile();
//                mImageUri = Uri.fromFile(mImageFile);
//                ContentValues values = new ContentValues();
//                values.put(MediaStore.Images.Media.TITLE, mImageFile.getAbsolutePath());
//                mImageUri = activity.getContentResolver().insert(
//                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);

//                Log.d("mImageFile", mImageFile.getAbsolutePath());
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, mImageUri);
            activity.startActivityForResult(intent, requestCode);
//            return mImageUri;
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
//        return mImageUri;
    }

    public static Uri startCropImageActivityForPicture(Activity context, Uri uri) {
        if (context == null || context.isFinishing()) {
            return null;
        }

        if (uri == null) {
            return null;
        }

        Uri outputUri = getUriForFile(context, FileUtils.newTempImageFile());
        if (outputUri == null) {
            return null;
        }

        startCropImageActivityForResult(context, uri, outputUri, 400, 400, REQUEST_CODE_IMAGE_CROP);

        return outputUri;
    }

    public static void startCropImageActivityForCamera(Activity context, Uri uri, Uri outUri) {
        startCropImageActivityForResult(context, uri, outUri, 400, 400, REQUEST_CODE_IMAGE_CROP);
    }

    public static void startCropImageActivityForResult(Activity context, Uri uri, Uri outUri, int outputX, int outputY, int requestCode) {
        if (context == null || context.isFinishing()) {
            return;
        }

        if (uri == null || outUri == null) {
            return;
        }

        try {
            Intent intent = new Intent("com.hhdd.android.camera.action.CROP");
//            Intent intent = new Intent("com.android.camera.action.CROP");
//            Intent intent = new Intent(context, CropImage.class);

            // java.lang.SecurityException: UID 10113 does not have permission to content://com.google.android.apps.photos.contentprovider/-1/1/content%3A%2F%2Fmedia%2Fexternal%2Fimages%2Fmedia%2F3442/ORIGINAL/NONE/1581216172 [user 0]
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !uri.toString().startsWith("content://com.hhdd.kada.fileprovider")) {
                intent.putExtra("uriString", uri.toString());
                intent.setType("image/*");
            } else {
                intent.setDataAndType(uri, "image/*");
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            }

            intent.putExtra("crop", "true");
            intent.putExtra("aspectX", 1);
            intent.putExtra("aspectY", 1);
            intent.putExtra("outputX", outputX);
            intent.putExtra("outputY", outputY);
            intent.putExtra("scale", true);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, outUri);

            intent.putExtra("outputFormat", Bitmap.CompressFormat.JPEG.toString());
            intent.putExtra("noFaceDetection", true); // no face detection
            intent.putExtra("return-data", false);
            context.startActivityForResult(intent, requestCode);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public static String getPath(final Context context, final Uri uri) {

        final boolean isKitKat = Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;

        // DocumentProvider
        if (isKitKat && DocumentsContract.isDocumentUri(context, uri)) {
            // ExternalStorageProvider
            if (isExternalStorageDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                if ("primary".equalsIgnoreCase(type)) {
                    return Environment.getExternalStorageDirectory() + "/" + split[1];
                }

                // TODO handle non-primary volumes
            }
            // DownloadsProvider
            else if (isDownloadsDocument(uri)) {

                final String id = DocumentsContract.getDocumentId(uri);
                final Uri contentUri = ContentUris.withAppendedId(
                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));

                return getDataColumn(context, contentUri, null, null);
            }
            // MediaProvider
            else if (isMediaDocument(uri)) {
                final String docId = DocumentsContract.getDocumentId(uri);
                final String[] split = docId.split(":");
                final String type = split[0];

                Uri contentUri = null;
                if ("image".equals(type)) {
                    contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                } else if ("video".equals(type)) {
                    contentUri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                } else if ("audio".equals(type)) {
                    contentUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                }

                final String selection = "_id=?";
                final String[] selectionArgs = new String[]{
                        split[1]
                };

                return getDataColumn(context, contentUri, selection, selectionArgs);
            }
        }
        // MediaStore (and general)
        else if ("content".equalsIgnoreCase(uri.getScheme())) {

            // Return the remote address
            if (isGooglePhotosUri(uri))
                return uri.getLastPathSegment();

            return getDataColumn(context, uri, null, null);
        }
        // File
        else if ("file".equalsIgnoreCase(uri.getScheme())) {
            return uri.getPath();
        }

        return null;
    }

    /**
     * Get the value of the data column for this Uri. This is useful for
     * MediaStore Uris, and other file-based ContentProviders.
     *
     * @param context       The context.
     * @param uri           The Uri to query.
     * @param selection     (Optional) Filter used in the query.
     * @param selectionArgs (Optional) Selection arguments used in the query.
     * @return The value of the _data column, which is typically a file path.
     */
    public static String getDataColumn(Context context, Uri uri, String selection,
                                       String[] selectionArgs) {

        Cursor cursor = null;
        final String column = "_data";
        final String[] projection = {
                column
        };

        try {
            cursor = context.getContentResolver().query(uri, projection, selection, selectionArgs,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                final int index = cursor.getColumnIndexOrThrow(column);
                return cursor.getString(index);
            }
        } finally {
            if (cursor != null)
                cursor.close();
        }
        return null;
    }


    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is ExternalStorageProvider.
     */
    public static boolean isExternalStorageDocument(Uri uri) {
        return "com.android.externalstorage.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is DownloadsProvider.
     */
    public static boolean isDownloadsDocument(Uri uri) {
        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is MediaProvider.
     */
    public static boolean isMediaDocument(Uri uri) {
        return "com.android.providers.media.documents".equals(uri.getAuthority());
    }

    /**
     * @param uri The Uri to check.
     * @return Whether the Uri authority is Google Photos.
     */
    public static boolean isGooglePhotosUri(Uri uri) {
        return "com.google.android.apps.photos.content".equals(uri.getAuthority());
    }

    public static String selectImage(Context context, Intent data) {
        Uri selectedImage = data.getData();
//      Log.e(TAG, selectedImage.toString());
        if (selectedImage != null) {
            String uriStr = selectedImage.toString();
            String path = uriStr.substring(10, uriStr.length());
            if (path.startsWith("com.sec.android.gallery3d")) {
                return null;
            }
        }
        String[] filePathColumn = {MediaStore.Images.Media.DATA};
        Cursor cursor = context.getContentResolver().query(selectedImage, filePathColumn, null, null, null);
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        String picturePath = cursor.getString(columnIndex);
        cursor.close();
        return picturePath;
    }

    public static Uri getUriForFile(Context context, File file) {
        if (context == null || file == null) {
            return null;
        }

        Uri uri;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            uri = FileProvider.getUriForFile(context, "com.hhdd.kada.fileprovider", file);
        } else {
            uri = Uri.fromFile(file);
        }

        return uri;
    }

}
