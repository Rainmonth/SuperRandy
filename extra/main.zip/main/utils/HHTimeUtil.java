package com.hhdd.kada.main.utils;

import android.text.TextUtils;

import com.hhdd.logger.LogHelper;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import static java.lang.System.currentTimeMillis;

/**
 * Created by yangyang on 15/5/18.
 */
public class HHTimeUtil {
    private final static long DAY_TIMES = 24 * 60 * 60 * 1000;
    private final static String WEB_DATE_FORMAT = "yyyy-MM-dd";
    public static final TimeZone targetTimeZone = TimeZone.getTimeZone("GMT+8"); //设置为东八区

    protected static String currentDate(String formatString) {
        DateFormat format = new SimpleDateFormat(formatString);
        format.setTimeZone(targetTimeZone);
        Date date = new Date(currentTimeMillis());
        return format.format(date);
    }

    public static Long currentDateLong() {
        String date = currentDate("yyyyMMdd");
        return Integer.valueOf(date).longValue();
    }

    public static Long beforeCurrentDateLong(long days) {
        DateFormat format = new SimpleDateFormat("yyyyMMdd");
        format.setTimeZone(targetTimeZone);
        long cur = currentTimeMillis() - (days * 24 * 3600 * 1000);
        Date date = new Date(cur);
        return Integer.valueOf(format.format(date)).longValue();
    }

    public static String currentMonthDay() {
        return currentDate("MM-dd");
    }

    public static String currentDate() {
        return currentDate("yyyy-MM-dd");
    }

    public static String currentDateSecond() {
        return currentDate("yyyy-MM-dd HH:mm:ss");
    }

    public static String currentDateMilli() {
        return currentDate("yyyy-MM-dd hh:mm:ss:SSS");
    }

    public static long currentMilliTime() {
        return currentTimeMillis();
    }

    public static String dateFromMilliTime(long milliTime) {
        Date date = new Date();
        date.setTime(milliTime);
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setTimeZone(TimeZone.getTimeZone(String.valueOf(targetTimeZone)));
        return dateFormat.format(date);
    }

    public static long milliTimeFromDate(String dateString) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
            Date date = dateFormat.parse(dateString);
            return date.getTime();
        } catch (ParseException e) {
            LogHelper.printStackTrace(e);
        }
        return 0;
    }

    public static long milliTimeFromDate2(String dateString) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+08:00"));
            Date date = dateFormat.parse(dateString);
            return date.getTime();
        } catch (ParseException e) {
            LogHelper.printStackTrace(e);
        }
        return 0;
    }

    public static String formatTime(long time) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        String date = format.format(time);
        return date;// 2012年10月03日 23:41:31
    }


    public static String formatLongTime(long time) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date = format.format(time);
        return date;// 2012年10月03日 23:41:31
    }

    public static String getDateEN() {
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String date1 = format1.format(new Date(currentTimeMillis()));
        return date1;// 2012-10-03 23:41:31
    }

    public static int getCurrentYear() {
        String[] tmpStr = getDateEN().split("-");
        return Integer.valueOf(tmpStr[0]);
    }

    public static int getYear(String date) {
        String[] arg = date.split("-");
        return Integer.parseInt(arg[0]);
    }

    public static int getMonth(String date) {
        String[] arg = date.split("-");
        return Integer.parseInt(arg[1]);
    }

    public static int getDay(String date) {
        String[] arg = date.split("-");
        return Integer.parseInt(arg[2]);
    }

    public static String getCommentData(String time) {
        long nowTime = System.currentTimeMillis();
        try {
            long commentTime = Long.parseLong(time);
            commentTime = commentTime * 1000;
            long interval = nowTime - commentTime;
            if (interval > 24 * 60 * 60 * 1000) {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
                return format.format(new Date(commentTime));
            } else if (interval <= 60 * 60 * 1000) {
                return "1小时前";
            } else {
                int hours = Math.round(interval / (60 * 60 * 1000f));
                return hours + "小时前";
            }
        } catch (Exception e) {
            return "";
        }
    }

    //是否是今天
    public static boolean isToday(long time) {
        long nowTime = System.currentTimeMillis();
        return TextUtils.equals(formatTime(nowTime).trim(), formatTime(time).trim());
    }

    /**
     * 判断date是否在指定范围内
     *
     * @param date
     * @param beginDate
     * @param endDate
     * @return
     */
    public static boolean isInRange(String date, String beginDate, String endDate) {
        long begin = milliTimeFromDate2(beginDate);
        long end = milliTimeFromDate2(endDate);
        long current = milliTimeFromDate2(date);
        if (current <= end && current >= begin) {
            return true;
        }
        return false;
    }


    public static String getBillData(long time) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String timeStr = format.format(new Date(time));


        Calendar current = Calendar.getInstance();

        Calendar today = Calendar.getInstance();    //今天

        today.set(Calendar.YEAR, current.get(Calendar.YEAR));
        today.set(Calendar.MONTH, current.get(Calendar.MONTH));
        today.set(Calendar.DAY_OF_MONTH, current.get(Calendar.DAY_OF_MONTH));
        //  Calendar.HOUR——12小时制的小时数 Calendar.HOUR_OF_DAY——24小时制的小时数
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);

        Calendar yesterday = Calendar.getInstance();    //昨天

        yesterday.set(Calendar.YEAR, current.get(Calendar.YEAR));
        yesterday.set(Calendar.MONTH, current.get(Calendar.MONTH));
        yesterday.set(Calendar.DAY_OF_MONTH, current.get(Calendar.DAY_OF_MONTH) - 1);
        yesterday.set(Calendar.HOUR_OF_DAY, 0);
        yesterday.set(Calendar.MINUTE, 0);
        yesterday.set(Calendar.SECOND, 0);

        Calendar tomorrow = Calendar.getInstance();    //明天

        tomorrow.set(Calendar.YEAR, current.get(Calendar.YEAR));
        tomorrow.set(Calendar.MONTH, current.get(Calendar.MONTH));
        tomorrow.set(Calendar.DAY_OF_MONTH, current.get(Calendar.DAY_OF_MONTH) + 1);
        tomorrow.set(Calendar.HOUR_OF_DAY, 0);
        tomorrow.set(Calendar.MINUTE, 0);
        tomorrow.set(Calendar.SECOND, 0);

        current.setTime(new Date(time));

        if (current.after(today) && current.before(tomorrow)) {
            return "今天 " + timeStr.split(" ")[1];
        } else if (current.before(today) && current.after(yesterday)) {
            return "昨天 " + timeStr.split(" ")[1];
        } else {
            String[] split = timeStr.split(" ");
            return split[0];
        }
    }

    /**
     * 根据年月日获取yyyy-MM-dd格式生日
     *
     * @param year
     * @param month
     * @param day
     * @return
     */
    public static String getFormatDate(int year, int month, int day) {
        StringBuilder sb = new StringBuilder();
        sb.append(year).append("-");
        if (month < 10) {
            sb.append("0");
        }
        sb.append(month).append("-");
        if (day < 10) {
            sb.append("0");
        }
        sb.append(day);
        return sb.toString();
    }

    /**
     * 获取两个时间差多少天
     *
     * @param date1
     * @param date2
     * @return
     */
    public static long getDifferentDays(Date date1, Date date2) {
        if (null == date1 || null == date2)
            throw new RuntimeException("参数异常");

        long time1 = date1.getTime();
        long time2 = date2.getTime();

        long difTime = time1 - time2;
        return (difTime / DAY_TIMES);
    }

    /**
     * 解析yyyy-MM-dd
     *
     * @param date
     * @return
     * @throws ParseException
     */
    public static Date parseWebDate(String date) throws ParseException {
        if (TextUtils.isEmpty(date) || date.length() != 10)
            throw new RuntimeException("time format error");
        return parseDate(date, WEB_DATE_FORMAT);
    }

    /**
     * string to date for format
     *
     * @param date
     * @param format
     * @return
     */
    public static Date parseDate(String date, String format) throws ParseException {
        if (TextUtils.isEmpty(date) || TextUtils.isEmpty(format))
            return null;
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.parse(date);
    }

    /**
     * date to string for yyyy-MM-dd
     * @return
     */
    public static String getNowWebDate(){
        return getDate(new Date(), WEB_DATE_FORMAT);
    }

    /**
     * date to string for format
     * @param date
     * @param format
     * @return
     */
    public static String getDate(Date date, String format){
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(date);
    }

}
