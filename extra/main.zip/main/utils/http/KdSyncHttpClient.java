package com.hhdd.kada.main.utils.http;

import android.content.Context;

import com.hhdd.kada.main.utils.http.tsccm.KdThreadSafeClientConnManager;
import com.loopj.android.http.AsyncHttpRequest;
import com.loopj.android.http.ResponseHandlerInterface;
import com.loopj.android.http.SyncHttpClient;

import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.protocol.HttpContext;

/**
 * Created by bjx on 2018/8/6.
 */

public class KdSyncHttpClient extends SyncHttpClient {

    private KdHttpRequestHeaderProcessor mHeaderProcessor;

    public KdSyncHttpClient() {
        super();
    }

    public KdSyncHttpClient(int httpPort) {
        super(httpPort);
    }

    public KdSyncHttpClient(int httpPort, int httpsPort) {
        super(httpPort, httpsPort);
    }

    public KdSyncHttpClient(boolean fixNoHttpResponseException, int httpPort, int httpsPort) {
        super(fixNoHttpResponseException, httpPort, httpsPort);
    }

    public KdSyncHttpClient(SchemeRegistry schemeRegistry) {
        super(schemeRegistry);
    }

    public void setHeaderProcessor(KdHttpRequestHeaderProcessor headerProcessor) {
        mHeaderProcessor = headerProcessor;
    }

    @Override
    protected ClientConnectionManager createConnectionManager(SchemeRegistry schemeRegistry, BasicHttpParams httpParams) {
        return new KdThreadSafeClientConnManager(httpParams, schemeRegistry);
    }

    @Override
    protected AsyncHttpRequest newAsyncHttpRequest(DefaultHttpClient client, HttpContext httpContext, HttpUriRequest uriRequest, String contentType, ResponseHandlerInterface responseHandler, Context context) {

        KdAsyncHttpRequest request = new KdAsyncHttpRequest(client, httpContext, uriRequest, responseHandler);
        request.setHeaderProcessor(mHeaderProcessor);

        return request;
    }
}
