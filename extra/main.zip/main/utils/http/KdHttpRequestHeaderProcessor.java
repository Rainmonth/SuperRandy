package com.hhdd.kada.main.utils.http;

import com.loopj.android.http.AsyncHttpRequest;

import org.apache.http.client.methods.HttpUriRequest;

import java.util.Map;

/**
 * Created by bjx on 2018/8/16.
 */

public interface KdHttpRequestHeaderProcessor {

    Map<String, String> getHttpRequestHeader(AsyncHttpRequest httpRequest, HttpUriRequest uriRequest);
}
