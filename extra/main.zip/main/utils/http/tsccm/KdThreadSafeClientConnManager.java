package com.hhdd.kada.main.utils.http.tsccm;

import com.hhdd.logger.LogHelper;

import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;

/**
 * Created by bjx on 2018/8/6.
 */
public class KdThreadSafeClientConnManager extends ThreadSafeClientConnManager {

    public KdThreadSafeClientConnManager(HttpParams params, SchemeRegistry schreg) {
        super(params, schreg);
    }

    @Override
    protected void finalize() throws Throwable {

        try {
            // https://bugly.qq.com/v2/crash-reporting/crashes/3c90f7f868/1612?pid=1
            // 线上统计有些设备上这个方法会偶现异常：java.util.concurrent.TimeoutException（org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager.finalize() timed out after 120 seconds）
            // 这里做catch捕捉，防止崩溃
            super.finalize();
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }
}
