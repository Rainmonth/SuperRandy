package com.hhdd.kada.main.utils.http;

import com.loopj.android.http.AsyncHttpRequest;
import com.loopj.android.http.ResponseHandlerInterface;

import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.AbstractHttpClient;
import org.apache.http.protocol.HttpContext;

import java.util.Map;

/**
 * Created by bjx on 2018/8/16.
 */

public class KdAsyncHttpRequest extends AsyncHttpRequest {

    private HttpUriRequest mHttpUriRequest;

    private KdHttpRequestHeaderProcessor mHeaderProcessor;

    public KdAsyncHttpRequest(AbstractHttpClient client, HttpContext context, HttpUriRequest request, ResponseHandlerInterface responseHandler) {
        super(client, context, request, responseHandler);

        mHttpUriRequest = request;
    }

    public void setHeaderProcessor(KdHttpRequestHeaderProcessor headerProcessor) {
        mHeaderProcessor = headerProcessor;
    }

    @Override
    public void onPreProcessRequest(AsyncHttpRequest request) {
        super.onPreProcessRequest(request);

        if (mHeaderProcessor == null || mHttpUriRequest == null) {
            return;
        }

        Map<String, String> headers = mHeaderProcessor.getHttpRequestHeader(request, mHttpUriRequest);
        if (headers == null || headers.isEmpty()) {
            return;
        }

        for (String header : headers.keySet()) {
            if (mHttpUriRequest.containsHeader(header)) {
                mHttpUriRequest.removeHeaders(header);
            }
            mHttpUriRequest.addHeader(header, headers.get(header));
        }
    }

    @Override
    public void onPostProcessRequest(AsyncHttpRequest request) {
        super.onPostProcessRequest(request);
    }


}
