package com.hhdd.kada.main.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by yangyang on 15/6/17.
 */
public class StringUtil {

    private static Pattern NUMBER_PATTERN = Pattern.compile("[0-9]*");
    private static Pattern IP_PATTERN = Pattern.compile("((25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))\\.){3}(25[0-5]|2[0-4]\\d|((1\\d{2})|([1-9]?\\d)))");

    public static boolean isNull(String str) {
        boolean isNull = false;
        if (str == null || str.toLowerCase().equals("null")) {
            isNull = true;
        }
        return isNull;
    }

    public static boolean isEmpty(String str) {
        boolean isEmpty = false;
        if (str == null || "".equals(str)) {
            isEmpty = true;
        }
        return isEmpty;
    }

    public static boolean isNumeric(String str) {
        Matcher matcher = NUMBER_PATTERN.matcher(str);
        return matcher.matches();
    }

    public static boolean isIp(String str) {
        if (isEmpty(str)) {
            return false;
        }

        Matcher matcher = IP_PATTERN.matcher(str);
        return matcher.matches();
    }

    public static String formatClickCount(int clickCount){
        if(clickCount > 10000){
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Math.round(clickCount/1000d)/10.0f);
            stringBuilder.append("万");
            return stringBuilder.toString();
        }else if(clickCount < 1000){
            return "<1000";
        }else{
            return String.valueOf(clickCount);
        }
    }
    public static String subformatClickCount(int clickCount){
        if(clickCount > 10000){
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(Math.round(clickCount/1000d)/10.0f);
            stringBuilder.append("万");
            return stringBuilder.toString();
        }else if(clickCount < 100){
            return "<100";
        }else{
            return String.valueOf(clickCount);
        }
    }


}
