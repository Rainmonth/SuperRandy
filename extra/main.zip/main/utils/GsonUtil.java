package com.hhdd.kada.main.utils;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.hhdd.logger.LogHelper;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by simon on 10/01/2017.
 */

public class GsonUtil {

    public static Object getInstanceByJson(Class<?> clazz, String json) {
        try {
            if (json!=null&&json.length()>0) {
                Object obj = null;
                Gson gson = new Gson();
                obj = gson.fromJson(json, clazz);
                return obj;
            }
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
        return null;
    }

    public static <T> List<T> jsonToList(String json, Class<T[]> clazz) {
        try {
            if (json!=null&&json.length()>0) {
                Gson gson = new Gson();
                T[] array = gson.fromJson(json, clazz);
                return Arrays.asList(array);
            }
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
        return null;
    }

    public static <T> ArrayList<T> jsonToArrayList(String json, Class<T> clazz)  {
        try {
            if (json!=null&&json.length()>0) {
                Type type = new TypeToken<ArrayList<JsonObject>>(){}.getType();
                ArrayList<JsonObject> jsonObjects = new Gson().fromJson(json, type);
                ArrayList<T> arrayList = new ArrayList<>();
                for (JsonObject jsonObject : jsonObjects) {
                    arrayList.add(new Gson().fromJson(jsonObject, clazz));
                }
                return arrayList;
            }
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
        return null;
    }
}
