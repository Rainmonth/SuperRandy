package com.hhdd.kada.main.utils;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.settings.UserSettings;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sxh on 2018/8/8.
 */
public class LocalSubscribeUtil {

    private static List<Integer> bookSubscribeIdList;
    private static List<Integer> storySubscribeIdList;
    private static Gson gson = new Gson();
    private static boolean isInitialized = false;    //是否初始化过

    public static void initialize() {
        if (isInitialized){
            return;
        }
        String bookSubscribedCollectionIds = UserSettings.getInstance().getBookSubscribedCollectionIds();
        if (!TextUtils.isEmpty(bookSubscribedCollectionIds)) {
            bookSubscribeIdList = new ArrayList<>();
            bookSubscribeIdList = gson.fromJson(bookSubscribedCollectionIds, new TypeToken<List<Integer>>() {
            }.getType());
        } else {
            bookSubscribeIdList = null;
        }

        String storySubscribedCollectionIds = UserSettings.getInstance().getStorySubscribedCollectionIds();
        if (!TextUtils.isEmpty(storySubscribedCollectionIds)) {
            storySubscribeIdList = new ArrayList<>();
            storySubscribeIdList = gson.fromJson(storySubscribedCollectionIds, new TypeToken<List<Integer>>() {
            }.getType());
        } else {
            storySubscribeIdList = null;
        }
        isInitialized = true;
    }

    public static void addBookSubscribeId(Integer collectId) {
        initialize();
        if (bookSubscribeIdList == null) {
            bookSubscribeIdList = new ArrayList<>();
        }
        if (!bookSubscribeIdList.contains(collectId)) {
            bookSubscribeIdList.add(collectId);
            UserSettings.getInstance().setBookSubscribedCollectionIds(gson.toJson(bookSubscribeIdList));
            EventCenter.fireEvent(new UserSettings.SubscribedCollectionIdChangedEvent(1));
        }
    }

    public static void removeBookSubscribeId(Integer collectId) {
        initialize();
        if (bookSubscribeIdList == null) {
            return;
        }
        if (bookSubscribeIdList.contains(collectId)) {
            bookSubscribeIdList.remove(collectId);
            UserSettings.getInstance().setBookSubscribedCollectionIds(gson.toJson(bookSubscribeIdList));
            EventCenter.fireEvent(new UserSettings.SubscribedCollectionIdChangedEvent(1));
        }
    }

    public static boolean containBookSubscribeId(Integer collectId) {
        initialize();
        return bookSubscribeIdList != null && bookSubscribeIdList.contains(collectId);
    }

    public static void addStorySubscribeId(Integer collectId) {
        initialize();
        if (storySubscribeIdList == null) {
            storySubscribeIdList = new ArrayList<>();
        }
        if (!storySubscribeIdList.contains(collectId)) {
            storySubscribeIdList.add(collectId);
            UserSettings.getInstance().setStorySubscribedCollectionIds(gson.toJson(storySubscribeIdList));
            EventCenter.fireEvent(new UserSettings.SubscribedCollectionIdChangedEvent(2));
        }
    }

    public static void removeStorySubscribeId(Integer collectId) {
        initialize();
        if (storySubscribeIdList == null) {
            return;
        }
        if (storySubscribeIdList.contains(collectId)) {
            storySubscribeIdList.remove(collectId);
            UserSettings.getInstance().setStorySubscribedCollectionIds(gson.toJson(storySubscribeIdList));
            EventCenter.fireEvent(new UserSettings.SubscribedCollectionIdChangedEvent(2));
        }
    }

    public static boolean containStorySubscribeId(Integer collectId) {
        initialize();
        return storySubscribeIdList != null && storySubscribeIdList.contains(collectId);
    }

    public static void recycle() {
        if (bookSubscribeIdList != null) {
            bookSubscribeIdList = null;
            isInitialized = false;
        }
        if (storySubscribeIdList != null) {
            storySubscribeIdList = null;
            isInitialized = false;
        }
    }

}
