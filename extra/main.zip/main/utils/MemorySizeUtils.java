package com.hhdd.kada.main.utils;

import android.os.Environment;
import android.os.StatFs;

import java.io.File;

/**
 * Created by sxh on 2017/6/22.
 */

public class MemorySizeUtils {


    /**
     * 以kb为单位得到内存
     * @return
     */
    public static long getAvailableMemoryByKb(){
        return getAvailableMemorySize()/1024;
    }


    /**
     * 以Mb为单位得到内存
     * @return
     */
    public static long getAvailableMemoryByMb(){
        return getAvailableMemoryByKb()/1024;
    }

    /**
     * 以GB为单位得到内存
     * @return
     */
    public static long getAvailableMemoryByGB(){
        return getAvailableMemoryByMb()/1024;
    }

    /**
     * @return isExit SDCard
     */
    public static boolean externalMemoryAvailable() {
        return android.os.Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED);
    }

    /**
     * @return Available of CacheDirectory
     */
    public static long getAvailableMemorySize() {
        if (externalMemoryAvailable())
            return getAvailableExternalMemorySize();
        else
            return getAvailableInternalMemorySize();
    }

    /**
     * @return Available Internal
     */
    public static long getAvailableInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return availableBlocks * blockSize;
    }

    /**
     * @return Available External
     */
    public static long getAvailableExternalMemorySize() {
        File path = Environment.getExternalStorageDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long availableBlocks = stat.getAvailableBlocks();
        return availableBlocks * blockSize;
    }
}
