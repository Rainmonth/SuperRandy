package com.hhdd.kada.main.utils;

import android.text.TextUtils;

import com.hhdd.logger.LogHelper;

import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Created by yangyang on 15/6/15.
 */
public class TimeUtil {

    /**
     * @param seconds 格式 xx.xxx
     * @return
     */
    public static int seconds2Milli(String seconds) {
        if (StringUtil.isEmpty(seconds)) {
            return 0;
        }

        int milliTime = 0;

        String[] splitSeconds = seconds.split("[.]");

        if (splitSeconds.length == 1) {
            if (!TextUtils.isEmpty(splitSeconds[0]) && StringUtil.isNumeric(splitSeconds[0])) {
                milliTime = Integer.valueOf(splitSeconds[0]).intValue() * 1000;
            }
        } else if (splitSeconds.length == 2) {
            String sec = splitSeconds[0];
            String milli = splitSeconds[1];

            if (!TextUtils.isEmpty(sec) && StringUtil.isNumeric(sec) && !TextUtils.isEmpty(milli) && StringUtil.isNumeric(milli)) {
                if (milli.length() > 3) {
                    milliTime = Integer.valueOf(sec).intValue() * 1000 + Integer.valueOf(milli.substring(0, 3)).intValue();
                } else {
                    milliTime = Integer.valueOf(sec).intValue() * 1000 + Integer.valueOf(milli).intValue();
                }
            }
        }

        return milliTime;
    }

    public static int audioMilliTime(String audioTime) {
        if (audioTime == null || TextUtils.isEmpty(audioTime) || StringUtil.isNull(audioTime)) {
            return 0;
        }

        int milliTime = 0;
        String[] splitTime = audioTime.split("[:]");
        int count = splitTime.length;
        if (count == 1) {
            String seconds = splitTime[0];

            milliTime = seconds2Milli(seconds);

        } else if (count == 2) {
            String seconds = splitTime[1];
            String min = splitTime[0];

            milliTime = seconds2Milli(seconds);

            if (!TextUtils.isEmpty(min) && StringUtil.isNumeric(min)) {
                milliTime += Integer.valueOf(min).intValue() * 60 * 1000;
            }
        } else if (count == 3) {
            String seconds = splitTime[2];
            String min = splitTime[1];
            String hours = splitTime[0];

            milliTime = seconds2Milli(seconds);

            if (!TextUtils.isEmpty(min) && StringUtil.isNumeric(min)) {
                milliTime += Integer.valueOf(min).intValue() * 60 * 1000;
            }

            if (!TextUtils.isEmpty(hours) && StringUtil.isNumeric(hours)) {
                milliTime += Integer.valueOf(hours).intValue() * 60 * 60 * 1000;
            }
        }

        return milliTime;
    }

    public static String audioMilliTime(long time) {
        StringBuilder sb = new StringBuilder();
        time = time / 1000;
        int s = (int) (time % 60);
        int m = (int) (time / 60 % 60);
        int h = (int) (time / 3600);
        sb.append(h);
        sb.append(":");
        sb.append(m);
        sb.append(":");
        sb.append(s);
        return sb.toString();
    }

    private static final TimeZone targetTimeZone = TimeZone.getTimeZone("GMT+8"); //设置为东八区

    private static DateFormat dfHHmmss = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");   //构造格式化模板

    public static String currentTime() {
        TimeZone.setDefault(targetTimeZone);                                // 设置时区
        Calendar calendar = Calendar.getInstance();                         // 获取实例
        Date date = calendar.getTime();                                     //获取Date对象
        String str = dfHHmmss.format(date);                                         //对象进行格式化，获取字符串格式的输出

        return str;
    }

    private static DateFormat dfHHmmssSSS = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");   //构造格式化模板

    public static String currentMiliTime() {
        TimeZone.setDefault(targetTimeZone);                                // 设置时区
        Calendar calendar = Calendar.getInstance();                         // 获取实例
        Date date = calendar.getTime();                                     //获取Date对象
        String str = dfHHmmssSSS.format(date);                                         //对象进行格式化，获取字符串格式的输出

        return str;
    }

    private static DateFormat dfDD = new SimpleDateFormat("dd");   //构造格式化模板

    public static String currentDate() {
        TimeZone.setDefault(targetTimeZone);                                // 设置时区
        Calendar calendar = Calendar.getInstance();                         // 获取实例
        Date date = calendar.getTime();                                     //获取Date对象
        String str = dfDD.format(date);                                         //对象进行格式化，获取字符串格式的输出

        return str;
    }

    public static String formatLongToTimeStr(Long l) {
        int hour = 0;
        int minute = 0;
        int second = 0;

        second = (int) (l / 1000.0f);

        if (second >= 60) {
            minute = (int) (second / 60.0f);
            second = second % 60;
        }
        if (minute >= 60) {
            hour = (int) (minute / 60.0f);
            minute = minute % 60;
        }
        if (hour == 0) {
            return getTwoLength(minute) + ":" + getTwoLength(second);
        }
        return (getTwoLength(hour) + ":" + getTwoLength(minute) + ":" + getTwoLength(second));
    }

    public static String getAudioTime(int second) {
        int hour = 0;
        int minute = 0;
        int sec = 0;
        hour = (int) (second / 3600.0f);
        minute = (int) (second / 60.0f);
        sec = second % 60;
//        if (hour == 0) {
//            return getTwoLength(minute) + ":" + getTwoLength(sec);
//        }
        return (getTwoLength(hour) + ":" + getTwoLength(minute) + ":" + getTwoLength(sec));
    }

    public static String formatReadTime(Long l) {
        int hour = 0;
        int minute = 0;
        long second = 0;

        second = l;

        if (second > 60) {
            minute = (int) (second / 60.0f);
            second = second % 60;
        }
        if (minute > 60) {
            hour = (int) (minute / 60.0f);
            minute = minute % 60;
        }
        return (getTwoLength(hour) + ":" + getTwoLength(minute) + ":" + getTwoLength(second));
    }

    public static String formatListenTime(Long l) {
        int hour = 0;
        int minute = 0;
        long second = 0;

        second = l;

        if (second > 60) {
            minute = (int) (second / 60.0f);
            second = second % 60;
        }
        if (minute > 60) {
            hour = (int) (minute / 60.0f);
            minute = minute % 60;
        }
        if (hour > 0) {
            return (getTwoLength(hour) + "小时" + getTwoLength(minute) + "分钟");
        } else {
            return (getTwoLength(minute) + "分钟" + getTwoLength(second) + "秒");
        }
    }

    public static String formatUserInfoTime(long time) {
        NumberFormat nf = NumberFormat.getNumberInstance();
        // 保留两位小数
        nf.setMaximumFractionDigits(2);
        // 如果不需要四舍五入，可以使用RoundingMode.DOWN
        nf.setRoundingMode(RoundingMode.UP);
        return nf.format(time / 3600f);
    }

    private static String getTwoLength(final int data) {
        if (data < 10) {
            return "0" + data;
        } else {
            return "" + data;
        }
    }

    private static String getTwoLength(final long data) {
        if (data < 10) {
            return "0" + data;
        } else {
            return "" + data;
        }
    }

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

    public static String formatLongDate(long date) {
        String dateStr = sdf.format(new Date(date));
        return dateStr;
    }

    private static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static String getCurrentTime() {
        return simpleDateFormat.format(System.currentTimeMillis());
    }

    /**
     * 日期格式字符串转换成时间戳
     *
     * @param date_str 字符串日期
     * @param format   如：yyyy-MM-dd HH:mm:ss
     * @return
     */
    public static long date2TimeStamp(String date_str, String format) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(format);
            return sdf.parse(date_str).getTime() / 1000;
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
        return 0;
    }

    public static long date2TimeStamp(String date) {
        return date2TimeStamp(date, "yyyy-MM-dd HH:mm:ss");
    }

    private static SimpleDateFormat gmtSdf = new SimpleDateFormat("EEE d MMM yyyy HH:mm:ss 'GMT'", Locale.US);

    /**
     * 获取格林尼治标准时
     */
    public static String toGMTString() {
        try {
            Calendar cd = Calendar.getInstance();
            gmtSdf.setTimeZone(TimeZone.getTimeZone("GMT")); // 设置时区为GMT
            return gmtSdf.format(cd.getTime());
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return "";
    }
}
