package com.hhdd.kada.main.utils;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Build;
import android.support.annotation.DimenRes;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.logger.LogHelper;

/**
 * Created by simon on 15/6/15.
 */
public class ScreenUtil {

    public static Point getScreenSize(Context context) {
        WindowManager windowManager = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
        Display display = windowManager.getDefaultDisplay();
        Point pt = new Point();
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB_MR2) {
            pt.x = display.getWidth();
            pt.y = display.getHeight();
        } else {
            display.getSize(pt);
        }
        return pt;
    }

    /**
     * 获取屏幕的宽度
     *
     * @param context
     * @return
     */
    public static int getScreenWidth(Context context) {
        return getScreenSize(context).x;
    }

    /**
     * 获取屏幕的高度
     *
     * @param context
     * @return
     */
    public static int getScreenHeight(Context context) {
        return getScreenSize(context).y;
    }

    /**
     * 获取屏幕中控件顶部位置的高度--即控件顶部的Y点
     *
     * @return
     */
    public static int getScreenViewTopHeight(View view) {
        return view.getTop();
    }

    /**
     * 获取屏幕中控件底部位置的高度--即控件底部的Y点
     *
     * @return
     */
    public static int getScreenViewBottomHeight(View view) {
        return view.getBottom();
    }

    /**
     * 获取屏幕中控件左侧的位置--即控件左侧的X点
     *
     * @return
     */
    public static int getScreenViewLeftHeight(View view) {
        return view.getLeft();
    }

    /**
     * 获取屏幕中控件右侧的位置--即控件右侧的X点
     *
     * @return
     */
    public static int getScreenViewRightHeight(View view) {
        return view.getRight();
    }

    public static int dip2px(Context context, float dipValue) {
        float density = context.getResources().getDisplayMetrics().density;
        return (int) (dipValue * density + 0.5f);
    }

    public static int getScreenWidth() {
        DisplayMetrics dm = KaDaApplication.applicationContext().getResources().getDisplayMetrics();
        return dm.widthPixels;
    }

    public static int getScreenHeight() {
        DisplayMetrics dm = KaDaApplication.applicationContext().getResources().getDisplayMetrics();
        return dm.heightPixels;
    }

    /**
     * 返回状态栏/通知栏的高度
     *
     * @param context
     * @return
     */
    public static int getStatusBarHeight(Context context) {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    /**
     * 获取底部导航栏高度
     * @param context
     * @return
     */
    public static int getNavigationBarHeight(Context context) {
        Resources resources = context.getResources();
        int resourceId = resources.getIdentifier("navigation_bar_height","dimen", "android");
        int height = resources.getDimensionPixelSize(resourceId);
        return height;
    }

    public static boolean inRangeOfView(View view, MotionEvent ev) {
        int[] location = new int[2];
        view.getLocationOnScreen(location);
        if (ev.getRawX() < location[0] || ev.getRawX() > (location[0] + view.getWidth()) || ev.getRawY() < location[1] || ev.getRawY() > (location[1] + view.getHeight())) {
            return false;
        }
        return true;
    }

    public static float getDimension(@DimenRes int id) {
        try {
            return KaDaApplication.getInstance().getResources().getDimension(id);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return 0;
    }


    public static int getDimensionPixelOffset(@DimenRes int id) {
        try {
            return KaDaApplication.getInstance().getResources().getDimensionPixelOffset(id);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return 0;
    }

}
