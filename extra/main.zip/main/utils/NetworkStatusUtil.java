package com.hhdd.kada.main.utils;

/**
 * Created by simon on 23/6/15.
 */


import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.telephony.TelephonyManager;
import android.text.TextUtils;

import com.hhdd.logger.LogHelper;

/**
 * Created by simon on 10/31/14.
 */
public class NetworkStatusUtil {
    /**
     * Called when the activity is first created.
     */
    private static final String CTWAP = "ctwap";
    private static final String CTNET = "ctnet";
    private static final String CMWAP = "cmwap";
    private static final String CMNET = "cmnet";
    private static final String NET_3G = "3gnet";
    private static final String WAP_3G = "3gwap";
    private static final String UNIWAP = "uniwap";
    private static final String UNINET = "uninet";

    private static final int TYPE_CT_WAP = 5;
    private static final int TYPE_CT_NET = 6;
    private static final int TYPE_CT_WAP_2G = 7;
    private static final int TYPE_CT_NET_2G = 8;

    private static final int TYPE_CM_WAP = 9;
    private static final int TYPE_CM_NET = 10;
    private static final int TYPE_CM_WAP_2G = 11;
    private static final int TYPE_CM_NET_2G = 12;

    private static final int TYPE_CU_WAP = 13;
    private static final int TYPE_CU_NET = 14;
    private static final int TYPE_CU_WAP_2G = 15;
    private static final int TYPE_CU_NET_2G = 16;

    private static final int TYPE_OTHER = 17;

    private static Uri PREFERRED_APN_URI = Uri
            .parse("content://telephony/carriers/preferapn");

    /**
     * 没有网络
     */
    public static final int TYPE_NET_WORK_DISABLED = 0;

    /**
     * wifi网络
     */
    private static final int TYPE_WIFI = 4;


    public static final int NETWORK_2G = 1;
    public static final int NETWORK_3G = 2;
    public static final int NETWORK_OTHER = 3;
    public static final int NETWORK_WIFI = 4;
    public static final int NETWORK_NO_NETWORK = 5;
    public static final int NETWORK_MOBLIE = 6;


    public static final int MNC_CM = 1; //中国移动
    public static final int MNC_CT = 2; //中国电信
    public static final int MNC_UNI = 3; //中国联通
    public static final int MNC_WIFI = 4;//WIFI
    public static final int MNC_UNKNOWN = 5; //未知运营商

    public static int getMNCFromDetailType(int type) {
        switch (type) {
            case TYPE_WIFI:
                return MNC_WIFI;
            case TYPE_CT_WAP_2G:
            case TYPE_CT_NET_2G:
            case TYPE_CT_WAP:
            case TYPE_CT_NET:
                return MNC_CT;
            case TYPE_CM_WAP_2G:
            case TYPE_CM_NET_2G:
            case TYPE_CM_WAP:
            case TYPE_CM_NET:
                return MNC_CM;
            case TYPE_CU_NET_2G:
            case TYPE_CU_WAP_2G:
            case TYPE_CU_NET:
            case TYPE_CU_WAP:
                return MNC_UNI;
            default:
                return MNC_UNKNOWN;
        }
    }


    public static int getNetWorkTypeFromDetailType(int type) {
        switch (type) {
            case TYPE_WIFI:
                return NETWORK_WIFI;
            case TYPE_NET_WORK_DISABLED:
                return NETWORK_NO_NETWORK;
            case TYPE_CT_WAP_2G:
            case TYPE_CT_NET_2G:
            case TYPE_CM_WAP_2G:
            case TYPE_CM_NET_2G:
            case TYPE_CU_NET_2G:
            case TYPE_CU_WAP_2G:
                return NETWORK_2G;
            case TYPE_CT_WAP:
            case TYPE_CT_NET:
            case TYPE_CM_WAP:
            case TYPE_CM_NET:
            case TYPE_CU_NET:
            case TYPE_CU_WAP:
                return NETWORK_3G;
            case TYPE_OTHER:
            default:
                return NETWORK_OTHER;
        }
    }

    public static int getDetailNetWorkType(Context context) {
        long start = System.currentTimeMillis();
        int checkNetworkType = checkNetworkType(context);
        LogHelper.i("NetType", "===========elpase:"
                + (System.currentTimeMillis() - start));

        switch (checkNetworkType) {
            case TYPE_WIFI:
                LogHelper.i("NetType", "================wifi");
                break;
            case TYPE_NET_WORK_DISABLED:
                LogHelper.i("NetType", "================no network");
                break;
            case TYPE_CT_WAP:
                LogHelper.i("NetType", "================ctwap");
                break;
            case TYPE_CT_WAP_2G:
                LogHelper.i("NetType", "================ctwap_2g");
                break;
            case TYPE_CT_NET:
                LogHelper.i("NetType", "================ctnet");
                break;
            case TYPE_CT_NET_2G:
                LogHelper.i("NetType", "================ctnet_2g");
                break;
            case TYPE_CM_WAP:
                LogHelper.i("NetType", "================cmwap");
                break;
            case TYPE_CM_WAP_2G:
                LogHelper.i("NetType", "================cmwap_2g");
                break;
            case TYPE_CM_NET:
                LogHelper.i("NetType", "================cmnet");
                break;
            case TYPE_CM_NET_2G:
                LogHelper.i("NetType", "================cmnet_2g");
                break;
            case TYPE_CU_NET:
                LogHelper.i("NetType", "================cunet");
                break;
            case TYPE_CU_NET_2G:
                LogHelper.i("NetType", "================cunet_2g");
                break;
            case TYPE_CU_WAP:
                LogHelper.i("NetType", "================cuwap");
                break;
            case TYPE_CU_WAP_2G:
                LogHelper.i("NetType", "================cuwap_2g");
                break;
            case TYPE_OTHER:
                LogHelper.i("NetType", "================other");
                break;
            default:
                break;
        }

        return checkNetworkType;

    }

    /**
     * 快速获取网络类型
     * 能区分 wifi 2G 3G 无网络
     * @param context
     * @return
     */
    public static int fastGetNetworkType(Context context) {
        try {
            final ConnectivityManager connectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            final NetworkInfo mobNetInfoActivity = connectivityManager
                    .getActiveNetworkInfo();
            if (mobNetInfoActivity == null || !mobNetInfoActivity.isConnectedOrConnecting()) {
                return NETWORK_NO_NETWORK;
            } else {
                // NetworkInfo不为null开始判断是网络类型
                int netType = mobNetInfoActivity.getType();
                if (netType == ConnectivityManager.TYPE_WIFI) {
                    // wifi net处理
                    return NETWORK_WIFI;
                } else if (netType == ConnectivityManager.TYPE_MOBILE) {
                    boolean is3G = isFastMobileNetwork(context);
                    if(is3G) {
                        return NETWORK_3G;
                    } else {
                        return NETWORK_2G;
                    }
                }
            }
        }catch (Exception e) {
            return NETWORK_OTHER;
        }

        return NETWORK_OTHER;
    }

    /**
     * 快速获取网络类型
     * 能区分 wifi 移动网络 无网络
     * @param context
     * @return
     */
    public static int getNetworkType(Context context) {
        try {
            final ConnectivityManager connectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            final NetworkInfo mobNetInfoActivity = connectivityManager
                    .getActiveNetworkInfo();
            if (mobNetInfoActivity == null || !mobNetInfoActivity.isConnectedOrConnecting()) {
                return NETWORK_NO_NETWORK;
            } else {
                // NetworkInfo不为null开始判断是网络类型
                int netType = mobNetInfoActivity.getType();
                if (netType == ConnectivityManager.TYPE_WIFI) {
                    // wifi net处理
                    return NETWORK_WIFI;
                } else if (netType == ConnectivityManager.TYPE_MOBILE) {
                    return NETWORK_MOBLIE;
                }
            }
        }catch (Exception e) {
            return NETWORK_OTHER;
        }

        return NETWORK_OTHER;
    }

    /**
     * 详细区分网络类型
     * 判断Network具体类型（联通移动wap，电信wap，其他net）
     */
    public static int checkNetworkType(Context context) {
        try {
            final ConnectivityManager connectivityManager = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            final NetworkInfo mobNetInfoActivity = connectivityManager
                    .getActiveNetworkInfo();
            if (mobNetInfoActivity == null || !mobNetInfoActivity.isConnectedOrConnecting()) {
                // 注意一：
                // NetworkInfo 为空或者不可以用的时候正常情况应该是当前没有可用网络，
                // 但是有些电信机器，仍可以正常联网，
                // 所以当成net网络处理依然尝试连接网络。
                // （然后在socket中捕捉异常，进行二次判断与用户提示）。
                return TYPE_NET_WORK_DISABLED;
            } else {
                // NetworkInfo不为null开始判断是网络类型
                int netType = mobNetInfoActivity.getType();
                if (netType == ConnectivityManager.TYPE_WIFI) {
                    // wifi net处理
                    return TYPE_WIFI;
                } else if (netType == ConnectivityManager.TYPE_MOBILE) {
                    // 注意二：
                    // 判断是否电信wap:
                    // 不要通过getExtraInfo获取接入点名称来判断类型，
                    // 因为通过目前电信多种机型测试发现接入点名称大都为#777或者null，
                    // 电信机器wap接入点中要比移动联通wap接入点多设置一个用户名和密码,
                    // 所以可以通过这个进行判断！

                    boolean is3G = isFastMobileNetwork(context);

                    Cursor c = null;

                    try {
                        c = context.getContentResolver().query(
                                PREFERRED_APN_URI, null, null, null, null);
                        if (c != null) {
                            c.moveToFirst();
                            final String user = c.getString(c
                                    .getColumnIndex("user"));
                            if (!TextUtils.isEmpty(user)) {
                                if (user.startsWith(CTWAP)) {
                                    return is3G ? TYPE_CT_WAP : TYPE_CT_WAP_2G;
                                } else if (user.startsWith(CTNET)) {
                                    return is3G ? TYPE_CT_NET : TYPE_CT_NET_2G;
                                }
                            }
                        }
                    } catch (Exception e) {
                    } finally {
                        if (c != null) {
                            c.close();
                        }
                    }


                    // 注意三：
                    // 判断是移动联通wap:
                    // 其实还有一种方法通过getString(c.getColumnIndex("proxy")获取代理ip
                    // 来判断接入点，10.0.0.172就是移动联通wap，10.0.0.200就是电信wap，但在
                    // 实际开发中并不是所有机器都能获取到接入点代理信息，例如魅族M9 （2.2）等...
                    // 所以采用getExtraInfo获取接入点名字进行判断

                    String netMode = mobNetInfoActivity.getExtraInfo();
                    LogHelper.i("", "==================netmode:" + netMode);
                    if (netMode != null) {
                        // 通过apn名称判断是否是联通和移动wap
                        netMode = netMode.toLowerCase();

                        if (netMode.equals(CMWAP)) {
                            return is3G ? TYPE_CM_WAP : TYPE_CM_WAP_2G;
                        } else if (netMode.equals(CMNET)) {
                            return is3G ? TYPE_CM_NET : TYPE_CM_NET_2G;
                        } else if (netMode.equals(NET_3G)
                                || netMode.equals(UNINET)) {
                            return is3G ? TYPE_CU_NET : TYPE_CU_NET_2G;
                        } else if (netMode.equals(WAP_3G)
                                || netMode.equals(UNIWAP)) {
                            return is3G ? TYPE_CU_WAP : TYPE_CU_WAP_2G;
                        }
                    }
                }
            }

        } catch (Exception ex) {
            LogHelper.printStackTrace(ex);
            return TYPE_OTHER;
        }



        return TYPE_OTHER;

    }

    private static boolean isFastMobileNetwork(Context context) {
        TelephonyManager telephonyManager = (TelephonyManager) context
                .getSystemService(Context.TELEPHONY_SERVICE);

        if (telephonyManager == null) {
            return false;
        }
        int networkType = telephonyManager.getNetworkType();
        switch (networkType) {
            case TelephonyManager.NETWORK_TYPE_1xRTT:
                return false; // ~ 50-100 kbps
            case TelephonyManager.NETWORK_TYPE_CDMA:
                return false; // ~ 14-64 kbps
            case TelephonyManager.NETWORK_TYPE_EDGE:
                return false; // ~ 50-100 kbps
            case TelephonyManager.NETWORK_TYPE_EVDO_0:
                return true; // ~ 400-1000 kbps
            case TelephonyManager.NETWORK_TYPE_EVDO_A:
                return true; // ~ 600-1400 kbps
            case TelephonyManager.NETWORK_TYPE_GPRS:
                return false; // ~ 100 kbps
            case TelephonyManager.NETWORK_TYPE_HSDPA:
                return true; // ~ 2-14 Mbps
            case TelephonyManager.NETWORK_TYPE_HSPA:
                return true; // ~ 700-1700 kbps
            case TelephonyManager.NETWORK_TYPE_HSUPA:
                return true; // ~ 1-23 Mbps
            case TelephonyManager.NETWORK_TYPE_UMTS:
                return true; // ~ 400-7000 kbps
            case TelephonyManager.NETWORK_TYPE_EHRPD:
                return true; // ~ 1-2 Mbps
            case TelephonyManager.NETWORK_TYPE_EVDO_B:
                return true; // ~ 5 Mbps
            case TelephonyManager.NETWORK_TYPE_HSPAP:
                return true; // ~ 10-20 Mbps
            case TelephonyManager.NETWORK_TYPE_IDEN:
                return false; // ~25 kbps
            case TelephonyManager.NETWORK_TYPE_LTE:
                return true; // ~ 10+ Mbps
            case TelephonyManager.NETWORK_TYPE_UNKNOWN:
                return false;
            default:
                return false;

        }
    }

    public static String getNetInfo(Context context) {
        int type = checkNetworkType(context);
        switch (type) {
            case TYPE_WIFI:
                return "wifi";
            case TYPE_NET_WORK_DISABLED:
                LogHelper.i("NetType", "================no network");
                return "disable";
            case TYPE_CT_WAP:
                LogHelper.i("NetType", "================ctwap");
                return "ctwap";
            case TYPE_CT_WAP_2G:
                LogHelper.i("NetType", "================ctwap_2g");
                return "ctwap_2g";
            case TYPE_CT_NET:
                LogHelper.i("NetType", "================ctnet");
                return "ctnet";
            case TYPE_CT_NET_2G:
                LogHelper.i("NetType", "================ctnet_2g");
                return "ctnet_2g";
            case TYPE_CM_WAP:
                LogHelper.i("NetType", "================cmwap");
                return "cmwap";
            case TYPE_CM_WAP_2G:
                LogHelper.i("NetType", "================cmwap_2g");
                return "cmwap_2g";
            case TYPE_CM_NET:
                LogHelper.i("NetType", "================cmnet");
                return "cmnet";
            case TYPE_CM_NET_2G:
                LogHelper.i("NetType", "================cmnet_2g");
                return "cmnet_2g";
            case TYPE_CU_NET:
                LogHelper.i("NetType", "================cunet");
                return "cunet";
            case TYPE_CU_NET_2G:
                LogHelper.i("NetType", "================cunet_2g");
                return "cunet_2g";
            case TYPE_CU_WAP:
                LogHelper.i("NetType", "================cuwap");
                return "cuwap";
            case TYPE_CU_WAP_2G:
                LogHelper.i("NetType", "================cuwap_2g");
                return "cuwap_2g";
            case TYPE_OTHER:
                LogHelper.i("NetType", "================other");
                return "unknown";
            default:
                break;
        }
        return "unknown";
    }

    public static class NetworkStatus {
        public String networkStatus = "unkown"; //×Ö·û´®ÐÅÏ¢
        public int networkType = NETWORK_OTHER;
    }

    public static NetworkStatus getNetworkStatus(Context context) {
        NetworkStatus status = new NetworkStatus();
        int type = checkNetworkType(context);
        switch (type) {
            case TYPE_WIFI:
                status.networkStatus = "wifi";
                status.networkType = NETWORK_WIFI;
                break;
            case TYPE_NET_WORK_DISABLED:
                LogHelper.i("NetType", "================no network");
                status.networkStatus =  "disable";
                status.networkType = NETWORK_NO_NETWORK;
                break;
            case TYPE_CT_WAP:
                LogHelper.i("NetType", "================ctwap");
                status.networkStatus = "ctwap";
                status.networkType = NETWORK_3G;
                break;
            case TYPE_CT_WAP_2G:
                LogHelper.i("NetType", "================ctwap_2g");
                status.networkStatus = "ctwap_2g";
                status.networkType = NETWORK_2G;
                break;
            case TYPE_CT_NET:
                LogHelper.i("NetType", "================ctnet");
                status.networkStatus = "ctnet";
                status.networkType = NETWORK_3G;
                break;
            case TYPE_CT_NET_2G:
                LogHelper.i("NetType", "================ctnet_2g");
                status.networkStatus = "ctnet_2g";
                status.networkType = NETWORK_2G;
                break;
            case TYPE_CM_WAP:
                LogHelper.i("NetType", "================cmwap");
                status.networkStatus = "cmwap";
                status.networkType = NETWORK_3G;
                break;
            case TYPE_CM_WAP_2G:
                LogHelper.i("NetType", "================cmwap_2g");
                status.networkStatus = "cmwap_2g";
                status.networkType = NETWORK_2G;
                break;
            case TYPE_CM_NET:
                LogHelper.i("NetType", "================cmnet");
                status.networkStatus = "cmnet";
                status.networkType = NETWORK_3G;
                break;
            case TYPE_CM_NET_2G:
                LogHelper.i("NetType", "================cmnet_2g");
                status.networkStatus = "cmnet_2g";
                status.networkType = NETWORK_2G;
                break;
            case TYPE_CU_NET:
                LogHelper.i("NetType", "================cunet");
                status.networkStatus = "cunet";
                status.networkType = NETWORK_3G;
                break;
            case TYPE_CU_NET_2G:
                LogHelper.i("NetType", "================cunet_2g");
                status.networkStatus = "cunet_2g";
                status.networkType = NETWORK_2G;
                break;
            case TYPE_CU_WAP:
                LogHelper.i("NetType", "================cuwap");
                status.networkStatus = "cuwap";
                status.networkType = NETWORK_3G;
                break;
            case TYPE_CU_WAP_2G:
                LogHelper.i("NetType", "================cuwap_2g");
                status.networkStatus = "cuwap_2g";
                status.networkType = NETWORK_2G;
                break;
            case TYPE_OTHER:
                LogHelper.i("NetType", "================other");
                status.networkStatus = "unknown";
                status.networkType = NETWORK_OTHER;
                break;
            default:
                break;
        }


        return status;
    }
}
