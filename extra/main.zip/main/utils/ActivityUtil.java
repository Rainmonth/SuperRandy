package com.hhdd.kada.main.utils;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.google.gson.Gson;
import com.hhdd.kada.Constants;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.main.model.AccountUnifyInfo;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.model.CapabilityModelInfo;
import com.hhdd.kada.main.model.DimensionInfo;
import com.hhdd.kada.main.model.RecommendContentInfo;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.model.TalentPlanCollectInfo;
import com.hhdd.kada.main.ui.activity.BindingConflictActivity;
import com.hhdd.kada.main.ui.activity.BindingFailActivity;
import com.hhdd.kada.main.ui.activity.BindingSuccessActivity;
import com.hhdd.kada.main.ui.activity.CollectActivity;
import com.hhdd.kada.main.ui.activity.DownloadActivity;
import com.hhdd.kada.main.ui.activity.LaunchActivity;
import com.hhdd.kada.main.ui.activity.MainActivity;
import com.hhdd.kada.main.ui.activity.ReadingModelDetailActivity;
import com.hhdd.kada.main.ui.activity.RecommendSubscribeContentActivity;
import com.hhdd.kada.main.ui.activity.RecommendSubscribeSettingActivity;
import com.hhdd.kada.main.ui.activity.RestActivity;
import com.hhdd.kada.main.ui.activity.SettingActivity;
import com.hhdd.kada.main.ui.activity.SleepActivity;
import com.hhdd.kada.main.ui.activity.SplashActivity;
import com.hhdd.kada.main.ui.book.BookCollectionTitleWebViewActivity;
import com.hhdd.kada.main.ui.story.StoryCollectionTitleWebViewActivity;
import com.hhdd.kada.module.talentplan.activity.TalentPlanContentActivity;
import com.hhdd.kada.module.talentplan.activity.TalentPlanIntroduceActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/25
 * @describe : com.hhdd.kada.main.utils
 */
public class ActivityUtil {

    public static void next(Context context, Intent intent) {
        if (context != null && intent != null) {
            context.startActivity(intent);
        }
    }

    public static void next(Context context, Class<? extends Activity> actClas) {
        Intent intent = new Intent(context, actClas);
        next(context, intent);
    }

    /**
     * 跳转到主页面
     * @param context
     */
    public static void nextMainActivity(Context context){
        Intent intent = new Intent(context, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        next(context, intent);
    }

    /**
     * 跳转到闪屏页面
     * @param context
     */
    public static void nextSplashActivity(Context context){
        Intent intent = new Intent(context, SplashActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        next(context, intent);
    }

    /**
     * 跳转收藏页面
     * @param context
     * @param type
     */
    public static void nextCollectActivity(Context context, int type){
        nextCollectDownloadActivity(context, type, CollectActivity.class);
    }

    /**
     * 跳转下载页面
     * @param context
     * @param type
     */
    public static void nextDownloadActivity(Context context, int type){
        nextCollectDownloadActivity(context, type, DownloadActivity.class);
    }

    private static void nextCollectDownloadActivity(Context context, int type, Class<? extends Activity> actClas){
        Intent intent = new Intent(context, actClas);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("type", type);
        next(context, intent);
    }

    /**
     * 跳转到休息页面
     * @param activity
     */
    public static void nextRestActivity(Activity activity) {
        Intent intent = new Intent(activity, RestActivity.class);
        activity.startActivity(intent);
        activity.overridePendingTransition(0, 0);
    }

    /**
     * 跳转到睡眠页面
     * @param activity
     */
    public static void nextSleepActivity(Activity activity) {
        Intent intent = new Intent(activity, SleepActivity.class);
        activity.startActivity(intent);
        activity.overridePendingTransition(0, 0);
    }

    /**
     * 跳转到推荐设置页面
     * @param context
     * @param dimensionInfoList
     */
    public static void nextRecommendSettingActivity(Context context, List<DimensionInfo> dimensionInfoList, boolean isToast) {
        Intent intent = new Intent(context, RecommendSubscribeSettingActivity.class);
        Gson gson = new Gson();
        String dimensionInfo = gson.toJson(dimensionInfoList);
        intent.putExtra(Constants.INTENT_KEY_RECOMMEND_DIMENSION_INFO, dimensionInfo);
        intent.putExtra(Constants.INTENT_KEY_RECOMMEND_TOAST, isToast);
        context.startActivity(intent);
    }

    /**
     * 跳转到推荐内容页面
     * @param context
     * @param info
     * @param dimensionIds
     */
    public static void nextRecommendContentActivity(Context context, RecommendContentInfo info, String dimensionIds) {
        Intent intent = new Intent(context, RecommendSubscribeContentActivity.class);
        intent.putExtra(Constants.INTENT_KEY_RECOMMEND_CONTENT_INFO, info);
        intent.putExtra(Constants.INTENT_KEY_RECOMMEND_DIMENSION_ID, dimensionIds);
        context.startActivity(intent);
    }

    /**
     * 跳转到优才计划介绍页面
     * @param context
     * @param isOpen
     */
    public static void nextTalentPlanIntroduceActivity(Context context, TalentPlanCollectInfo info, boolean isOpen) {
        Intent intent = new Intent(context, TalentPlanIntroduceActivity.class);
        intent.putExtra(Constants.INTENT_KEY_TALENTPLAN_OPEN, isOpen);
        intent.putExtra(Constants.INTENT_KEY_TALENTPLAN_COLLECT_INFO, info);
        context.startActivity(intent);
    }

    /**
     * 跳转到设置页面
     * @param context
     * @param showLockDialog
     */
    public static void nextSettingActivity(Context context, boolean showLockDialog) {
        Intent intent = new Intent(context, SettingActivity.class);
        intent.putExtra(Constants.INTENT_KEY_SETTING_SHOWLOCKDIALOG, showLockDialog);
        context.startActivity(intent);
    }

    /**
     * 跳转app启动分发页面
     * @param context
     * @param redirectUrl
     */
    public static void nextLaunchActivity(Context context, String redirectUrl, int launchFromType) {
        Intent intent = new Intent(context, LaunchActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(Constants.INTENT_KEY_LAUNCH_REDIRECT_INFO, redirectUrl);
        intent.putExtra(Constants.INTENT_KEY_LAUNCH_FROM_TYPE, launchFromType);
        context.startActivity(intent);
    }

    /**
     * 跳转到优才计划内容页(带参)
     * @param context
     * @param showWeek
     */
    public static void nextTalentPlanContentActivity(Context context, String showWeek) {
        Intent intent = new Intent(context, TalentPlanContentActivity.class);
        intent.putExtra(Constants.INTENT_KEY_TALENTPLAN_CURRENT_WEEK, showWeek);
        next(context, intent);
    }

    /**
     * 跳转到阅读模型详情页
     * @param context
     * @param info
     * @param dimensionIndex
     * @param levelIndex
     */
    public static void nextReadingModelDetailActivity(Context context, CapabilityModelInfo info,
                                                      int dimensionIndex, int levelIndex) {
        Intent intent = new Intent(context, ReadingModelDetailActivity.class);
        intent.putExtra(Constants.INTENT_KEY_CAPABILITY_MODEL_INFO, info);
        intent.putExtra(Constants.INTENT_KEY_DIMENSION_INDEX, dimensionIndex);
        intent.putExtra(Constants.INTENT_KEY_LEVEL_INDEX, levelIndex);
        next(context, intent);
    }

    /**
     * 跳转到绘本合集简介页面
     * @param context
     * @param info
     */
    public static void nextBookCollectionTitleWebViewActivity(Context context, BookCollectionDetailInfo info) {
        Intent intent = new Intent(context, BookCollectionTitleWebViewActivity.class);
        intent.putExtra(Constants.INTENT_KEY_COLLECTION_INFO, info);
        next(context, intent);
    }

    /**
     * 跳转到听书合集简介页面
     * @param context
     * @param info
     */
    public static void nextStoryCollectionTitleWebViewActivity(Context context, StoryCollectionDetail info) {
        Intent intent = new Intent(context, StoryCollectionTitleWebViewActivity.class);
        intent.putExtra(Constants.INTENT_KEY_COLLECTION_INFO, info);
        next(context, intent);
    }

    /**
     * 跳转到帐号绑定冲突页面
     * @param context
     * @param accountUnifyInfoList
     */
    public static void nextBindingConflictActivity (Context context, ArrayList<AccountUnifyInfo> accountUnifyInfoList) {
        Intent intent = new Intent(context, BindingConflictActivity.class);
        intent.putExtra(Constants.INTENT_KEY_ACCOUNT_UNIFY_INFO, accountUnifyInfoList);
        next(context, intent);
    }

    /**
     * 跳转到帐号绑定成功页面
     * @param context
     * @param isNeedLoginAgain
     */
    public static void nextBindingSuccessActivity(Context context, boolean isNeedLoginAgain) {
        Intent intent = new Intent(context, BindingSuccessActivity.class);
        intent.putExtra(Constants.INTENT_KEY_UNIFY_RESULT_NEED_LOGIN, isNeedLoginAgain);
        next(context, intent);
    }

    /**
     * 跳转到帐号绑定失败页面
     * @param context
     * @param resultText
     */
    public static void nextBindingFailActivity(Context context, String resultText) {
        Intent intent = new Intent(context, BindingFailActivity.class);
        intent.putExtra(Constants.INTENT_KEY_UNIFY_RESULT_TEXT, resultText);
        next(context, intent);
    }

    /**
     * 判断MainActivity是否启动
     */
    public static boolean isMainActivityLaunch() {
        List<Activity> activityList = ActivityHelper.getActivities();
        boolean isMainActivityLaunch = false;
        if (activityList != null) {
            for (Activity activity : activityList) {
                if (activity instanceof MainActivity) {
                    isMainActivityLaunch = true;
                    break;
                }
            }
        }
        return isMainActivityLaunch;
    }

    /**
     * 验证context的合法性
     * @param context
     * @return
     */
    public static boolean isValidContext(Context context) {
        if (context == null) {
            return false;
        }
        if (context instanceof Activity) {
            Activity activity = (Activity) context;
            if (activity.isFinishing()) {
                return false;
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                if (activity.isDestroyed()) {
                    return false;
                }
            }
        }
        return true;
    }
}
