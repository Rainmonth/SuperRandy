package com.hhdd.kada.main.utils;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore;
import android.renderscript.Allocation;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.View;

import com.facebook.drawee.generic.RootDrawable;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.views.FastBlur;
import com.hhdd.logger.LogHelper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

/**
 * Created by simon on 19/6/15.
 */
public class BitmapUtils {

    public static byte[] Bitmap2Bytes(Bitmap bm) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 100, baos);
        return baos.toByteArray();
    }

    public static Bitmap byteToBitmap(byte[] imgByte) {
        int width = ScreenUtil.getScreenWidth(KaDaApplication.getInstance()) * 3 / 4;
        int height = ScreenUtil.getScreenHeight(KaDaApplication.getInstance()) * 3 / 4;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(imgByte, 0, imgByte.length, options);
        if (options.mCancel || options.outWidth == -1 || options.outHeight == -1) {
            return null;
        }
        options.inSampleSize = calculateInSampleSize(options, -1, (int) (width * height));
//        options.inSampleSize = calculateInSampleSize(options, height,width);
        options.inJustDecodeBounds = false;
        options.inDither = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap bitmap = BitmapFactory.decodeByteArray(
                imgByte, 0, imgByte.length, options);
        options = null;
        return bitmap;
    }

    public static Bitmap byteToBitmap(byte[] imgByte, int width, int height) {
        InputStream input = null;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(imgByte, 0, imgByte.length, options);
        if (options.mCancel || options.outWidth == -1 || options.outHeight == -1) {
            return null;
        }
        options.inSampleSize = computeSampleSize(options, -1, (int) (width * height));
//        options.inSampleSize = calculateInSampleSize(options, height,width);
        options.inJustDecodeBounds = false;
        options.inDither = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inTempStorage = new byte[5 * 1024];
        Bitmap bitmap = BitmapFactory.decodeByteArray(
                imgByte, 0, imgByte.length, options);
        if (options.mCancel || options.outWidth == -1 || options.outHeight == -1) {
            return null;
        }
        options = null;
        return bitmap;
    }

    public static Bitmap zoomBitmap(Bitmap bitmap, int width, int height) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        Matrix matrix = new Matrix();
        float scaleWidth = ((float) width / w);
        float scaleHeight = ((float) height / h);
        matrix.postScale(scaleWidth, scaleHeight);
        Bitmap newbmp = Bitmap.createBitmap(bitmap, 0, 0, w, h, matrix, true);
        return newbmp;
    }

    public static Bitmap drawableToBitmap(Drawable drawable,int w,int h) {
        // 取 drawable 的长宽
//        int w = drawable.getIntrinsicWidth();
//        int h = drawable.getIntrinsicHeight();

        // 取 drawable 的颜色格式
        if(drawable != null){
            Bitmap.Config config =
                    drawable.getOpacity() != PixelFormat.OPAQUE ? Bitmap.Config.ARGB_8888 : Bitmap.Config.RGB_565;
            // 建立对应 bitmap
            Bitmap bitmap = Bitmap.createBitmap(w, h, config);
            // 建立对应 bitmap 的画布
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, w, h);
            // 把 drawable 内容画到画布中
            drawable.draw(canvas);
            return bitmap;
        }
        return null;
    }

    public static Bitmap drawableToBitmap2(Drawable drawable) {
        if(drawable != null && drawable instanceof RootDrawable){
            ((RootDrawable) drawable).getDrawable();
        }
        BitmapDrawable bd = (BitmapDrawable) drawable;
        Bitmap bitmap = bd.getBitmap();
        return bitmap;
    }

    public static Bitmap createReflectionImageWithOrigin(Bitmap bitmap) {
        final int reflectionGap = 4;
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();

        Matrix matrix = new Matrix();
        matrix.preScale(1, -1);

        Bitmap reflectionImage = Bitmap.createBitmap(bitmap, 0, h / 2, w,
                h / 2, matrix, false);

        Bitmap bitmapWithReflection = Bitmap.createBitmap(w, (h + h / 2),
                Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(bitmapWithReflection);
        canvas.drawBitmap(bitmap, 0, 0, null);
        Paint deafalutPaint = new Paint();
        canvas.drawRect(0, h, w, h + reflectionGap, deafalutPaint);

        canvas.drawBitmap(reflectionImage, 0, h + reflectionGap, null);

        Paint paint = new Paint();
        LinearGradient shader = new LinearGradient(0, bitmap.getHeight(), 0,
                bitmapWithReflection.getHeight() + reflectionGap, 0x70ffffff,
                0x00ffffff, Shader.TileMode.CLAMP);
        paint.setShader(shader);
        // Set the Transfer mode to be porter duff and destination in
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        // Draw a rectangle using the paint with our linear gradient
        canvas.drawRect(0, h, w, bitmapWithReflection.getHeight()
                + reflectionGap, paint);

        return bitmapWithReflection;
    }


    public static final int WIFI_BITMAP_LENGTH = 110;

    public static String writeToFile(Context context, Uri uri) {
        File file = FileUtils.newTempImageFile();
        FileOutputStream os = null;
        InputStream is = null;
        try {
            os = new FileOutputStream(file);
            is = context.getContentResolver().openInputStream(uri);
            byte[] b = new byte[1024];
            int count = 0;
            while (true) {
                int readLength = is.read(b);
                if (readLength == -1) {
                    break;
                }
                os.write(b, 0, readLength);
                count++;
                if (count % 5 == 0) {
                    os.flush();
                }
            }

        } catch (Exception e) {
            LogHelper.e("aa","aa");
        } catch (Throwable t) {
            LogHelper.e("aa", "bb");
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    LogHelper.printStackTrace(e);
                }
            }
            if (os != null) {
                try {
                    os.close();
                } catch (Exception e) {
                    LogHelper.printStackTrace(e);
                }
            }
        }
        return file.getAbsolutePath();
    }

    public static File compressAndRotateToBitmapThumbFile(Context context,
                                                          Uri uri, int width, int height) {
        if (uri == null) {
            return null;
        }
        String path = uri.getPath();
        if (!"file".equals(uri.getScheme())) {
            path = writeToFile(context, uri);
        }
        return compressAndRotateToBitmapThumbFile(context, path, width, height);
    }

    public static File compressAndRotateToBitmapThumbFile(Context context,
                                                          String path, int width, int height) {
        int degree = getOrientation(context, path, null);
        Bitmap bm = compressFileToBitmapThumb(path, width, height);
        File delFile = new File(path);
        if (delFile.exists()) {
            delFile.delete();
        }
        if (bm == null)
            return null;
        Bitmap rotate = rotateBitmap(bm, degree);

        if (rotate != null) {
            String nameString = UUID.randomUUID().toString() + ".jpg";
            String pathString = Dirs.getTmpCachePath();
            int size = getBitmapCompress(context, bm);
            if (BitmapUtils.writeBitmap(pathString, nameString, rotate, size)) {
                rotate.recycle();
                rotate = null;
                return new File(pathString, nameString);
            }
            rotate.recycle();
            rotate = null;
        }
        return null;
    }

    public static File compressAndRotateToBitmapThumbFile(Context context,
                                                          String originPath, String targetPath, int width, int height) {
        int degree = getOrientation(context, originPath, null);
        Bitmap bm = compressFileToBitmapThumb(originPath, width, height);
        if (bm == null)
            return null;
        Bitmap rotate = rotateBitmap(bm, degree);

        if (rotate != null) {
            int size = getBitmapCompress(context, bm);
            if (BitmapUtils.writeBitmap(targetPath, rotate, size)) {
                rotate.recycle();
                rotate = null;
                return new File(targetPath);
            }
            rotate.recycle();
            rotate = null;
        }
        return null;
    }

    public static Bitmap compressFileToBitmapThumb(String filePath, int targetSize) {
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }
        File file = new File(filePath);
        if (!file.exists()) {
            return null;
        }
        FileInputStream fis = null;
        FileDescriptor fd = null;
        try {
            fis = new FileInputStream(file);
            fd = fis.getFD();
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
            return null;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 1;
        options.inJustDecodeBounds = true;
        try {
            BitmapFactory.decodeFileDescriptor(fd, null, options);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
            try {
                fis.close();
            } catch (IOException e1) {
                LogHelper.printStackTrace(e1);
            }
            return null;
        } catch (Throwable t) {
            LogHelper.printStackTrace(t);
            try {
                fis.close();
            } catch (IOException e) {
                LogHelper.printStackTrace(e);
            }
            return null;
        }

        if (options.mCancel || options.outWidth == -1
                || options.outHeight == -1) {
            try {
                fis.close();
            } catch (IOException e) {
                LogHelper.printStackTrace(e);
            }
            return null;
        }
        int currentSize = Math.min(options.outWidth, options.outHeight);
        float ratio = (float) targetSize / (float) currentSize;

        int targetWidth = (int) (options.outWidth * ratio);
        int targetHeight = (int) (options.outHeight * ratio);

//		options.outWidth = targetWidth;
//		options.outHeight = targetHeight;
        options.inJustDecodeBounds = false;

        options.inDither = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;

        int maxPixels = targetWidth * targetHeight;
        if (isLargeImage(options)) {
            if (options.outWidth != 0) {
                maxPixels = options.outHeight * options.outWidth;
                if (options.outWidth >= 800) {
                    maxPixels = maxPixels / (options.outWidth / 400);
                }
            } else {
                maxPixels = maxPixels * 4;
            }
        }
        int sampleSize = computeSampleSize(options, targetSize, maxPixels);
        int maxSample = Math.max(sampleSize, 40);

        for (int index = sampleSize; index <= maxSample; index = index * 2) {
            try {
                options.inSampleSize = index;
                Bitmap bm = BitmapFactory.decodeFileDescriptor(fd, null,
                        options);
                if (null != bm) {
                    Bitmap newBm = Bitmap.createScaledBitmap(bm, targetWidth, targetHeight, true);
                    return newBm;
                }
            } catch (OutOfMemoryError e) {
                LogHelper.printStackTrace(e);
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            } catch (Throwable t) {
                LogHelper.printStackTrace(t);
            }
        }
        try {
            fis.close();
        } catch (IOException e) {
            LogHelper.printStackTrace(e);
        }
        return null;
    }

    public static Bitmap compressFileToBitmapThumb(String filePath, int width,
                                                   int height) {
        if (TextUtils.isEmpty(filePath)) {
            return null;
        }
        File file = new File(filePath);
        if (!file.exists()) {
            return null;
        }
        FileInputStream fis = null;
        FileDescriptor fd = null;
        try {
            fis = new FileInputStream(file);
            fd = fis.getFD();
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
            return null;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 1;
        options.inJustDecodeBounds = true;
        try {
            BitmapFactory.decodeFileDescriptor(fd, null, options);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
            try {
                fis.close();
            } catch (IOException e1) {
                LogHelper.printStackTrace(e1);
            }
            return null;
        } catch (Throwable t) {
            LogHelper.printStackTrace(t);
            try {
                fis.close();
            } catch (IOException e) {
                LogHelper.printStackTrace(e);
            }
            return null;
        }

        if (options.mCancel || options.outWidth == -1
                || options.outHeight == -1) {
            try {
                fis.close();
            } catch (IOException e) {
                LogHelper.printStackTrace(e);
            }
            return null;
        }
        int targetSize = Math.min(width, height);
        int maxPixels = width * height;
        if (isLargeImage(options)) {
            if (options.outWidth != 0) {
                maxPixels = options.outHeight * options.outWidth;
                if (options.outWidth >= 800) {
                    maxPixels = maxPixels / (options.outWidth / 400);
                }
            } else {
                maxPixels = maxPixels * 4;
            }
        }
        int sampleSize = computeSampleSize(options, targetSize, maxPixels);
        int maxSample = Math.max(sampleSize, 40);
        options.inJustDecodeBounds = false;

        options.inDither = false;
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;

        for (int index = sampleSize; index <= maxSample; index = index * 2) {
            try {
                options.inSampleSize = index;
                Bitmap bm = BitmapFactory.decodeFileDescriptor(fd, null,
                        options);
                if (null != bm) {
                    return bm;
                }
            } catch (OutOfMemoryError e) {
                LogHelper.printStackTrace(e);
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            } catch (Throwable t) {
                LogHelper.printStackTrace(t);
            }
        }
        try {
            fis.close();
        } catch (IOException e) {
            LogHelper.printStackTrace(e);
        }
        return null;
    }

    /**
     * 以最省内存的方式读取本地资源的图片
     *
     * @param context
     * @param resId
     * @return
     */
    public static Bitmap readBitMap(Context context, int resId) {
        BitmapFactory.Options opt = new BitmapFactory.Options();
        opt.inPreferredConfig = Bitmap.Config.RGB_565;
        opt.inPurgeable = true;
        opt.inInputShareable = true;
        // 获取资源图片
        InputStream is = context.getResources().openRawResource(resId);
        return BitmapFactory.decodeStream(is, null, opt);
    }

    /**
     * 获取照片的角度 两种方式:1.根据绝对路径或根据Uri
     *
     * @param imagePath 照片的路径
     * @param context
     * @param photoUri
     */
    public static int getOrientation(Context context, String imagePath,
                                     Uri photoUri) {
        int nOrientation = 0;
        if (!TextUtils.isEmpty(imagePath)) {
            try {
                ExifInterface exif = new ExifInterface(imagePath);
                nOrientation = exif.getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, 0);
                switch (nOrientation) {
                    case ExifInterface.ORIENTATION_ROTATE_90:
                        return 90;
                    case ExifInterface.ORIENTATION_ROTATE_270:
                        return 270;
                    case ExifInterface.ORIENTATION_ROTATE_180:
                        return 180;
                    case ExifInterface.ORIENTATION_NORMAL:
                        return 0;
                }

            } catch (IOException e) {
                LogHelper.printStackTrace(e);
            }
        } else if (context != null && photoUri != null) {
            Cursor cursor = null;
            try {
                cursor = context
                        .getContentResolver()
                        .query(photoUri,
                                new String[]{MediaStore.Images.ImageColumns.ORIENTATION},
                                null, null, null);

                if (cursor == null || cursor.getCount() != 1) {
                    return 0;
                }

                cursor.moveToFirst();
                int ret = cursor.getInt(0);
                return ret;
            } catch (Throwable t) {
                LogHelper.printStackTrace(t);
            } finally {
                if (cursor != null) {
                    cursor.close();
                    cursor = null;
                }
            }
        }
        return 0;
    }

    /**
     * 获取bitmap大小，转化为实际占用空间物理大小
     *
     * @param bm
     * @return
     */
    public static int getBitmapCompress(Context context, Bitmap bm) {

        int initCompress = 100;

        int width = bm.getWidth();
        int height = bm.getHeight();

        int size = width * height / 1024 / 8;

        int totalSize = WIFI_BITMAP_LENGTH;

        if (bm.getHeight() / bm.getWidth() >= 3) {
            totalSize = 160;

        }
        if (size > 300) {
            initCompress = 10;
        } else if (size > 260) {
            initCompress = 20;
        } else if (size > 220) {
            initCompress = 30;
        } else if (size > 180) {
            initCompress = 40;
        } else if (size > 140) {
            initCompress = 50;
        } else if (size >= 110) {
            initCompress = 60;
        } else if (size >= 100) {
            initCompress = 65;
        } else if (size >= 90) {
            initCompress = 70;
        } else if (size >= 80) {
            initCompress = 75;
        } else if (size >= 70) {
            initCompress = 80;
        } else if (size >= 60) {
            initCompress = 85;
        } else if (size >= 50) {
            initCompress = 90;
        }

        // if(!AndTools.isWifi(context)){
        // totalSize = MOBIEL_BITMAP_LENGTH;
        // }

        int compress = initCompress;
        try {
            for (int i = compress; i >= 10; i = i - 10) {
                compress = i;
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bm.compress(Bitmap.CompressFormat.JPEG, i, stream);
                byte[] imageInByte = stream.toByteArray();
                if (imageInByte.length / 1024 <= totalSize) {
                    break;
                }
            }
        } catch (Exception e) {
            compress = 10;
        } catch (Throwable t) {
            compress = 10;
        }
        return compress;
    }

    private static int calculateInSampleSize(BitmapFactory.Options opts, int reqHeight, int reqWidth) {
        if (opts == null)
            return -1;
        int width = opts.outWidth;
        int height = opts.outHeight;

        int sampleSize = 1;

        if (width > reqWidth || height > reqHeight) {
            int heightRatio = (int) (height / (float) reqHeight);
            int widthRatio = (int) (width / (float) reqWidth);
            sampleSize = (heightRatio > widthRatio) ? widthRatio : heightRatio;
        }
        return sampleSize;
    }

    public static int computeSampleSize(BitmapFactory.Options options,
                                        int minSideLength, int maxNumOfPixels) {
        int initialSize = computeInitialSampleSize(options, minSideLength,
                maxNumOfPixels);

        int roundedSize;
        if (initialSize <= 8) {
            roundedSize = 1;
            while (roundedSize < initialSize) {
                roundedSize <<= 1;
            }
        } else {
            roundedSize = (initialSize + 7) / 8 * 8;
        }

        return roundedSize;
    }

    private static final int UNCONSTRAINED = -1;

    private static int computeInitialSampleSize(BitmapFactory.Options options,
                                                int minSideLength, int maxNumOfPixels) {
        double w = options.outWidth;
        double h = options.outHeight;

        int lowerBound = (maxNumOfPixels == UNCONSTRAINED) ? 1 : (int) Math
                .ceil(Math.sqrt(w * h / maxNumOfPixels));
        int upperBound = (minSideLength == UNCONSTRAINED) ? 128 : (int) Math
                .min(Math.floor(w / minSideLength),
                        Math.floor(h / minSideLength));

        if (upperBound < lowerBound) {
            return lowerBound;
        }

        if ((maxNumOfPixels == UNCONSTRAINED)
                && (minSideLength == UNCONSTRAINED)) {
            return 1;
        } else if (minSideLength == UNCONSTRAINED) {
            return lowerBound;
        } else {
            return upperBound;
        }
    }

    public static Bitmap rotateBitmap(Bitmap b, int degrees) {
        if (degrees != 0 && b != null) {
            Matrix m = new Matrix();
            m.setRotate(degrees, b.getWidth() / 2, b.getHeight() / 2);
            try {
                Bitmap b2 = Bitmap.createBitmap(b, 0, 0, b.getWidth(),
                        b.getHeight(), m, true);
                // b.recycle();
                // b = null;
                return b2;
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            } catch (Throwable ex) {
                LogHelper.printStackTrace(ex);
            }
        }
        return b;
    }

    public static Bitmap rotateSquerBitmap(Bitmap b, int degrees) {

        Matrix m = new Matrix();
        int width = b.getWidth();
        int height = b.getHeight();
        int x = 0;
        int y = 0;

        if (width > height) {
            x = Math.abs(width - height) / 2;
            width = width - x * 2;
        } else {
            y = Math.abs(width - height) / 2;
            height = height - y * 2;
        }
        if (degrees != 0) {
            m.setRotate(degrees, b.getWidth() / 2, b.getHeight() / 2);
        }
        try {
            Bitmap b2 = Bitmap.createBitmap(b, x, y, width,
                    height, m, true);
            // b.recycle();
            // b = null;
            return b2;
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        } catch (Throwable ex) {
            LogHelper.printStackTrace(ex);
        }

        return b;
    }

    public static boolean isLargeImage(BitmapFactory.Options options) {

        return (options.outHeight > 0 && options.outWidth > 0) ? (options.outHeight
                / options.outWidth >= 3)
                : false;
    }

    public static void writeBitmap(Context context, String path, String name,
                                   Bitmap bitmap) {
        int compress = getBitmapCompress(context, bitmap);
        writeBitmap(path, name, bitmap, compress);
    }

    public static boolean writeBitmap(String path, String name, Bitmap bitmap,
                                      int compressRate) {
        if (null == bitmap || TextUtils.isEmpty(path)
                || TextUtils.isEmpty(name))
            return false;
        boolean bPng = false;
        if (name.endsWith(".png")) {
            bPng = true;
        }

        File file = new File(path);
        if (!file.exists()) {
            file.mkdirs();
        }

        File _file = new File(path, name);
        boolean bNew = true;
        if (_file.exists()) {
            bNew = false;
            _file = new File(path, name + ".tmp");
            _file.delete();
        }
        FileOutputStream fos = null;
        boolean bOK = false;
        try {
            fos = new FileOutputStream(_file);
            if (bPng) {
                bitmap.compress(Bitmap.CompressFormat.PNG, compressRate, fos);
            } else {
                bitmap.compress(Bitmap.CompressFormat.JPEG, compressRate, fos);
            }
            bOK = true;
            return true;
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        } catch (Throwable t) {
            LogHelper.printStackTrace(t);
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                    if (bNew == false && bOK) {
                        _file.renameTo(new File(path, name));
                    }
                } catch (IOException e) {
                }
            }
        }
        return false;
    }

    public static boolean writeBitmap(String path, Bitmap bitmap,
                                      int compressRate) {
        if (null == bitmap || TextUtils.isEmpty(path))
            return false;

        File file = new File(path);
        if (file.exists()) {
            file.delete();
        }
        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.PNG, compressRate, fos);
            return true;
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        } catch (Throwable t) {
            LogHelper.printStackTrace(t);
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                }
            }
        }
        return false;
    }


    public static Bitmap toGrayscale(Bitmap bmpOriginal) {
        int width, height;
        height = bmpOriginal.getHeight();
        width = bmpOriginal.getWidth();

        Bitmap bmpGrayscale = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmpGrayscale);
        Paint paint = new Paint();
        ColorMatrix cm = new ColorMatrix();
        cm.setSaturation(0.2f);
        ColorMatrixColorFilter f = new ColorMatrixColorFilter(cm);
        paint.setColorFilter(f);
        c.drawBitmap(bmpOriginal, 0, 0, paint);
        return bmpGrayscale;
    }

    public static Bitmap takeScreenShot(Activity activity, int height, int y) {
        // View是你需要截图的View
        View view = activity.getWindow().getDecorView();

        boolean willNotCache = view.willNotCacheDrawing();
        view.setWillNotCacheDrawing(false);
        int color = view.getDrawingCacheBackgroundColor();

        view.setDrawingCacheBackgroundColor(0);

        if (color != 0) {
            view.destroyDrawingCache();
        }

        view.setDrawingCacheEnabled(true);
        view.buildDrawingCache();
        Bitmap b1 = view.getDrawingCache();
        // 获取状态栏高度
        Rect frame = new Rect();
        activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int statusBarHeight = frame.top;
        // 获取屏幕长和高
        int width = activity.getWindowManager().getDefaultDisplay().getWidth();
        if (y < 0) {
            y = 0;
        }
        if (height == 0) {
            height = activity.getWindowManager().getDefaultDisplay()
                    .getHeight() - y;
        }
        if (height - statusBarHeight <= 0) {
            return null;
        }
        // 去掉标题栏
        // Bitmap b = Bitmap.createBitmap(b1, 0, 25, 320, 455);
        Bitmap b = Bitmap.createBitmap(b1, 0, statusBarHeight + y, width, height
                - statusBarHeight);
        view.destroyDrawingCache();

        view.setWillNotCacheDrawing(willNotCache);

        view.setDrawingCacheBackgroundColor(color);
        return b;
    }


    public static Bitmap takeScreenshot(Context context, View v, int height, int y) {
        v.clearFocus(); //

        v.setPressed(false); //

        // 能画缓存就返回false

        boolean willNotCache = v.willNotCacheDrawing();

        v.setWillNotCacheDrawing(false);

        int color = v.getDrawingCacheBackgroundColor();

        v.setDrawingCacheBackgroundColor(0);

        if (color != 0) {

            v.destroyDrawingCache();
        }

        v.buildDrawingCache();

        Bitmap cacheBitmap = v.getDrawingCache();

        if (cacheBitmap == null) {
            return null;
        }

        // 获取状态栏高度
        int statusBarHeight = LocalDisplay.getStatusBarHeight(context);

        if (height == 0 && y == 0) {
            height = v.getHeight();
            y = 1;
        }
        if (height == 0) {
            height = v.getHeight();
        }

        if (y != 0) {
            height = height - y;
        } else {
            height = height - statusBarHeight;
        }
//
        if (height <= 0) {
            return null;
        }
        if (height > v.getHeight()) {
            return null;
        }
        Bitmap bitmap = Bitmap.createBitmap(cacheBitmap, 0, y, ScreenUtil.getScreenWidth(context), height);

//
        v.destroyDrawingCache();
//
        v.setWillNotCacheDrawing(willNotCache);
//
        v.setDrawingCacheBackgroundColor(color);

        return bitmap;
    }

    public static Bitmap takeScreenShot(Activity activity,int topHeight){
        // View是你需要截图的View
        View view = activity.getWindow().getDecorView();

        boolean willNotCache = view.willNotCacheDrawing();
        view.setWillNotCacheDrawing(false);
        int color = view.getDrawingCacheBackgroundColor();

        view.setDrawingCacheBackgroundColor(0);

        if (color != 0) {
            view.destroyDrawingCache();
        }

        view.setDrawingCacheEnabled(true);
        view.buildDrawingCache();
        Bitmap b1 = view.getDrawingCache();
        // 获取状态栏高度
        Rect frame = new Rect();
        activity.getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int statusBarHeight = frame.top;
        // 获取屏幕长和高
        DisplayMetrics dm = activity.getResources().getDisplayMetrics();
        // 去掉标题栏
        Bitmap b = Bitmap.createBitmap(b1, 0, statusBarHeight + topHeight, dm.widthPixels, dm.heightPixels
                - statusBarHeight-topHeight);
        view.destroyDrawingCache();

        view.setWillNotCacheDrawing(willNotCache);

        view.setDrawingCacheBackgroundColor(color);
        return b;
    }

    public static Drawable blur(Context context,Bitmap bkg, View view) {
        float scaleFactor;
        float radius;
        scaleFactor = 6;
        radius = 20;

        if(view.getMeasuredHeight() >0 && view.getMeasuredWidth()>0){
            Bitmap overlay = Bitmap.createBitmap((int) (view.getMeasuredWidth() / scaleFactor),
                    (int) (view.getMeasuredHeight() / scaleFactor), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(overlay);
            canvas.translate(-view.getLeft() / scaleFactor, -view.getTop() / scaleFactor);
            Paint paint = new Paint();
            paint.setFlags(Paint.FILTER_BITMAP_FLAG);
            canvas.drawBitmap(bkg, null, new Rect(0, 0, (int) (view.getMeasuredWidth() / scaleFactor)
                    , (int) (view.getMeasuredHeight() / scaleFactor)), paint);
            overlay = FastBlur.doBlur(overlay, (int) radius, true);
            return new BitmapDrawable(context.getResources(), overlay);
        }
        return null;

    }

    public static Bitmap CaptureScreen(Context context, View v, int height, int y) {

        int statusBarHeight = LocalDisplay.getStatusBarHeight(context);

        if (height == 0 && y == 0) {
            height = v.getHeight();
            y = 1;
        }
        if (height == 0) {
            height = v.getHeight();
        }

        if (y != 0) {
            height = height - y;
        } else {
            height = height - statusBarHeight;
        }
//
        if (height < 0) {
            return null;
        }
        if (height > v.getHeight()) {
            return null;
        }
//        if(y==0){
        Bitmap bitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);

        Bitmap finalmap = Bitmap.createBitmap(bitmap, 0, y, v.getWidth(), height);
        v.draw(new Canvas(finalmap));
        return finalmap;
//        }else{
//            Bitmap bitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);
//            v.draw(new Canvas(bitmap));
//            Bitmap finalmap = Bitmap.createBitmap(bitmap, 0, y, v.getWidth(), height);
//            return finalmap;
//        }

    }




    public static Bitmap CaptureScreenTop(Context context, View v, int height) {
        int statusBarHeight = LocalDisplay.getStatusBarHeight(context);
        int bitmapHeight = height - statusBarHeight;
        if (bitmapHeight > v.getHeight() || bitmapHeight < 0) {
            return null;
        }
        Bitmap bitmap = Bitmap.createBitmap(v.getWidth(), bitmapHeight, Bitmap.Config.ARGB_8888);

        v.draw(new Canvas(bitmap));
        return bitmap;
    }

    public static Bitmap CaptureScreenBottom(Context context, View v, int height, int y) {
//        int statusBarHeight = KaDaApplication.getStatusBarHeight(context);
        int bitmapHeight = height;
        if (bitmapHeight == 0) {
            bitmapHeight = v.getHeight();
        }
        Bitmap bitmap = Bitmap.createBitmap(v.getWidth(), v.getHeight(), Bitmap.Config.ARGB_8888);
        v.draw(new Canvas(bitmap));

        if (bitmapHeight - y < 0 || bitmapHeight - y > v.getHeight()) {
            return null;
        }
        Bitmap finalbitmap = Bitmap.createBitmap(bitmap, 0, y, v.getWidth(), bitmapHeight - y);

        return finalbitmap;
    }


    public static void blur(Context context,Bitmap bkg, View view, float radius) {
        int versioncode ;
        try {
            versioncode = Integer.valueOf(android.os.Build.VERSION.SDK);
        } catch (NumberFormatException e) {
            versioncode = 0;
        }
        if(versioncode >= 17){
            Bitmap overlay = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(overlay);
            canvas.drawBitmap(bkg, -view.getLeft(), -view.getTop(), null);
            RenderScript rs = RenderScript.create(context);
            Allocation overlayAlloc = Allocation.createFromBitmap(rs, overlay);
            ScriptIntrinsicBlur blur = ScriptIntrinsicBlur.create(rs, overlayAlloc.getElement());
            blur.setInput(overlayAlloc);
            blur.setRadius(radius);
            blur.forEach(overlayAlloc);
            overlayAlloc.copyTo(overlay);
            view.setBackground(new BitmapDrawable(context.getResources(), overlay));
            rs.destroy();
        }

    }


    public static String compressImage(String filePath, String targetPath, int quality)  {
        Bitmap bm = getSmallBitmap(filePath);//获取一定尺寸的图片
        int degree = readPictureDegree(filePath);//获取相片拍摄角度
        if(degree!=0){//旋转照片角度，防止头像横着显示
            bm=rotateBitmap(bm,degree);
        }
        File outputFile=new File(targetPath);
        try {
            if (!outputFile.exists()) {
                outputFile.getParentFile().mkdirs();
                //outputFile.createNewFile();
            }else{
                outputFile.delete();
            }
            FileOutputStream out = new FileOutputStream(outputFile);
            bm.compress(Bitmap.CompressFormat.JPEG, quality, out);
        }catch (Exception e){}
        return outputFile.getPath();
    }

    /**
     * 根据路径获得图片信息并按比例压缩，返回bitmap
     */
    public static Bitmap getSmallBitmap(String filePath) {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;//只解析图片边沿，获取宽高
        BitmapFactory.decodeFile(filePath, options);
        // 计算缩放比
        options.inSampleSize = calculateInSampleSize(options, 480, 800);
        // 完整解析图片返回bitmap
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeFile(filePath, options);
    }

    /**
     * 获取照片角度
     * @param path
     * @return
     */
    public static int readPictureDegree(String path) {
        int degree = 0;
        try {
            ExifInterface exifInterface = new ExifInterface(path);
            int orientation = exifInterface.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    degree = 90;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    degree = 180;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    degree = 270;
                    break;
            }
        } catch (IOException e) {
            LogHelper.printStackTrace(e);
        }
        return degree;
    }

    public static Bitmap resourceToBitmap(Context context,int drawableId){
        Resources resources = context.getResources();
        Bitmap bmp= BitmapFactory.decodeResource(resources,drawableId);
        return bmp;
    }

    public static Bitmap readBitmap(Context context, int resId){
        BitmapFactory.Options opt =new BitmapFactory.Options();
        opt.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeResource(context.getResources(), resId, opt);
    }
}
