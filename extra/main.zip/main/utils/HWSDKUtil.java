package com.hhdd.kada.main.utils;

import android.text.TextUtils;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.main.model.AccountUnifyInfo;
import com.hhdd.kada.main.model.HWLoginInfo;
import com.hhdd.logger.LogHelper;
import com.huawei.android.hms.agent.HMSAgent;
import com.huawei.android.hms.agent.hwid.handler.SignInHandler;
import com.huawei.hms.support.api.hwid.SignInHuaweiId;

import java.lang.reflect.Method;
import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/7/17
 * @describe : com.hhdd.kada.main.utils 华为sdk工具类(壳)(待优化)
 */
public class HWSDKUtil {

    private static StrongReference<DefaultCallback> hwLoginStrongReference;
    private static StrongReference<DefaultCallback> validateHWStrongReference;
    private static final String HW_CHANNEL = "huawei";
    private static final int TYPE_LOGIN = 1; // 华为登录
    private static final int TYPE_BIND = TYPE_LOGIN + 1; //绑定华为帐号

    /**
     * 华为授权登录
     * @param type
     * @param handler
     */
    private static void authLogin(final int type, final HWLoginHandler handler) {
        HMSAgent.Hwid.signIn(true, new SignInHandler() {
            @Override
            public void onResult(int rst, SignInHuaweiId result) {
                if (rst == 0 && result != null) {
                    switch (type) {
                        case TYPE_LOGIN:
                            hwLogin(result, handler);
                            break;
                        case TYPE_BIND:
                            validateHWAccount(result, handler);
                            break;
                        default:
                            break;
                    }
                } else {
                    if (handler != null) {
                        handler.onFail(rst, KaDaApplication.instance.getResources()
                                .getString(R.string.hw_login_fail_text));
                    }
                }
            }
        });
    }

    /**
     * 华为登录
     *
     * @param handler
     */
    public static void login(final HWLoginHandler<HWLoginInfo> handler) {
        authLogin(TYPE_LOGIN, handler);
    }

    /**
     * 华为授权登录成功后去服务端进行登录操作
     *
     * @param result
     * @param handler
     */
    private static void hwLogin(SignInHuaweiId result, final HWLoginHandler<HWLoginInfo> handler) {
        if (hwLoginStrongReference == null) {
            hwLoginStrongReference = new StrongReference<>();
        }
        DefaultCallback<HWLoginInfo> loginCallback = new DefaultCallback<HWLoginInfo>() {
            @Override
            public void onDataReceived(final HWLoginInfo data) {
                if (handler != null) {
                    handler.onSuccess(data);
                }
            }

            @Override
            public void onException(int code, String reason) {
                if (handler != null) {
                    handler.onFail(code, reason);
                }
            }
        };
        hwLoginStrongReference.set(loginCallback);
        UserAPI.hwLogin(result.getOpenId(), result.getUnionId(), result.getAccessToken(),
                result.getDisplayName(), result.getPhotoUrl(), hwLoginStrongReference);
    }

    /**
     * 绑定华为帐号
     *
     * @param handler
     */
    public static void bindHWAccount(final HWLoginHandler<List<AccountUnifyInfo>> handler) {
        authLogin(TYPE_BIND, handler);
    }

    /**
     * 验证绑定华为帐号
     *
     * @param result
     * @param handler
     */
    private static void validateHWAccount(SignInHuaweiId result, final HWLoginHandler<List<AccountUnifyInfo>> handler) {
        int userAccountType = UserService.getInstance().getUserAccountType();
        if (userAccountType == 0 && handler != null) {
            handler.onFail(0, "当前登录帐号类型异常");
            return;
        }
        if (validateHWStrongReference == null) {
            validateHWStrongReference = new StrongReference<>();
        }
        DefaultCallback callback = new DefaultCallback<List<AccountUnifyInfo>>() {
            @Override
            public void onDataReceived(final List<AccountUnifyInfo> data) {
                if (handler != null) {
                    handler.onSuccess(data);
                }
            }

            @Override
            public void onException(int code, String reason) {
                if (handler != null) {
                    handler.onFail(code, reason);
                }
            }
        };
        validateHWStrongReference.set(callback);
        UserAPI.validateHW(userAccountType, result.getOpenId(), result.getUnionId(), result.getAccessToken(),
                result.getDisplayName(), result.getPhotoUrl(), validateHWStrongReference);
    }

    /**
     * 清除接口回调资源
     */
    public static void clearLoginReference() {
        if (hwLoginStrongReference != null) {
            hwLoginStrongReference.clear();
            hwLoginStrongReference = null;
        }
    }

    /**
     * 清除接口回调资源
     */
    public static void clearValidateHWReference() {
        if (validateHWStrongReference != null) {
            validateHWStrongReference.clear();
            validateHWStrongReference = null;
        }
    }

    /**
     * 退出app时回收资源
     */
    public static void destroy() {
        clearLoginReference();
        clearValidateHWReference();
    }

    public interface HWLoginHandler<T> {
        /**
         * 华为登录成功
         *
         * @param t
         */
        void onSuccess(T t);

        /**
         * 华为登录失败
         */
        void onFail(int errorCode, String message);
    }

    /**
     * 判断是否为华为机器 emuiVersion不为空则为华为机器
     *
     * @return
     */
    public static String getEmuiVersion() {
        String emuiVersion = "";
        Class<?>[] clsArray = new Class<?>[]{String.class};
        Object[] objArray = new Object[]{"ro.build.version.emui"};
        try {
            Class<?> SystemPropertiesClass = Class.forName("android.os.SystemProperties");
            Method get = SystemPropertiesClass.getDeclaredMethod("get", clsArray);
            String version = (String) get.invoke(SystemPropertiesClass, objArray);
            LogHelper.d("get EMUI version is:" + version);
            if (!TextUtils.isEmpty(version)) {
                return version;
            }
        } catch (ClassNotFoundException e) {
            LogHelper.e(" getEmuiVersion wrong, ClassNotFoundException");
        } catch (LinkageError e) {
            LogHelper.e(" getEmuiVersion wrong, LinkageError");
        } catch (NoSuchMethodException e) {
            LogHelper.e(" getEmuiVersion wrong, NoSuchMethodException");
        } catch (NullPointerException e) {
            LogHelper.e(" getEmuiVersion wrong, NullPointerException");
        } catch (Exception e) {
            LogHelper.e(" getEmuiVersion wrong");
        }
        return emuiVersion;
    }

    /**
     * 判断是否为华为设备
     *
     * @return
     */
    public static boolean isHuaWeiDevice() {
        return !TextUtils.isEmpty(getEmuiVersion());
    }

    /**
     * 华为渠道并且是华为设备，显示华为相关内容(登录，帐号信息等)
     *
     * @return
     */
    public static boolean isShowHuaWeiInfo() {
        return HW_CHANNEL.equals(AppUtils.getChannelData(KaDaApplication.instance));
    }
}
