package com.hhdd.kada.main.utils;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.kada.Constants;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.settings.Settings;

import java.util.Calendar;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/3/7
 * @describe : com.hhdd.kada.main.utils
 */
public class RestSleepUtil {

    public static final int NOT_IN_REST = 0; //未在休息时间且未在睡眠时间内
    public static final int IN_REST_TIME = 1; //休息时间内
    public static final int IN_SLEEP_TIME = 2; //睡眠时间内

    /**
     * 检测当前时间是否处于休息时间或睡眠时间
     * @return
     */
    public static int checkTimeInRestSleep() {
        PrefsManager prefsManager = ((PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER));
        boolean unEnabledSleepTime = prefsManager.getBoolean(Constants.KEY_SLEEP_TIME_UNENABLED, true);
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        Settings settings = Settings.getInstance();
        int sleepTime = settings.getSleepTime();
        int wakeUpTime = settings.getWakeUpTime();
        boolean showSleepPage = !unEnabledSleepTime && (hour >= sleepTime || hour < wakeUpTime);
        if (showSleepPage) {
            return IN_SLEEP_TIME;
        } else {
            long restTimeStart = prefsManager.getLong(Constants.REST_TIME_START);
            if(restTimeStart > 0) {
                int restTimeSecond = settings.getRestTime();
                boolean inRestTime = (System.currentTimeMillis() - restTimeStart) / 1000 < restTimeSecond;
                if (inRestTime) {
                    return IN_REST_TIME;
                }
            }
            return NOT_IN_REST;
        }
    }
}
