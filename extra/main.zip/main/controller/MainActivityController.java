package com.hhdd.kada.main.controller;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.support.v4.util.LongSparseArray;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.android.thread.IThread;
import com.hhdd.core.UpdateManager;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.Client;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.UserAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.coin.event.GetDailyTaskListEvent;
import com.hhdd.kada.download.DownloadManager;
import com.hhdd.kada.main.event.CookieExpireDialogActivityFinishEvent;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.LogoutEvent;
import com.hhdd.kada.main.event.ShowCookieExpiredDialogEvent;
import com.hhdd.kada.main.listen.ListenActivity;
import com.hhdd.kada.main.listen.ListenService2;
import com.hhdd.kada.main.manager.DialogManager;
import com.hhdd.kada.main.manager.TimeOutManager;
import com.hhdd.kada.main.ui.dialog.CookieExpireDialogActivity;
import com.hhdd.kada.main.ui.dialog.SettingDialog;
import com.hhdd.kada.main.ui.fragment.InitFragment;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.PrefsManager;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.medal.Medal;
import com.hhdd.kada.medal.MedalDialog;
import com.hhdd.kada.medal.MedalGrantedEvent;
import com.hhdd.kada.medal.MedalManager;
import com.hhdd.kada.medal.UserTrack;
import com.hhdd.kada.module.userhabit.StaPageName;
import com.hhdd.logger.LogHelper;

import net.ellerton.japng.android.api.PngAndroid;
import net.ellerton.japng.error.PngException;

import java.io.IOException;
import java.lang.reflect.Field;

import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.controller
 */
public class MainActivityController extends BaseController {

    private Handler handler = new Handler();
    private Context context;
    private boolean isVisiable;
    private CallBack callBack;
    private boolean isCookieExpiredDialogShowing = false;
    private StrongReference<DefaultCallback> userLoginTypeReference;

    public MainActivityController(Context context) {
        this.context = context;
    }

    public void setCallBack(CallBack callBack) {
        this.callBack = callBack;
    }

    @Override
    public void initData() {
        super.initData();
        ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE)).postDaemonTask(new Runnable() {
            @Override
            public void run() {
                releasePreloadedDrawable();
            }
        }, "releasePreloadedDrawable");

        EventBus.getDefault().register(this);
        //提交个推token
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ((Client) ServiceProxyFactory.getProxy().getService(ServiceProxyName.CLIENT)).commitToken();
            }
        }, 5000);


        // 检查版本升级
        handler.post(new Runnable() {
            @Override
            public void run() {
                String serviceVersion = ((UpdateManager) (ServiceProxyFactory.getProxy().getService(ServiceProxyName.UPDATE_MANAGER))).getServerVersion();
                if (serviceVersion != null && serviceVersion.length() > 0) {
                    onEvent(new CheckUpdateEvent());
                }
            }
        });


//        if (UserService.getInstance().isLogining()) {
//            handler.post(new Runnable() {
//                @Override
//                public void run() {
//                    checkAndRemindUnCompleteDownloads();
//                }
//            });
//        }

        handler.post(new Runnable() {
            @Override
            public void run() {
                checkCollectionStatus();
            }
        });

        getUserLoginType();
    }

    /**
     * 获取当前登录用户登录类型，修改逻辑如下
     * v3.6.0版本以前用户未退出登录一直升级到v3.7.5，此时本地无登录类型数据，会请求该接口从服务端查询，
     * 若该用户之前未绑定过，服务器可以查询出当前登录用户的登录类型，并返回，客户端记录保存
     * 若该用户在v3.6.5-v3.7.5(当前版本)绑定过帐号，服务端无法查询出此时的登录类型，客户端仍然无法保存，此时，
     * 当该类型用户再去进行第二次(比如微信手机绑定帐号再去绑定华为帐号)，客户端会根据本地是否记录登录类型做判断，
     * 如果本地无登录类型，弹框提示用户继续绑定需要重新登录（设置中操作立即绑定触发）
     */
    private void getUserLoginType() {
        if (!UserService.getInstance().isLogining() || UserService.getInstance().getUserAccountType() > 0) {
            return;
        }
        DefaultCallback<String> callback = new DefaultCallback<String>() {
            @Override
            public void onDataReceived(String responseData) {
                if (!TextUtils.isEmpty(responseData)) {
                    int lastLoginWay = getLastLoginWay(responseData);
                    if (lastLoginWay > 0) {
                        PrefsManager prefsManager = (PrefsManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.PREFS_MANAGER);
                        prefsManager.putInt(Constants.LAST_LOGIN_WAY, lastLoginWay);
                    }
                }
            }

            @Override
            public void onException(int code, String reason) {

            }
        };
        if(userLoginTypeReference == null) {
            userLoginTypeReference = new StrongReference<>();
        }
        userLoginTypeReference.set(callback);
        UserAPI.getUserLoginType(userLoginTypeReference);
    }

    /**
     * 获取对应本地上次登录类型
     * @param userLoginType
     * @return
     */
    private int getLastLoginWay(String userLoginType) {
        try {
            int loginType = Integer.parseInt(userLoginType);
            if (loginType == 1) {
                return InitFragment.LAST_LOGIN_WAY_IS_PHONE;
            } else if (loginType == 2) {
                return InitFragment.LAST_LOGIN_WAY_IS_WX;
            } else if (loginType == 3) {
                return InitFragment.LAST_LOGIN_WAY_IS_HW;
            }
        } catch (NumberFormatException e) {
            LogHelper.printStackTrace(e);
        }
        return 0;
    }

    @Override
    public void onResume() {
        super.onResume();
        isVisiable = true;

        ((TimeOutManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.TIME_OUT_MANAGER)).stopCheck();

        Client client = (Client) ServiceProxyFactory.getProxy().getService(ServiceProxyName.CLIENT);
        if (client.needShowCookieExpiredDialog()) {
            showCookieExpireDialog(); // 显示登陆过期弹窗
            return;
        }

        doCheckIfNeedDisplayMedal();

        //重新检查下是否显示设置对话框，防止程序切换到后台
        if (((TimeOutManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.TIME_OUT_MANAGER)).isSettingDialogNeedDisplay() && isVisiable) {
            if (context == null) {
                return;
            }
            if (context instanceof Activity) {
                if (((Activity) context).isFinishing()) {
                    return;
                }
            }
            SettingDialog dialog = new SettingDialog(context);
            dialog.show();
        }

        if (isVisiable) {
            if (((UserTrack) ServiceProxyFactory.getProxy().getService(ServiceProxyName.USER_TRACK)).isNeedCommit()) {
                ((UserTrack) ServiceProxyFactory.getProxy().getService(ServiceProxyName.USER_TRACK)).triggerCommit();
                ((MedalManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.MEDAL_MANAGER)).triggerNewGrantedMedals();
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        isVisiable = false;
    }

    /**
     * 检查是否有未完成下载任务
     */
    private void checkAndRemindUnCompleteDownloads() {
        long unCompeteItemsCount = ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).unCompeteItemsCount();
        if (unCompeteItemsCount > 0 && !((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).hasDownloadingItems()) {
            AlertDialog alertDialog = new AlertDialog.Builder(context)
                    .setMessage("\n有未完成的下载任务,是否继续下载？")
                    .setNegativeButton("继续", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int whichButton) {
                            dialog.dismiss();
                            if (NetworkUtils.isNetworkAvailable(context)) {
                                ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).reAddAllUnCompleteTasks();
                                ToastUtils.showToast("下载任务已经恢复哦");
                            } else {
                                ToastUtils.showToast("请检查网路连接");
                            }
                        }
                    }).setPositiveButton("清除", new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog,
                                            int whichButton) {
                            ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).removeAllPendingTasks(false);
                            dialog.dismiss();
                        }
                    }).create();
            if (context instanceof Activity && !((Activity) context).isFinishing()) {
                alertDialog.show();
            }
        }
    }

    /**
     * 检查合辑状态，将downloading状态的合辑置为pause
     */
    private void checkCollectionStatus() {
        long unCompeteItemsCount = ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).unCompeteCollectionItemsCount();
        if (unCompeteItemsCount > 0) {
            ((DownloadManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DOWNLOAD_MANAGER)).initialAllCollectionStatus();
        }
    }


    private void doCheckIfNeedDisplayMedal() {
        if (((AuthService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.AUTH_SERVICE)).isAuthorized()) {
            handler.removeCallbacks(mDisplayMedalRunnable);
            handler.postDelayed(mDisplayMedalRunnable, 2000);
        }
    }

    private Runnable mDisplayMedalRunnable = new Runnable() {
        @Override
        public void run() {
            if (context == null) {
                return;
            }

            if (context instanceof Activity) {
                if (((Activity) context).isFinishing()) {
                    return;
                }
            }

            if (isVisiable) {
                Medal medalInfo = ((MedalManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.MEDAL_MANAGER)).fetchOneNewGrantedMealForDisplay();
                if (medalInfo != null) {
                    String imageUrl = medalInfo.isReceive() ? medalInfo.getGainImg() : medalInfo.getUnGainImg();
                    MedalDialog mMedalDialog = new MedalDialog(context, medalInfo, (int) medalInfo.getMedalId(), CdnUtils.getImgCdnUrl(imageUrl), medalInfo.getName(), true, true);
//                    mMedalDialog.show();

                    //获得勋章 只在界面没有dialog展示时显示 否则不加入dialog显示列表
//                    if (!((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).isDialogShow()) {
                    ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).showDialog(mMedalDialog);
//                    }

                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.show_medal_auto, TimeUtil.currentTime()));
                }
            }
        }
    };

    //=========================================================================================

    boolean isShow = true;

    public void onEvent(LoginEvent event) {
        isShow = false;

        //切换用户，需停止听书播放
        try {
            Intent listenIntent = new Intent(KaDaApplication.getInstance(), ListenService2.class);
            listenIntent.setAction(ListenService2.INTENT_ACTION);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_TYPE, ListenService2.Types.STOP);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_NEED_COMMIT, true);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_REMOVE_NOTIFICATION, true);
            KaDaApplication.getInstance().startService(listenIntent);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        hideFloatView();

    }

    public void onEvent(LogoutEvent event) {
        //切换用户，需停止听书播放
        try {
            Intent listenIntent = new Intent(KaDaApplication.getInstance(), ListenService2.class);
            listenIntent.setAction(ListenService2.INTENT_ACTION);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_TYPE, ListenService2.Types.STOP);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_NEED_COMMIT, true);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_REMOVE_NOTIFICATION, true);
            KaDaApplication.getInstance().startService(listenIntent);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        hideFloatView();
    }

    public void onEvent(GetDailyTaskListEvent event) {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isShow) {
                    isShow = true;
                    if (callBack != null) {
                        callBack.showRedDot();
                    }
                }
            }
        }, 20);
    }

    // IGrantMedal
    public void onEvent(MedalGrantedEvent event) {
        doCheckIfNeedDisplayMedal();
    }

    public void onEvent(CheckUpdateEvent event) {
        UserHabitService.getInstance().track(UserHabitService.newUserHabit("update_notice_view", "", TimeUtil.currentTime()));
        ((UpdateManager) (ServiceProxyFactory.getProxy().getService(ServiceProxyName.UPDATE_MANAGER))).showNoticeDialog(context, null, false);
    }


    public static class CheckUpdateEvent {

    }

    public void onEvent(CookieExpireDialogActivityFinishEvent event) {
        isCookieExpiredDialogShowing = false;
    }

    public void onEventMainThread(ShowCookieExpiredDialogEvent event) {
        showCookieExpireDialog();
    }

    private void showCookieExpireDialog() {
        try {
            if (!isCookieExpiredDialogShowing) {
                isCookieExpiredDialogShowing = true;

                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "account_login_expiration_view", TimeUtil.currentTime()));

                ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).dismissAllDialog();
                ActivityUtil.next(context, CookieExpireDialogActivity.class);
            }
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
    }


    //==========================================================================================================================
    //==========================================================================================================================
    // 听书动画 未获得悬浮框权限时 在MainActivity中显示动画
    //==========================================================================================================================
    //==========================================================================================================================
    private int screenWidth;
    private int screenHeight;
    int lastX;
    int lastY;
    int lastXDown;
    int lastYDown;
    ImageView btn_floatView;
    Drawable btn_floatView_drawable = null;
    boolean isMove = false;

    public ImageView initFloatView() {
        if (btn_floatView != null) {

        } else {
            screenWidth = context.getResources().getDisplayMetrics().widthPixels;
            screenHeight = context.getResources().getDisplayMetrics().heightPixels;

            btn_floatView = new ImageView(context);
            btn_floatView.setVisibility(View.INVISIBLE);

            btn_floatView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (isMove) {

                    } else {
                        ListenActivity.startActivity(context, true);
                    }
                }
            });

            btn_floatView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    // TODO Auto-generated method stub
                    int action = event.getAction();

                    //Toast.makeText(DraftTest.this, "λ�ã�"+x+","+y, Toast.LENGTH_SHORT).show();
                    switch (action) {
                        case MotionEvent.ACTION_DOWN:
                            lastX = (int) event.getRawX();
                            lastY = (int) event.getRawY();
                            lastXDown = lastX;
                            lastYDown = lastY;
                            break;
                        /**
                         * layout(l,t,r,b)
                         * l  Left position, relative to parent
                         t  Top position, relative to parent
                         r  Right position, relative to parent
                         b  Bottom position, relative to parent
                         * */
                        case MotionEvent.ACTION_MOVE:
                            int dx = (int) event.getRawX() - lastX;
                            int dy = (int) event.getRawY() - lastY;

                            int left = v.getLeft() + dx;
                            int top = v.getTop() + dy;
                            int right = v.getRight() + dx;
                            int bottom = v.getBottom() + dy;
                            if (left < 0) {
                                left = 0;
                                right = left + v.getWidth();
                            }
                            if (right > screenWidth) {
                                right = screenWidth;
                                left = right - v.getWidth();
                            }
                            if (top < 0) {
                                top = 0;
                                bottom = top + v.getHeight();
                            }
                            if (bottom > screenHeight - context.getResources().getDimension(R.dimen.tab_activity_bottom_height)) {
                                bottom = screenHeight - (int) context.getResources().getDimension(R.dimen.tab_activity_bottom_height);
                                top = bottom - v.getHeight();
                            }
                            v.layout(left, top, right, bottom);
                            ((RelativeLayout.LayoutParams) (v.getLayoutParams())).setMargins(left, top, 0, 0);
                            lastX = (int) event.getRawX();
                            lastY = (int) event.getRawY();

                            break;
                        case MotionEvent.ACTION_UP:
                            if (Math.abs(event.getRawX() - lastXDown) < 10 && Math.abs(event.getRawY() - lastYDown) < 10) {
                                isMove = false;
                            } else {
                                isMove = true;
                            }
                            break;
                    }
                    return false;
                }
            });
        }
        return btn_floatView;
    }

    public static class OnShowFloatingWindowEvent {

    }

    public static class OnHideFloatingWindowEvent {

    }

    public void onEvent(OnShowFloatingWindowEvent event) {
        initFloatView();
        ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE)).postDaemonTask(showFloatViewRunnable, "LoadFloatViewJob");
    }

    private Runnable showFloatViewRunnable = new Runnable() {
        @Override
        public void run() {
            if (btn_floatView_drawable == null || !(btn_floatView_drawable instanceof AnimationDrawable)) {
                try {
                    btn_floatView_drawable = PngAndroid.readDrawable(context.getApplicationContext(), context.getAssets().open("apng/listen_icon.png"));
                } catch (PngException e) {
                    LogHelper.printStackTrace(e);
                } catch (IOException e) {
                    LogHelper.printStackTrace(e);
                } catch (Exception e) {
                    LogHelper.printStackTrace(e);
                }
            }
            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (btn_floatView != null && btn_floatView_drawable != null) {
                        btn_floatView.setImageDrawable(btn_floatView_drawable);
                        ((AnimationDrawable) btn_floatView_drawable).start();
                        btn_floatView.setVisibility(View.VISIBLE);
                    }
                }
            });
        }
    };

    public void onEvent(OnHideFloatingWindowEvent event) {
        hideFloatView();
    }

    private void hideFloatView() {
        if (btn_floatView_drawable != null) {
            ((AnimationDrawable) btn_floatView_drawable).stop();
            ((AnimationDrawable) btn_floatView_drawable).selectDrawable(0);
            btn_floatView_drawable = null;
        }
        if (btn_floatView != null) {
            btn_floatView.setVisibility(View.INVISIBLE);
            btn_floatView.setImageDrawable(null);
        }
    }


    @TargetApi(16)
    private void releasePreloadedDrawable() {
        if (Build.VERSION.SDK_INT < 16) {
            return;
        }
        try {
            Class resources = Resources.class;
            Field field = resources.getDeclaredField("sPreloadedDrawables");
            field.setAccessible(true);

            /**
             * api18后preloadedDrawables变成了数组存储
             * http://grepcode.com/file/repository.grepcode.com/java/ext/com.google.android/android/4.3.1_r1/android/content/res/Resources.java#Resources.0sPreloadedDrawables
             */
            if (Build.VERSION.SDK_INT >= 18 && (field.get(resources) instanceof LongSparseArray[])) {
                LongSparseArray<Drawable.ConstantState>[] preloadDrawables
                        = (LongSparseArray<Drawable.ConstantState>[]) (field.get(resources));

                for (LongSparseArray<Drawable.ConstantState> s : preloadDrawables) {
                    if (null != s) {
                        s.clear();
                    }
                }
            } else {
                if (field.get(resources) instanceof LongSparseArray) {
                    LongSparseArray<Drawable.ConstantState> preloadDrawable
                            = (LongSparseArray<Drawable.ConstantState>) (field.get(resources));
                    if (null != preloadDrawable) {
                        preloadDrawable.clear();
                    }
                }
            }
        } catch (Throwable e) {
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
        handler.removeCallbacksAndMessages(null);
        if (userLoginTypeReference != null) {
            userLoginTypeReference.clear();
            userLoginTypeReference = null;
        }
    }

    public interface CallBack {
        void showRedDot();
    }
}
