package com.hhdd.kada.main.controller;

import android.content.Context;
import android.os.Handler;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.kada.R;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.listener.CollectionSubscribeListener;
import com.hhdd.kada.module.audio.AudioName;
import com.hhdd.kada.module.player.AudioInfo;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;
import com.hhdd.kada.pay.PayManager;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/4/14
 * @describe : com.hhdd.kada.main.controller
 */
public abstract class BaseCollectionSubscribeController implements CollectionSubscribeListener {

    protected Context context;
    protected Handler handler;
    //订阅类型，区分不同页面操作登录订阅/创建订单，仅当前页面做订阅/创建订单操作(防止多页面同时订阅/创建订单)
    protected String subscribeType;
    protected String createOrderType;

    protected IMediaPlayer mShortMediaPlayer;
    private boolean isNeedContinuePlayListen = false;

    public BaseCollectionSubscribeController(Context context, String subscribeType, String createOrderType) {
        this.context = context;
        this.subscribeType = subscribeType;
        this.createOrderType = createOrderType;

        handler = new Handler();
        mShortMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
        mShortMediaPlayer.addOnPlayListener(mOnPlayListener);
    }

    protected void playLetMomSubscribeAudio() {
        if (mShortMediaPlayer != null) {
            isNeedContinuePlayListen = ListenManager.getInstance().isPlayingOrPromptAudioPlaying();

            if (isNeedContinuePlayListen) {
                ListenManager.getInstance().setPausedByShortAudio(true);
                ListenManager.getInstance().pause(false);
            }

            // 停掉背景音
            mShortMediaPlayer.stop(PlayMode.SEQUENCE_PLAY_MODE, AudioName.TAG_BOOK_COLLECTION_BG_AUDIO);

            boolean isPlayingAppStartAudio = false;
            List<AudioInfo> audioInfos = mShortMediaPlayer.getCurrentPlayAudio();
            if (!audioInfos.isEmpty()) {
                for (AudioInfo audioInfo : audioInfos) {
                    if (AudioName.APP_START_AUDIO.equals(audioInfo.mAudioTag)) {
                        isPlayingAppStartAudio = true;
                        break;
                    }
                }
            }

            if (isPlayingAppStartAudio) {
                mShortMediaPlayer.addPlayQueue(R.raw.let_mom_subscribe, PlayMode.SEQUENCE_PLAY_MODE, AudioName.LET_MOM_SUBSCRIBE_AUDIO);
            } else {
                mShortMediaPlayer.addPlayQueue(R.raw.let_mom_subscribe, PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.LET_MOM_SUBSCRIBE_AUDIO);
            }
        }
    }

    /**
     * 资源回收
     */
    public void destroy() {
        handler.removeCallbacksAndMessages(null);
        handler = null;
        DialogFactory.dismissAllDialog(context);
        PayManager.destroy(context);

        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.LET_MOM_SUBSCRIBE_AUDIO);
            mShortMediaPlayer.removeOnPlayListener(mOnPlayListener);
        }
    }

    private OnPlayListener mOnPlayListener = new OnPlayListener() {
        @Override
        public void onPrepared(String audioTag, int playMode) {

        }

        @Override
        public void onCompletion(String audioTag, int playMode) {
            if (AudioName.LET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onError(String audioTag, int playMode) {
            if (AudioName.LET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onStop(String audioTag, int playMode) {
            if (AudioName.LET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }
    };

    private void continuePlayListen() {
        if (isNeedContinuePlayListen || ListenManager.getInstance().isPausedByShortAudio()) {
            isNeedContinuePlayListen = false;

            ListenManager.getInstance().setPause(false);
            ListenManager.getInstance().play();
        }
    }

    /**
     * 点击订阅按钮操作
     */
    public abstract void doSubscribe();

    /**
     * 取消订阅操作
     */
    public abstract void doCancelSubscribe();
}
