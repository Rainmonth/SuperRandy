package com.hhdd.kada.main.controller;

import android.app.Activity;
import android.support.v4.app.Fragment;
import android.text.TextUtils;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.db.DatabaseManager;
import com.hhdd.core.model.ReadingHistoryInfo;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.BookAPI;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.db.main.entities.ReadingHistory;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.listen.ListenManager;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.model.BookInfo;
import com.hhdd.kada.main.model.BookListItem;
import com.hhdd.kada.main.playback.PlaybackActivity;
import com.hhdd.kada.main.playback.event.UpdateBookCollectionDetailEvent;
import com.hhdd.kada.main.ui.book.BookCollectResumeViewHolder;
import com.hhdd.kada.main.ui.book.BookCollectionBannerViewHolder;
import com.hhdd.kada.main.ui.book.BookCollectionFragment;
import com.hhdd.kada.main.ui.book.BookCollectionListViewHolder;
import com.hhdd.kada.main.ui.dialog.ContentIsDeletedDialog;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.SeparatorLineViewHolder;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseModelListVO;
import com.hhdd.kada.main.vo.BaseModelVO;
import com.hhdd.kada.module.audio.AudioName;
import com.hhdd.kada.module.player.AudioInfo;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;
import com.hhdd.logger.LogHelper;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


/**
 * Created by sxh on 2017/8/1.
 */

public class BookCollectionFragmentController extends BaseController {

    private static final int View_Type_Collection_Banner = 1;
    private static final int View_Type_Book_Resume_Play = 2;
    private static final int View_Type_List_Item = 7;
    private static final int View_Type_Sep_Line = 8;

    int playCount = 0;  //记录背景音频是否播放过
    private BookCollectionFragment fragment;
    List<BookListItem> downloadList = new ArrayList<>();   //用于下载
    List<BaseModel> dataList = new ArrayList<>();

    private List<BaseModel> bookListItems;
    private BookCollectionDetailInfo detailInfo;
    private BookCollectionSubscribeController subscribeController;
    private boolean trackHabbit = true;

    private IMediaPlayer mShortMediaPlayer;

    private boolean isNeedMomSubscribeMusicPlaying = false;
    private boolean isNeedContinuePlayListen = false;

    private static final String CREATE_ORDER = BookCollectionFragment.class.getSimpleName() + "_CREATE_ORDER";
    private static final String SUBSCRIBE = BookCollectionFragment.class.getSimpleName() + "_SUBSCRIBE";

    private OnEventProcessor mOnEventProcessor = new OnEventProcessor() {
        @Override
        public boolean process(int type, Object... args) {
            switch (type) {
                case BookCollectionListViewHolder.TYPE_BOOK_ITEM_CLICKED:
                    try {
                        BookInfo bookInfo = (BookInfo) args[0];
                        processBooKItemClicked(bookInfo);
                    } catch (Throwable e) {
                        LogHelper.printStackTrace(e);
                    }
                    return true;
                case BookCollectResumeViewHolder.TYPE_BOOK_RESUME_CLICKED:
                    processCollectResumeClicked();
                    return true;
            }
            return false;
        }
    };

    private StrongReference<DefaultCallback> bookCollectionStrongReference;

    private OnPlayListener mOnPlayListener = new OnPlayListener() {
        @Override
        public void onPrepared(String audioTag, int playMode) {
        }

        @Override
        public void onCompletion(String audioTag, int playMode) {
            if (AudioName.NEET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                isNeedMomSubscribeMusicPlaying = false;

                continuePlayListen();

            } else if (AudioName.TAG_BOOK_COLLECTION_BG_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onError(String audioTag, int playMode) {
            if (AudioName.NEET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                isNeedMomSubscribeMusicPlaying = false;

                continuePlayListen();

            } else if (AudioName.TAG_BOOK_COLLECTION_BG_AUDIO.equals(audioTag)) {
                continuePlayListen();
            }
        }

        @Override
        public void onStop(String audioTag, int playMode) {
            if (AudioName.NEET_MOM_SUBSCRIBE_AUDIO.equals(audioTag)) {
                isNeedMomSubscribeMusicPlaying = false;
            }
        }
    };

    private void continuePlayListen() {
        if (isNeedContinuePlayListen || ListenManager.getInstance().isPausedByShortAudio()) {
            isNeedContinuePlayListen = false;

            ListenManager.getInstance().setPause(false);
            ListenManager.getInstance().play();
        }
    }

    public void setBookCollectionDetailInfo(BookCollectionDetailInfo detailInfo) {
        this.detailInfo = detailInfo;
        if (subscribeController != null) {
            subscribeController.setBookCollectionDetailInfo(detailInfo);
        }
    }

    public BookCollectionDetailInfo getBookCollectionDetailInfo() {
        return detailInfo;
    }

    public BookCollectionSubscribeController getSubscribeController() {
        return subscribeController;
    }

    public List<BookListItem> getDownloadList() {
        return downloadList;
    }

    public void setSubscribedStatus(int type) {
        detailInfo.setSubscribe(type);
    }

    public BookCollectionFragmentController(Fragment fragment) {
        if (fragment != null && fragment instanceof BookCollectionFragment) {
            this.fragment = (BookCollectionFragment) fragment;
        }
    }

    @Override
    public void initView() {
        Map<Integer, Class<?>> map = new HashMap<>();
        map.put(View_Type_Collection_Banner, BookCollectionBannerViewHolder.class);
        map.put(View_Type_List_Item, BookCollectionListViewHolder.class);
        map.put(View_Type_Sep_Line, SeparatorLineViewHolder.class);
        map.put(View_Type_Book_Resume_Play, BookCollectResumeViewHolder.class);

        BaseViewHolderCreator creator = new BaseViewHolderCreator(fragment, map);
        creator.setOnEventProcessor(mOnEventProcessor);
        fragment.setViewHolderCreator(creator);

        mShortMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);
        mShortMediaPlayer.addOnPlayListener(mOnPlayListener);

        subscribeController = new BookCollectionSubscribeController(fragment.getContext(), SUBSCRIBE, CREATE_ORDER);
    }

    @Override
    public void initData() {
        if (detailInfo != null) {
            fragment.refreshUIBySubscribeStatus();
            reloadDataImpl();
        }
        getBookCollectionItemInfo();
    }

    ReadingHistoryInfo mReadingHistory;

    /**
     * 继续播放
     */
    public void loadResumeData() {
        //已订阅合集支持续播
        if (detailInfo != null && detailInfo.getSubscribe() == 1) {
            Flowable.create(new LoadHistoryInfoFlowableOnSubscribe(detailInfo.getCollectId()), BackpressureStrategy.BUFFER)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<ReadingHistoryInfo>() {
                        @Override
                        public void accept(final ReadingHistoryInfo readingHistoryInfo) throws Exception {
                            if (readingHistoryInfo != null) {
                                KaDaApplication.mainLooperHandler().post(new Runnable() {
                                    @Override
                                    public void run() {
                                        mReadingHistory = readingHistoryInfo;
                                        reloadDataImpl();
                                    }
                                });
                            }
                        }
                    });
        } else {
            mReadingHistory = null;
        }
    }

    private static class LoadHistoryInfoFlowableOnSubscribe implements FlowableOnSubscribe<ReadingHistoryInfo> {

        private int mCollectId;

        public LoadHistoryInfoFlowableOnSubscribe(int collectId) {
            mCollectId = collectId;
        }

        @Override
        public void subscribe(FlowableEmitter<ReadingHistoryInfo> e) throws Exception {
            ReadingHistory readingHistory = DatabaseManager.getInstance().historyDB().queryCollectHistory(mCollectId);
            if (readingHistory != null) {
                ReadingHistoryInfo readingHistoryInfo = ReadingHistoryInfo.createByReadingHistory(readingHistory);
                e.onNext(readingHistoryInfo);
            }
            e.onComplete();
        }
    }

    /**
     * 获取绘本合集详情信息
     */
    public void getBookCollectionItemInfo() {
        getBookCollectionItemInfo("");
    }

    /**
     * 获取绘本合集详情信息
     *
     * @param type
     */
    public void getBookCollectionItemInfo(final String type) {
        final int collectId = fragment.getCollectId();
        if (bookCollectionStrongReference == null) {
            bookCollectionStrongReference = new StrongReference<>();
        }
        DefaultCallback bookCollectionCallback = new DefaultCallback<BookCollectionDetailInfo>() {

            @Override
            public void onLoadFromCache(BookCollectionDetailInfo cacheData) {
                super.onLoadFromCache(cacheData);
                if (cacheData != null && cacheData.getItems() != null && cacheData.getItems().size() > 0) {
                    detailInfo = cacheData;
                    if (subscribeController != null) {
                        subscribeController.setBookCollectionDetailInfo(detailInfo);
                    }
                    loadResumeData();
                    KaDaApplication.mainLooperHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            fragment.refreshUIBySubscribeStatus();
                            playRecommendAudio(detailInfo.getExplainAudio());
                            if (trackHabbit) {
                                fragment.setUserVisibleHint(true);
                                trackHabbit = false;
                            }
                            reloadDataImpl();
                        }
                    });
                }
            }

            @Override
            public void onDataReceived(final BookCollectionDetailInfo data) {
                if (data != null) {
                    detailInfo = data;
                    if (subscribeController != null) {
                        subscribeController.setBookCollectionDetailInfo(detailInfo);
                    }
                    loadResumeData();
                    KaDaApplication.mainLooperHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            fragment.refreshUIBySubscribeStatus();
                            playRecommendAudio(detailInfo.getExplainAudio());
                            if (trackHabbit) {
                                fragment.setUserVisibleHint(true);
                                trackHabbit = false;
                            }
                            reloadDataImpl();

                            //如果是未订阅状态，根据操作类型进行对应的操作
                            if (data.getSubscribe() != 1) {
                                if (SUBSCRIBE.equals(type)) {
                                    subscribeController.subscribe(1);
                                } else if (CREATE_ORDER.equals(type)) {
                                    subscribeController.createOrder();
                                }
                            }

                            if (PlaybackActivity.TYPE_SUBSCRIBE_COLLECTION.equals(type)) { // 绘本播放页面发起的订阅流程
                                UpdateBookCollectionDetailEvent event = new UpdateBookCollectionDetailEvent();
                                event.type = 1;
                                event.bookCollectionDetailInfo = data;
                                EventCenter.fireEvent(event);
                            }

                            if (data.getSubscribe() == 1) { // 订阅成功 通知绘本播放页面刷新UI
                                UpdateBookCollectionDetailEvent event = new UpdateBookCollectionDetailEvent();
                                event.type = 2;
                                event.bookCollectionDetailInfo = data;
                                EventCenter.fireEvent(event);
                            }
                        }
                    });
                } else {
                    KaDaApplication.mainLooperHandler().post(new Runnable() {
                        @Override
                        public void run() {
                            showContentDialog(1, 1, collectId);
                            fragment.handleErrorOccurred(true, 0, "加载数据为空");
                        }
                    });
                }
            }

            @Override
            public void onException(int code, String reason) {
                super.onException(reason);
                fragment.handleErrorOccurred(true, code, reason);
            }
        };
        bookCollectionStrongReference.set(bookCollectionCallback);
        BookAPI.getBookCollectionItem(collectId, false, bookCollectionStrongReference);
    }

    public void reloadDataImpl() {
        if (detailInfo.getItems() == null || detailInfo.getItems().size() <= 0) {
            fragment.handleLoadComplete(false);
            return;
        }

        dataList.clear();
        downloadList.clear();
        if (detailInfo.getSubscribe() != 1) {
            fragment.showGuideDialog();
        }
        BaseModelVO bannerModelVO = new BaseModelVO(detailInfo, View_Type_Collection_Banner);
        dataList.add(bannerModelVO);


        if (mReadingHistory != null) {
            int size = detailInfo.getItems().size();
            for (int i = 0; i < size; i++) {
                if (detailInfo.getItems().get(i).getBookId() == mReadingHistory.getBookId()) {
                    BookInfo bookInfo = detailInfo.getItems().get(i);
                    /**
                     * 当前阅读页面<绘本总页数  直接播放到当前页
                     * 否则 如果有下一本，播放下一本的第一页；如果已经是最后一本，播放合辑第一本的第一页
                     */
                    if (mReadingHistory.getReadCurrentPage() >= bookInfo.getPageCount() || mReadingHistory.getReadCurrentPage() == 0) {
                        if (i < size - 1) {
                            bookInfo = detailInfo.getItems().get(i + 1);
                        } else {
                            bookInfo = detailInfo.getItems().get(0);
                        }
                        mReadingHistory.setReadCurrentPage(0);
                        mReadingHistory.setBookId(bookInfo.getBookId());
                        mReadingHistory.setVersion(bookInfo.getVersion());
                        mReadingHistory.setCoverUrl(bookInfo.getCoverUrl());
                    }
                    BaseModelVO resumeModelVO = new BaseModelVO(bookInfo, View_Type_Book_Resume_Play);
                    dataList.add(resumeModelVO);
                    break;
                }
            }
        }


        if (detailInfo.getItems() != null && detailInfo.getItems().size() > 0) {
            bookListItems = new ArrayList<>();
            bookListItems.addAll(detailInfo.getItems());
            List<BaseModel> singleLineTmp = new ArrayList<>();
            for (int i = 0; i < bookListItems.size(); i++) {
                ((BookInfo) bookListItems.get(i)).setCollectId(detailInfo.getCollectId());
                BookListItem bookListItem = new BookListItem(BookListItem.TYPE_BOOK, bookListItems.get(i));
                bookListItem.setSubscribeStatus(detailInfo.getSubscribe());
                bookListItem.getData().setIndex(i);
                downloadList.add(bookListItem);
                singleLineTmp.add(bookListItem);
                if (singleLineTmp.size() >= 3) {
                    BaseModelListVO itemModelVO = new BaseModelListVO(View_Type_List_Item, singleLineTmp);
                    dataList.add(itemModelVO);
                    singleLineTmp.clear();
                }
            }
            if (singleLineTmp.size() > 0) {
                BaseModelListVO itemModelVO = new BaseModelListVO(View_Type_List_Item, singleLineTmp);
                dataList.add(itemModelVO);
                singleLineTmp.clear();
            }
        }
        BaseModelVO tabModelVO = new BaseModelVO(null, View_Type_Sep_Line);
        dataList.add(tabModelVO);
        fragment.reloadData(dataList);
        fragment.handleLoadComplete(false);
    }

    private void playRecommendAudio(String soundUrl) {
        if (playCount == 0 && !TextUtils.isEmpty(soundUrl)) {
            playCount = 1;
            if (mShortMediaPlayer != null) {

                isNeedContinuePlayListen = ListenManager.getInstance().isPlayingOrPromptAudioPlaying();
                if (isNeedContinuePlayListen) {
                    ListenManager.getInstance().setPausedByShortAudio(true);
                    ListenManager.getInstance().pause(false);

                    String proxyUrl = mShortMediaPlayer.getProxyUrl(soundUrl, Dirs.getTmpCachePath() + File.separator + detailInfo.getCollectId() + "sound.mp3");
                    mShortMediaPlayer.addPlayQueue(proxyUrl, PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.TAG_BOOK_COLLECTION_BG_AUDIO);
                } else {
                    String proxyUrl = mShortMediaPlayer.getProxyUrl(soundUrl, Dirs.getTmpCachePath() + File.separator + detailInfo.getCollectId() + "sound.mp3");
                    mShortMediaPlayer.addPlayQueue(proxyUrl, PlayMode.SEQUENCE_PLAY_MODE, AudioName.TAG_BOOK_COLLECTION_BG_AUDIO);
                }

            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        releaseSoundPlay();
    }

    @Override
    public void onDestroy() {

        continuePlayListen();

        releaseSoundPlay();

        if (bookCollectionStrongReference != null) {
            bookCollectionStrongReference.clear();
            bookCollectionStrongReference = null;
        }
        if (subscribeController != null) {
            subscribeController.destroy();
        }

        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.removeOnPlayListener(mOnPlayListener);
        }
    }

    private void releaseSoundPlay() {
        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.stop(PlayMode.SEQUENCE_PLAY_MODE, AudioName.TAG_BOOK_COLLECTION_BG_AUDIO);
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.NEET_MOM_SUBSCRIBE_AUDIO);
        }

        isNeedMomSubscribeMusicPlaying = false;
    }

    void showContentDialog(int kind, int type, int id) {
        if (fragment == null || fragment.getContext() == null || fragment.getActivity().isFinishing()) {
            return;
        }
        ContentIsDeletedDialog contentIsDeletedDialog = new ContentIsDeletedDialog(fragment.getContext());
        contentIsDeletedDialog.setCallback(new ContentIsDeletedDialog.ContentDialogCallback() {
            @Override
            public void doYes() {
                fragment.onBackPressed();
            }
        });
        contentIsDeletedDialog.setData(kind, type, id);
        contentIsDeletedDialog.show();
    }

    private void processBooKItemClicked(BookInfo bookInfo) {
        if (bookInfo == null) {
            return;
        }

        if (fragment == null) {
            return;
        }

        final Activity activity = fragment.getActivity();
        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (detailInfo.getSubscribe() == 1) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(bookInfo.getBookId() + "," + detailInfo.getCollectId(), "book_subscribed_collection_content_list_click_" + bookInfo.getIndex(), TimeUtil.currentTime()));
        } else {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(bookInfo.getBookId() + "," + detailInfo.getCollectId(), "book_unsubscribed_collection_content_list_click_" + bookInfo.getIndex(), TimeUtil.currentTime()));
        }

        if (bookInfo.getStatus() != Constants.ONLINE && bookInfo.getStatus() != Constants.OFFLINE) {
            showContentDialog(1, 2, bookInfo.getBookId());
            return;
        }

        if (((bookInfo.getExtFlag() & Extflag.EXT_FLAG_8192) == Extflag.EXT_FLAG_8192) || detailInfo.getSubscribe() == 1) {
            //关闭背景音频
            releaseSoundPlay();

            //可以试听
            PlaybackActivity.startActivity(activity, bookInfo.getBookId(), detailInfo, 0);
        } else {

            /**
             * https://www.tapd.cn/21794391/prong/stories/view/1121794391001002042?url_cache_key=94970b5b787f68b17b259199d62fd552&action_entry_type=story_tree_list
             * 提示订阅音频出现期间再次点击带锁内容，提示订阅音频和手势引导不重新计时。提示订阅音频结束后再次点击带锁内容，提示订阅音频和手势引导从0开始重新计时。
             */
            if (isNeedMomSubscribeMusicPlaying) {
                return;
            }

            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(detailInfo.getCollectId()), "book_unsubscribed_collection_lock_click", TimeUtil.currentTime()));
            if (mShortMediaPlayer != null) {
                isNeedMomSubscribeMusicPlaying = true;

                // 停掉背景音
                mShortMediaPlayer.stop(PlayMode.SEQUENCE_PLAY_MODE, AudioName.TAG_BOOK_COLLECTION_BG_AUDIO);

                boolean isPlayingAppStartAudio = false;
                List<AudioInfo> audioInfos = mShortMediaPlayer.getCurrentPlayAudio();
                if (!audioInfos.isEmpty()) {
                    for (AudioInfo audioInfo : audioInfos) {
                        if (AudioName.APP_START_AUDIO.equals(audioInfo.mAudioTag)) {
                            isPlayingAppStartAudio = true;
                            break;
                        }
                    }
                }

                if (isPlayingAppStartAudio) { // 正在播放app启动音
                    mShortMediaPlayer.addPlayQueue(R.raw.need_mom_subscribe, PlayMode.SEQUENCE_PLAY_MODE, AudioName.NEET_MOM_SUBSCRIBE_AUDIO);
                } else {

                    isNeedContinuePlayListen = ListenManager.getInstance().isPlayingOrPromptAudioPlaying();
                    if (isNeedContinuePlayListen) {
                        ListenManager.getInstance().setPausedByShortAudio(true);
                        ListenManager.getInstance().pause(false);
                    }

                    mShortMediaPlayer.addPlayQueue(R.raw.need_mom_subscribe, PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.NEET_MOM_SUBSCRIBE_AUDIO);
                }
            }

            if (fragment != null) {
                fragment.showSubscribeFingerGuideAnim();
            }
        }
    }

    private void processCollectResumeClicked() {

        if (fragment == null) {
            return;
        }

        final Activity activity = fragment.getActivity();

        if (activity == null || activity.isFinishing()) {
            return;
        }

        if (mReadingHistory != null) {
            UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(String.valueOf(mReadingHistory.getCollectId()), "book_collection_continue_play_click", TimeUtil.currentTime()));
            PlaybackActivity.startActivity(activity, mReadingHistory.getBookId(), detailInfo, mReadingHistory.getReadCurrentPage());
        }
    }

}
