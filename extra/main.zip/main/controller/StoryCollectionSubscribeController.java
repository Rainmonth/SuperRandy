package com.hhdd.kada.main.controller;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.PayAPI;
import com.hhdd.kada.api.StoryAPI;
import com.hhdd.kada.dialog.ConfirmDialogManager;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.event.CancelSubscribeEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.SubscribeSuccessEvent;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.ui.activity.LoginOrRegisterActivity;
import com.hhdd.kada.main.ui.dialog.ChildrenLockDialog;
import com.hhdd.kada.main.ui.dialog.ConfirmDialog;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.pay.PayManager;
import com.hhdd.kada.pay.controller.BasePayController;
import com.hhdd.kada.record.callback.ChildrenDialogCallback;
import com.hhdd.kada.store.model.OrderFragParamData;

import java.util.HashMap;
import java.util.Map;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/4/14
 * @describe : com.hhdd.kada.main.controller
 */
public class StoryCollectionSubscribeController extends BaseCollectionSubscribeController {

    private StoryCollectionDetail mStoryCollectionDetail;
    private long mCollectId;
    private int mSubscribe;
    private int mStatus;
    private int mCollectionExtFlag;
    private int mType;
    private StrongReference<DefaultCallback> subscribeStrongReference;

    public StoryCollectionSubscribeController(Context context, String subscribeType, String createOrderType) {
        super(context, subscribeType, createOrderType);
    }

    public void setStoryCollectionDetailInfo(StoryCollectionDetail storyCollectionDetailInfo) {
        this.mStoryCollectionDetail = storyCollectionDetailInfo;
        this.mCollectId = storyCollectionDetailInfo.getCollectId();
        this.mSubscribe = storyCollectionDetailInfo.getSubscribe();
        this.mStatus = storyCollectionDetailInfo.getStatus();
        this.mCollectionExtFlag = storyCollectionDetailInfo.getExtFlag();
        this.mType = storyCollectionDetailInfo.getType();
    }

    public void setRelatedData(long collectId, int subscribe, int status, int collectionExtFlag, int type) {
        this.mCollectId = collectId;
        this.mSubscribe = subscribe;
        this.mStatus = status;
        this.mCollectionExtFlag = collectionExtFlag;
        this.mType = type;
    }

    @Override
    public void doSubscribe() {
        doSubscribe(null);
    }

    public void doSubscribe(final DialogInterface.OnShowListener showListener) {
        if (context == null) {
            return;
        }
        if (context instanceof Activity) {
            Activity activity = (Activity) context;
            if (activity.isFinishing()) {
                return;
            }
        }
        if (mCollectId <= 0) {
            return;
        }

        //收费合集 与 免费合集
        if (mStatus != Constants.ONLINE) {
            ToastUtils.showToast(KaDaApplication.instance.getResources().getString(R.string.content_is_offline_can_not_subscribe));
            return;
        }
        if ((mCollectionExtFlag & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32) {
            ChildrenLockDialog dialog = new ChildrenLockDialog(context);
            dialog.setCallback(new ChildrenDialogCallback() {
                @Override
                public void onAnswerRight() {
                    if (UserService.getInstance().isLogining()) {
                        createOrder();
                    } else {
                        //跳转登录页面，登录成功后刷新页面，判断是否订阅，未订阅创建订单
                        LoginOrRegisterActivity.startActivity(context, createOrderType);
                    }
                }

                @Override
                public void onDirectDismiss() {

                }
            });
            dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    if (showListener != null) {
                        showListener.onShow(dialog);
                    }

                    playLetMomSubscribeAudio();
                }
            });
            dialog.show();

        } else {
            subscribe(1);

//            if (UserService.getInstance().isLogining()) {
//                subscribe(1);
//            } else {
//                //跳转登录页面，登录成功后刷新页面，判断是否订阅，未订阅直接订阅
//                LoginOrRegisterActivity.startActivity(context, subscribeType);
//            }
        }
    }

    @Override
    public void doCancelSubscribe() {
        if (mStatus != Constants.ONLINE) {
            ToastUtils.showToast(KaDaApplication.instance.getResources().getString(R.string.content_is_offline_can_not_cancel_subscribe));
            return;
        }
        final boolean isChargeCollection = (mCollectionExtFlag & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32;
        final ConfirmDialogManager confirmDialogManager = DialogFactory.getConfirmDialogManager();
        confirmDialogManager.showDialog(context, isChargeCollection ? R.string.confirm_dialog_subscribe_charge_content
                        : R.string.confirm_dialog_subscribe_free_content, R.string.confirm_dialog_subscribe_cancel, R.string.confirm_dialog_confirm,
                isChargeCollection, new ConfirmDialog.OnConfirmDialogListener() {
                    @Override
                    public void onCancel() {
                        confirmDialogManager.dismissDialog(context);
                    }

                    @Override
                    public void onConfirm() {
                        confirmDialogManager.dismissDialog(context);
                        if (!isChargeCollection) {
                            subscribe(2);
                        }
                    }
                });
    }

    @Override
    public void subscribe(final int status) {
        //免费直接订阅
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(context, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                cancelSubscribeRequest();
            }
        });
        if (subscribeStrongReference == null) {
            subscribeStrongReference = new StrongReference<>();
        }
        DefaultCallback subscribeCallback = new DefaultCallback<String>() {
            @Override
            public void onDataReceived(final String responseData) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(context);
                        if (!TextUtils.isEmpty(responseData)) {
                            int toastStringResId = status == 1 ? R.string.subscribe_success_toast
                                    : R.string.subscribe_cancel_success_toast;
                            ToastUtils.showToast(toastStringResId);
                            if (status == 1) {
                                EventCenter.fireEvent(new SubscribeSuccessEvent((int) mCollectId));
                            } else {
                                String from = "";
                                if (!TextUtils.isEmpty(subscribeType)) {
                                    String[] typeArr = subscribeType.split("_");
                                    if (typeArr.length > 0) {
                                        from = typeArr[0];
                                    }
                                }

                                EventCenter.fireEvent(new CancelSubscribeEvent((int) mCollectId, from));
                            }
                        } else {
                            int toastStringResId = status == 1 ? R.string.content_is_offline_can_not_subscribe
                                    : R.string.content_is_offline_can_not_cancel_subscribe;
                            ToastUtils.showToast(toastStringResId);
                        }
                    }
                });
            }

            @Override
            public void onException(String reason) {
                customDialogManager.dismissDialog(context);
                int toastStringResId = status == 1 ? R.string.subscribe_fail_toast
                        : R.string.subscribe_cancel_fail_toast;
                ToastUtils.showToast(toastStringResId);
            }
        };
        subscribeStrongReference.set(subscribeCallback);
        StoryAPI.storyAPI_subscribe((int) mCollectId, status, mType, subscribeStrongReference);
    }

    @Override
    public void createOrder() {
        StoryCollectionDetail detail = null;
        if (mStoryCollectionDetail != null && mStoryCollectionDetail.getModelStatus() == null) {
            //若非自我构造实体，将实体传入订单支付页面
            detail = mStoryCollectionDetail;
        }
        OrderFragParamData orderFragParamData = new OrderFragParamData(0, (int) mCollectId, detail);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(BasePayController.KEY_ORDER_TYPE, PayAPI.TYPE_ORDER_STORY);
        paramMap.put(BasePayController.KEY_ORDER_COLLECTION_ID, (int) mCollectId);
        paramMap.put(BasePayController.KEY_ORDER_ATTACH_PARAM, orderFragParamData);
        BasePayController controller = PayManager.getPayController(context);
        if (controller != null) {
            controller.createOrder(paramMap);
        }
    }

    /**
     * 取消订阅接口请求
     */
    private void cancelSubscribeRequest() {
        if (subscribeStrongReference != null) {
            subscribeStrongReference.clear();
            subscribeStrongReference = null;
        }
    }

    @Override
    public void destroy() {
        super.destroy();
        cancelSubscribeRequest();
    }
}
