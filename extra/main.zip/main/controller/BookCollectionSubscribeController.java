package com.hhdd.kada.main.controller;

import android.content.Context;
import android.content.DialogInterface;
import android.text.TextUtils;

import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.BookAPI;
import com.hhdd.kada.api.PayAPI;
import com.hhdd.kada.dialog.ConfirmDialogManager;
import com.hhdd.kada.dialog.CustomDialogManager;
import com.hhdd.kada.dialog.DialogFactory;
import com.hhdd.kada.main.event.BookSubscribeStatusEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.model.BookCollectionDetailInfo;
import com.hhdd.kada.main.ui.activity.LoginOrRegisterActivity;
import com.hhdd.kada.main.ui.dialog.ChildrenLockDialog;
import com.hhdd.kada.main.ui.dialog.ConfirmDialog;
import com.hhdd.kada.main.ui.dialog.CustomProgressDialog;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.pay.PayManager;
import com.hhdd.kada.pay.controller.BasePayController;
import com.hhdd.kada.record.callback.ChildrenDialogCallback;
import com.hhdd.kada.store.model.OrderFragParamData;

import java.util.HashMap;
import java.util.Map;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/4/14
 * @describe : com.hhdd.kada.main.controller
 */
public class BookCollectionSubscribeController extends BaseCollectionSubscribeController {

    private BookCollectionDetailInfo bookCollectionDetailInfo;
    private StrongReference<DefaultCallback> subscribeStrongReference;

    public BookCollectionSubscribeController(Context context, String subscribeType, String createOrderType) {
        super(context, subscribeType, createOrderType);
    }

    public void setBookCollectionDetailInfo(BookCollectionDetailInfo bookCollectionDetailInfo) {
        this.bookCollectionDetailInfo = bookCollectionDetailInfo;
    }

    @Override
    public void doSubscribe() {
        if (bookCollectionDetailInfo == null) {
            ToastUtils.showToast("数据异常");
            return;
        }
        int status = bookCollectionDetailInfo.getStatus();
        if (status != Constants.ONLINE && status != 0) {
            ToastUtils.showToast(KaDaApplication.instance.getResources().getString(R.string.content_is_offline_can_not_subscribe));
            return;
        }

        if ((bookCollectionDetailInfo.getExtFlag() & Extflag.EXT_FLAG_1024) == Extflag.EXT_FLAG_1024) {
            ChildrenLockDialog lockDialog = new ChildrenLockDialog(context);
            lockDialog.setCallback(new ChildrenDialogCallback() {
                @Override
                public void onAnswerRight() {
                    if (UserService.getInstance().isLogining()) {
                        createOrder();
                    } else {
                        //跳转登录页面，登录成功后刷新页面，判断是否订阅，未订阅创建订单
                        LoginOrRegisterActivity.startActivity(context, createOrderType);
                    }
                }

                @Override
                public void onDirectDismiss() {

                }
            });
            lockDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                @Override
                public void onShow(DialogInterface dialog) {
                    playLetMomSubscribeAudio();
                }
            });
            lockDialog.show();
        } else {
            subscribe(1);

//            if (UserService.getInstance().isLogining()) {
//                subscribe(1);
//            } else {
//                //跳转登录页面，登录成功后刷新页面，判断是否订阅，未订阅直接订阅
//                LoginOrRegisterActivity.startActivity(context, subscribeType);
//            }
        }
    }

    @Override
    public void doCancelSubscribe() {
        if (bookCollectionDetailInfo != null) {
            int status = bookCollectionDetailInfo.getStatus();
            if (status != Constants.ONLINE && status != 0) {
                ToastUtils.showToast(KaDaApplication.instance.getResources().getString(R.string.content_is_offline_can_not_cancel_subscribe));
                return;
            }
            final boolean isChargeCollection = (bookCollectionDetailInfo.getExtFlag() & Extflag.EXT_FLAG_1024) == Extflag.EXT_FLAG_1024;
            final ConfirmDialogManager confirmDialogManager = DialogFactory.getConfirmDialogManager();
            confirmDialogManager.showDialog(context, isChargeCollection ? R.string.confirm_dialog_subscribe_charge_content
                    : R.string.confirm_dialog_subscribe_free_content, R.string.confirm_dialog_subscribe_cancel, R.string.confirm_dialog_confirm,
                    isChargeCollection, new ConfirmDialog.OnConfirmDialogListener() {
                @Override
                public void onCancel() {
                    confirmDialogManager.dismissDialog(context);
                }

                @Override
                public void onConfirm() {
                    confirmDialogManager.dismissDialog(context);
                    if (!isChargeCollection) {
                        subscribe(2);
                    }
                }
            });
        }
    }

    @Override
    public void subscribe(final int status) {
        if (bookCollectionDetailInfo == null) {
            ToastUtils.showToast("数据异常");
            return;
        }
        final CustomDialogManager customDialogManager = DialogFactory.getCustomDialogManager();
        customDialogManager.showDialog(context, new CustomProgressDialog.Listener() {
            @Override
            public void onClosed() {
                clearSubscribeReference();
            }
        });
        //免费订阅
        if (subscribeStrongReference == null) {
            subscribeStrongReference = new StrongReference<>();
        }
        DefaultCallback subscribeCallback = new DefaultCallback() {
            @Override
            public void onDataReceived(final Object data) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        customDialogManager.dismissDialog(context);
                        if (data != null) {
                            int toastStringResId = status == 1 ? R.string.subscribe_success_toast
                                    : R.string.subscribe_cancel_success_toast;
                            int eventStatus = status == 1 ? 1 : 3;
                            ToastUtils.showToast(toastStringResId);
                            String from = "";
                            if (!TextUtils.isEmpty(subscribeType)) {
                                String[] typeArr = subscribeType.split("_");
                                if (typeArr.length > 0) {
                                    from = typeArr[0];
                                }
                            }
                            EventCenter.fireEvent(new BookSubscribeStatusEvent(bookCollectionDetailInfo.getCollectId(),eventStatus, from));
                        } else {
                            int toastStringResId = status == 1 ? R.string.content_is_offline_can_not_subscribe
                                    : R.string.content_is_offline_can_not_cancel_subscribe;
                            ToastUtils.showToast(toastStringResId);
                        }
                    }
                });
            }

            @Override
            public void onException(String reason) {
                customDialogManager.dismissDialog(context);
                int toastStringResId = status == 1 ? R.string.subscribe_fail_toast
                        : R.string.subscribe_cancel_fail_toast;
                ToastUtils.showToast(toastStringResId);
            }
        };
        subscribeStrongReference.set(subscribeCallback);
        BookAPI.bookAPI_subscribe(bookCollectionDetailInfo.getCollectId(), status, bookCollectionDetailInfo.getType(), subscribeStrongReference);
    }

    @Override
    public void createOrder() {
        OrderFragParamData orderFragParamData = new OrderFragParamData(0,
                bookCollectionDetailInfo.getCollectId(), bookCollectionDetailInfo);
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put(BasePayController.KEY_ORDER_TYPE, PayAPI.TYPE_ORDER_BOOK);
        paramMap.put(BasePayController.KEY_ORDER_COLLECTION_ID, bookCollectionDetailInfo.getCollectId());
        paramMap.put(BasePayController.KEY_ORDER_ATTACH_PARAM, orderFragParamData);
        BasePayController controller = PayManager.getPayController(context);
        if (controller != null) {
            controller.createOrder(paramMap);
        }
    }

    /**
     * 回收订阅请求资源
     */
    private void clearSubscribeReference() {
        if (subscribeStrongReference != null) {
            subscribeStrongReference.clear();
            subscribeStrongReference = null;
        }
    }

    @Override
    public void destroy() {
        super.destroy();
        clearSubscribeReference();
    }
}
