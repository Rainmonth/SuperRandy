package com.hhdd.kada.main.manager;

import android.app.Dialog;
import android.content.DialogInterface;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.logger.LogHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lj on 17/3/29.
 * 控制dialog出现 多个dialog不能同时出现
 */

public class DialogManager {


    public DialogManager() {
    }

    private List<Dialog> list = new ArrayList<>();

    public synchronized boolean isDialogShow() {
        return list.size() > 0 && list.get(0).isShowing();
    }

    public synchronized void showDialog(final Dialog dialog, DialogInterface.OnDismissListener dismissListener) {
        if (dialog != null) {
            list.add(dialog);
            if (list.size() == 1) {
                dialog.show();
            }
            if (dismissListener != null) {
                dialog.setOnDismissListener(dismissListener);
            }
        }
    }

    public synchronized void showDialog(final Dialog dialog) {
        if (dialog != null) {
            list.add(dialog);
            if (list.size() == 1) {
                dialog.show();
            }
            dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface dialog1) {
                    dismissDialog(dialog);
                }
            });

        }
    }

    public synchronized void dismissDialog(Dialog dialog) {
        if (dialog != null) {
            if (list.contains(dialog)) {
                list.remove(dialog);
                if (list.size() > 0) {
                    //如果是运营弹窗，直接跳过,留到下一次播放
//                    if (list.get(0) instanceof ActivityDialog) {
//                        list.remove(dialog);
//                    }
//                    if (list.size() > 0) {
                        KaDaApplication.mainLooperHandler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                list.get(0).show();
                            }
                        }, 10);
//                    }
                }
            }
//            else {
//                dialog.dismiss();
//            }
        }
    }

    /**
     * 清除关闭队列所有弹窗
     */
    public synchronized void dismissAllDialog() {
        if (list != null && list.size() > 0) {
            List<Dialog> tempDialogList = new ArrayList<>();
            tempDialogList.addAll(list);
            list.clear();
            for (Dialog dialog : tempDialogList) {
                dialog.dismiss();
            }
            tempDialogList.clear();
        }
    }

    /**
     *  从DialogManager中移除一个Dialog
     *  如果队列中不包含这个Dialog，并且Dialog#isShowing是true，直接执行{@link Dialog#dismiss()}
     *  如果队列中包含这个Dialog：
     *  1、Dialog#isShowing是true，则执行{@link #dismissDialog(Dialog)}
     *  2、Dialog#isShowing是false，则从list中remove这个Dialog
     * @param dialog
     */
    public synchronized void removeDialog(Dialog dialog) {
        if (dialog == null) {
            return;
        }

        try {
            if (!list.contains(dialog)) {
                if (dialog.isShowing()) {
                    dialog.dismiss();
                }
                return;
            }

            if (dialog.isShowing()) {
                dismissDialog(dialog);
            } else {
                list.remove(dialog);
            }
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }

}
