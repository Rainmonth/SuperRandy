package com.hhdd.kada.main.manager;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;

import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.utils.SafeHandler;

/**
 * Created by lj on 16/12/2.
 */

public class TimeOutManager implements Handler.Callback {

    public static final int MSG_USED_TIMEOUT = 200;
    private boolean isSettingDialogNeedDisplay = false;
    private boolean isCheck = false;
    private boolean isShow = false;//dialog是否显示



//    private static TimeOutManager sInstance;
//    public TimeOutManager(){}
//
//    public static TimeOutManager getsInstance(){
//        if(sInstance == null){
//            sInstance = new TimeOutManager();
//        }
//        return sInstance;
//    }


    protected SafeHandler mHandler = null;

    public SafeHandler getHandler() {
        if (mHandler == null) {
            mHandler = new SafeHandler(Looper.getMainLooper(), this);
        }
        return mHandler;
    }

    public void startCheck(){
        if (!isCheck && !Settings.getInstance().isNoLimitUsing()) {
            isCheck = true;
            checkAndStartLimitUsingTimer();
        }
    }

    public void stopCheck(){
        if(isCheck){
            isCheck = false;
            if (startTime != 0) {
                time += System.currentTimeMillis() - startTime;
                interval_time = System.currentTimeMillis();
            }
        }
        getHandler().removeMessages(MSG_USED_TIMEOUT);
    }


    long time;
    long startTime;
    long interval_time = 0; // 停留在首页时中间间隔时间
    long usingDuration; //用户设置的使用时长 用户设置改变时 要重新计时

    void checkAndStartLimitUsingTimer() {

        getHandler().removeMessages(MSG_USED_TIMEOUT);
        if (interval_time != 0) {
            interval_time = System.currentTimeMillis() - interval_time;
        }
        if (Settings.getInstance().isNoLimitUsing()) {
            //...
            startTime = 0;
        } else {
            Message msg = getHandler().obtainMessage(MSG_USED_TIMEOUT);
            if (time == 0 || usingDuration != Settings.getInstance().getUsingDuration()) {
                time = 0;
                usingDuration = Settings.getInstance().getUsingDuration();
                getHandler().sendMessageDelayed(msg, usingDuration * 60 * 1000);
//                getHandler().sendMessageDelayed(msg, 1000);
            } else {
                if (interval_time > 15 * 60 * 1000) { //间隔时长超过15分钟 重新计时
                    interval_time = 0;
                    time = 0;
                    getHandler().sendMessageDelayed(msg, Settings.getInstance().getUsingDuration() * 60 * 1000);
                } else {
                    interval_time = 0;
                    getHandler().sendMessageDelayed(msg, Settings.getInstance().getUsingDuration() * 60 * 1000 - time);
                }
            }
            startTime = System.currentTimeMillis();
        }

    }



    @Override
    public boolean handleMessage(Message msg) {
        if (msg.what == MSG_USED_TIMEOUT) {
            time = 0 ;
            isSettingDialogNeedDisplay = true;
        }
        return false;
    }


    public boolean isShowSettingDialog() {
        if (isSettingDialogNeedDisplay  && !isShow) {
            time = 0;
            isShow = true;
            return true;
        }
        return false;
    }

    public void doHideSettingDialog(){
        isSettingDialogNeedDisplay = false;
        isShow = false;
    }


    public boolean isSettingDialogNeedDisplay() {
        return isSettingDialogNeedDisplay;
    }

    public void setSettingDialogNeedDisplay(boolean settingDialogNeedDisplay) {
        isSettingDialogNeedDisplay = settingDialogNeedDisplay;
    }

    public boolean isShow(){
        return isShow;
    }

    public void setShow(boolean isShow){
        this.isShow = isShow;
    }


    public void onDestory(){
        if (mHandler != null) {
            mHandler.destroy();
            mHandler = null;
        }

    }
}
