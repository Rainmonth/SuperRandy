package com.hhdd.kada.main.manager;

import android.content.Intent;

import com.google.gson.Gson;
import com.hhdd.android.ref.StrongReference;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.api.API;
import com.hhdd.kada.main.model.WeixinPayModel;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.logger.LogHelper;
import com.tencent.mm.opensdk.modelmsg.SendAuth;
import com.tencent.mm.opensdk.openapi.IWXAPI;
import com.tencent.mm.opensdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.opensdk.openapi.WXAPIFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/**
 * description:微信登陆认证的管理器
 * <p>
 * Created by lj on 16/11/11.
 */

public class WChatManager {

    public static final String APP_ID = AppUtils.getString(R.string.WX_APP_ID);


    private String tag;
//    private static WChatManager mInstance;

    public IWXAPI WXAPI;

    //用来区分是从那个页面调用微信登录
    private String mTransaction = null;

    /**
     * 构造方法当中初始化IWXAPI
     */
    public WChatManager() {
        WXAPI = WXAPIFactory.createWXAPI(KaDaApplication.getInstance(), APP_ID, false);
    }

    public void register(){
        try {
            WXAPI.registerApp(APP_ID);
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }

    public void unregister(){
        try {
            WXAPI.unregisterApp();
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }

    public void detach() {
        try {
            WXAPI.detach();
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }
    }

//    public static WChatManager getInstance() {
//        if (mInstance == null) {
//            mInstance = new WChatManager();
//        }
//        return mInstance;
//    }

    public String getTransaction() {
        return mTransaction;
    }


    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    /**
     * 第一步、获得授权的code
     */
    public void requestOauthCode(IWXListener listener, String transaction) {
        try {
            if (!WXAPI.isWXAppInstalled()) {
                if (listener != null) {
                    listener.wxUnInstall();
                }
                return;
            }
            //1.生成一个此链接的唯一标识，返回的时候会原封不动地返回回来
            Random random = new Random();
            int value = random.nextInt(1000) + 1;
            mTransaction = transaction;
            String state = mTransaction + value;
            //2.发出请求，获取code
            final SendAuth.Req req = new SendAuth.Req();
            req.scope = "snsapi_userinfo";
            req.state = state;
            req.transaction = mTransaction;
            WXAPI.sendReq(req);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
    }

    /**
     * 第二步、通过上一步得到的code，获取到access_token
     * https://api.weixin.qq.com/sns/oauth2/access_token?appid=APPID&secret=SECRET&code=CODE&grant_type=authorization_code
     *
     * @param code 上一次获取到的code
     */
    public void login(final String code, final String userSequence, final StrongReference<DefaultCallback> strongReference) {
        if (strongReference==null){
            return;
        }
        API.UrlAPI<WeixinPayModel> urlAPI = new API.UrlAPI<WeixinPayModel>() {

            @Override
            protected Map<String, String> buildArgs() {
                Map<String, String> args = super.buildArgs();
                if (args == null) {
                    args = new HashMap<>();
                }
                args.put("code", code);
                if (userSequence != null && userSequence.length() > 0) {
                    args.put("userSequence", userSequence);
                }
                args.put("appid", APP_ID);
                args.put("deviceId", KaDaApplication.DEVICE_ID);
                return args;
            }

            @Override
            protected String buildQueryUrl() {
                return API.WEIXIN_LOGIN_URL();
            }

            @Override
            public WeixinPayModel parseResponseJsonData(String jsonString) {
                try {
                    Gson gson = new Gson();
                    WeixinPayModel model = gson.fromJson(jsonString, WeixinPayModel.class);
                    return model;
                } catch (Exception e) {

                }
                return null;
            }
        };

        urlAPI.setNeedCache(false).setNeedCookie(true);
        urlAPI.get(new API.ResponseHandler<WeixinPayModel>() {
            @Override
            public void onSuccess(WeixinPayModel responseData) {
                if(strongReference == null) {
                    return;
                }
                DefaultCallback callback = strongReference.getAndClear();
                if(callback != null) {
                    callback.onDataReceived(responseData);
                }
            }

            @Override
            public void onFailure(int code, String message) {
                if(strongReference == null) {
                    return;
                }
                DefaultCallback callback = strongReference.getAndClear();
                if(callback != null) {
                    callback.onException(code, message);
                }
            }
        });
    }


    /**
     * 处理微信的回调
     *
     * @param intent  activity的意图界面
     * @param handler 微信回调
     */
    public void handleIntent(Intent intent, IWXAPIEventHandler handler) {
        WXAPI.handleIntent(intent, handler);
    }

    /**
     * 微信的回调接口
     */
    public interface IWXListener {
        void wxUnInstall();
    }

}