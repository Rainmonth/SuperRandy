package com.hhdd.kada.main.manager;

import android.Manifest;
import android.app.Activity;
import android.os.Build;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.ui.dialog.PermissionDialog;
import com.hhdd.kada.main.utils.TimeUtil;

/**
 * Created by sxh on 2017/7/13.
 * 权限申请管理
 */

public class PermissionManager {

    public final static int PERMISSION_CAMERA = 1;   //相机权限
    public final static int PERMISSION_READ_EXTERNAL_STORAGE = 2;   //读取外部存储卡权限、相机权限
    public final static int PERMISSION_WRITE_EXTERNAL_STORAGE = 3;    //写入外部存储卡权限
    public final static int STORAGE_NOT_ENOUGH = 4;   //存储空间不足
    public final static int PERMISSION_READ_WRITE_EXTERNAL_STORAGE = 5;   //读写权限同时申请

//    private static PermissionManager sInstance;
    private PermissionDialog dialog;
    private PermissionDialogCallBack callBack;

    public PermissionManager() {
    }

//    public static PermissionManager getInstance() {
//        if (sInstance == null) {
//            sInstance = new PermissionManager();
//        }
//        return sInstance;
//    }

    public PermissionDialog getDialog() {
        return dialog;
    }

    public void setDialog(PermissionDialog dialog) {
        this.dialog = dialog;
    }

    public void setCallBack(PermissionDialogCallBack callBack) {
        this.callBack = callBack;
    }

    /**
     * 适用于activity进行权限申请
     *
     * @param activity
     * @param type
     */
    public void requestPermission(final Activity activity, int type) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M && type != STORAGE_NOT_ENOUGH) {
            return;
        }
        if(activity == null || activity.isFinishing()){
            return;
        }
        dialog = new PermissionDialog(activity);
        dialog.setPermissionType(type);
        switch (type) {
            case PERMISSION_CAMERA:
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "camera_authority_notice_view", TimeUtil.currentTime()));
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.CAMERA},
                                PERMISSION_CAMERA);
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "camera_authority_notice_setting_click", TimeUtil.currentTime()));
                    }
                });
                break;
            case PERMISSION_WRITE_EXTERNAL_STORAGE:
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "sd_visit_authority_notice_view", TimeUtil.currentTime()));
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                PERMISSION_WRITE_EXTERNAL_STORAGE);
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "sd_visit_authority_notice_setting_click", TimeUtil.currentTime()));
                    }
                });
                break;
            case PERMISSION_READ_EXTERNAL_STORAGE:
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "photo_authority_notice_view", TimeUtil.currentTime()));
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                                PERMISSION_READ_EXTERNAL_STORAGE);
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "photo_authority_notice_setting_click", TimeUtil.currentTime()));
                    }
                });
                break;
            case STORAGE_NOT_ENOUGH:
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "no_enough_space_notice_view", TimeUtil.currentTime()));
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "no_enough_space_notice_setting_click", TimeUtil.currentTime()));
                    }
                });
                break;
            case PERMISSION_READ_WRITE_EXTERNAL_STORAGE:
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                PERMISSION_READ_WRITE_EXTERNAL_STORAGE);
                        if (callBack != null) {
                            callBack.onRequestPermission();
                        }
                    }
                });
                break;
        }
//        dialog.show();
        ((DialogManager) ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).showDialog(dialog);
    }

    /**
     * 适用于fragment进行权限申请
     *
     * @param fragment
     * @param type
     */
    public void requestPermission(final Fragment fragment, int type) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M && type != STORAGE_NOT_ENOUGH) {
            return;
        }
        if(fragment == null || fragment.getContext() == null){
            return;
        }
        if(fragment.getContext() instanceof Activity){
            if(((Activity) fragment.getContext()).isFinishing()){
                return;
            }
        }
        dialog = new PermissionDialog(fragment.getContext());
        dialog.setPermissionType(type);
        switch (type) {
            case PERMISSION_CAMERA:
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "camera_authority_notice_view", TimeUtil.currentTime()));
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        fragment.requestPermissions(new String[]{Manifest.permission.CAMERA},
                                PERMISSION_CAMERA);
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "camera_authority_notice_setting_click", TimeUtil.currentTime()));
                    }
                });
                break;
            case PERMISSION_WRITE_EXTERNAL_STORAGE:
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "sd_visit_authority_notice_view", TimeUtil.currentTime()));
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        fragment.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                PERMISSION_WRITE_EXTERNAL_STORAGE);
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "sd_visit_authority_notice_setting_click", TimeUtil.currentTime()));
                    }
                });
                break;
            case PERMISSION_READ_EXTERNAL_STORAGE:
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "photo_authority_notice_view", TimeUtil.currentTime()));
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        fragment.requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                                PERMISSION_READ_EXTERNAL_STORAGE);
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "photo_authority_notice_setting_click", TimeUtil.currentTime()));
                    }
                });
                break;
            case STORAGE_NOT_ENOUGH:
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "no_enough_space_notice_view", TimeUtil.currentTime()));
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "no_enough_space_notice_setting_click", TimeUtil.currentTime()));
                    }
                });
                break;

            case PERMISSION_READ_WRITE_EXTERNAL_STORAGE:
                dialog.setCallback(new PermissionDialog.Callback() {
                    @Override
                    public void refresh() {
                        fragment.requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE},
                                PERMISSION_READ_WRITE_EXTERNAL_STORAGE);
                    }
                });
                break;
        }
//        dialog.show();
        ((DialogManager)ServiceProxyFactory.getProxy().getService(ServiceProxyName.DIALOG_MANAGER)).showDialog(dialog);
    }

    public interface PermissionDialogCallBack {
        void onRequestPermission();
    }

}
