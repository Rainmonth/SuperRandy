package com.hhdd.kada.main.common;

import java.io.Serializable;

/**
 * Created by simon on 4/14/16.
 */
public class FragParamData implements Serializable {

    public final Object paramObject; //引用对象 Serializable
    public final String title;
    public final int dataListMode; //refer to DataListFragment
    public final int dataListPageSize;

    public FragParamData(int dataListMode, String title, Object paramObject) {
        this(dataListMode,title,paramObject,30);
    }

    public FragParamData(int dataListMode, String title, Object paramObject, int dataListPageSize) {
        this.dataListMode = dataListMode;
        this.paramObject=paramObject;
        this.title=title;
        this.dataListPageSize = dataListPageSize;
    }
}
