package com.hhdd.kada.main.common;

import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.FrameLayout;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.views.list.ListPageInfo;
import com.hhdd.kada.android.library.views.list.PagedListDataModel;
import com.hhdd.kada.android.library.views.list.RecyclerPagedListDataAdapter;
import com.hhdd.kada.android.library.views.list.ViewHolderCreator;
import com.hhdd.kada.android.library.views.loadmore.LoadMoreDefaultFooterView;
import com.hhdd.kada.android.library.views.pullretofresh.PullToRefreshBase;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.base.BaseUrlApi;
import com.hhdd.kada.base.BaseFragment;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.viewholders.MyViewHolderCreator;
import com.hhdd.kada.main.vo.BaseVO;
import com.hhdd.kada.widget.support.KdLinearLayoutManager;
import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;

import java.lang.reflect.Field;
import java.util.List;

/**
 * Created by lj on 17/4/17.
 */

public class RecyclerDataListNoTitleFragment extends BaseFragment {

    public static final int LIST_MODE_NONE = 0x0;
    public static final int LIST_MODE_PULL_DOWN_TO_REFRESH = PullToRefreshBase.MODE_PULL_DOWN_TO_REFRESH;
    public static final int LIST_MODE_PULL_UP_TO_REFRESH = PullToRefreshBase.MODE_PULL_UP_TO_REFRESH;
    public static final int LIST_MODE_BOTH = PullToRefreshBase.MODE_BOTH;

    private PagedListDataModel<BaseModel> mDataListModel;
    public DataLoadingView mLoadingView;
    private XRecyclerView mListView;
    LoadMoreDefaultFooterView footerView;
    FrameLayout container;

    int dataListMode = LIST_MODE_NONE;

    private FragParamData fragParamData;

    ListPageInfo<BaseVO> dataListDisplayed;

    RecyclerPagedListDataAdapter mAdapter;

    public RecyclerDataListNoTitleFragment() {
        this(LIST_MODE_NONE, null, null);
    }

    public RecyclerDataListNoTitleFragment(int dataListMode) {
        this(dataListMode, null, null);
    }

    public RecyclerDataListNoTitleFragment(int dataListMode, String title, Object paramObject) {
        this(new FragParamData(dataListMode, title, paramObject));
    }

    public RecyclerDataListNoTitleFragment(FragParamData fragParamData) {
        super();
        this.fragParamData = fragParamData;
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        setContentView(R.layout.data_list_layout_recycler2);
        initViews();
    }

    void initViews() {

        container = (FrameLayout) findViewById(R.id.container);
        mLoadingView = (DataLoadingView) findViewById(R.id.loading_view);

        mAdapter = new RecyclerPagedListDataAdapter<BaseVO>();
        mAdapter.setViewHolderCreator(MyViewHolderCreator.create(this));
        mListView = (XRecyclerView) findViewById(R.id.list_view);
        mListView.setLayoutManager(new KdLinearLayoutManager(getContext(), LinearLayoutManager.VERTICAL, false));
        mListView.setAdapter(mAdapter);
        //解决条目图片闪动的bug，标志使用Adapter#getItemId()作为RecyclerView的holder缓存ID，就不会复用错误的holder了。
        try {
            Field field = mListView.getClass().getDeclaredField("mWrapAdapter");
            field.setAccessible(true);
            final RecyclerView.Adapter<?> o = (RecyclerView.Adapter<?>) field.get(mListView);
            o.setHasStableIds(true);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        }
        mListView.setRefreshProgressStyle(ProgressStyle.SysProgress);
//        mListView.setLoadingMoreProgressStyle(ProgressStyle.BallSpinFadeLoader);
        if (getContext() != null) {
            footerView = new LoadMoreDefaultFooterView(getContext());
            mListView.setFootView(footerView);
        }
        mListView.addOnScrollListener(mOnScrollListener);

        initListViewHeader(mListView);
        initListViewFooter(mListView);

        dataListDisplayed = new ListPageInfo<BaseVO>();
        mAdapter.setListPageInfo(dataListDisplayed);

        /// list mode
        dataListMode = LIST_MODE_BOTH;
        if (fragParamData != null) {
            dataListMode = fragParamData.dataListMode;
        }

        /// data list model
        if (fragParamData != null && fragParamData.paramObject != null && fragParamData.paramObject instanceof API.PaginationUrlAPI) {
            mDataListModel = new DataListModel((API.PaginationUrlAPI) (fragParamData.paramObject), fragParamData.dataListPageSize);
            ((DataListModel) mDataListModel).addListener(mListener);
        }
        if (mDataListModel == null) {
            mDataListModel = new MyPagedListDataModel(new ListPageInfo<BaseModel>());
        }
        mDataListModel.setPageListDataHandler(mPagedListDataHandler);

        mListView.setLoadingListener(new XRecyclerView.LoadingListener() {
            @Override
            public void onRefresh() {
                doRefresh();
            }

            @Override
            public void onLoadMore() {
                doLoadMore();
            }
        });

//        setupDataListMode();
        mListView.setPullRefreshEnabled(false);
        mListView.setLoadingMoreEnabled(false);

        if (mLoadingView != null) {
            mLoadingView.setOnRetryClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    handleRetry();
                }
            });
        }
    }

    private RecyclerView.OnScrollListener mOnScrollListener = new RecyclerView.OnScrollListener() {

        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
            onScrollStateChange(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            onScroll(recyclerView, dx, dy);
        }
    };

    public FrameLayout getInnerContainer() {
        return container;
    }


    public XRecyclerView getmListView() {
        return mListView;
    }

    protected void setViewHolderCreator(ViewHolderCreator viewHolderCreator) {
        if (mAdapter != null) {
            mAdapter.setViewHolderCreator(viewHolderCreator);
        }
    }

    protected void handleRetry() {
        showLoadingView();

        doRefresh();
    }

    protected void showLoadingView() {
        if (mLoadingView != null) {
            mLoadingView.showLoading();
        }
    }

    void setupDataListMode() {
        if (dataListMode == LIST_MODE_NONE) {
            mListView.setPullRefreshEnabled(false);
            mListView.setLoadingMoreEnabled(false);
        } else if (dataListMode == LIST_MODE_PULL_DOWN_TO_REFRESH) {
            mListView.setPullRefreshEnabled(true);
            mListView.setLoadingMoreEnabled(false);
        } else if (dataListMode == LIST_MODE_PULL_UP_TO_REFRESH) {
            mListView.setPullRefreshEnabled(false);
            mListView.setLoadingMoreEnabled(true);
        } else {
            mListView.setPullRefreshEnabled(true);
            mListView.setLoadingMoreEnabled(true);
        }
    }

    protected void initListViewHeader(XRecyclerView listView) {

    }

    protected void initListViewFooter(XRecyclerView listView) {

    }

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        if (data != null && data instanceof FragParamData) {
            fragParamData = (FragParamData) data;
        }
    }

    protected void doRefresh() {
        if (mDataListModel != null) {

            mDataListModel.getListPageInfo().goToHead();
            mDataListModel.queryFirstPage();

            if (dataListDisplayed.getDataList().size() == 0) {
                mListView.setPullRefreshEnabled(false);
                mListView.setLoadingMoreEnabled(false);
            }
        }
    }

    protected void doLoadMore() {
        if (mDataListModel != null) {
            mDataListModel.queryNextPage();
        }
        if (footerView != null) {
            footerView.onLoading(null);
        }
    }

    public void setBackgroundColor(int resId) {
        if (container != null) {
            container.setBackgroundColor(resId);
        }
    }

    DataListModel.Listener mListener = new DataListModel.Listener() {
        @Override
        public void onLoadBegin(DataListModel listModel, boolean isFirstPage) {

        }

        @Override
        public void onLoadComplete(DataListModel listModel, boolean isFirstPage, List<BaseModel> list, boolean hasMoreData) {
            handleLoadComplete(hasMoreData);
        }

        @Override
        public void onErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg) {
            handleErrorOccurred(isFirstPage, errorCode, errorMsg);
        }
    };


    public void handleErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg) {
        mListView.refreshComplete();
        mListView.loadMoreComplete();
//        if(mLoadMoreContainer != null){
//            mLoadMoreContainer.loadMoreError(0, errorMsg);
//        }
        if (footerView != null) {
            footerView.onLoadError(null, 0, errorMsg);
        }

        if (mLoadingView != null) {
            if (errorCode == BaseUrlApi.ERROR_CODE_6000) {
                mLoadingView.showNetError();
            } else {
                mLoadingView.showError();
            }
        }
    }

    protected void handleLoadComplete(boolean hasMoreData) {
        mListView.loadMoreComplete();
        mListView.refreshComplete();
//        if(mLoadMoreContainer != null){
//            mLoadMoreContainer.loadMoreFinish(hasM0oreData?false:dataListDisplayed.isEmpty(), hasMoreData);
//        }
        if (footerView != null) {
            footerView.onLoadFinish(null, dataListDisplayed.isEmpty(), hasMoreData);
        }

        if (mListView.getAdapter().getItemCount() == 0) {
            if (mLoadingView != null) {
                mLoadingView.showEmpty();
            }
        } else {
            if (mLoadingView != null) {
                mLoadingView.hide();
            }
        }
    }

    protected RecyclerDataListNoTitleFragment reloadData(List<BaseModel> dataList) {
        if (mDataListModel != null) {
            if (mDataListModel.getListPageInfo() != null) {
                mDataListModel.getListPageInfo().goToHead();
                mDataListModel.setRequestResult(dataList, false);
            }
        }
        return this;
    }

    protected void notifyDataSetChanged() {
        mAdapter.notifyDataSetChanged();
    }

    protected void reassembleDisplayedDataList(List<BaseVO> dataListDisplayed, List<BaseModel> itemsAdded, boolean isFirstPage) {
        if (dataListDisplayed == null || itemsAdded == null) {
            return;
        }

        for (BaseModel model : itemsAdded) {
            if (model instanceof BaseVO) {
                BaseVO vo = (BaseVO) model;
                dataListDisplayed.add(vo);
            }
        }
    }

    PagedListDataModel.PagedListDataHandler mPagedListDataHandler = new PagedListDataModel.PagedListDataHandler() {
        @Override
        public void onPageDataLoaded(PagedListDataModel listModel, ListPageInfo<?> listPageInfo, List<?> itemsAdded) {

            boolean isFirstPage = ((ListPageInfo<BaseModel>) listPageInfo).isFirstPage();
            boolean hasMore = ((ListPageInfo<BaseModel>) listPageInfo).hasMore();

            if (isFirstPage) {
                dataListDisplayed.getDataList().clear();
                setupDataListMode();
            }

            reassembleDisplayedDataList(dataListDisplayed.getDataList(), (List<BaseModel>) itemsAdded, isFirstPage);

            if (itemsAdded == null || itemsAdded.size() == 0) {
                mListView.setLoadingMoreEnabled(false);
            }
            mAdapter.notifyDataSetChanged();

            if (dataListDisplayed.getDataList() != null && dataListDisplayed.getDataList().size() > 0) {
                if (mLoadingView != null) {
                    mLoadingView.hide();
                }
            } else {
                if (mLoadingView != null) {
                    mLoadingView.showEmpty();
                }
            }
        }
    };

    public ListPageInfo<BaseVO> getDataListDisplayed() {
        return dataListDisplayed;
    }


    public void onScrollStateChange(RecyclerView view, int scrollState) {
        if (scrollState == RecyclerView.SCROLL_STATE_IDLE) {//空闲状0态
            FrescoUtils.imageResume();
        } else {
            FrescoUtils.imagePause();
        }
    }

    public void onScroll(RecyclerView recyclerView, int dx, int dy) {

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if (mListView != null) {
            mListView.removeOnScrollListener(mOnScrollListener);
            mListView.refreshComplete();
            mListView.removeAllViews();
        }

        if (mLoadingView != null) {
            mLoadingView.destroy();
        }
    }

    private static class MyPagedListDataModel extends PagedListDataModel<BaseModel> {

        public MyPagedListDataModel(ListPageInfo<BaseModel> listPageInfo) {
            super(listPageInfo);
        }

        @Override
        protected void doQueryData() {

        }
    }
}
