package com.hhdd.kada.main.common;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.android.library.utils.SafeHandler;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.module.userhabit.StaCtrName;
import com.hhdd.kada.module.userhabit.StaPageName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by simon on 4/6/16.
 */
public class DataLoadingView extends FrameLayout {

    View mContainer;
    View mainContainer;
    View loadingContainer;
    View errorContainer;
    View netErrorContainer;
    View emptyContainer;
    ImageView imageView;
    TextView loadText;
    ImageView loadShadow;

    int index;
    float angle = 360.0f;
    boolean clockwise = true;
    private AnimatorSet mAnimatorSet;
    private List<Integer> imageList;

    private static final int FRAMETIME = 100;
    private SafeHandler mHandler;
    private boolean isAnimStarting = false;

    private OnClickListener listener;

    public DataLoadingView(Context context) {
        this(context, null);
    }

    public DataLoadingView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DataLoadingView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        mContainer = LayoutInflater.from(context).inflate(R.layout.list_loading_layout, this);
        mainContainer = mContainer.findViewById(R.id.container);
        loadingContainer = mContainer.findViewById(R.id.loading_container);
        errorContainer = mContainer.findViewById(R.id.error_container);
        netErrorContainer = mContainer.findViewById(R.id.network_error_container);
        emptyContainer = mContainer.findViewById(R.id.empty_container);

        imageView = (ImageView) mContainer.findViewById(R.id.loading_image);
        loadText = (TextView) mContainer.findViewById(R.id.loading_text);
        loadShadow = (ImageView) mContainer.findViewById(R.id.loading_shadow);

        imageView.setPivotX(LocalDisplay.dp2px(30));
        imageView.setPivotY(LocalDisplay.dp2px(30));

        initImageList();

        errorContainer.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.error_page_click, TimeUtil.currentTime()));

                if (listener != null) {
                    listener.onClick(v);
                }
            }
        });

        netErrorContainer.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaCtrName.error_page_click, TimeUtil.currentTime()));

                if (listener != null) {
                    listener.onClick(v);
                }
            }
        });

        emptyContainer.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onClick(v);
                }
            }
        });

    }

    private void initImageList() {
        imageList = new ArrayList<>();
        imageList.add(R.drawable.loading1);
        imageList.add(R.drawable.loading2);
        imageList.add(R.drawable.loading3);
    }

    public void hide() {

        setVisibility(GONE);

        imageView.setImageDrawable(null);
        loadingContainer.setVisibility(GONE);
        errorContainer.setVisibility(GONE);
        netErrorContainer.setVisibility(GONE);
        emptyContainer.setVisibility(GONE);

        cancelAnim();
    }

    public void showLoading() {
        if (getVisibility() != View.VISIBLE) {
            setVisibility(VISIBLE);
        }

        errorContainer.setVisibility(GONE);
        netErrorContainer.setVisibility(GONE);
        loadingContainer.setVisibility(VISIBLE);
        emptyContainer.setVisibility(GONE);

        startLoadingAnim();

        loadText.setText("正在加载中...");
    }

    //网络有问题-》 点击重试
    public void showError() {
        if (getVisibility() != View.VISIBLE) {
            setVisibility(VISIBLE);
        }

        loadingContainer.setVisibility(View.GONE);
        netErrorContainer.setVisibility(GONE);
        emptyContainer.setVisibility(GONE);
        errorContainer.setVisibility(VISIBLE);

        cancelAnim();

        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.error_page_view, TimeUtil.currentTime()));
    }

    public void showNetError() {
        if (getVisibility() != View.VISIBLE) {
            setVisibility(VISIBLE);
        }

        loadingContainer.setVisibility(View.GONE);
        errorContainer.setVisibility(GONE);
        emptyContainer.setVisibility(GONE);
        netErrorContainer.setVisibility(VISIBLE);

        cancelAnim();

        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", StaPageName.error_page_view, TimeUtil.currentTime()));
    }

    public void showEmpty() {
        if (getVisibility() != View.VISIBLE) {
            setVisibility(VISIBLE);
        }

        loadingContainer.setVisibility(View.GONE);
        errorContainer.setVisibility(GONE);
        netErrorContainer.setVisibility(GONE);
        emptyContainer.setVisibility(VISIBLE);

        cancelAnim();
    }

    public void showNone() {
        if (getVisibility() != View.VISIBLE) {
            setVisibility(VISIBLE);
        }

        loadingContainer.setVisibility(View.GONE);
        errorContainer.setVisibility(GONE);
        netErrorContainer.setVisibility(GONE);
        emptyContainer.setVisibility(GONE);

        cancelAnim();
    }


    public void setBackgroundColor(int color) {
        mainContainer.setBackgroundColor(color);
    }

    public void setOnRetryClickListener(View.OnClickListener listener) {
        this.listener = listener;
    }

    private void startLoadingAnim() {

        if (isAnimStarting) {
            return;
        }
        isAnimStarting = true;

        index = 1;

        if (mHandler == null) {
            mHandler = new SafeHandler();
        }

        imageView.setImageResource(imageList.get(index));

        /**
         * 螃蟹上下移动动画
         */
        ObjectAnimator transYAnim1 = ObjectAnimator.ofFloat(imageView, View.TRANSLATION_Y, 0, -LocalDisplay.dp2px(100));
        transYAnim1.setInterpolator(new DecelerateInterpolator());
        transYAnim1.setDuration(5 * FRAMETIME);

        ObjectAnimator transYAnim2 = ObjectAnimator.ofFloat(imageView, View.TRANSLATION_Y, -LocalDisplay.dp2px(100), 0);
        transYAnim2.setInterpolator(new AccelerateInterpolator());
        transYAnim2.setDuration(5 * FRAMETIME);

        AnimatorSet transYSet = new AnimatorSet();
        transYSet.playSequentially(transYAnim1, transYAnim2);

        /**
         * 螃蟹纵向拉伸动画
         */
        ObjectAnimator scaleYAnim1 = ObjectAnimator.ofFloat(imageView, View.SCALE_Y, 0.65f, 1.0f);
        scaleYAnim1.setInterpolator(new LinearInterpolator());
        scaleYAnim1.setDuration(2 * FRAMETIME);

        ObjectAnimator scaleYAnim2 = ObjectAnimator.ofFloat(imageView, View.SCALE_Y, 1.0f, 0.65f);
        scaleYAnim2.setInterpolator(new LinearInterpolator());
        scaleYAnim2.setDuration(2 * FRAMETIME);

        AnimatorSet scaleYSet = new AnimatorSet();
        scaleYSet.play(scaleYAnim1);
        scaleYSet.play(scaleYAnim2).after(8 * FRAMETIME);

        /**
         * 阴影横向拉伸动画
         */
        ObjectAnimator shadowScaleYAnim1 = ObjectAnimator.ofFloat(loadShadow, View.SCALE_X, 1.0f, 0.3f);
        shadowScaleYAnim1.setInterpolator(new DecelerateInterpolator());
        shadowScaleYAnim1.setDuration(5 * FRAMETIME);

        ObjectAnimator shadowScaleYAnim2 = ObjectAnimator.ofFloat(loadShadow, View.SCALE_X, 0.3f, 1.0f);
        shadowScaleYAnim2.setInterpolator(new AccelerateInterpolator());
        shadowScaleYAnim2.setDuration(5 * FRAMETIME);

        AnimatorSet shadowScaleSet = new AnimatorSet();
        shadowScaleSet.playSequentially(shadowScaleYAnim1, shadowScaleYAnim2);

        mAnimatorSet = new AnimatorSet();
        mAnimatorSet.playTogether(transYSet, scaleYSet, shadowScaleSet);
        mAnimatorSet.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {

                if (clockwise) {
                    angle = 360.0f;
                    clockwise = false;
                } else {
                    angle = -360.0f;
                    clockwise = true;
                }

                ObjectAnimator rotationAnim = ObjectAnimator.ofFloat(imageView, View.ROTATION, 0.0f, angle);
                rotationAnim.setInterpolator(new LinearInterpolator());
                rotationAnim.setDuration(10 * FRAMETIME);
                rotationAnim.start();
            }

            @Override
            public void onAnimationEnd(Animator animation) {

                if (index < imageList.size() - 1) {
                    index = index + 1;
                } else {
                    index = 0;
                }

                imageView.setImageResource(imageList.get(index));
                if (mHandler != null) {
                    mHandler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            if (mAnimatorSet != null) {
                                mAnimatorSet.start();
                            }
                        }
                    }, 10);
                }
            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        mAnimatorSet.start();
    }

    void cancelAnim() {
        if (mAnimatorSet != null) {
            mAnimatorSet.cancel();
            mAnimatorSet.removeAllListeners();
            mAnimatorSet = null;
        }

        if (mHandler != null) {
            mHandler.destroy();
            mHandler = null;
        }

        isAnimStarting = false;
    }

    public void destroy() {

        cancelAnim();
    }
}
