package com.hhdd.kada.main.common;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListView;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.android.library.views.CustomListView;
import com.hhdd.kada.android.library.views.list.ListPageInfo;
import com.hhdd.kada.android.library.views.list.PagedListDataModel;
import com.hhdd.kada.android.library.views.list.PagedListViewDataAdapter;
import com.hhdd.kada.android.library.views.list.ViewHolderCreator;
import com.hhdd.kada.android.library.views.loadmore.LoadMoreContainer;
import com.hhdd.kada.android.library.views.loadmore.LoadMoreHandler;
import com.hhdd.kada.android.library.views.loadmore.LoadMoreListViewContainer;
import com.hhdd.kada.android.library.views.pullretofresh.PullToRefreshBase;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.base.BaseUrlApi;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.viewholders.BaseViewHolderCreator;
import com.hhdd.kada.main.viewholders.MyViewHolderCreator;
import com.hhdd.kada.main.viewholders.listener.OnEventProcessor;
import com.hhdd.kada.main.vo.BaseVO;

import java.util.List;

import in.srain.cube.views.ptr.PtrDefaultHandler;
import in.srain.cube.views.ptr.PtrFrameLayout;
import in.srain.cube.views.ptr.PtrHandler;

/**
 * Created by simon on 6/12/16.
 */
@Deprecated
@SuppressLint("ValidFragment")
public class DataListFragment2 extends TitleBasedFragment implements AbsListView.OnScrollListener{

    public static final int LIST_MODE_NONE = 0x0;
    public static final int LIST_MODE_PULL_DOWN_TO_REFRESH = PullToRefreshBase.MODE_PULL_DOWN_TO_REFRESH;
    public static final int LIST_MODE_PULL_UP_TO_REFRESH = PullToRefreshBase.MODE_PULL_UP_TO_REFRESH;
    public static final int LIST_MODE_BOTH = PullToRefreshBase.MODE_BOTH;

    private PagedListViewDataAdapter<BaseVO> mAdapter;
    private PagedListDataModel<BaseModel> mDataListModel;
    private DataLoadingView mLoadingView;
    private PtrFrameLayout mPtrFrame;
    private CustomListView mListView;
    private LoadMoreListViewContainer mLoadMoreContainer;
//    private SlidingLayout mSlidingLayout;

    private FragParamData fragParamData;

    ListPageInfo<BaseVO> dataListDisplayed;

    int dataListMode = LIST_MODE_NONE;

    protected boolean isRefresh=true;

    AbsListView.OnScrollListener onScrollListener;

    public DataListFragment2() {
        this(LIST_MODE_NONE,null,null);
    }

    public DataListFragment2(int dataListMode) {
        this(dataListMode,null,null);
    }

    public DataListFragment2(int dataListMode, String title, Object paramObject) {
        this(new FragParamData(dataListMode,title,paramObject));
    }

    public DataListFragment2(FragParamData fragParamData) {
        super();
        this.fragParamData = fragParamData;
    }

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        setInnerContentView(R.layout.data_list_layout2);
        initViews();
    }

    protected void setViewHolderCreator(ViewHolderCreator viewHolderCreator) {
        if (mAdapter!=null) {
            mAdapter.setViewHolderCreator(viewHolderCreator);
        }
        if (mListView!=null) {
            mListView.setAdapter(mAdapter);
        }
    }

    protected OnEventProcessor getOnEventProcessor() {
        return null;
    }

    protected void initViews() {

        mLoadingView = (DataLoadingView) findViewById(R.id.loading_view);

        BaseViewHolderCreator viewHolderCreator = MyViewHolderCreator.create(this);
        OnEventProcessor onEventProcessor = getOnEventProcessor();
        if (onEventProcessor != null) {
            viewHolderCreator.setOnEventProcessor(getOnEventProcessor());
        }

        mAdapter = new PagedListViewDataAdapter<BaseVO>();
        mAdapter.setViewHolderCreator(viewHolderCreator);

        mPtrFrame = (PtrFrameLayout)findViewById(R.id.list_view_container);
        mLoadMoreContainer = (LoadMoreListViewContainer)findViewById(R.id.load_more_container);

        mListView = (CustomListView)findViewById(R.id.list_view);
        mListView.setScrollingCacheEnabled(true);
        initListViewHeader(mListView);
        initListViewFooter(mListView);

        dataListDisplayed = new ListPageInfo<BaseVO>();
        mAdapter.setListPageInfo(dataListDisplayed);

        /// list mode
        dataListMode = LIST_MODE_BOTH;
        if (fragParamData!=null) {
            dataListMode = fragParamData.dataListMode;
        }

        if (fragParamData!=null&&fragParamData.title!=null&&fragParamData.title.length()>0) {
            useTitleBar(fragParamData.title);
        }

        /// data list model
        if (fragParamData!=null&&fragParamData.paramObject!=null &&fragParamData.paramObject instanceof API.PaginationUrlAPI) {
            mDataListModel = new DataListModel((API.PaginationUrlAPI)(fragParamData.paramObject),
                    fragParamData.dataListPageSize);
            ((DataListModel) mDataListModel).addListener(mListener);
        }
        if (mDataListModel==null) {
            mDataListModel = new PagedListDataModel<BaseModel>(new ListPageInfo<BaseModel>()) {
                @Override
                protected void doQueryData() {
                    //do nothing
                }
            };
        }
        mDataListModel.setPageListDataHandler(mPagedListDataHandler);


        if(dataListMode == LIST_MODE_BOTH || dataListMode == LIST_MODE_PULL_DOWN_TO_REFRESH){
            if(getContext() != null) {
                final PullRefreshFishHeaderView header = new PullRefreshFishHeaderView(getContext());
                header.setLayoutParams(new PtrFrameLayout.LayoutParams(-1, -2));
                header.setPadding(0, LocalDisplay.dp2px(15), 0, LocalDisplay.dp2px(10));
                header.setUp(mPtrFrame);

//        mPtrFrame.disableWhenHorizontalMove(true);
//        mPtrFrame.setDurationToCloseHeader(500);
//        mPtrFrame.setLoadingMinTime(300);

                mPtrFrame.setLoadingMinTime(1000);
                mPtrFrame.setDurationToCloseHeader(1500);
                mPtrFrame.setHeaderView(header);
                mPtrFrame.addPtrUIHandler(header);
            }
        }

        mPtrFrame.setPtrHandler(new PtrHandler() {
            @Override
            public boolean checkCanDoRefresh(PtrFrameLayout frame, View content, View header) {
                // here check list view, not content.
                return PtrDefaultHandler.checkContentCanBePulledDown(frame, mListView, header);
//                return true;
            }

            @Override
            public void onRefreshBegin(PtrFrameLayout frame) {
                doRefresh();
            }
        });


        mLoadMoreContainer.setOnScrollListener(this);

        mLoadMoreContainer.setShowLoadingForFirstPage(false);
        mLoadMoreContainer.setAutoLoadMore(true);
        mLoadMoreContainer.setLoadMoreHandler(new LoadMoreHandler() {
            @Override
            public void onLoadMore(LoadMoreContainer loadMoreContainer) {
                doLoadMore();
            }
        });

//        mSlidingLayout = (SlidingLayout)findViewById(R.id.sliding_layout);

        setupDataListMode();
        mListView.setAdapter(mAdapter);

        if(mLoadingView != null){
            mLoadingView.showLoading();
            mLoadingView.setOnRetryClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    handleRetry();
                }
            });
        }
//        // auto load data
//        mPtrFrame.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                mPtrFrame.autoRefresh(false);
//            }
//        }, 150);
    }

    void setupDataListMode() {
        if (dataListMode==LIST_MODE_NONE) {
            mPtrFrame.setEnabled(false);
            mLoadMoreContainer.setLoadMoreEnabled(false);
//            mSlidingLayout.setSlidingMode(SlidingLayout.SLIDING_MODE_BOTH);
        } else if (dataListMode==LIST_MODE_PULL_DOWN_TO_REFRESH) {
            mPtrFrame.setEnabled(true);
            mLoadMoreContainer.setLoadMoreEnabled(false);
//            mSlidingLayout.setSlidingMode(SlidingLayout.SLIDING_MODE_BOTTOM);
        } else if (dataListMode==LIST_MODE_PULL_UP_TO_REFRESH) {
            mPtrFrame.setEnabled(false);
            mLoadMoreContainer.setLoadMoreEnabled(true);
//            mSlidingLayout.setSlidingMode(SlidingLayout.SLIDING_MODE_TOP);
        } else {
            mPtrFrame.setEnabled(true);
            mLoadMoreContainer.setLoadMoreEnabled(true);
//            mSlidingLayout.setSlidingMode(SlidingLayout.SLIDING_MODE_NONE);
        }
    }

    protected void initListViewHeader(ListView listView) {

    }

    protected void initListViewFooter(ListView listView) {

    }

    public ListView getListView() {
        return mListView;
    }

    protected void showLoadingView() {
        if (mLoadingView!=null) {
            mLoadingView.showLoading();
        }
    }

    protected void hideLoadingView() {
        if (mLoadingView!=null) {
            mLoadingView.hide();
        }
    }

    public ListPageInfo<BaseVO> getDataListDisplayed() {
        return dataListDisplayed;
    }

    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
        if (data !=null && data instanceof FragParamData) {
            fragParamData = (FragParamData)data;
        }
    }

    protected void doRefresh() {
        if (mDataListModel!=null){
            mDataListModel.getListPageInfo().goToHead();
            mDataListModel.queryFirstPage();
        }
    }

    protected void doLoadMore() {
        if (mDataListModel!=null) {
            mDataListModel.queryNextPage();
        }
    }


    DataListModel.Listener mListener = new DataListModel.Listener() {
        @Override
        public void onLoadBegin(DataListModel listModel, boolean isFirstPage) {

        }

        @Override
        public void onLoadComplete(DataListModel listModel, boolean isFirstPage, List<BaseModel> list, boolean hasMoreData) {
            handleLoadComplete(hasMoreData);
        }

        @Override
        public void onErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg) {
            handleErrorOccurred(isFirstPage,errorCode,errorMsg);
        }
    };


    protected void handleRetry() {
        mLoadingView.showLoading();
        doRefresh();
    }

    public void handleErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg) {
        mPtrFrame.refreshComplete();
        mLoadMoreContainer.loadMoreError(0, errorMsg);
        isRefresh = false;

        if(mLoadingView != null){
            if(errorCode == BaseUrlApi.ERROR_CODE_6000){
                mLoadingView.showNetError();
            }else{
                mLoadingView.showError();
            }
        }
    }

    protected void handleLoadComplete(boolean hasMoreData) {
        mPtrFrame.refreshComplete();

        mLoadMoreContainer.loadMoreFinish(hasMoreData?false:dataListDisplayed.isEmpty(), hasMoreData);
        isRefresh = false;

        if(mLoadingView != null){
            mLoadingView.hide();
        }
    }

    protected DataListFragment2 reloadData(List<BaseModel> dataList) {
        if (mDataListModel!=null) {
            if (mDataListModel.getListPageInfo()!=null) {
                mDataListModel.getListPageInfo().goToHead();
                mDataListModel.setRequestResult(dataList,false);
            }
        }
        return this;
    }

    protected DataListFragment2 notifyDataSetChanged() {
        mAdapter.notifyDataSetChanged();
        return this;
    }

    protected DataListFragment2 reloadData(PagedListDataModel<BaseModel> dataListModel) {

        if (dataListModel!=null && mDataListModel!=dataListModel) {
            if (mDataListModel!=null && mDataListModel instanceof DataListModel) {
                ((DataListModel) mDataListModel).removeListener(mListener);
            }
            if (dataListModel instanceof DataListModel) {
                ((DataListModel) dataListModel).addListener(mListener);
            }

            mDataListModel.setPageListDataHandler(null);
            mDataListModel = dataListModel;
            mDataListModel.setPageListDataHandler(mPagedListDataHandler);
        }
        //        // auto load data
        mPtrFrame.postDelayed(new Runnable() {
            @Override
            public void run() {
                //mPtrFrame.autoRefresh(false);
                doRefresh();
            }
        }, 50);
        return this;
    }

    protected void reassembleDisplayedDataList(List<BaseVO> dataListDisplayed,
                                               List<BaseModel> itemsAdded,
                                               boolean isFirstPage) {
        if (dataListDisplayed==null||itemsAdded==null) return;

        for (BaseModel model : itemsAdded) {
            if (model instanceof BaseVO) {
                BaseVO vo = (BaseVO)model;
                dataListDisplayed.add(vo);
            }
        }
    }

    PagedListDataModel.PagedListDataHandler mPagedListDataHandler = new PagedListDataModel.PagedListDataHandler() {
        @Override
        public void onPageDataLoaded(PagedListDataModel listModel, ListPageInfo<?> listPageInfo, List<?> itemsAdded) {

            boolean isFirstPage = ((ListPageInfo<BaseModel>)listPageInfo).isFirstPage();
            boolean hasMore = ((ListPageInfo<BaseModel>)listPageInfo).hasMore();

            if (isFirstPage) {
                dataListDisplayed.getDataList().clear();
            }

            reassembleDisplayedDataList(dataListDisplayed.getDataList(),
                    (List<BaseModel>)itemsAdded,isFirstPage);

            mAdapter.notifyDataSetChanged();

            if(mLoadingView != null){
                mLoadingView.hide();
            }
        }
    };

    @Override
    public void onScrollStateChanged(AbsListView view, int scrollState) {
        switch(scrollState){
            case AbsListView.OnScrollListener.SCROLL_STATE_IDLE://空闲状态
                FrescoUtils.imageResume();
                break;
            case AbsListView.OnScrollListener.SCROLL_STATE_FLING://滚动状态
                FrescoUtils.imagePause();
                break;
            case AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL://触摸后滚动
                break;
        }
    }

    @Override
    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

    }

    public void setViewGroup(ViewGroup viewGroup){
        if(mListView != null){
            mListView.setViewGroup(viewGroup);
        }
    }

    public void setLoadingTextColor(int color){
        if(mLoadMoreContainer != null){
            mLoadMoreContainer.setFootTextColor(color);
        }
    }

}

