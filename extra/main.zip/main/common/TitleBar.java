package com.hhdd.kada.main.common;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hhdd.kada.R;

/**
 * Created by simon on 4/5/16.
 */
public class TitleBar extends RelativeLayout {

    View container;
    RelativeLayout leftViewContainer;
    ImageView leftImageView;
    RelativeLayout centerViewContainer;
    TextView centerTextView;
    RelativeLayout rightViewContainer;
    ImageView rightImageView;

    public TitleBar(Context context) {
        this(context, null);
    }

    public TitleBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TitleBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

        container = LayoutInflater.from(context).inflate(R.layout.common_titlebar, this);

        leftViewContainer = (RelativeLayout) findViewById(R.id.rl_title_bar_left);
        leftImageView = (ImageView) findViewById(R.id.iv_title_bar_left);

        centerViewContainer = (RelativeLayout) findViewById(R.id.rl_title_bar_center);
        centerTextView = (TextView) findViewById(R.id.tv_title_bar_title);

        rightViewContainer = (RelativeLayout) findViewById(R.id.rl_title_bar_right);
        rightImageView = (ImageView) findViewById(R.id.iv_title_bar_right);
    }

    public ImageView getLeftImageView() {
        return leftImageView;
    }

    public TextView getTitleTextView() {
        return centerTextView;
    }

    public ImageView getRightImageView() {
        return rightImageView;
    }

    public void setTitle(String title) {
        centerTextView.setText(title);
    }

    public void clearBackgroundColor() {
        //隐藏最下面的线
        container.findViewById(R.id.line).setVisibility(GONE);
    }

    private RelativeLayout.LayoutParams makeLayoutParams(View view) {
        ViewGroup.LayoutParams lpOld = view.getLayoutParams();
        RelativeLayout.LayoutParams lp = null;
        if (lpOld == null) {
            lp = new RelativeLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        } else {
            lp = new RelativeLayout.LayoutParams(lpOld.width, lpOld.height);
        }
        return lp;
    }

    /**
     * set customized view to left side
     *
     * @param view the view to be added to left side
     */
    public void setCustomizedLeftView(View view) {
        leftImageView.setVisibility(GONE);
        RelativeLayout.LayoutParams lp = makeLayoutParams(view);
        lp.addRule(CENTER_VERTICAL);
        lp.addRule(ALIGN_PARENT_LEFT);
        getLeftViewContainer().addView(view, lp);
    }

    /**
     * set customized view to left side
     *
     * @param layoutId the xml layout file id
     */
    public void setCustomizedLeftView(int layoutId) {
        View view = inflate(getContext(), layoutId, null);
        setCustomizedLeftView(view);
    }

    /**
     * set customized view to center
     *
     * @param view the view to be added to center
     */
    public void setCustomizedCenterView(View view) {
        centerTextView.setVisibility(GONE);
        RelativeLayout.LayoutParams lp = makeLayoutParams(view);
        lp.addRule(CENTER_IN_PARENT);
        getCenterViewContainer().addView(view, lp);
    }

    /**
     * set customized view to center
     *
     * @param layoutId the xml layout file id
     */
    public void setCustomizedCenterView(int layoutId) {
        View view = inflate(getContext(), layoutId, null);
        setCustomizedCenterView(view);
    }

    /**
     * set customized view to right side
     *
     * @param view the view to be added to right side
     */
    public void setCustomizedRightView(View view) {
        RelativeLayout.LayoutParams lp = makeLayoutParams(view);
        lp.addRule(CENTER_VERTICAL);
        lp.addRule(ALIGN_PARENT_RIGHT);
        getRightViewContainer().addView(view, lp);
    }

    public void setCustomizedRightView(int layoutId) {
        View view = inflate(getContext(), layoutId, null);
        setCustomizedRightView(view);
    }

    public RelativeLayout getLeftViewContainer() {
        return leftViewContainer;
    }

    public RelativeLayout getCenterViewContainer() {
        return centerViewContainer;
    }

    public RelativeLayout getRightViewContainer() {
        return rightViewContainer;
    }

    public void setLeftOnClickListener(final OnClickListener l) {
        leftViewContainer.setOnClickListener(l);
    }

    public void setCenterOnClickListener(OnClickListener l) {
        centerViewContainer.setOnClickListener(l);
    }

    public void setRightOnClickListener(OnClickListener l) {
        rightViewContainer.setOnClickListener(l);
    }
}
