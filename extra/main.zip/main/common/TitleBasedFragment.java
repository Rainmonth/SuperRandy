package com.hhdd.kada.main.common;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.postprocessors.IterativeBoxBlurPostProcessor;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.base.BaseFragment;
import com.hhdd.kada.main.utils.FrescoUtils;

/**
 * Created by simon on 4/5/16.
 */
public class TitleBasedFragment extends BaseFragment {

    protected TitleBar titleBar;
    protected FrameLayout innerContainer;
    protected View innerContentView;
    protected LinearLayout container;
    protected SimpleDraweeView background;

    @Override
    protected void onCreateView(Bundle savedInstanceState) {
        super.onCreateView(savedInstanceState);
        setContentView(R.layout.fragment_with_titlebar);

        titleBar = (TitleBar) findViewById(R.id.titlebar);
        titleBar.setVisibility(View.GONE);
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.KITKAT){
            titleBar.setPadding(0, LocalDisplay.SCREEN_STATUS_HEIGHT, 0, 0);
            ViewGroup.LayoutParams titleBarLayoutParams = titleBar.getLayoutParams();
            if (titleBarLayoutParams == null) {
                titleBarLayoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            }
            titleBarLayoutParams.height = (int) (KaDaApplication.getInstance().getResources().getDimension(R.dimen.common_titlebar_height) + LocalDisplay.SCREEN_STATUS_HEIGHT);
        }


        innerContainer = (FrameLayout) findViewById(R.id.content_cotainer);
        container = (LinearLayout) findViewById(R.id.container);
        background = (SimpleDraweeView) findViewById(R.id.background);

        setBackgroundResource(R.drawable.bg_mother_header);

        titleBar.setLeftOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    public void useTitleBar(String title) {
        useTitleBar(true);
        titleBar.setTitle(title);
    }

    public void useTitleBar(boolean use) {
        titleBar.setVisibility(use ? View.VISIBLE : View.GONE);
    }

    public void setInnerContentView(int layoutResID) {
        setInnerContentView(inflater.inflate(layoutResID, innerContainer, false));
    }

    public void setInnerContentView(View view) {
        innerContentView = view;
        if (innerContentView != null) {
            innerContentView.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
            innerContainer.addView(innerContentView);
        }
    }

    public void setInnerViewPaddingBottom(int paddingBottom) {
        if (innerContentView != null) {
            innerContentView.setPadding(0, 0, 0, paddingBottom);
        }
    }

    public void setInnerViewPadding(int paddingLeft, int paddingTop, int paddingRight, int paddingBottom) {
        if (innerContentView != null) {
            innerContentView.setPadding(paddingLeft, paddingTop, paddingRight, paddingBottom);
        }
    }

    /**
     * @param color 颜色值
     */
    public void setBackgroundColor(int color) {
        background.setImageDrawable(null);
        background.setBackgroundColor(color);
    }

    /**
     * @param resId 背景资源Id
     */
    public void setBackgroundResource(int resId) {
        background.setImageDrawable(null);
        background.setBackgroundResource(resId);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        background.setImageDrawable(null);
        background.setBackgroundDrawable(drawable);
    }

    // 加载网络图片作为背景
    public void setBackground(String url, int placeholderImgResId) {
        background.setBackgroundDrawable(null);
        background.getHierarchy().setPlaceholderImage(placeholderImgResId);
        FrescoUtils.showImg(background, url);
    }

    // 以高斯模糊形式加载背景
    public void setBackgroundBlur(String imgUrl, int placeholderResId) {
        background.setBackgroundDrawable(null);
        background.getHierarchy().setPlaceholderImage(placeholderResId);
        FrescoUtils.showImg(background, new IterativeBoxBlurPostProcessor(30), imgUrl, 0, 0);
    }

    public FrameLayout getInnerContainer() {
        return innerContainer;
    }

    public LinearLayout getContainer() {
        return container;
    }


    public View getInnerContentView() {
        return innerContentView;
    }

    public TitleBar getTitleBar() {
        return titleBar;
    }

    /**
     * make it looks like Activity
     */
    protected void onBackPressed() {
        Activity activity = getContext();
        // 这里一定要加判空
        if (activity == null || activity.isFinishing()) {
            return;
        }

        activity.onBackPressed();
    }


    @Override
    public boolean processBackPressed() {
        return super.processBackPressed();
    }


    @Override
    public void onEnter(Object data) {
        super.onEnter(data);
    }

}
