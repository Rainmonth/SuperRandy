package com.hhdd.kada.main.common;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import com.hhdd.kada.R;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.base.BaseFragmentActivity;
import com.hhdd.kada.main.utils.InputMethodUtil;
import com.hhdd.logger.LogHelper;

import java.io.Serializable;

/**
 * Created by simon on 5/11/16.
 */
public class FragmentHolderActivity extends BaseFragmentActivity {

    public static final String Param_Fragment_Class_Name = "Class_Name";
    public static final String Param_Data = "Param_Data";

    public static void presentActivity(BaseFragmentActivity context, Class cls, Serializable data) {
        if (context == null || context.isFinishing() || cls == null) {
            return;
        }

        Intent intent = new Intent(context, FragmentHolderActivity.class);
        intent.putExtra(Param_Fragment_Class_Name, cls.getName());
        if (data != null) {
            intent.putExtra(Param_Data, data);
        }
        context.presentActivity(intent);
    }

    public static void presentActivity(BaseActivity context, Class cls, Serializable data) {
        if (context == null || context.isFinishing() || cls == null) {
            return;
        }

        Intent intent = new Intent(context, FragmentHolderActivity.class);
        intent.putExtra(Param_Fragment_Class_Name, cls.getName());
        if (data != null) {
            intent.putExtra(Param_Data, data);
        }
        context.startActivity(intent);
    }

    public static void pushActivity(BaseFragmentActivity context, Class cls, Serializable data) {
        if (context == null || context.isFinishing() || cls == null) {
            return;
        }

        Intent intent = new Intent(context, FragmentHolderActivity.class);
        intent.putExtra(Param_Fragment_Class_Name, cls.getName());
        if (data != null) {
            intent.putExtra(Param_Data, data);
        }
        context.pushActivity(intent);
    }

    public static void pushActivity(BaseActivity context, Class cls, Serializable data) {
        if (context == null || context.isFinishing() || cls == null) {
            return;
        }

        Intent intent = new Intent(context, FragmentHolderActivity.class);
        intent.putExtra(Param_Fragment_Class_Name, cls.getName());
        if (data != null) {
            intent.putExtra(Param_Data, data);
        }
        context.startActivity(intent);
    }

    public static void pushActivity(Activity context, Class cls, Serializable data) {
        if (context == null || context.isFinishing() || cls == null) {
            return;
        }
        Intent intent = new Intent(context, FragmentHolderActivity.class);
        intent.putExtra(Param_Fragment_Class_Name, cls.getName());
        if (data != null) {
            intent.putExtra(Param_Data, data);
        }
        context.startActivity(intent);
    }

    private String className;
    private Serializable data;

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (savedInstanceState != null) {
            int count = getSupportFragmentManager().getBackStackEntryCount();
            if (count <= 1) {
                finish();
            }
        } else {
            setContentView(R.layout.activity_fragment_holder);

            //启动
            present();
        }
    }

    void present() {
        Intent intent = getIntent();
        if (intent == null) {
            finish();

            return;
        }

        //启动
        className = intent.getStringExtra(Param_Fragment_Class_Name);
        data = intent.getSerializableExtra(Param_Data);
        if (className != null && className.length() > 0) {
            try {
                Class cls = Class.forName(className);
                pushFragmentToBackStackNoAnim(cls, data);
                return;
            } catch (ClassNotFoundException e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    public Serializable getData() {
        return data;
    }

    @Override
    protected int getFragmentContainerId() {
        return R.id.fragment_container;
    }

    @Override
    public void finish() {
        super.finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        InputMethodUtil.fixInputMethodManagerLeak(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
