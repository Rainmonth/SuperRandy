package com.hhdd.kada.main.common;

import android.app.Activity;

import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.base.BaseActivity;
import com.hhdd.kada.base.BaseFragmentActivity;

import java.io.Serializable;

/**
 * Created by simon on 6/25/16.
 */
public class FragmentUtil {

    public static Activity getTopActivity() {
        for (int i=ActivityHelper.getActivities().size()-1;i>=0;i--) {
            Activity activity = ActivityHelper.getActivities().get(i);
            if (!activity.isFinishing()) {
                if (activity instanceof BaseFragmentActivity) {
                    return activity;
                }
                else if (activity instanceof BaseActivity) {
                    return activity;
                }
                //兼容老的
                else if (activity instanceof BaseFragmentActivity) {
                    return activity;
                }
                else if (activity instanceof BaseActivity) {
                    return activity;
                }
                break;
            }
        }
        return null;
    }

    public static void pushFragment(Class<?> cls, Serializable data) {
        pushFragment(cls,data,false);
    }

    public static void pushFragment(Class<?> cls, Serializable data, boolean useFragmentHolderByForce) {
        if (ActivityHelper.getActivities().size()>0) {
            int count = ActivityHelper.getActivities().size();
            for (int i=count-1;i>=0;i--) {
                Activity activity = ActivityHelper.getActivities().get(i);
                if (!activity.isFinishing()) {
                    if (activity instanceof BaseFragmentActivity) {
                        if (!useFragmentHolderByForce) {
                            ((BaseFragmentActivity)activity).pushFragmentToBackStack(cls,data);
                        } else {
                            FragmentHolderActivity.pushActivity((BaseFragmentActivity)activity,cls,data);
                        }
                    }
                    else if (activity instanceof BaseActivity) {
                        FragmentHolderActivity.pushActivity((BaseActivity)activity,cls,data);
                    }
                    //兼容老的
                    else if (activity instanceof BaseFragmentActivity) {
                        FragmentHolderActivity.pushActivity(activity,cls,data);
                    }
                    else if (activity instanceof BaseActivity) {
                        FragmentHolderActivity.pushActivity(activity,cls,data);
                    }
                    break;
                }
            }
        }
    }


    public static void presentFragment(Class<?> cls, Serializable data) {
        presentFragment(cls,data,false);
    }

    public static void presentFragment(Class<?> cls, Serializable data, boolean useFragmentHolderByForce) {
        if (ActivityHelper.getActivities().size()>0) {
            int count = ActivityHelper.getActivities().size();
            for (int i=count-1;i>=0;i--) {
                Activity activity = ActivityHelper.getActivities().get(i);
                if (!activity.isFinishing()) {
                    if (activity instanceof BaseFragmentActivity) {
                        if (!useFragmentHolderByForce) {
                            ((BaseFragmentActivity)activity).presentFragmentToBackStack(cls,data);
                        } else {
                            FragmentHolderActivity.presentActivity((BaseFragmentActivity)activity,cls,data);
                        }
                    }
                    else if (activity instanceof BaseActivity) {
                        FragmentHolderActivity.presentActivity((BaseActivity)activity,cls,data);
                    }
                    //兼容老的
                    else if (activity instanceof BaseFragmentActivity) {
                        FragmentHolderActivity.pushActivity(activity,cls,data);
                    }
                    else if (activity instanceof BaseActivity) {
                        FragmentHolderActivity.pushActivity(activity,cls,data);
                    }
                    break;
                }
            }
        }
    }
}
