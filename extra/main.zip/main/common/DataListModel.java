package com.hhdd.kada.main.common;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.android.library.views.list.ListPageInfo;
import com.hhdd.kada.android.library.views.list.PagedListDataModel;
import com.hhdd.kada.api.API;
import com.hhdd.kada.api.PaginationData;
import com.hhdd.kada.main.model.BaseModel;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by simon on 4/6/16.
 */
public class DataListModel extends PagedListDataModel<BaseModel> {

    private List<Listener> listeners = new ArrayList<Listener>();

    private API.PaginationUrlAPI<BaseModel> mUrlAPI;

    private volatile boolean mIsLoading = false;

    public DataListModel(API.PaginationUrlAPI<BaseModel> urlAPI, int pageSize) {
        super(new ListPageInfo<BaseModel>(pageSize));
        mUrlAPI = urlAPI;
    }

    public void addListener(Listener listener) {
        if (!this.listeners.contains(listener)) {
            this.listeners.add(listener);
        }
    }

    public void removeListener(Listener listener) {
        if (this.listeners != null) {
            this.listeners.remove(listener);
        }
    }

    public boolean isLoading() {
        return mIsLoading;
    }

    protected PaginationData<BaseModel> parseResponseJsonData(String responseJsonData) {
        return mUrlAPI.parseResponseJsonData(responseJsonData);
    }

    @Override
    protected void doQueryData() {
        if (mUrlAPI == null) {
            return;
        }

        if (isLoading()) {
            return;
        }

        mIsLoading = true;

        final boolean isFirstPage = mListPageInfo.isFirstPage();
        int page = mListPageInfo.getPage();
        int size = mListPageInfo.getNumPerPage();
        Map<String, String> args = new HashMap<String, String>();
        args.put("pagingSize", String.valueOf(size));
        args.put("pagingNumber", String.valueOf(page));

        if (isFirstPage) {
            mUrlAPI.setNeedCache(true);
        } else {
            mUrlAPI.setNeedCache(false);
        }


        mUrlAPI.get(args, new API.CachedResponseHandler<PaginationData<BaseModel>>() {
            @Override
            public void onFirstLoadFromCache(final PaginationData<BaseModel> cachedData) {
                KaDaApplication.mainLooperHandler().post(new Runnable() {
                    @Override
                    public void run() {
                        if (cachedData != null) {
                            setRequestResult(cachedData.getList(), cachedData.hasMore());
                            for (DataListModel.Listener listener : listeners) {
                                listener.onLoadComplete(DataListModel.this, isFirstPage, cachedData.getList(), cachedData.hasMore());
                            }
                        } else {
                            setRequestResult(null, false);
                            for (DataListModel.Listener listener : listeners) {
                                listener.onLoadComplete(DataListModel.this, isFirstPage, null, false);
                            }
                        }
                    }
                });
            }

            @Override
            public void onSuccess(final PaginationData<BaseModel> responseData) {
                mIsLoading = false;

                if (responseData != null) {
                    KaDaApplication.mainLooperHandler().post(new Runnable() {
                        @Override
                        public void run() {

                            setRequestResult(responseData.getList(), responseData.hasMore());

                            for (Listener listener : listeners) {
                                listener.onLoadComplete(DataListModel.this, isFirstPage, responseData.getList(), responseData.hasMore());
                            }
                        }
                    });
                } else {
                    KaDaApplication.mainLooperHandler().post(new Runnable() {
                        @Override
                        public void run() {

                            setRequestResult(null, false);

                            for (Listener listener : listeners) {
                                listener.onLoadComplete(DataListModel.this, isFirstPage, null, false);
                            }
                        }
                    });
                }

            }

            @Override
            public void onFailure(int code, String message) {
                mIsLoading = false;

                setRequestFail();

                for (Listener listener : listeners) {
                    listener.onErrorOccurred(isFirstPage, code, message);
                }
            }
        });

        for (Listener listener : listeners) {
            listener.onLoadBegin(this, isFirstPage);
        }
    }

    public interface Listener {
        void onLoadBegin(DataListModel listModel, boolean isFirstPage);

        void onLoadComplete(DataListModel listModel, boolean isFirstPage, List<BaseModel> list, boolean hasMoreData);

        void onErrorOccurred(boolean isFirstPage, int errorCode, String errorMsg);
    }
}
