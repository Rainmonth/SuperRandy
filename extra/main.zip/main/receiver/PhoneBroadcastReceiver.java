package com.hhdd.kada.main.receiver;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.telephony.TelephonyManager;

import com.hhdd.kada.KaDaApplication;

/**
 * Created by lj on 16/5/13.
 */
public class PhoneBroadcastReceiver extends BroadcastReceiver {

    private static final String TAG = "message";
    private static boolean mIncomingFlag = false;
    private static String mIncomingNumber = null;


    public static final String ACTION_PHONE_STATE_CHANGE = "com.hhdd.kada.phone_state";
    public static final String ACTION_PHONE_STATE = "phone_state_key";

    @Override
    public void onReceive(Context context, Intent intent) {
        // 如果是拨打电话
        if (intent.getAction().equals(Intent.ACTION_NEW_OUTGOING_CALL)) {
            mIncomingFlag = false;

            Intent intent1 = new Intent(PhoneBroadcastReceiver.ACTION_PHONE_STATE_CHANGE);
//        intent1.putExtra(PhoneBroadcastReceiver.ACTION_PHONE_STATE, networkStatus);
            LocalBroadcastManager.getInstance(KaDaApplication.getInstance()).sendBroadcast(intent1);
        } else {
            // 如果是来电
            TelephonyManager tManager = (TelephonyManager) context
                    .getSystemService(Service.TELEPHONY_SERVICE);
            switch (tManager.getCallState()) {

                case TelephonyManager.CALL_STATE_RINGING:
                    mIncomingNumber = intent.getStringExtra("incoming_number");
                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    if (mIncomingFlag) {
                    }
                    break;
                case TelephonyManager.CALL_STATE_IDLE:
                    if (mIncomingFlag) {
                    }
                    break;
            }

            Intent intent1 = new Intent(PhoneBroadcastReceiver.ACTION_PHONE_STATE_CHANGE);
//        intent1.putExtra(PhoneBroadcastReceiver.ACTION_PHONE_STATE, networkStatus);
            LocalBroadcastManager.getInstance(KaDaApplication.getInstance()).sendBroadcast(intent1);
        }
    }


    /*@Override
    public void onReceive(Context context, Intent intent) {
        String number = getResultData();
        if("5556".equals(number)){
            setResultData(null);//挂断
        }else{
            number = "12593"+ number; //其他，则加区号
            setResultData(number);
        }
    }*/
}