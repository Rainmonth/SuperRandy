package com.hhdd.kada.main.receiver;

/**
 * Created by lj on 15/11/17.
 */

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.Constants;
import com.hhdd.kada.URLScheme;
import com.hhdd.kada.android.library.app.ActivityHelper;
import com.hhdd.kada.main.event.CloseRestEvent;
import com.hhdd.kada.main.event.CloseSleepEvent;
import com.hhdd.kada.main.event.UnLockEvent;
import com.hhdd.kada.main.model.GetuiMessageModel;
import com.hhdd.kada.main.ui.activity.MainActivity;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.ui.activity.RestActivity;
import com.hhdd.kada.main.ui.activity.SleepActivity;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.logger.LogHelper;
import com.igexin.sdk.PushConsts;
import com.igexin.sdk.PushManager;

import de.greenrobot.event.EventBus;

public class GetuiPushReceiver extends BroadcastReceiver {

    /**
     * 应用未启动, 个推 service已经被唤醒,保存在该时间段内离线消息(此时 GetuiSdkDemoActivity.tLogView == null)
     */

    @Override
    public void onReceive(final Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        LogHelper.d("GetuiSdkDemo", "onReceive() action=" + bundle.getInt("action"));
        switch (bundle.getInt(PushConsts.CMD_ACTION)) {
            case PushConsts.GET_MSG_DATA:
                // 获取透传数据
                // String appid = bundle.getString("appid");
                byte[] payload = bundle.getByteArray("payload");

                String taskid = bundle.getString("taskid");
                String messageid = bundle.getString("messageid");

                // smartPush第三方回执调用接口，actionid范围为90000-90999，可根据业务场景执行
                boolean result = PushManager.getInstance().sendFeedbackMessage(context, taskid, messageid, 90001);
                System.out.println("第三方回执接口调用" + (result ? "成功" : "失败"));

                if (payload != null) {
                    final String data = new String(payload);

                    LogHelper.d("GetuiSdkDemo", "receiver payload : " + data);

                    Gson gson = new Gson();
                    GetuiMessageModel message = gson.fromJson(data, new TypeToken<GetuiMessageModel>() {
                    }.getType());

                    if(message != null){
                        LogHelper.d("GetuiSdkDemo", "message : " + message.toString());
                        //收到推送后，如果app是运行的，则推到前台，否则启动app；如果收到的协议为opencontroller，并且当前页面不为主页(一级页面)，不处理
                        boolean isSkip = true;
                        String redirectUrl = message.getRedirect_url();
                        if(!TextUtils.isEmpty(redirectUrl)) {
                            Uri uri = Uri.parse(redirectUrl);
                            if(!TextUtils.isEmpty(uri.getHost()) && uri.getHost().compareToIgnoreCase(URLScheme.REDIRECT_URI_FORMAT_OPENCONTROLLER) == 0){
                                isSkip = MainActivity.class.getName().equals(AppUtils.getTopActivityClassName());
                            }
                        }
                        UserHabitService.getInstance().track(UserHabitService.newUserHabit(redirectUrl, "clickpush", TimeUtil.currentTime()));
                        if(AppUtils.isRunning()){
                            AppUtils.moveToFront();
                            Activity activity = ActivityHelper.getTopActivity();
                            if(activity instanceof RestActivity) {
                                EventBus.getDefault().post(new CloseRestEvent());
                                EventBus.getDefault().post(new UnLockEvent(UnLockEvent.TYPE_REST_AUTO));
                                ActivityHelper.unregisterActivity(activity);
                            } else if(activity instanceof SleepActivity) {
                                EventBus.getDefault().post(new CloseSleepEvent());
                                EventBus.getDefault().post(new UnLockEvent(UnLockEvent.TYPE_SLEEP_PUSH));
                                ActivityHelper.unregisterActivity(activity);
                            }
                            if(isSkip) {
                                RedirectActivity.startActivity(context, redirectUrl);
                            }
                        } else {
                            if(!isSkip) {
                                redirectUrl = "";
                            }
                            ActivityUtil.nextLaunchActivity(context, redirectUrl, Constants.LAUNCH_FROM_TYPE_PUSH);
                        }
                    }

//                    ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
//                    List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(100);
//                    boolean isAppRunning = false;
//                    String MY_PKG_NAME = "com.hhdd.kada";
//                    for (ActivityManager.RunningTaskInfo info : list) {
//                        if (info.topActivity.getPackageName().equals(MY_PKG_NAME) || info.baseActivity.getPackageName().equals(MY_PKG_NAME)) {
//                            isAppRunning = true;
//                            break;
//                        }
//                    }

//                    notification(message,intent,context);
                }
                break;
            case PushConsts.GET_CLIENTID:
                // 获取ClientID(CID)
                // 第三方应用需要将CID上传到第三方服务器，并且将当前用户帐号和CID进行关联，以便日后通过用户帐号查找CID进行消息推送
                String cid = bundle.getString("clientid");
                LogHelper.d("GetuiSdkDemo",cid);
//                if (GetuiSdkDemoActivity.tView != null) {
//                    GetuiSdkDemoActivity.tView.setText(cid);
//                }
                break;

            case PushConsts.THIRDPART_FEEDBACK:
                /*
                 * String appid = bundle.getString("appid"); String taskid =
                 * bundle.getString("taskid"); String actionid = bundle.getString("actionid");
                 * String result = bundle.getString("result"); long timestamp =
                 * bundle.getLong("timestamp");
                 *
                 * Log.d("GetuiSdkDemo", "appid = " + appid); Log.d("GetuiSdkDemo", "taskid = " +
                 * taskid); Log.d("GetuiSdkDemo", "actionid = " + actionid); Log.d("GetuiSdkDemo",
                 * "result = " + result); Log.d("GetuiSdkDemo", "timestamp = " + timestamp);
                 */
                break;

            default:
                break;
        }
    }


//    private void notification(GetuiMessageModel msg, Intent intent,Context context) {
//
//        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
//        String runningActivity = am.getRunningTasks(1).get(0).topActivity.getClassName();
//        List<ActivityManager.RunningTaskInfo> list = am.getRunningTasks(100);
//        boolean isAppRunning = false;
//        String MY_PKG_NAME = "com.hhdd.kada";
//        for (ActivityManager.RunningTaskInfo info : list) {
//            if (info.topActivity.getPackageName().equals(MY_PKG_NAME) || info.baseActivity.getPackageName().equals(MY_PKG_NAME)) {
//                isAppRunning = true;
//                break;
//            }
//        }

//        String type_id = msg.getRedirect_url();
//        Intent intent1 = null;
//        intent1 = new Intent(context, RedirectActivity.class);
//        intent1.setData(Uri.parse(type_id));
//        //启动activity必须加上Flags
//        intent1.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        intent1.putExtra("flag", RedirectActivity.PUSH_CLICK);
//        intent1.putExtra("runningActivity", runningActivity);
//        intent1.putExtra("isAppRunning",isAppRunning);
//
//
//        final PendingIntent mainIntent = PendingIntent.getActivity(
//                context, 1, intent1,
//                PendingIntent.FLAG_UPDATE_CURRENT);
////        NotificationManage.getInstance(context).notify(
////                1,
////                NotificationManage.generalNotification(
////                        context, mainIntent, 1,
////                        R.drawable.app_icon, null, msg.getTitle(), msg.getTitle(),
////                        msg.getText(), true));
//    }


//    public static class NotificationManage {
//
//        private static NotificationManager mNotificationManager;
//
//        public static NotificationManager getInstance(Context context) {
//            if (mNotificationManager == null) {
//                mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
//            }
//            return mNotificationManager;
//        }
//
//        public static void clearAllLWNotification(Context context) {
//            if (context == null) {
//                return;
//            }
//            try {
//                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
//                nm.cancelAll();
//            } catch (Throwable tr) {
//            }
//        }
//
//
//        public static Notification generalNotification(Context context, PendingIntent intent, int notficationId,
//                                                       int notifyIconId, Bitmap largeIcon, String tickerText, String title, String text, boolean isRemind) {
//            if (largeIcon == null) {
//
//                BitmapDrawable bitmap = (BitmapDrawable) KaDaApplication.getInstance().getResources().getDrawable(notifyIconId);
//                if (bitmap != null) {
//                    largeIcon = bitmap.getBitmap();
//                } else {
//
//                    bitmap = (BitmapDrawable) KaDaApplication.getInstance().getResources().getDrawable(R.drawable.app_icon);
//                    largeIcon = bitmap.getBitmap();
//                }
//            }
//            NotificationCompat.Builder builder = new NotificationCompat.Builder(context);
//            //对于通知栏上的内容，不应该进行图片的拉伸，否则会导致图片效果的模糊
////		largeIcon = Bitmap.createScaledBitmap(largeIcon, AndTools.dp2px(BBLApplication.getInstance(), 64), AndTools.dp2px(BBLApplication.getInstance(), 64), false);
//            builder.setLargeIcon(largeIcon).setSmallIcon(R.drawable.app_icon).setContentTitle(title).setContentText(text);
//            builder.setTicker(tickerText);
//            builder.setContentIntent(intent);
//            builder.setAutoCancel(true).setOnlyAlertOnce(true).setLights(0xff00ff00, 5000, 5000);
//            int defaults = 0;
//            if (isRemind) {
////			 String ringtoneUri = LocalNotifySetting.getPrefNotifyString(
////		                Preferences.PREF_KEY_RINGTONE, null);
////			 boolean soundNotify = LocalNotifySetting.getPrefNotifyValue(Preferences.PREF_KEY_NOTFIY_SOUND, true);
//                AudioManager audio = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
//                int systemRingerMode = audio.getRingerMode();
//                if (systemRingerMode == AudioManager.RINGER_MODE_NORMAL) {
//                    // 声音开关是否打开
////				 if(soundNotify){
////	    			//判断是否处于静音模式，如果处于静音模式，在通知提醒的时候则不应该播放通知铃声
////	    		     if (ringtoneUri != null) {
////	    		    	 builder.setSound(Uri.parse(ringtoneUri));
////	    		     } else {
////	    		    	 //判断用户是主动静音还是在首次登陆的时候没有设置过语音提示内容
////	    		    	 boolean isSilenceMode = LocalNotifySetting.getPrefNotifyValue(Preferences.RINGTONE_SILINCE_MODE, false);
////	    		    	 if(!isSilenceMode){
//                    defaults |= Notification.DEFAULT_SOUND;
////	    		    	 }
////	    		     }
////				 }
//                }
////		     if (LocalNotifySetting.getPrefNotifyValue(Preferences.PREF_KEY_VIBRATE, true)) {
//                defaults |= Notification.DEFAULT_VIBRATE;
////		     }
//
//            }
//            if (defaults != 0) {
//                builder.setDefaults(defaults);
//            }
//            return builder.build();
//        }
//    }

}

