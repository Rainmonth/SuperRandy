package com.hhdd.kada.main.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.hhdd.kada.KaDaApplication;


import com.hhdd.kada.main.listen.ListenService2;


/**
 * Created by sxh on 2017/7/11.
 * 监听ListenService被回收
 */

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals("com.hhdd.listen.destroy")) {
            //重新启动service的相关操作
            Context ctx = KaDaApplication.getInstance();
            Intent listenIntent = new Intent(ctx, ListenService2.class);
            listenIntent.setAction(ListenService2.INTENT_ACTION);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_TYPE, ListenService2.Types.START);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_INDEX, 0);
            listenIntent.putExtra(ListenService2.INTENT_PARAM_START_POSITION, 0);
            KaDaApplication.getInstance().startService(listenIntent);
        }
    }
}
