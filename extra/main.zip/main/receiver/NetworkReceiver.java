package com.hhdd.kada.main.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.main.utils.NetworkStatusUtil;
import com.hhdd.kada.main.utils.NetworkUtils;

/**
 * Created by simon on 23/6/15.
 */
public class NetworkReceiver extends BroadcastReceiver {

    public static final String ACTION_NETWORK_CHANGED = "com.hhdd.kada.network_changed";
    public static final String ACTION_NETWORK_CHANGED_STATE_KEY = "network_state_key";

    public static String sNetworkStatus;
    public static int sNetworkType;

    public static void registerReceiver(Context context) {
        if (context!=null) {
            IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
            NetworkReceiver networkReceiver = new NetworkReceiver();
            context.registerReceiver(networkReceiver, filter);
        }
    }
    public NetworkReceiver() {
        updateNetworkStatus();
    }

    @Override
    public void onReceive(Context context, Intent intent) {

        String action = intent.getAction();
        if(TextUtils.equals(action, ConnectivityManager.CONNECTIVITY_ACTION)){
            ConnectivityManager connectivity = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo info = connectivity.getActiveNetworkInfo();
            if (null==info) {
                return;
            }

            int status = getNetworkStatus(context);
            if (status == 0) { //如果是连接中间状态，不错处理。
                return;
            }
            boolean networkStatus = false;
            if (status == 1) {
                networkStatus = true;
            }

            updateNetworkStatus();

            Intent intent1 = new Intent(NetworkReceiver.ACTION_NETWORK_CHANGED);
            intent1.putExtra(NetworkReceiver.ACTION_NETWORK_CHANGED_STATE_KEY, networkStatus);
            LocalBroadcastManager.getInstance(KaDaApplication.getInstance()).sendBroadcast(intent1);
        }
    }

    private String updateNetworkStatus() {
        boolean networkStatus = NetworkUtils.isNetworkAvailable(KaDaApplication.getInstance());
        if (networkStatus) {
            NetworkStatusUtil.NetworkStatus status = NetworkStatusUtil.getNetworkStatus(KaDaApplication.getInstance());
            sNetworkStatus = status.networkStatus;
            sNetworkType = status.networkType;
        } else {
            sNetworkStatus = null;
            sNetworkType = NetworkStatusUtil.NETWORK_NO_NETWORK;
        }
        return sNetworkStatus;
    }

    /**
     * 获取网络类型
     *
     * @param context Context对象
     * @return -1 网络不通
     * 0 中间状态
     * 1 网络联通
     */
    public static int getNetworkStatus(Context context) {
        int result = -1;
        ConnectivityManager connectivity = (ConnectivityManager) (context.getSystemService(Context.CONNECTIVITY_SERVICE));
        if (connectivity == null) {
            result = -1;
        } else {
            NetworkInfo[] info = null;
            try {
                info = connectivity.getAllNetworkInfo();
            } catch (Exception e) {
            }
            if (info != null) {
                for (int i = 0; i < info.length; i++) {
                    if (info[i] != null) {
                        NetworkInfo.State tem = info[i].getState();
                        if (tem == NetworkInfo.State.CONNECTING) {
                            result = 0;
                        }
                        if (tem == NetworkInfo.State.CONNECTED) { //一旦有网络是联通的则触发返回
                            result = 1;
                            break;
                        }
                    }
                }
            }
        }
        return result;
    }
}

