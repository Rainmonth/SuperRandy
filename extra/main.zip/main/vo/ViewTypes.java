package com.hhdd.kada.main.vo;


import com.hhdd.kada.coin.viewholder.ExploreHeadViewHolder;
import com.hhdd.kada.coin.viewholder.ExploreTaskViewHolder;
import com.hhdd.kada.main.ui.story.StoryFragment;
import com.hhdd.kada.main.viewholders.AutoLayoutViewHolder;
import com.hhdd.kada.main.viewholders.BannerViewHolder;
import com.hhdd.kada.main.viewholders.Book1x3ViewHolder;
import com.hhdd.kada.main.viewholders.Book2x2ViewHolder;
import com.hhdd.kada.main.viewholders.BookListViewHolder;
import com.hhdd.kada.main.viewholders.CompatEmptyViewHolder;
import com.hhdd.kada.main.viewholders.ExploreRecommendViewHolder;
import com.hhdd.kada.main.viewholders.FlipTextViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentBigImage1x2ViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentBookViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentCircleViewHolderByConfig;
import com.hhdd.kada.main.viewholders.MotherExcellentPositionSubjectViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentSingleBookCollectViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentSingleStoryCollectViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentStoryViewHolder;
import com.hhdd.kada.main.viewholders.MotherExcellentSubjectViewHolder;
import com.hhdd.kada.main.viewholders.OrgSlideViewHolder;
import com.hhdd.kada.main.viewholders.RecommendArticleViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorLineViewHolder;
import com.hhdd.kada.main.viewholders.SeparatorViewHolder;
import com.hhdd.kada.main.viewholders.Story1x3ViewHolder;
import com.hhdd.kada.main.viewholders.Story2x2ViewHolder;
import com.hhdd.kada.main.viewholders.StoryCateViewHolder;
import com.hhdd.kada.main.viewholders.StoryConfigPositionViewHolder;
import com.hhdd.kada.main.viewholders.StoryListViewHolder;
import com.hhdd.kada.main.viewholders.StorySchemaTwoColViewHolder;
import com.hhdd.kada.main.viewholders.TitleViewHolder;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by simon on 5/31/16.
 */
public enum ViewTypes {

    View_Type_CompatEmpty(0, CompatEmptyViewHolder.class),

    View_Type_Separator(1, SeparatorViewHolder.class),
    View_Type_SeparatorLine(2, SeparatorLineViewHolder.class),
    View_Type_DataList_Banner(10, BannerViewHolder.class),
    View_Type_DataList_StoryCate(11, StoryCateViewHolder.class),
    View_Type_DataList_Title(12, TitleViewHolder.class),
    View_Type_DataList_OrgSlide(13, OrgSlideViewHolder.class),
    View_Type_DataList_StoryList(14, StoryListViewHolder.class),
    View_Type_DataList_StoryCollect2X2(15, Story2x2ViewHolder.class), //合集 2X2布局
    View_Type_DataList_StoryCollect1X3(16, Story1x3ViewHolder.class), //合集 1X3布局

    View_Type_DataList_AutoLayout(18, AutoLayoutViewHolder.class), //三个故事

    View_Type_DataList_BookList(30, BookListViewHolder.class),
    View_Type_DataList_RecommendArticle(32, RecommendArticleViewHolder.class),
    View_Type_DataList_Explore_Recommend(33, ExploreRecommendViewHolder.class),
    View_Type_DataList_Headlines(34, FlipTextViewHolder.class),

    View_Type_DataList_DailyTask(50, ExploreTaskViewHolder.class),
    View_Type_Explore_Head(49, ExploreHeadViewHolder.class),

    View_Type_Mother_Excellent_Subject(51, MotherExcellentSubjectViewHolder.class),// 标题更多
    View_Type_Mother_Excellent_Book(52, MotherExcellentBookViewHolder.class),
    View_Type_Mother_Excellent_Story(53, MotherExcellentStoryViewHolder.class),
    View_Type_DataList_BookCollect2X2(54, Book2x2ViewHolder.class), //合集 2X2布局
    View_Type_DataList_BookCollect1X3(55, Book1x3ViewHolder.class), //合集 1X3布局
    View_Type_DataList_BookCate(56, StoryCateViewHolder.class),//
    View_Type_Mother_Excellent_Position_Subject(57, MotherExcellentPositionSubjectViewHolder.class),                    // 可调位置的标题栏布局
    View_Type_Mother_Excellent_Big_Image_1x2(58, MotherExcellentBigImage1x2ViewHolder.class),                           // 妈妈精选2x2大图基本单元 1x2
    View_Type_Mother_Excellent_Circle_Image_layout(59, MotherExcellentCircleViewHolderByConfig.class),                  // 妈妈精选可配置圆形功能分类布局
    View_Type_Mother_Excellent_Single_Book_Collect_layout(60, MotherExcellentSingleBookCollectViewHolder.class),        // 单排大图 + 文字描述布局(绘本合集)
    View_Type_Mother_Excellent_Single_Story_Collect_layout(62, MotherExcellentSingleStoryCollectViewHolder.class),      // 单排大图 + 文字描述布局(听书合集)
    View_Type_Story_Simple_Image_Title(63, MotherExcellentSubjectViewHolder.class),                                     // 听书图片标题
    View_Type_Story_Config_Position_Title(64, StoryConfigPositionViewHolder.class),                          // 听书可配置标题文字位置标题
    View_Type_Story_Schema_Two_Col(65, StorySchemaTwoColViewHolder.class);                                     // 听书双图协议跳转

    //所有包装RedirectInfo的布局定义
    public static Map<String, Integer> typeIdMap() {
        Map<String, Integer> map = new HashMap<String, Integer>();
        map.put("seperator", View_Type_Separator.getId());
        map.put("separator_line", View_Type_SeparatorLine.getId());
        map.put("story_cate", View_Type_DataList_StoryCate.getId());
        map.put("book_cate", View_Type_DataList_BookCate.getId());
        map.put("org_slide", View_Type_DataList_OrgSlide.getId());
        map.put("auto_layout", View_Type_DataList_AutoLayout.getId());
        map.put("title", View_Type_DataList_Title.getId());
        map.put("banner", View_Type_DataList_Banner.getId());
        map.put("recommend_article", View_Type_DataList_RecommendArticle.getId());
        map.put("explore_recommend", View_Type_DataList_Explore_Recommend.getId());
        map.put("mall_headlines", View_Type_DataList_Headlines.getId());
        map.put("story_2x2_layout", View_Type_DataList_StoryCollect2X2.getId());
        map.put("story_1x3_layout", View_Type_DataList_StoryCollect1X3.getId());
        map.put("mother_excellent_subject", View_Type_Mother_Excellent_Subject.getId());
        map.put("mother_excellent_subject_item_book", View_Type_Mother_Excellent_Book.getId());
        map.put("mother_excellent_subject_item_story", View_Type_Mother_Excellent_Story.getId());
        map.put("book_2x2_layout", View_Type_DataList_BookCollect2X2.getId());
        map.put("book_1x3_layout", View_Type_DataList_BookCollect1X3.getId());
        map.put("mother_excellent_position_subject", View_Type_Mother_Excellent_Position_Subject.getId());
        map.put("mother_excellent_big_image_1x2", View_Type_Mother_Excellent_Big_Image_1x2.getId());
        map.put("mother_excellent_circle_image_layout", View_Type_Mother_Excellent_Circle_Image_layout.getId());
        map.put("mother_excellent_single_book_collection_layout", View_Type_Mother_Excellent_Single_Book_Collect_layout.getId());
        map.put("mother_excellent_single_story_collection_layout", View_Type_Mother_Excellent_Single_Story_Collect_layout.getId());
        //
        map.put("story_circle_cate_layout", StoryFragment.View_Type_Story_Circle_Cate);
        map.put("story_collection_two_col", StoryFragment.View_Type_Story_Collection_Two_Col);
        map.put("story_collection_one_col", StoryFragment.View_Type_Story_Collection_One_Col);
        map.put("story_schema_two_col", View_Type_Story_Schema_Two_Col.getId());
        map.put("story_image_title", View_Type_Story_Simple_Image_Title.getId());
        map.put("story_complex_title", View_Type_Story_Config_Position_Title.getId());
        return map;
    }

    //所有包装BookListItem的布局定义
    //所有包装StoryListItem的布局定义
    //所有包装VideoListItem的布局定义

//    View_Type_StoryList(19,StoryListViewHolder.class),
//    View_Type_BookList(20,BookCollectionListViewHolder.class),
//
//    View_Type_Banner(21,BannerViewHolder.class),
//
//    View_Type_Category(22, BookCategoryViewHolder.class),
//
//    View_Type_Collection_Banner(23,CollectionBannerViewHolder.class),
//    View_Type_Collection_Item_List(24, CollectionItemListViewHolder.class),
//    View_Type_Collection_Story_Item_List(25, CollectionStoryItemListViewHolder.class),
//
//    View_Type_Story_Category(99,StoryCategoryViewHolder.class);

    int id;
    Class<?> cls;

    ViewTypes(int id, Class<?> cls) {
        this.id = id;
        this.cls = cls;
    }

    public int getId() {
        return id;
    }

    public Class<?> getCls() {
        return cls;
    }


    public static boolean isCompat(int viewType) {
        boolean compat = false;
        if (viewTypeMapsData.get(viewType) != null) {
            compat = true;
        }
        return compat;
    }

    public static final Map<Integer, Class<?>> viewTypeMapsData = new HashMap<Integer, Class<?>>();

    static {
        for (ViewTypes type : ViewTypes.values()) {
            viewTypeMapsData.put(type.getId(), type.getCls());
        }
    }
}
