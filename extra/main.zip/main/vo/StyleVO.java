package com.hhdd.kada.main.vo;

import com.google.gson.Gson;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.logger.LogHelper;

/**
 * Created by simon on 06/01/2017.
 */

// {type:seperator, style:{}, list:[] }
// style:{circle:0|1,corner:0|1,icon:"imgUrl",bg:"#00000000",align:middle|""} //icon根据比例hardcode,circle优先

public class StyleVO extends BaseModel {

    int circle; //图片是否展示圆形

    int corner; //是否带圆角，圆角大小hardcode

    String icon; //图片上展示的icon，大小根据比例hardcode；例如，视频上展示播放icon

    String bg; //背景颜色#00000000[16进制,前2位表示alpha值//]，只对title(默认纯白),separator(默认为透明),auto_layout(默认纯白);

    String align; //middle|"" //只对title有效(默认左对齐，如果指定middle则展示在中间)

    String textColor; //文字颜色#00000000[16进制,前2位表示alpha值]，默认为黑色#555555

    GradientVO gradient;

    int shadow;

    public StyleVO() {

    }

    public int getCircle() {
        return circle;
    }

    public void setCircle(int circle) {
        this.circle = circle;
    }

    public int getCorner() {
        return corner;
    }

    public void setCorner(int corner) {
        this.corner = corner;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getBg() {
        if (bg!=null&&bg.length()==9&&bg.indexOf("#")==0)
            return bg;
        return "";
    }

    public void setBg(String bg) {
        this.bg = bg;
    }

    public String getAlign() {
        return align;
    }

    public void setAlign(String align) {
        this.align = align;
    }

    public GradientVO getGradient() {
        return gradient;
    }

    public void setGradient(GradientVO gradient) {
        this.gradient = gradient;
    }

    public int getShadow() {
        return shadow;
    }

    public void setShadow(int shadow) {
        this.shadow = shadow;
    }

    public String getTextColor() {
        if (textColor!=null&&textColor.length()==9&&textColor.indexOf("#")==0)
            return textColor;
        return "";
    }

    public void setTextColor(String textColor) {
        this.textColor = textColor;
    }

    public static StyleVO parse(String jsonString) {
        if (jsonString!=null&&jsonString.length()>0) {
            try {
                Gson gson = new Gson();
                return gson.fromJson(jsonString,StyleVO.class);
            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        }
        return null;
    }

    public boolean isRoundAsCircle() {
        return getCircle()>0;
    }
    public boolean isRoundAsCorner() {
        return getCorner()>0;
    }

    public boolean isAlignMiddle() {
        if (align!=null&&align.length()>0
                &&align.compareToIgnoreCase("middle")==0) {
            return true;
        }
        return false;
    }

    public static class GradientVO extends BaseModel{
        int angle;
        String startColor;
        String endColor;

        public int getAngle() {
            return angle;
        }

        public void setAngle(int angle) {
            this.angle = angle;
        }

        public String getStartColor() {
            return startColor;
        }

        public void setStartColor(String startColor) {
            this.startColor = startColor;
        }

        public String getEndColor() {
            return endColor;
        }

        public void setEndColor(String endColor) {
            this.endColor = endColor;
        }
    }
}
