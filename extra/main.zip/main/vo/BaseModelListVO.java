package com.hhdd.kada.main.vo;

import com.hhdd.kada.main.model.BaseModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by simon on 6/13/16.
 */
public class BaseModelListVO extends BaseVO {

    private List<BaseModel> itemList = new ArrayList<BaseModel>();

    public List<BaseModel> getItemList() {
        return itemList;
    }

    public void setItemList(List<BaseModel> itemList) {
        this.itemList.clear();
        if (itemList!=null)
            this.itemList.addAll(itemList);
    }

    public BaseModelListVO() {

    }

    public BaseModelListVO(int viewType) {
        setViewType(viewType);
    }

    public BaseModelListVO(ViewTypes viewType) {
        setViewType(viewType);
    }

    public BaseModelListVO(ViewTypes viewType,List<BaseModel> itemList) {
        setViewType(viewType);
        this.itemList.clear();
        if (itemList!=null)
            this.itemList.addAll(itemList);
    }

    public BaseModelListVO(int viewType,List<BaseModel> itemList) {
        setViewType(viewType);
        this.itemList.clear();
        if (itemList!=null)
            this.itemList.addAll(itemList);
    }


}
