package com.hhdd.kada.main.vo;

import com.hhdd.kada.main.model.BaseModel;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/27
 * @describe : com.hhdd.kada.main.vo
 */
public class BookStoryModelListVO extends BaseModelListVO {
    public boolean isEdit;

    public BookStoryModelListVO(boolean isEdit, List<BaseModel> list, int viewType) {
        this.isEdit = isEdit;
        setItemList(list);
        setViewType(viewType);
    }

    public boolean isEdit() {
        return isEdit;
    }

    public void setEdit(boolean edit) {
        isEdit = edit;
    }
}
