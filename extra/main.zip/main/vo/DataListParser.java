package com.hhdd.kada.main.vo;

import android.text.TextUtils;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.RedirectPositionSubjectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.ui.story.StoryFragment;
import com.hhdd.logger.LogHelper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by simon on 9/22/16.
 */

public class DataListParser {

    public static List<BaseModelListVO> parse(String jsonString) {

        if (jsonString != null && jsonString.length() > 2) {
            String sub = jsonString.substring(0, 2);
            //http://daily.service.hhdd.com/conf/page.json //兼容老的数组
            if (jsonString.substring(0, 2).compareToIgnoreCase("[{") == 0) {
                try {
                    List<BaseModelListVO> list = new ArrayList<>();
                    Gson gson = new Gson();
                    JSONArray jsonArray = new JSONArray(jsonString);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject itemJson = jsonArray.getJSONObject(i);
                        if (itemJson.has("type")) {
                            String type = itemJson.getString("type");

                            Map<String, Integer> typeIdMap = ViewTypes.typeIdMap();
                            if (type != null && typeIdMap.get(type) != null) {

                                BaseModelListVO baseModelListVO = new BaseModelListVO();
                                baseModelListVO.setViewType(typeIdMap.get(type));

                                if (itemJson.has("style")) {
                                    String style = itemJson.getString("style");
                                    baseModelListVO.setStyle(style);
                                }

                                if (itemJson.has("list")) {
                                    List<RedirectInfo> redirectInfos = gson.fromJson(itemJson.getString("list"), new TypeToken<List<RedirectInfo>>() {
                                    }.getType());
                                    if (redirectInfos != null) {
                                        List<BaseModel> itemList = new ArrayList<>();
                                        itemList.addAll(redirectInfos);
                                        baseModelListVO.setItemList(itemList);
                                    }
                                }
                                list.add(baseModelListVO);
                            }
                        }
                    }
                    return list;
                } catch (JSONException e) {
                    LogHelper.printStackTrace(e);
                }
            } else {
                try {
                    List<BaseModelListVO> list = new ArrayList<>();
                    Gson gson = new Gson();
                    JSONObject jsonObject = new JSONObject(jsonString);
                    if (jsonObject != null && jsonObject.has("items")) {
                        JSONArray jsonArray = jsonObject.getJSONArray("items");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject itemJson = jsonArray.getJSONObject(i);
                            if (itemJson.has("type")) {
                                String type = itemJson.getString("type");
                                Map<String, Integer> typeIdMap = ViewTypes.typeIdMap();
                                if (type != null && typeIdMap.get(type) != null) {

                                    BaseModelListVO baseModelListVO = new BaseModelListVO();
                                    baseModelListVO.setViewType(typeIdMap.get(type));

                                    if (itemJson.has("style")) {
                                        String style = itemJson.getString("style");
                                        baseModelListVO.setStyle(style);
                                    }

                                    if (itemJson.has("list")) {
                                        List<RedirectInfo> redirectInfos = gson.fromJson(itemJson.getString("list"), new TypeToken<List<RedirectInfo>>() {
                                        }.getType());
                                        if (redirectInfos != null) {
                                            List<BaseModel> itemList = new ArrayList<>();
                                            itemList.addAll(redirectInfos);
                                            baseModelListVO.setItemList(itemList);
                                        }
                                    }
                                    list.add(baseModelListVO);
                                }
                            }
                        }
                        return list;
                    }

                } catch (JSONException e) {
                    LogHelper.printStackTrace(e);
                }
            }
        }
        return null;
    }

    public static List<BaseModelListVO> parseStoryJson(String jsonString) {
        if (jsonString != null && jsonString.length() > 2) {
            try {
                List<BaseModelListVO> list = new ArrayList<>();
                Gson gson = new Gson();
//                JSONArray jsonArray = new JSONArray(jsonString);
                JSONObject jsonObject = new JSONObject(jsonString);
                int index = 0;
                if (jsonObject != null && jsonObject.has("items")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("items");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject itemJson = jsonArray.getJSONObject(i);
                        if (itemJson.has("type")) {
                            String type = itemJson.getString("type");
                            Map<String, Integer> typeIdMap = ViewTypes.typeIdMap();
                            if (type != null && typeIdMap.get(type) != null) {

                                BaseModelListVO baseModelListVO = new BaseModelListVO();
                                baseModelListVO.setViewType(typeIdMap.get(type));

                                if (itemJson.has("style")) {
                                    String style = itemJson.getString("style");
                                    baseModelListVO.setStyle(style);
                                }

                                if (itemJson.has("list")) {
                                    //合集数据
                                    if (TextUtils.equals(type, "story_2x2_layout") || TextUtils.equals(type, "story_1x3_layout")) {
                                        List<StoryCollectionInfo> collectionInfos = gson.fromJson(itemJson.getString("list"), new TypeToken<List<StoryCollectionInfo>>() {
                                        }.getType());
                                        if (collectionInfos != null) {
                                            List<BaseModel> itemList = new ArrayList<>();
//                                            itemList.addAll(collectionInfos);
//                                            baseModelListVO.setItemList(itemList);
                                            for (int j = 0; j < collectionInfos.size(); j++) {
                                                StoryListItem item = new StoryListItem(StoryListItem.TYPE_STORY_COLLECTION_NEW, collectionInfos.get(j));
                                                item.setIndex(index);
                                                index++;
                                                itemList.add(item);
                                            }
                                            baseModelListVO.setItemList(itemList);
                                        }
                                    } else {
                                        List<RedirectInfo> redirectInfos = gson.fromJson(itemJson.getString("list"), new TypeToken<List<RedirectInfo>>() {
                                        }.getType());
                                        if (redirectInfos != null) {
                                            List<BaseModel> itemList = new ArrayList<>();
                                            itemList.addAll(redirectInfos);
                                            baseModelListVO.setItemList(itemList);
                                        }
                                    }
                                }
                                list.add(baseModelListVO);
                            }
                        }
                    }
                    return list;
                }

            } catch (JSONException e) {
                LogHelper.printStackTrace(e);
            }
        }
        return null;
    }

    public static List<BaseModelListVO> parseJson(String jsonString) {
        if (jsonString != null && jsonString.length() > 2) {
            try {
                List<BaseModelListVO> list = new ArrayList<>();
                Gson gson = new Gson();
                JSONObject jsonObject = new JSONObject(jsonString);
                int index = 0;
                if (jsonObject != null && jsonObject.has("items")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("items");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject itemJson = jsonArray.getJSONObject(i);
                        if (itemJson.has("type")) {
                            String type = itemJson.getString("type");
                            Map<String, Integer> typeIdMap = ViewTypes.typeIdMap();
                            if (type != null && typeIdMap.get(type) != null) {

                                BaseModelListVO baseModelListVO = new BaseModelListVO();
                                baseModelListVO.setViewType(typeIdMap.get(type));

                                if (itemJson.has("style")) {
                                    String style = itemJson.getString("style");
                                    baseModelListVO.setStyle(style);
                                }

                                if (itemJson.has("list")) {
                                    int typeId = typeIdMap.get(type);
                                    if (typeId == ViewTypes.View_Type_Mother_Excellent_Book.getId() ||
                                            typeId == ViewTypes.View_Type_DataList_BookCollect2X2.getId() ||
                                            typeId == ViewTypes.View_Type_DataList_BookCollect1X3.getId() ||
                                            typeId == ViewTypes.View_Type_Mother_Excellent_Single_Book_Collect_layout.getId()) {
                                        List<BaseModel> baseModelList = gson.fromJson(itemJson.getString("list"), new TypeToken<List<BookCollectionInfo>>() {
                                        }.getType());
                                        baseModelListVO.setItemList(baseModelList);
                                    } else if (typeId == ViewTypes.View_Type_Mother_Excellent_Story.getId() ||
                                            typeId == ViewTypes.View_Type_Mother_Excellent_Single_Story_Collect_layout.getId()) {
                                        List<BaseModel> baseModelList = gson.fromJson(itemJson.getString("list"), new TypeToken<List<StoryCollectionInfo>>() {
                                        }.getType());
                                        baseModelListVO.setItemList(baseModelList);
                                    } else if (typeId == ViewTypes.View_Type_DataList_StoryCollect2X2.getId()) {
                                        List<StoryCollectionInfo> collectionInfos = gson.fromJson(itemJson.getString("list"), new TypeToken<List<StoryCollectionInfo>>() {
                                        }.getType());
                                        if (collectionInfos != null) {
                                            List<BaseModel> itemList = new ArrayList<>();
                                            for (int j = 0; j < collectionInfos.size(); j++) {
                                                StoryListItem item = new StoryListItem(StoryListItem.TYPE_STORY_COLLECTION_NEW, collectionInfos.get(j));
                                                item.setIndex(index);
                                                index++;
                                                itemList.add(item);
                                            }
                                            baseModelListVO.setItemList(itemList);
                                        }
                                    } else if (typeId == ViewTypes.View_Type_Mother_Excellent_Position_Subject.getId()) {
                                        List<BaseModel> baseModelList = gson.fromJson(itemJson.getString("list"), new TypeToken<List<RedirectPositionSubjectInfo>>() {
                                        }.getType());
                                        baseModelListVO.setItemList(baseModelList);
                                    } else {
                                        List<BaseModel> baseModelList = gson.fromJson(itemJson.getString("list"), new TypeToken<List<RedirectInfo>>() {
                                        }.getType());
                                        baseModelListVO.setItemList(baseModelList);
                                    }
                                }
                                list.add(baseModelListVO);
                            }
                        }
                    }
                    return list;
                }

            } catch (JSONException e) {
                LogHelper.printStackTrace(e);
            }
        }
        return null;
    }

    /**
     * 解析听书首页配置的数据
     * 包含一定的容错处理
     * @param jsonString
     * @return
     */
    public static List<BaseModelListVO> parseStoryConfJson(String jsonString) {
        if (jsonString != null && jsonString.length() > 2) {
            try {
                List<BaseModelListVO> list = new ArrayList<>();
                Gson gson = new Gson();
                JSONObject jsonObject = new JSONObject(jsonString);
                int index = 0;
                if (jsonObject != null && jsonObject.has("items")) {
                    JSONArray jsonArray = jsonObject.getJSONArray("items");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject itemJson = jsonArray.getJSONObject(i);
                        if (itemJson.has("type")) {
                            String type = itemJson.getString("type");
                            // 根据type找id，根据id找ViewHolder
                            Map<String, Integer> typeIdMap = ViewTypes.typeIdMap();
                            if (type != null && typeIdMap.get(type) != null) {

                                BaseModelListVO baseModelListVO = new BaseModelListVO();
                                baseModelListVO.setViewType(typeIdMap.get(type));

                                if (itemJson.has("style")) {
                                    String style = itemJson.getString("style");
                                    baseModelListVO.setStyle(style);
                                }

                                if (itemJson.has("list")) {
                                    // 如果在听书首页接口返回了这些type，将他们转换成听书对应的type
                                    if ("mother_excellent_position_subject".equals(type)) {// 可配置位置的标题
                                        type = "story_complex_title";
                                    } else if ("mother_excellent_single_story_collection_layout".equals(type)) {
                                        type = "story_collection_two_col";
                                    } else if ("story_cate".equals(type)) {
                                        type = "story_circle_cate_layout";
                                    } else if ("mother_excellent_subject".equals(type) ||
                                            "mother_excellent_subject_item_story".equals(type)) {
                                        type = "story_image_title";
                                    }
                                    int typeId = typeIdMap.get(type);
                                    if (typeId == StoryFragment.View_Type_Story_Collection_One_Col ||
                                            typeId == StoryFragment.View_Type_Story_Collection_Two_Col) {
                                        List<BaseModel> baseModelList = gson.fromJson(itemJson.getString("list"), new TypeToken<List<StoryCollectionInfo>>() {
                                        }.getType());
                                        baseModelListVO.setItemList(baseModelList);
                                    } else if (typeId == ViewTypes.View_Type_DataList_StoryCollect2X2.getId()) {
                                        List<StoryCollectionInfo> collectionInfos = gson.fromJson(itemJson.getString("list"), new TypeToken<List<StoryCollectionInfo>>() {
                                        }.getType());
                                        if (collectionInfos != null) {
                                            List<BaseModel> itemList = new ArrayList<>();
                                            for (int j = 0; j < collectionInfos.size(); j++) {
                                                StoryListItem item = new StoryListItem(StoryListItem.TYPE_STORY_COLLECTION_NEW, collectionInfos.get(j));
                                                item.setIndex(index);
                                                index++;
                                                itemList.add(item);
                                            }
                                            baseModelListVO.setItemList(itemList);
                                        }
                                    } else if (typeId == ViewTypes.View_Type_Story_Config_Position_Title.getId()) {
                                        List<BaseModel> baseModelList = gson.fromJson(itemJson.getString("list"), new TypeToken<List<RedirectPositionSubjectInfo>>() {
                                        }.getType());
                                        baseModelListVO.setItemList(baseModelList);
                                    } else {// 两栏协议、顶部分类
                                        List<BaseModel> baseModelList = gson.fromJson(itemJson.getString("list"), new TypeToken<List<RedirectInfo>>() {
                                        }.getType());
                                        baseModelListVO.setItemList(baseModelList);
                                    }
                                }
                                list.add(baseModelListVO);
                            }
                        }
                    }
                    return list;
                }

            } catch (JSONException e) {
                LogHelper.printStackTrace(e);
            }
        }
        return null;
    }
//
//    private static StringBuilder stringBuilder = new StringBuilder();
//    private static String jsonHead = "{\"items\":[";
//    private static String jsonTail = "]}";
//    private static String storyCircleCateJson = "{\"type\":\"story_circle_cate_layout\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentselectbook\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/7e6f7e67-680c-47b3-8e37-db379b1fbb3f.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"选绘本\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentselectstory\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/76b93ad0-7283-4238-b22b-d6d7515874a4.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_1\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"选听书\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentsubject?module=config&path=getListConfig.json&title=迪士尼专区&configType=10531\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/e711f4c3-d199-4df2-876e-bbbadfaf9b23.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_2\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"迪士尼\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openbookcollectioncommon?extFlag=64&title=新品\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/8c2063f6-f616-4e03-b526-3ca6e5753343.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_3\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"新品推荐\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentsubject?module=config&path=getListConfig.json&title=最热免费&configType=10532\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/98c05105-3c2f-4304-9f30-0ff6aea1359e.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_4\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"热门免费\",\"subTitle\":\"\",\"width\":0,\"height\":0}]}";
//
//    private static String storyImageTitleJson = "{\"type\":\"story_image_title\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/0fe0b874-b888-4d64-a28e-7a7e63697292.jpg\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_shuqituijiantitle_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"暑期推荐\",\"subTitle\":\"\",\"width\":0,\"height\":0}]}";
//
//    private static String storyOneColJson = "{\"type\":\"story_collection_one_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"可爱的身体\",\"coverUrl\":\"http://image.hhdd.com/books/cover/17c3165c-2526-4a44-9f9f-64acc63f5f87.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/0fadd0cd-0118-45a8-9f5a-32893e9f5b2e.jpg\",\"extFlag\":\"128\",\"collectId\":\"52624\",\"type\":\"2\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"3578385\",\"recommend\":\"为孩子揭开身体的奥秘。\",\"serialize\":\"\",\"author\":\"七尾纯|小林雅子|今井弓子\",\"price\":\"0\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction52624.html\",\"count\":\"8\",\"onlineCount\":\"8\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"5415\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_baobeizuiaibookmianfei_0\\\",\\\"content\\\":\\\"\\\"}\",\"applePrice\":\"0\"}]}";
//
//    private static String storyTwoColJson = "{\"type\":\"story_collection_two_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"故事爸爸的恐龙王国 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/22798/2825e42f-1653-4037-8642-574cf1c8f716.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/22798/2825e42f-1653-4037-8642-574cf1c8f716.jpg\",\"extFlag\":\"0\",\"collectId\":\"22798\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"201078\",\"recommend\":\"故事爸爸带你探索精彩恐龙大陆！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction22798.html\",\"count\":\"13\",\"onlineCount\":\"13\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"12207\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_baobeizuiaistorymianfei_0\\\",\\\"content\\\":\\\"2,22798\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"小兔汤姆系列故事 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/12598/5fb2f795-1b38-4bd7-bcda-adc7732dec74.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/12598/5fb2f795-1b38-4bd7-bcda-adc7732dec74.jpg\",\"extFlag\":\"0\",\"collectId\":\"12598\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"1590489\",\"recommend\":\"最适合低龄宝宝的一本童话故事！\",\"serialize\":\"\",\"author\":\"玛莉-阿丽娜·巴文\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction12598.html\",\"count\":\"16\",\"onlineCount\":\"16\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"9064\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_baobeizuiaistorymianfei_1\\\",\\\"content\\\":\\\"2,12598\\\"}\",\"applePrice\":\"0.00\"}]}";
//
//    private static String storyConfigTitleShowMoreJson = "{\"type\":\"story_complex_title\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openbookcollectioncommon?extFlag=64&title=新品\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/0fe0b874-b888-4d64-a28e-7a7e63697292.jpg\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_shuqituijiantitle_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"暑期推荐\",\"subTitle\":\"精彩暑期推荐\",\"width\":0,\"height\":0}]}";
//    private static String storyConfigTitleJson = "{\"type\":\"story_complex_title\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/0fe0b874-b888-4d64-a28e-7a7e63697292.jpg\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_shuqituijiantitle_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"暑期推荐\",\"subTitle\":\"精彩暑期推荐\",\"width\":0,\"height\":0}]}";
//
//    private static String storyTwoSchemaJson = "{\"type\":\"story_schema_two_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openbookcollectioncommon?extFlag=64&title=新品\",\"html5\":\"\",\"imageUrl\":\"http://story.hhdd.com/story/cover/22798/2825e42f-1653-4037-8642-574cf1c8f716.jpg\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_3\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"新品推荐\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentsubject?module=config&path=getListConfig.json&title=最热免费&configType=10532\",\"html5\":\"\",\"imageUrl\":\"http://story.hhdd.com/story/cover/12598/5fb2f795-1b38-4bd7-bcda-adc7732dec74.jpg\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_4\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"热门免费\",\"subTitle\":\"\",\"width\":0,\"height\":0}]}";
//
//    private static String fakeJson1 = "{\"items\":[" +
//            "{\"type\":\"story_circle_cate_layout\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentselectbook\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/7e6f7e67-680c-47b3-8e37-db379b1fbb3f.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"选绘本\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentselectstory\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/76b93ad0-7283-4238-b22b-d6d7515874a4.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_1\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"选听书\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentsubject?module=config&path=getListConfig.json&title=迪士尼专区&configType=10531\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/e711f4c3-d199-4df2-876e-bbbadfaf9b23.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_2\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"迪士尼\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openbookcollectioncommon?extFlag=64&title=新品\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/8c2063f6-f616-4e03-b526-3ca6e5753343.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_3\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"新品推荐\",\"subTitle\":\"\",\"width\":0,\"height\":0},{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"kada://openexcellentsubject?module=config&path=getListConfig.json&title=最热免费&configType=10532\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/98c05105-3c2f-4304-9f30-0ff6aea1359e.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_jingxuanyefeilei_4\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"热门免费\",\"subTitle\":\"\",\"width\":0,\"height\":0}]}" +
//            "{\"type\":\"story_collection_one_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"迪士尼金牌电影故事：寻梦环游记\",\"coverUrl\":\"http://image.hhdd.com/books/cover/585e452b-4e2b-41a5-8992-d1e4c89cd54f.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/6a7642f3-cc11-45ed-93e2-98843b45c75a.jpg\",\"extFlag\":\"33792\",\"collectId\":\"62308\",\"type\":\"2\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"27743\",\"recommend\":\"随身携带大电影，享全新视听体验\",\"serialize\":\"\",\"author\":\"\",\"price\":\"1\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction62308.html\",\"count\":\"5\",\"onlineCount\":\"5\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"2509\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_shuqituijianmianfei_0\\\",\\\"content\\\":\\\"\\\"}\",\"applePrice\":\"1\"}]}," +
//            "{\"type\":\"mother_excellent_subject_item_story\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"唐诗三百首 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/12216/9b1dd123-c5e3-442d-a3bf-5857c0f09def.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/12216/1f1ef971-3ec8-4b64-99eb-5a5a5573173b.jpg\",\"extFlag\":\"0\",\"collectId\":\"12216\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"1880604\",\"recommend\":\"熟读唐诗三百首，不会吟诗也会吟\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction12216.html\",\"count\":\"106\",\"onlineCount\":\"106\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"12570\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_shuqistory_0\\\",\\\"content\\\":\\\"2,12216\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"婷婷唱古文 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/20214/b19d9a9f-bc95-4738-b5ad-71477db3c120.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/20214/a6a07cc0-61ac-4851-93fd-85a63d006ac2.jpg\",\"extFlag\":\"0\",\"collectId\":\"20214\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"3461851\",\"recommend\":\"婷婷唱古文，轻松学古诗！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction20214.html\",\"count\":\"77\",\"onlineCount\":\"77\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"8661\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_shuqistory_1\\\",\\\"content\\\":\\\"2,20214\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"90天环游世界 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/20162/7bb0af7c-aa7c-4e64-8c91-f7cdcaa290c7.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/20162/d3e961fa-ddbf-4840-88ef-d8f246f69901.jpg\",\"extFlag\":\"32\",\"collectId\":\"20162\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"132142\",\"recommend\":\"双语人文地理故事,拓展宝宝眼界\",\"serialize\":\"\",\"author\":\"\",\"price\":\"88.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction20162.html\",\"count\":\"90\",\"onlineCount\":\"90\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"1974\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_shuqistory_2\\\",\\\"content\\\":\\\"2,20162\\\"}\",\"applePrice\":\"88.00\"}]}," +
//            "{\"list\":[],\"type\":\"seperator\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":null,\\\"align\\\":null,\\\"bg\\\":\\\"#fff8f8f8\\\",\\\"bgcolor\\\":null,\\\"alpha\\\":null,\\\"textColor\\\":null,\\\"shadow\\\":0,\\\"gradient\\\":null}\"}," +
//            "{\"type\":\"mother_excellent_subject\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/44c8ec0e-c780-4986-a278-1c2b75ed0fd4.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_baobeizuiaititle_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"宝贝最爱\",\"subTitle\":\"\",\"width\":0,\"height\":0}]}," +
//            "{\"type\":\"story_collection_two_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"故事爸爸的恐龙王国 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/22798/2825e42f-1653-4037-8642-574cf1c8f716.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/22798/2825e42f-1653-4037-8642-574cf1c8f716.jpg\",\"extFlag\":\"0\",\"collectId\":\"22798\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"201078\",\"recommend\":\"故事爸爸带你探索精彩恐龙大陆！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction22798.html\",\"count\":\"13\",\"onlineCount\":\"13\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"12207\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_baobeizuiaistorymianfei_0\\\",\\\"content\\\":\\\"2,22798\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"小兔汤姆系列故事 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/12598/5fb2f795-1b38-4bd7-bcda-adc7732dec74.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/12598/5fb2f795-1b38-4bd7-bcda-adc7732dec74.jpg\",\"extFlag\":\"0\",\"collectId\":\"12598\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"1590489\",\"recommend\":\"最适合低龄宝宝的一本童话故事！\",\"serialize\":\"\",\"author\":\"玛莉-阿丽娜·巴文\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction12598.html\",\"count\":\"16\",\"onlineCount\":\"16\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"9064\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_baobeizuiaistorymianfei_1\\\",\\\"content\\\":\\\"2,12598\\\"}\",\"applePrice\":\"0.00\"}]}," +
//            "{\"type\":\"story_collection_two_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"海底小纵队 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/13673/dc899abe-8f1a-4550-a3aa-9fcb8bea88eb.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/13673/dc899abe-8f1a-4550-a3aa-9fcb8bea88eb.jpg\",\"extFlag\":\"0\",\"collectId\":\"13673\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"17180013\",\"recommend\":\"国外超火的海洋探险动画在这里！\",\"serialize\":\"\",\"author\":\"巴巴妈妈\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction13673.html\",\"count\":\"84\",\"onlineCount\":\"84\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"49497\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_baobeizuiaistoryfufei_0\\\",\\\"content\\\":\\\"2,13673\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"瑞丁老爸西游记 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/13674/58d282bf-4b50-457c-bc26-84b3075deb0d.png\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/13674/58d282bf-4b50-457c-bc26-84b3075deb0d.png\",\"extFlag\":\"0\",\"collectId\":\"13674\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"383165\",\"recommend\":\"瑞丁老爸带你看齐天大圣孙悟空！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction13674.html\",\"count\":\"9\",\"onlineCount\":\"9\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"8832\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_baobeizuiaistoryfufei_1\\\",\\\"content\\\":\\\"2,13674\\\"}\",\"applePrice\":\"0.00\"}]}," +
//            "{\"type\":\"story_collection_one_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"可爱的身体\",\"coverUrl\":\"http://image.hhdd.com/books/cover/17c3165c-2526-4a44-9f9f-64acc63f5f87.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/0fadd0cd-0118-45a8-9f5a-32893e9f5b2e.jpg\",\"extFlag\":\"128\",\"collectId\":\"52624\",\"type\":\"2\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"3578385\",\"recommend\":\"为孩子揭开身体的奥秘。\",\"serialize\":\"\",\"author\":\"七尾纯|小林雅子|今井弓子\",\"price\":\"0\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction52624.html\",\"count\":\"8\",\"onlineCount\":\"8\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"5415\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_baobeizuiaibookmianfei_0\\\",\\\"content\\\":\\\"\\\"}\",\"applePrice\":\"0\"}]}," +
//            "{\"type\":\"book_2x2_layout\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"昆虫 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/3a346b99-0b57-4ca7-8ebb-994185078c32.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/8cb7a239-8610-4a8b-813d-d6dacaac605f.jpg\",\"extFlag\":\"0\",\"collectId\":\"60052\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"3280047\",\"recommend\":\"神秘的昆虫家族\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60052.html\",\"count\":\"8\",\"onlineCount\":\"8\",\"readyOnlineCount\":\"1\",\"subscribeCount\":\"6178\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_baobeizuiaibookfufei_0\\\",\\\"content\\\":\\\"1,60052\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"10024\",\"name\":\"小猫当当 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/bfdb3a2c-729f-4023-b65e-9a9003c8f09b.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/3d46ff42-591d-45f1-9ac5-7a1d1af2cf2d.jpg\",\"extFlag\":\"128\",\"collectId\":\"52620\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"3\",\"clickCount\":\"8193505\",\"recommend\":\"在阅读中养成正确习惯、良好性格\",\"serialize\":\"\",\"author\":\"清野幸子 \",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction52620.html\",\"count\":\"10\",\"onlineCount\":\"10\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"62668\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_baobeizuiaibookfufei_1\\\",\\\"content\\\":\\\"1,52620\\\"}\",\"applePrice\":\"0.00\"}]}," +
//            "{\"list\":[],\"type\":\"seperator\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":null,\\\"align\\\":null,\\\"bg\\\":\\\"#fff8f8f8\\\",\\\"bgcolor\\\":null,\\\"alpha\\\":null,\\\"textColor\\\":null,\\\"shadow\\\":0,\\\"gradient\\\":null}\"}," +
//            "{\"type\":\"mother_excellent_subject\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/40e7e156-c800-4da6-aa88-ce7d9ecfaad4.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_chengzhangbidutitle_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"成长必读\",\"subTitle\":\"\",\"width\":0,\"height\":0}]}," +
//            "{\"type\":\"story_collection_two_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"盒子历险记之白毛雪人的烦恼 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/22280/86089688-1dac-4f3c-8751-32a0e2b9dbc9.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/22280/86089688-1dac-4f3c-8751-32a0e2b9dbc9.jpg\",\"extFlag\":\"0\",\"collectId\":\"22280\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"402282\",\"recommend\":\"让想象力变成孩子的超能力！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction22280.html\",\"count\":\"50\",\"onlineCount\":\"50\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"3732\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_chengzhangbidustorymianfei_0\\\",\\\"content\\\":\\\"2,22280\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"一起来听英文歌 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/15661/18f1d51d-b428-42b2-b0d7-d30989e57bc9.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/15661/18f1d51d-b428-42b2-b0d7-d30989e57bc9.jpg\",\"extFlag\":\"0\",\"collectId\":\"15661\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"4601632\",\"recommend\":\"这里不止abc\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction15661.html\",\"count\":\"14\",\"onlineCount\":\"14\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"4212\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_chengzhangbidustorymianfei_1\\\",\\\"content\\\":\\\"2,15661\\\"}\",\"applePrice\":\"0.00\"}]}," +
//            "{\"type\":\"story_collection_two_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"胖小猪的故事 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/14877/d28a815f-5b87-4176-bed7-01a99fc9a064.png\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/14877/d28a815f-5b87-4176-bed7-01a99fc9a064.png\",\"extFlag\":\"0\",\"collectId\":\"14877\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"268627\",\"recommend\":\"胖小猪呼噜噜，每天欢乐又幸福\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction14877.html\",\"count\":\"7\",\"onlineCount\":\"7\",\"readyOnlineCount\":\"2\",\"subscribeCount\":\"3039\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_chengzhangbidustoryfufei_0\\\",\\\"content\\\":\\\"2,14877\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"哭鼻子大王 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/14287/88ca38da-2e80-41b3-8dec-78fc56e81f84.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/14287/88ca38da-2e80-41b3-8dec-78fc56e81f84.jpg\",\"extFlag\":\"0\",\"collectId\":\"14287\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"2408516\",\"recommend\":\"这是一本会让你笑破肚皮的书！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction14287.html\",\"count\":\"31\",\"onlineCount\":\"31\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"10804\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_chengzhangbidustoryfufei_1\\\",\\\"content\\\":\\\"2,14287\\\"}\",\"applePrice\":\"0.00\"}]}," +
//            "{\"type\":\"story_collection_one_col\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"经典获奖绘本\",\"coverUrl\":\"http://image.hhdd.com/books/cover/1db5ee15-1849-4934-8031-9c4adcfb1783.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/4eeae9fa-8c64-4f26-a3b5-6449d07f531d.jpg\",\"extFlag\":\"16\",\"collectId\":\"60201\",\"type\":\"2\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"5319254\",\"recommend\":\"全球的经典大奖合辑都在这里啦！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60201.html\",\"count\":\"15\",\"onlineCount\":\"12\",\"readyOnlineCount\":\"3\",\"subscribeCount\":\"39106\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_chengzhangbidubookmianfei_0\\\",\\\"content\\\":\\\"\\\"}\",\"applePrice\":\"0\"}]}," +
//            "{\"type\":\"book_2x2_layout\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"安全教育指南 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/a5960f7d-aa0f-4e13-a9f7-a4eccee6b311.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/98c1ee91-2526-4d7f-9229-75c005e4c398.jpg\",\"extFlag\":\"0\",\"collectId\":\"60107\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"3669618\",\"recommend\":\"每个孩子必备的安全教育指南！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60107.html\",\"count\":\"9\",\"onlineCount\":\"9\",\"readyOnlineCount\":\"5\",\"subscribeCount\":\"28857\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_chengzhangbidubookfufei_0\\\",\\\"content\\\":\\\"1,60107\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"独立，我可以！ \",\"coverUrl\":\"http://image.hhdd.com/books/cover/c10b425f-2663-4166-8cb8-4afd2d037bb6.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/aee1659d-3b94-43f9-b289-e8354e3ee139.jpg\",\"extFlag\":\"0\",\"collectId\":\"60022\",\"type\":\" 2\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"2015990\",\"recommend\":\"学会独立是孩子成长的第一步！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60022.html\",\"count\":\"9\",\"onlineCount\":\"9\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"4791\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_chengzhangbidubookfufei_1\\\",\\\"content\\\":\\\"1,60022\\\"}\",\"applePrice\":\"0.00\"}]}," +
//            "{\"list\":[],\"type\":\"seperator\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":null,\\\"align\\\":null,\\\"bg\\\":\\\"#fff8f8f8\\\",\\\"bgcolor\\\":null,\\\"alpha\\\":null,\\\"textColor\\\":null,\\\"shadow\\\":0,\\\"gradient\\\":null}\"}," +
//            "{\"type\":\"story_image_title\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/59dbdb39-278d-4beb-9d9e-f51f7a748971.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_tejiajingpintitle_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"特价精品\",\"subTitle\":\"\",\"width\":0,\"height\":0}]}," +
//            "{\"type\":\"mother_excellent_subject_item_story\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"培养孩子创新精神的发明故事 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/20421/12196b5a-eae1-4e2f-92be-615743c2e5a2.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/20421/092f52c1-5dd5-469f-b8b8-8fa7dc0edf52.jpg\",\"extFlag\":\"4128\",\"collectId\":\"20421\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"51289\",\"recommend\":\"发明故事教孩子热爱探究不畏失败\",\"serialize\":\"\",\"author\":\"\",\"price\":\"8.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction20421.html\",\"count\":\"40\",\"onlineCount\":\"40\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"825\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_tejiajingpinstory_0\\\",\\\"content\\\":\\\"2,20421\\\"}\",\"applePrice\":\"8.00\"},{\"categoryId\":\"0\",\"name\":\"奶泡泡弟子规 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/26107/a01dddef-f41b-4286-a577-56c6f903207d.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/26107/d5d05b97-3c31-4bcd-a634-e2a908b46d8d.jpg\",\"extFlag\":\"4128\",\"collectId\":\"26107\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"82897\",\"recommend\":\"让孩子受益一生的智慧宝典！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"88.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction26107.html\",\"count\":\"90\",\"onlineCount\":\"90\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"1691\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_tejiajingpinstory_1\\\",\\\"content\\\":\\\"2,26107\\\"}\",\"applePrice\":\"88.00\"},{\"categoryId\":\"0\",\"name\":\"浩然爸爸讲千字文 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/21273/5336423b-bec1-4fb3-8388-737343ded6c8.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/21273/46f6b66f-67dd-4776-8532-0180aec9ed9e.jpg\",\"extFlag\":\"32\",\"collectId\":\"21273\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"77652\",\"recommend\":\"国学启蒙首选，软实力从小构建\",\"serialize\":\"\",\"author\":\"\",\"price\":\"99.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction21273.html\",\"count\":\"64\",\"onlineCount\":\"64\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"2033\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_tejiajingpinstory_2\\\",\\\"content\\\":\\\"2,21273\\\"}\",\"applePrice\":\"99.00\"}]}," +
//            "{\"type\":\"mother_excellent_subject_item_book\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"宝贝看大戏 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/7e5c2328-8a91-4568-be60-e4e64545ed32.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/69440f1b-1087-4a5a-ac78-1c1d17a39c89.jpg\",\"extFlag\":\"33792\",\"collectId\":\"62568\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"14087\",\"recommend\":\"带领孩子无门槛走进传统戏曲文化\",\"serialize\":\"\",\"author\":\"\",\"price\":\"50.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction62568.html\",\"count\":\"40\",\"onlineCount\":\"40\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"1058\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_tejiajingpinbook_0\\\",\\\"content\\\":\\\"1,62568\\\"}\",\"applePrice\":\"50.00\"},{\"categoryId\":\"0\",\"name\":\"北大小明星启蒙阅读包 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/95a793ac-f7b7-42b8-863c-61c200d1adf9.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/6e09a130-d1ea-43ed-bee6-15472458d9b6.jpg\",\"extFlag\":\"33792\",\"collectId\":\"62026\",\"type\":\" 2\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"423414\",\"recommend\":\"5-8岁一站式中文启蒙阅读精品\",\"serialize\":\"\",\"author\":\"\",\"price\":\"68.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction62026.html\",\"count\":\"60\",\"onlineCount\":\"61\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"2827\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_tejiajingpinbook_1\\\",\\\"content\\\":\\\"1,62026\\\"}\",\"applePrice\":\"68.00\"},{\"categoryId\":\"0\",\"name\":\"中国经典动画升级版 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/cdcee7a2-459a-4495-93fc-6d4043bdaf9d.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/6f738d6d-20ad-4b96-87a1-24a651ddb646.jpg\",\"extFlag\":\"33792\",\"collectId\":\"62244\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"82038\",\"recommend\":\"传承童年记忆，再现升级经典！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"30.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction62244.html\",\"count\":\"12\",\"onlineCount\":\"12\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"1758\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_tejiajingpinbook_2\\\",\\\"content\\\":\\\"1,62244\\\"}\",\"applePrice\":\"30.00\"}]}," +
//            "{\"list\":[],\"type\":\"seperator\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":null,\\\"align\\\":null,\\\"bg\\\":\\\"#fff8f8f8\\\",\\\"bgcolor\\\":null,\\\"alpha\\\":null,\\\"textColor\\\":null,\\\"shadow\\\":0,\\\"gradient\\\":null}\"}," +
//            "{\"type\":\"mother_excellent_subject\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"position\":0,\"redirectId\":\"0\",\"redirectUri\":\"\",\"html5\":\"\",\"imageUrl\":\"http://image.hhdd.com/books/cover/314c67d4-becb-4460-a578-2a2737dc9111.png\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_area_more_click_mianfeibooktitle_0\\\",\\\"content\\\":\\\"\\\"}\",\"title\":\"热门一览\",\"subTitle\":\"\",\"width\":0,\"height\":0}]}," +
//            "{\"type\":\"mother_excellent_subject_item_story\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"贝儿故事王国 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/21988/58edec16-4a6c-47d9-a120-d33f6323c2ee.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/21988/20a1ceb5-aa85-443e-a825-06b5e14a3f91.jpg\",\"extFlag\":\"0\",\"collectId\":\"21988\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"205325\",\"recommend\":\"贝儿故事王国，孩子的童话天堂！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction21988.html\",\"count\":\"78\",\"onlineCount\":\"78\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"3042\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_0\\\",\\\"content\\\":\\\"2,21988\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"小云熊 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/25421/ea18f90f-df25-4712-b79e-f26c5a2db10f.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/25421/11de4fbc-9f20-4a88-8e4c-228b7313d379.jpg\",\"extFlag\":\"0\",\"collectId\":\"25421\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"140941\",\"recommend\":\"让孩子开怀欢笑的小云熊北北来啦\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction25421.html\",\"count\":\"24\",\"onlineCount\":\"24\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"13390\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_1\\\",\\\"content\\\":\\\"2,25421\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"冰冰姐姐 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/20544/fe22aec9-7dca-4c43-943d-376d934d2307.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/20544/6517d5fb-6bfb-4d47-a1eb-313636f63905.jpg\",\"extFlag\":\"0\",\"collectId\":\"20544\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"739116\",\"recommend\":\"冰冰姐姐用爱讲述动人故事~\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction20544.html\",\"count\":\"50\",\"onlineCount\":\"50\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"3902\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_2\\\",\\\"content\\\":\\\"2,20544\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"瑞丁老爸西游记 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/13674/6fdf5065-97d5-42b1-9e2a-1ab5e5b8a95c.png\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/13674/58d282bf-4b50-457c-bc26-84b3075deb0d.png\",\"extFlag\":\"0\",\"collectId\":\"13674\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"383165\",\"recommend\":\"瑞丁老爸带你看齐天大圣孙悟空！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction13674.html\",\"count\":\"9\",\"onlineCount\":\"9\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"8832\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_3\\\",\\\"content\\\":\\\"2,13674\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"小王子 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/12213/6ab27e23-f3d2-4e6c-9314-41cc9d607e85.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/12213/9ed90553-bf03-41e6-82c9-3d7ea7c15cf0.jpg\",\"extFlag\":\"0\",\"collectId\":\"12213\",\"type\":\" 4\",\"minAge\":\"7\",\"maxAge\":\"9\",\"clickCount\":\"1688249\",\"recommend\":\"这里有小王子和玫瑰的故事~\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction12213.html\",\"count\":\"27\",\"onlineCount\":\"27\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"8805\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_4\\\",\\\"content\\\":\\\"2,12213\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"秋果妈妈讲故事 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/21586/5edd18ea-b892-41c1-9139-92ff7ebed074.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/21586/f9390f6a-e301-4cc7-806e-70351950aa6b.jpg\",\"extFlag\":\"16\",\"collectId\":\"21586\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"212554\",\"recommend\":\"香香甜甜故事果，快快乐乐你和我\",\"serialize\":\"每周一更新2集\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction21586.html\",\"count\":\"38\",\"onlineCount\":\"31\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"2639\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_5\\\",\\\"content\\\":\\\"2,21586\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"精选儿歌 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/14737/3566d861-e63f-4d36-ae57-8821f9aab0a5.png\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/14737/4c26c4fa-6417-4cf6-b908-f58468934782.png\",\"extFlag\":\"0\",\"collectId\":\"14737\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"971791\",\"recommend\":\"精选英文儿歌，和孩子一起轻松学\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction14737.html\",\"count\":\"6\",\"onlineCount\":\"6\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"4957\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_6\\\",\\\"content\\\":\\\"2,14737\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"女巫温妮 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/13465/06e4a5e6-4c44-4800-bcab-36137497640d.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/13465/1ed0a2a5-1559-4827-821c-ca00d2217bac.jpg\",\"extFlag\":\"0\",\"collectId\":\"13465\",\"type\":\" 4\",\"minAge\":\"4\",\"maxAge\":\"9\",\"clickCount\":\"591167\",\"recommend\":\"跟着女巫温妮一起念神奇咒语吧！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction13465.html\",\"count\":\"16\",\"onlineCount\":\"16\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"5301\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_7\\\",\\\"content\\\":\\\"2,13465\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"牙齿白白刷刷刷 \",\"coverUrl\":\"http://story.hhdd.com/story/cover/14266/b6f2c9c2-3747-4a90-9d9f-b74d4ddaa8d4.jpg\",\"bannerUrl\":\"http://story.hhdd.com/story/cover/14266/bdd8e7e1-b07c-43bd-afdd-b9e7f2e9495f.jpg\",\"extFlag\":\"0\",\"collectId\":\"14266\",\"type\":\" 4\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"326515\",\"recommend\":\"爱牙护牙很重要，牙齿健康少不了\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/story2/collect/introduction/collectIntroduction14266.html\",\"count\":\"4\",\"onlineCount\":\"4\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"2100\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeistinshu1_8\\\",\\\"content\\\":\\\"2,14266\\\"}\",\"applePrice\":\"0.00\"}]}," +
//            "{\"type\":\"mother_excellent_subject_item_book\",\"style\":\"{\\\"circle\\\":0,\\\"corner\\\":0,\\\"icon\\\":\\\"\\\",\\\"align\\\":\\\"\\\",\\\"bg\\\":\\\"\\\",\\\"bgcolor\\\":\\\"#000000\\\",\\\"alpha\\\":100,\\\"textColor\\\":\\\"#000000\\\",\\\"gradient\\\":{\\\"angle\\\":90,\\\"startColor\\\":\\\"#000000\\\",\\\"endColor\\\":\\\"#000000\\\"}}\",\"list\":[{\"categoryId\":\"0\",\"name\":\"自信 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/a04cec0b-c3a2-4e3a-8c2d-2251492dce2c.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/cd5ecc56-7008-4aca-8972-05a4e2f33cbb.jpg\",\"extFlag\":\"0\",\"collectId\":\"60077\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"625895\",\"recommend\":\"你，是最特别的！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60077.html\",\"count\":\"7\",\"onlineCount\":\"7\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"7837\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_0\\\",\\\"content\\\":\\\"1,60077\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"寻找神秘的恐龙 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/76d80ed2-4379-4d86-8545-d61cc2f594f8.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/1111309f-3b8e-4aa6-9561-f2f56d8d71a4.jpg\",\"extFlag\":\"16\",\"collectId\":\"60126\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"11881537\",\"recommend\":\"和咔哒一起去寻找神秘的恐龙吧！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60126.html\",\"count\":\"6\",\"onlineCount\":\"7\",\"readyOnlineCount\":\"2\",\"subscribeCount\":\"79375\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_1\\\",\\\"content\\\":\\\"1,60126\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"10024\",\"name\":\"小幽灵趣味图画书 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/fcb907bb-1978-4f88-957e-a4cb29c2c921.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/89211936-64e3-4af1-8139-c27b7ac0a72b.jpg\",\"extFlag\":\"16\",\"collectId\":\"53921\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"3\",\"clickCount\":\"5079736\",\"recommend\":\"祖先城堡是一座非常奇特的城堡…\",\"serialize\":\"\",\"author\":\"雅克·迪凯努瓦\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction53921.html\",\"count\":\"9\",\"onlineCount\":\"9\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"4528\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_2\\\",\\\"content\\\":\\\"1,53921\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"10024\",\"name\":\"名家经典绘本 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/6197babe-ced6-43a9-bc4b-692378ab4bf7.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/e5014bfa-346f-4a4c-bf97-47aedbd70314.jpg\",\"extFlag\":\"16\",\"collectId\":\"52803\",\"type\":\" 2\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"6044996\",\"recommend\":\"耳熟能详的故事，不一样的讲述。\",\"serialize\":\"\",\"author\":\"安徒生|格林兄弟|罗大里等\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction52803.html\",\"count\":\"22\",\"onlineCount\":\"22\",\"readyOnlineCount\":\"4\",\"subscribeCount\":\"5752\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_3\\\",\\\"content\\\":\\\"1,52803\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"10024\",\"name\":\"小猪普莱墩儿的故事 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/d7497123-1961-405a-9a99-79c12b408843.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/edbabd1c-a40d-428e-a782-75c5b12f7ee9.jpg\",\"extFlag\":\"0\",\"collectId\":\"52631\",\"type\":\" 2\",\"minAge\":\"4\",\"maxAge\":\"6\",\"clickCount\":\"973155\",\"recommend\":\"普莱墩儿的眼里有多姿多彩的世界\",\"serialize\":\"\",\"author\":\"柯林·麦克诺顿\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction52631.html\",\"count\":\"7\",\"onlineCount\":\"7\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"2301\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_4\\\",\\\"content\\\":\\\"1,52631\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"我的随身绘本：爱的启蒙故事 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/5104a827-46df-4c2b-bce0-527d71bd501d.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/3652c807-16ee-48cc-9560-6ea22dbcbd43.jpg\",\"extFlag\":\"0\",\"collectId\":\"60732\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"38862\",\"recommend\":\"启蒙下的天然智慧探索大世界\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60732.html\",\"count\":\"22\",\"onlineCount\":\"22\",\"readyOnlineCount\":\"0\",\"subscribeCount\":\"1799\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_5\\\",\\\"content\\\":\\\"1,60732\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"10024\",\"name\":\"巴菲的奇妙故事 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/2ba42af1-c4ef-40fd-aa05-7fccce5371c2.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/31b8a844-4740-4ed1-9131-c4381e122065.jpg\",\"extFlag\":\"128\",\"collectId\":\"52663\",\"type\":\" 2\",\"minAge\":\"7\",\"maxAge\":\"9\",\"clickCount\":\"1807575\",\"recommend\":\"所有小朋友的守护神巴菲。\",\"serialize\":\"\",\"author\":\"罗朗斯·吉洛特|梅勒尔\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction52663.html\",\"count\":\"11\",\"onlineCount\":\"10\",\"readyOnlineCount\":\"1\",\"subscribeCount\":\"2946\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_6\\\",\\\"content\\\":\\\"1,52663\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"好朋友 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/e4ba0f9d-278c-46ac-b122-89b177a15ec1.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/495d52d3-cbac-41e2-a589-be99852a8728.jpg\",\"extFlag\":\"0\",\"collectId\":\"60104\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"9\",\"clickCount\":\"3086952\",\"recommend\":\"找啊找啊找朋友，找到一个好朋友\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60104.html\",\"count\":\"10\",\"onlineCount\":\"12\",\"readyOnlineCount\":\"6\",\"subscribeCount\":\"15036\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_7\\\",\\\"content\\\":\\\"1,60104\\\"}\",\"applePrice\":\"0.00\"},{\"categoryId\":\"0\",\"name\":\"环球之旅 \",\"coverUrl\":\"http://image.hhdd.com/books/cover/eac44081-0357-4f0f-9389-1c8b97604bed.jpg\",\"bannerUrl\":\"http://image.hhdd.com/books/cover/5134ba70-4097-44d0-8a06-da830acba60e.jpg\",\"extFlag\":\"0\",\"collectId\":\"60061\",\"type\":\" 2\",\"minAge\":\"0\",\"maxAge\":\"6\",\"clickCount\":\"2277286\",\"recommend\":\"我的环球之旅起航啦！\",\"serialize\":\"\",\"author\":\"\",\"price\":\"0.00\",\"introduction\":\"https://cdn.hhdd.com/book2/collect/introduction/collectIntroduction60061.html\",\"count\":\"18\",\"onlineCount\":\"19\",\"readyOnlineCount\":\"3\",\"subscribeCount\":\"1365\",\"sourceKey\":\"{\\\"name\\\":\\\"mom_home_boutique_click_mianfeihuiben1_8\\\",\\\"content\\\":\\\"1,60061\\\"}\",\"applePrice\":\"0.00\"}]}]}";
//
//    // 伪数据，要删除
//    public static List<BaseModelListVO> getFakeData() {
//        stringBuilder.append(jsonHead)
//                .append(storyCircleCateJson).append(",")
////                .append(storyImageTitleJson).append(",")
//                .append(storyConfigTitleJson).append(",")
//                .append(storyOneColJson).append(",")
//                .append(storyTwoColJson).append(",")
////                .append(storyImageTitleJson).append(",")
////                .append(storyConfigTitleJson).append(",")
//                .append(storyConfigTitleShowMoreJson).append(",")
//                .append(storyOneColJson).append(",")
//                .append(storyTwoColJson).append(",")
//                .append(storyTwoSchemaJson).append(",")
//                .append(storyTwoSchemaJson).append("")
//                .append(jsonTail);
//        String fakeJson = stringBuilder.toString();
//        LogHelper.d("Randy", fakeJson);
//        return DataListParser.parseJson(fakeJson);
//    }
}
