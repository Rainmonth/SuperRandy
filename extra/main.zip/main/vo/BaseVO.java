package com.hhdd.kada.main.vo;

import com.hhdd.kada.main.model.BaseModel;

/**
 * Created by simon on 4/5/16.
 */
public class BaseVO extends BaseModel {

    private int viewType = ViewTypes.View_Type_CompatEmpty.getId();

    private String bgColor;

    public int getViewType() {
        return viewType;
    }

    public BaseVO setViewType(int viewType) {
        this.viewType = viewType;
        return this;
    }

    public BaseVO setViewType(ViewTypes viewTypes) {
        this.viewType = viewTypes.getId();
        return this;
    }

    ///...
    //style:{circle:0|1,corner:0|1,icon:"imgUrl",bg:"#00000000",align:middle|""} //icon根据比例hardcode,circle优先
    private String style;

    public void setStyle(String style) {
        this.style = style;
    }

    public String getStyle() {
        return style;
    }

    /// style

    StyleVO styleVO;

    public StyleVO getStyleVO() {
        if (styleVO == null && style != null && style.length() > 0) {
            styleVO = StyleVO.parse(style);
        }
        return styleVO;
    }
}
