package com.hhdd.kada.main.vo;

import com.hhdd.kada.main.model.BaseModel;

/**
 * Created by simon on 6/16/16.
 */
public class BaseModelVO extends BaseVO {
    BaseModel model;

    public BaseModelVO() {

    }

    public BaseModelVO(BaseModel model, int viewType) {
        setModel(model);
        setViewType(viewType);
    }

    public BaseModelVO(BaseModel model, ViewTypes viewTypes) {
        setModel(model);
        setViewType(viewTypes);
    }

    public void setModel(BaseModel model) {
        this.model = model;
    }

    public BaseModel getModel() {
        return model;
    }
}
