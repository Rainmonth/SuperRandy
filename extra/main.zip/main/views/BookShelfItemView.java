package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

import com.hhdd.kada.Constants;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.ui.book.BookItemView;
import com.hhdd.kada.main.views.base.BaseFrameLayout;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/2
 * @describe : com.hhdd.kada.main.views
 */
public class BookShelfItemView extends BaseFrameLayout {

    @BindView(R.id.bookItemView)
    BookItemView bookItemView;
    @BindView(R.id.deleteView)
    ImageView deleteView;

    public BookShelfItemView(Context context) {
        super(context);
    }

    public BookShelfItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.view_holder_bookshelf_list_item;
    }

    @Override
    public void doInitListener() {
        bookItemView.setOnClickListener(new OnBookShelfItemViewClickListener(Constants.ACTION_BOOKSHELF_ITEM));
        deleteView.setOnClickListener(new OnBookShelfItemViewClickListener(Constants.ACTION_BOOKSHELF_ITEM_DELETE));
    }

    public BookItemView getBookItemView() {
        return bookItemView;
    }


    public ImageView getDeleteView() {
        return deleteView;
    }

    public void update(BaseModel model, boolean isShowDelete){
        bookItemView.update(model, false, getResources().getDimensionPixelOffset(R.dimen.playback_first_page_image_width), getResources().getDimensionPixelOffset(R.dimen.playback_first_page_image_height));
        deleteView.setVisibility(isShowDelete ? VISIBLE : GONE);
    }

    class OnBookShelfItemViewClickListener extends KaDaApplication.OnClickWithAnimListener{

        private int action;

        public OnBookShelfItemViewClickListener(int action) {
            this.action = action;
        }

        @Override
        public void OnClickWithAnim(View v) {
            onChildViewClick(v, action);
        }
    }
}
