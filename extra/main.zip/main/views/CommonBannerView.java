package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

import com.bigkoo.convenientbanner.ConvenientBanner;

import in.srain.cube.views.ptr.PtrFrameLayout;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/2/6 0006
 * @describe : com.yaowang.ywcommonproject.view
 */
public class CommonBannerView<T> extends MyConvenientBanner {

    public CommonBannerView(Context context) {
        super(context);
    }

    public CommonBannerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CommonBannerView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() != MotionEvent.ACTION_UP) {
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        return super.onTouchEvent(e);
    }
}
