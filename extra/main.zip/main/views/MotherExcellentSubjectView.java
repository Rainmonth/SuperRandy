package com.hhdd.kada.main.views;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.base.BaseDataRelativeLayout;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.views
 */
public class MotherExcellentSubjectView extends BaseDataRelativeLayout<RedirectInfo> {

    @BindView(R.id.bgImageView)
    SimpleDraweeView bgImageView;
    @BindView(R.id.moreTextView)
    TextView moreTextView;

    private RedirectInfo redirectInfo;

    public MotherExcellentSubjectView(Context context) {
        super(context);
    }

    public MotherExcellentSubjectView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_mother_excellent_subject;
    }

    @Override
    public void update(RedirectInfo data) {
        if(data != null) {
            this.redirectInfo = data;
            FrescoUtils.showUrl(data.getImageUrl(), bgImageView);
            moreTextView.setText(data.getSubTitle());
            moreTextView.setVisibility(TextUtils.isEmpty(data.getSubTitle()) ? GONE : VISIBLE);
        }
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        bgImageView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                doSubjectClick();
            }
        });
        moreTextView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                doSubjectClick();
            }
        });
    }

    private void doSubjectClick() {
        if(redirectInfo != null){
            RedirectActivity.startActivity(context, redirectInfo);
        }
    }
}
