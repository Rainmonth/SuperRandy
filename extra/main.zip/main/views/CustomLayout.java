package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;

import com.hhdd.kada.R;

/**
 * Created by lj on 16/6/14.
 */
public class CustomLayout extends ViewGroup {
    private static final String TAG = "CustomLayout";

    public CustomLayout(Context context) {
        super(context);
    }

    public CustomLayout(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    /**
     * 要求所有的孩子测量自己的大小，然后根据这些孩子的大小完成自己的尺寸测量
     */
    protected void onMeasure( int widthMeasureSpec, int heightMeasureSpec) {

        int lengthX = 0; // right position of child relative to parent

        int lengthY = 0; // bottom position of child relative to parent

        int row = 0;

        int parentWidth = MeasureSpec.getSize(widthMeasureSpec);

        int margin = getResources().getDimensionPixelOffset(R.dimen.search_text_margin);

        for (int index = 0; index < getChildCount(); index++) {

            final View child = getChildAt(index);

            // measure

            child.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);


            int childWidth = child.getMeasuredWidth();

            int height = child.getMeasuredHeight();

            lengthX += childWidth + margin;

            lengthY = row * (height + margin) + margin + height;

            // if it can't drawing on a same line , skip to next line

            if (lengthX - margin > parentWidth) {

                lengthX = childWidth + margin ;

                row++;

                lengthY = row * (height + margin) + margin + height;

            }
            //限制最多只能显示三行的内容
            if (row>=2){
                lengthY = 2*(height + margin) + margin + height;
            }
        }
        setMeasuredDimension(parentWidth,lengthY);

//        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    /**
     * 为所有的子控件摆放位置.
     */
    @Override
    protected void onLayout(boolean arg0, int arg1, int arg2, int arg3, int arg4) {
        final int count = getChildCount();

        int row = 0;// which row lay you view relative to parent

        int lengthX = arg1; // right position of child relative to parent

        int lengthY = arg2; // bottom position of child relative to parent

        int margin = getResources().getDimensionPixelOffset(R.dimen.search_text_margin);
        for (int i = 0; i < count; i++) {

            final View child = this.getChildAt(i);

            int width = child.getMeasuredWidth();

            int height = child.getMeasuredHeight();

            lengthX += width + margin;

            lengthY = row * (height + margin) + margin + height;

            // if it can't drawing on a same line , skip to next line

            if (lengthX - margin > arg3) {

                lengthX = width + margin + arg1;

                row++;

                lengthY = row * (height + margin) + margin + height;

            }

            child.layout(lengthX - width-margin, lengthY - height, lengthX - margin, lengthY);

        }

    }
}