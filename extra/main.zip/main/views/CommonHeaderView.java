package com.hhdd.kada.main.views;

import android.content.Context;
import android.graphics.drawable.AnimationDrawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.model.UserDetail;
import com.hhdd.core.service.AuthService;
import com.hhdd.core.service.CoinService;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.core.service.UserService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.coin.event.CoinUpdateEvent;
import com.hhdd.kada.coin.model.CoinAmountInfo;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.event.CoinRedDotDismissEvent;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.LogoutEvent;
import com.hhdd.kada.main.event.UpdateCommonMedalEvent;
import com.hhdd.kada.main.ui.activity.NewUserInfoActivity;
import com.hhdd.kada.main.ui.explore.ExploreFragment;
import com.hhdd.kada.main.utils.ActivityUtil;
import com.hhdd.kada.main.utils.FileUtils;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.HHTimeUtil;
import com.hhdd.kada.main.utils.StringUtil;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.medal.MedalListFragment;
import com.hhdd.kada.module.search.SearchActivity;
import com.hhdd.kada.module.search.SearchBaseFragment;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.views
 */
public class CommonHeaderView extends BaseHeaderView {

    @BindView(R.id.downloadLayout)
    View downloadLayout;
    @BindView(R.id.coinImageView)
    ImageView coinImageView;
    @BindView(R.id.coinCountTextView)
    TextView coinCountTextView;
    @BindView(R.id.medalLayout)
    RelativeLayout medalLayout;
    @BindView(R.id.medalAnimImageView)
    ImageView medalAnimImageView;
    @BindView(R.id.coinLayout)
    View coinLayout;
    @BindView(R.id.coin_red_dot)
    ImageView coinRedDot;
    @BindView(R.id.searchLayout)
    RelativeLayout searchLayout;
    private AnimationDrawable coinAnim;
    private AnimationDrawable medalAnim;


    private int type = TYPE_BOOK;//下载 进入源，绘本 听书 发现
    public static final int TYPE_BOOK = 0;
    public static final int TYPE_STORY = 1;
    public static final int TYPE_DISCOVERY = 2;

    private static final String[] HABIT_FROM = {"book", "story", "discovery"};
    private static final int[] MEDAL_ICON = {R.drawable.icon_medal_default_1,
            R.drawable.icon_medal_default_2, R.drawable.icon_medal_default_3};
    private String path;

    public CommonHeaderView(Context context) {
        super(context);
    }

    public CommonHeaderView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_common_header;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        EventBus.getDefault().register(this);
        updateHeadLoginState();
        coinImageView.setBackgroundResource(R.drawable.coin_anim);
        coinAnim = (AnimationDrawable) coinImageView.getBackground();
        coinAnim.start();
        showMedalView();
        medalAnim = (AnimationDrawable) medalAnimImageView.getBackground();
        medalAnim.start();
    }

    private void showMedalView() {
        List<UserDetail.UserMedalInfo> medalInfoList = new ArrayList<>();
        UserDetail userDetail = UserService.getInstance().getCurrentUserDetail();
        if (userDetail != null && userDetail.getMedalList() != null) {
            medalInfoList.addAll(userDetail.getMedalList());
        }
        int index = 0;
        for (int i = medalLayout.getChildCount() - 2; i > 0; i--) {
            SimpleDraweeView medalImageView = (SimpleDraweeView) medalLayout.getChildAt(i);
            String url = "res://" + context.getPackageName() + "/" + MEDAL_ICON[index];
            if (medalInfoList.size() > index) {
                UserDetail.UserMedalInfo medalInfo = medalInfoList.get(index);
                String medalUrl = medalInfo.getImage();
                if (!TextUtils.isEmpty(medalUrl)) {
                    url = medalUrl;
                }
            }
            FrescoUtils.showUrl(url, medalImageView);
            index++;
        }
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        headImageView.setOnClickListener(new OnItemAnimClickListener());
        downloadLayout.setOnClickListener(new OnItemAnimClickListener());
        medalLayout.setOnClickListener(new OnItemAnimClickListener());
        coinLayout.setOnClickListener(new OnItemAnimClickListener());
        searchLayout.setOnClickListener(new OnItemAnimClickListener());
    }

    @Override
    public void doInitData() {
        super.doInitData();
        showCoinCount();
        showCoinRedDot();
    }

    public View getCoinLayout() {
        return coinLayout;
    }

    public void setType(int type) {
        this.type = type;
    }

    private void showCoinRedDot() {
        path = UserService.getInstance().getShowCoinReddotCacheFile();
        if (!((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).isAllTaskFinished()) {
            String str = FileUtils.readStringFromFile(path);
            if (TextUtils.isEmpty(str) || (StringUtil.isNumeric(str) && !HHTimeUtil.isToday(Long.parseLong(str)))) {
                coinRedDot.setVisibility(VISIBLE);
            } else {
                coinRedDot.setVisibility(GONE);
            }
        } else {
            coinRedDot.setVisibility(GONE);
        }
    }

    private void showCoinCount() {
        UserDetail userDetail = UserService.getInstance().getCurrentUserDetail();
        if (userDetail != null && userDetail.getCoinInfo() != null) {
            coinCountTextView.setText(String.valueOf(userDetail.getCoinInfo().getCoin()));
        } else {
            coinCountTextView.setText("0");
        }
    }

    public void upDateCoinCount() {
        CoinAmountInfo coinAmountInfo = ((CoinService) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COIN_SERVICE)).getCoinAmountInfo();
        if (coinAmountInfo != null) {
            coinCountTextView.setText(String.valueOf(coinAmountInfo.getCoin()));
        } else {
            coinCountTextView.setText("0");
        }
    }

    class OnItemAnimClickListener extends KaDaApplication.OnClickWithAnimListener {
        @Override
        public void OnClickWithAnim(View v) {
            switch (v.getId()) {
                case R.id.headImageView:
                    ActivityUtil.next(context, NewUserInfoActivity.class);
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(HABIT_FROM[type], "common_head_child_avatar_click", TimeUtil.currentTime()));
                    break;
                case R.id.medalLayout:
                    MedalListFragment.pushFragment();
                    String isLogin = UserService.getInstance().isLogining() ? "1" : "0";
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(HABIT_FROM[type] + isLogin, "common_head_medal_click", TimeUtil.currentTime()));
                    break;
                case R.id.coinLayout:
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(HABIT_FROM[type], "common_head_coin_click", TimeUtil.currentTime()));
//                    if (UserService.getInstance().isLogining()) {
                    FragmentUtil.pushFragment(ExploreFragment.class, coinRedDot.getVisibility() == VISIBLE, true);
                    if (coinRedDot.getVisibility() == VISIBLE) {
                        FileUtils.saveStringToFile(String.valueOf(System.currentTimeMillis()), path);
                        EventCenter.fireEvent(new CoinRedDotDismissEvent());
                    }


//                    } else {
//                        LoginDialog loginDialog = new LoginDialog(getContext(), "kada://opencoinhome", 8);
//                        loginDialog.show();
//                    }
                    break;
                case R.id.downloadLayout:
                    ActivityUtil.nextDownloadActivity(context, type);
                    UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit(HABIT_FROM[type], "common_head_download_click", TimeUtil.currentTime()));
                    break;

                case R.id.searchLayout:
                    if (context == null) {
                        return;
                    }
                    if (type == TYPE_BOOK) {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "child_book_home_search_input_click", TimeUtil.currentTime()));
                        SearchActivity.startActivity(context, SearchBaseFragment.SEARCH_FROM_BOOK);
                    } else {
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", "story_home_page_search", TimeUtil.currentTime()));
                        SearchActivity.startActivity(context, SearchBaseFragment.SEARCH_FROM_STORY);
                    }
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 是否显示咔哒币动画 onResume onPause onVisible onInvisible
     *
     * @param isShowAnim
     */
    public void doCoinAnim(boolean isShowAnim) {
        if (coinAnim != null) {
            if (isShowAnim) {
                coinAnim.start();
            } else {
                coinAnim.stop();
            }
        }
    }

    public void doMedalAnim(boolean isShowAnim) {
        if (medalAnim != null) {
            if (isShowAnim) {
                medalAnim.start();
            } else {
                medalAnim.stop();
            }
        }
    }

    public void onEvent(LoginEvent event) {
        updateHeadLoginState();
    }


    public void onEvent(CoinRedDotDismissEvent event) {
        coinRedDot.setVisibility(GONE);
    }

    public void onEvent(AuthService.AuthorizedSuccessEvent event) {
        updateHeadLoginState();
    }

    public void onEvent(LogoutEvent event) {
        //退出登录后，先直接将头像置为未登录状态
        headImageView.setBorderWidth(0f);
        headImageView.setImageResource(R.drawable.icon_header_unlogin);
        showMedalView();
    }

    public void onEvent(UserService.UserInfoChangeEvent event) {
        showCoinCount();
        showCoinRedDot();
    }

    public void onEventMainThread(UpdateCommonMedalEvent event) {
        showMedalView();
    }

    public void onEventMainThread(CoinUpdateEvent event) {
        upDateCoinCount();
    }

    public void onEvent(UserService.AvatarFetchedEvent event) {
        updateHeadLoginState();
    }

    public void onEvent(UserService.AvatarChangedEvent event) {
        updateHeadLoginState();
    }

    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
    }
}
