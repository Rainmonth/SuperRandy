package com.hhdd.kada.main.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.AnimationDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.views.base.BaseRelativeLayout;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.views
 */
public class MainTabItemView extends BaseRelativeLayout {

    @BindView(R.id.tabImageView)
    ImageView tabImageView;
    @BindView(R.id.tabTextView)
    TextView tabTextView;
    @BindView(R.id.tabRedPoint)
    View tabRedPointView;

    AnimationDrawable animationDrawable;

    public MainTabItemView(Context context) {
        super(context);
    }

    public MainTabItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    protected void initAttributeSet(AttributeSet attrs) {
        super.initAttributeSet(attrs);
        if (attrs != null) {
            TypedArray typedArray = null;
            try {
                int defaultItemIconSize = LocalDisplay.dp2px(35);
                typedArray = context.obtainStyledAttributes(attrs,
                        R.styleable.MainTabItemView);
                if (typedArray.hasValue(R.styleable.MainTabItemView_itemIcon)) {
                    tabImageView.setImageResource(typedArray.getResourceId(R.styleable.MainTabItemView_itemIcon, 0));
                }

                ViewGroup.LayoutParams params = tabImageView.getLayoutParams();
                if (params == null) {
                    params = new ViewGroup.LayoutParams(defaultItemIconSize, defaultItemIconSize);
                }
                int itemIconSize = defaultItemIconSize;
                if (typedArray.hasValue(R.styleable.MainTabItemView_itemIconSize)) {
                    itemIconSize = typedArray.getDimensionPixelSize(R.styleable.MainTabItemView_itemIconSize, defaultItemIconSize);
                }
                params.width = itemIconSize;
                params.height = itemIconSize;
                tabImageView.setLayoutParams(params);

                if (typedArray.hasValue(R.styleable.MainTabItemView_itemText)) {
                    tabTextView.setText(typedArray.getString(R.styleable.MainTabItemView_itemText));
                }
            } finally {
                if (typedArray != null) {
                    typedArray.recycle();
                    typedArray = null;
                }
            }
        }
    }

    public View getTabRedPointView() {
        return tabRedPointView;
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_main_tab_item;
    }

    public final static int MOTHER_TYPE = 1;
    public final static int BOOK_TYPE = 2;
    public final static int STORY_TYPE = 3;

    public void startAnim(int type,boolean isSelected) {
        int resId = 0;
        switch (type) {
            case MOTHER_TYPE:
                resId = isSelected ? R.drawable.mother_tab_selected_anim : R.drawable.mother_tab_default_anim;
                break;
            case BOOK_TYPE:
                resId = isSelected ? R.drawable.book_tab_selected_anim : R.drawable.book_tab_default_anim;
                break;
            case STORY_TYPE:
                resId = isSelected ? R.drawable.story_tab_selected_anim : R.drawable.story_tab_default_anim;
                break;
        }
        animationDrawable = (AnimationDrawable) getResources().getDrawable(resId);
        tabImageView.setImageDrawable(animationDrawable);
        animationDrawable.start();
    }

    public void stopAnim() {
        if (animationDrawable != null) {
            animationDrawable.stop();
            animationDrawable = null;
        }
    }
}
