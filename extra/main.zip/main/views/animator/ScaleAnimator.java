package com.hhdd.kada.main.views.animator;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.view.View;

/**
 * Created by lj on 15/7/15.
 */
public class ScaleAnimator extends BaseViewAnimator {

    private float mScale;

    public ScaleAnimator(float scale) {
        mScale = scale;
    }

    @Override
    protected void prepare(View target) {
        ValueAnimator scaleX = ObjectAnimator.ofFloat(target, "scaleX", 1.0f, mScale);
        ValueAnimator scaleY = ObjectAnimator.ofFloat(target, "scaleY", 1.0f, mScale);
        scaleX.setRepeatMode(ValueAnimator.REVERSE);
        scaleY.setRepeatMode(ValueAnimator.REVERSE);
        scaleX.setRepeatCount(1);
        scaleY.setRepeatCount(1);
        getAnimatorAgent().play(scaleX).with(scaleY);

    }
}
