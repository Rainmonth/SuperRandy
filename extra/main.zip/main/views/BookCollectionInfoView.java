package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.ui.book.BookItemView;
import com.hhdd.kada.main.views.base.BaseDataLinearLayout;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.views
 */
public class BookCollectionInfoView extends BaseDataLinearLayout<BookCollectionInfo> {

    @BindView(R.id.bookItemView)
    BookItemView bookItemView;
    @BindView(R.id.titleTextView)
    TextView titleTextView;
    @BindView(R.id.descriptionTextView)
    TextView descriptionTextView;
    private BookCollectionInfo bookCollectionInfo;

    public BookCollectionInfoView(Context context) {
        super(context);
    }

    public BookCollectionInfoView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_bookinfo;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        setOrientation(VERTICAL);
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        bookItemView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                if(bookCollectionInfo != null) {
                    onChildViewClick(v, 99, bookCollectionInfo);
                }
            }
        });
    }

    @Override
    public void update(BookCollectionInfo data) {
        if(data != null) {
            bookCollectionInfo = data;
            bookItemView.update(data);
//            <!--精简《精选页》1x3 不显示标题 by lazy for v3.7 at 2018/5/24 -->
//            titleTextView.setText(data.getName());
            descriptionTextView.setText(data.getRecommend());
        }
    }
}
