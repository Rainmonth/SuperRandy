package com.hhdd.kada.main.views;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.settings.Settings;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.ScreenUtil;

/**
 * Created by simon on 23/6/15.
 */
public class DataLoadingBuilder {

    private Context mContext = null;
    private View mAboveView;
    private ViewGroup mContainer = null;
    private int mEmptyTextResource = R.string.kd_empty;
    private int mEmptyIconResource;
    private int mErrorTextResource;
    private int mErrorIconResource;
    private int mErrorSubTextResource;
    private ImageView imageView;
    private int mId;

//    BroadcastReceiver mNetworkReceiver = new BroadcastReceiver() {
//        @Override
//        public void onReceive(Context context, Intent intent) {
//            if (TextUtils.equals(NetworkReceiver.ACTION_NETWORK_CHANGED, intent.getAction())) {
//                boolean status = intent.getBooleanExtra(NetworkReceiver.ACTION_NETWORK_CHANGED_STATE_KEY, true);
//                Log.d("status",status+"");
//                if (status) {
//                    if(imageView!=null)
//                        imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_image_text));
////                    startBubbleAnim();
//                } else {
//                    if(imageView!=null){
//                        if(Settings.getInstance().isDownloadWhenNoWifi() && NetworkUtils.isNetworkAvailable(KaDaApplication.getInstance())){
//                            imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_image_text));
//                        }else{
//                            imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.load_fail));
//                            imageView.getLayoutParams().height = ScreenUtil.dip2px(mContext,160);
////                            stopBubbleAnim();
//                        }
//                    }
//                }
//            }
//        }
//    };

    public void setImageViewRes(int id) {
        mId = id;
    }

    public DataLoadingBuilder(Context context, View aboveView) {
        this.mContext = context;
        this.mAboveView = aboveView;
        init(aboveView);

//        KaDaApplication.registerLocalBroadcastReceiver(mNetworkReceiver, new IntentFilter(NetworkReceiver.ACTION_NETWORK_CHANGED));
    }

    private void init(View aboveView) {
        if (aboveView != null) {
            mContainer = (ViewGroup) LayoutInflater.from(mContext).inflate(R.layout.loading_layout, null);
            ViewGroup parentView = (ViewGroup) aboveView.getParent();
            parentView.addView(mContainer); // 你需要在这儿设置正确的位置，以达到你需要的效果。

            mContainer.setVisibility(View.GONE);
        }
    }

    public boolean isVisible() {
        if (mContainer != null) {
            return mContainer.getVisibility() == View.VISIBLE;
        }
        return false;
    }

    public View showLoading() {
        mContainer.setVisibility(View.VISIBLE);
        View view = mContainer.findViewById(R.id.progress_container);
        if (view.getVisibility() != View.VISIBLE) {
            view.setVisibility(View.VISIBLE);
            mContainer.findViewById(R.id.play_back_loading_container).setVisibility(View.GONE);

            imageView = (ImageView) mContainer.findViewById(R.id.loading_pangxie);
            imageView.setVisibility(View.VISIBLE);
            if (NetworkUtils.isReachableViaWiFi()) {
                imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_image_text));
            } else {
                if (NetworkUtils.isNetworkAvailable(KaDaApplication.getInstance())) {
                    imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_image_text));
                } else {
                    if (mId != 0) {
                        imageView.setImageDrawable(mContainer.getResources().getDrawable(mId));
                    } else {
                        imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_slow));
                    }
                    imageView.getLayoutParams().height = ScreenUtil.dip2px(mContext, 160);
                }
            }
        }
        return mContainer;
    }

    public View showReadingLoading() {
        mContainer.setVisibility(View.VISIBLE);
        View view = mContainer.findViewById(R.id.play_back_loading_container);
        if (view.getVisibility() != View.VISIBLE) {
            view.setVisibility(View.VISIBLE);
            mContainer.findViewById(R.id.progress_container).setVisibility(View.GONE);

            imageView = (ImageView) mContainer.findViewById(R.id.play_back_loading_pangxie);
            TextView loadingText = (TextView) mContainer.findViewById(R.id.play_back_loading_text);
            View progress = mContainer.findViewById(R.id.play_back_loading_progress);

//            imageView.setVisibility(View.VISIBLE);
            if (NetworkUtils.isReachableViaWiFi()) {
//                imageView.setVisibility(View.GONE);
//                imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_image_text));
                loadingText.setVisibility(View.VISIBLE);
            } else {
                if (NetworkUtils.isNetworkAvailable(KaDaApplication.getInstance())) {
//                    imageView.setVisibility(View.GONE);
//                    imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_image_text));
                    loadingText.setVisibility(View.VISIBLE);
                } else {
//                    imageView.setVisibility(View.VISIBLE);
//                    progress.setVisibility(View.GONE);
                    loadingText.setVisibility(View.GONE);
                    imageView.setVisibility(View.VISIBLE);
                    imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_slow));
                }
            }
            imageView.getLayoutParams().height = ScreenUtil.dip2px(mContext, 160);
        }
        return mContainer;
    }

    public View showSearchLoading() {
        mContainer.setVisibility(View.VISIBLE);
        View view = mContainer.findViewById(R.id.progress_container);
        if (view.getVisibility() != View.VISIBLE) {
            view.setVisibility(View.VISIBLE);
            mContainer.findViewById(R.id.play_back_loading_container).setVisibility(View.GONE);

            imageView = (ImageView) mContainer.findViewById(R.id.loading_pangxie);
            imageView.setVisibility(View.GONE);
            TextView textView = (TextView) mContainer.findViewById(R.id.loading_text);
            textView.setText("小朋友\n搜索的内容正在加载中");
            textView.setTextColor(mContainer.getResources().getColor(R.color.white));
            textView.setVisibility(View.VISIBLE);
        }
        return mContainer;
    }


    public void showNetError() {
        mContainer.setVisibility(View.VISIBLE);
        if (imageView != null) {
            imageView.setImageDrawable(mContainer.getResources().getDrawable(R.drawable.loading_slow));
            imageView.getLayoutParams().height = ScreenUtil.dip2px(mContext, 160);
        }

    }

    public void dismiss() {
        if (mContainer != null
                && mContainer.getVisibility() == View.VISIBLE) {
//            stopBubbleAnim();
            mContainer.setVisibility(View.GONE);
        }
    }


    public void setOnRetryClickListener(View.OnClickListener listener) {
    }

    public void setBackgroundColor(int color) {
        if (mContainer != null) {
            mContainer.setBackgroundColor(color);
        }
    }

    public void onDestroy() {
//        KaDaApplication.unregisterLocalBroadcastReceiver(mNetworkReceiver);
    }
}
