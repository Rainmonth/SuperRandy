package com.hhdd.kada.main.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.AttributeSet;

import com.hhdd.core.service.UserService;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.views.base.BaseRelativeLayout;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/25
 * @describe : com.hhdd.kada.main.views
 */
public abstract class BaseHeaderView extends BaseRelativeLayout {

    @BindView(R.id.headImageView)
    com.makeramen.roundedimageview.RoundedImageView headImageView;

    public BaseHeaderView(Context context) {
        super(context);
    }

    public BaseHeaderView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    /**
     * 更新头像登录显示状态
     */
    public void updateHeadLoginState(){
        if(UserService.getInstance().isLogining()) {
            float borderWidth = LocalDisplay.dp2px(2);
            headImageView.setBorderWidth(borderWidth);
            Bitmap bitmap = UserService.getInstance().currentUserAvatar();
            if (bitmap != null) {
                headImageView.setImageBitmap(bitmap);
            } else {
                headImageView.setImageResource(R.drawable.cemara);
            }
        }else {
            headImageView.setBorderWidth(0f);
            headImageView.setImageResource(R.drawable.icon_header_unlogin);
        }
    }
}
