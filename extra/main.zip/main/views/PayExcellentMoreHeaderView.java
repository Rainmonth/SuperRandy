package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.base.BaseDataRelativeLayout;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/1
 * @describe : com.hhdd.kada.main.views
 */
public class PayExcellentMoreHeaderView extends BaseDataRelativeLayout<RedirectInfo> {

    @BindView(R.id.bgImageView)
    SimpleDraweeView bgImageView;

    public PayExcellentMoreHeaderView(Context context) {
        super(context);
    }

    public PayExcellentMoreHeaderView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_pay_excellent_more_header;
    }

    @Override
    public void update(RedirectInfo data) {
        if(data != null){
            String imgUrl = CdnUtils.getImgCdnUrl(data.getImageUrl(), CdnUtils.getBannerSize());
            FrescoUtils.showImg(bgImageView, imgUrl);
        }
    }
}
