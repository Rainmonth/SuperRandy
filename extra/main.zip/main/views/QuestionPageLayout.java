package com.hhdd.kada.main.views;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.hhdd.core.model.QuestionDetailInfo;
import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.ui.adapter.MyBaseAdapter;
import com.hhdd.kada.main.ui.viewholder.BaseViewHolder;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.logger.LogHelper;
import com.nostra13.universalimageloader.core.DisplayImageOptions;

import java.util.List;

/**
 * Created by zhengkaituo on 16/1/7.
 */
public class QuestionPageLayout extends FrameLayout {

    GridView listview;
    ScaleDraweeView questionimage;
    ImageView question_icon;
    TextView question_title;
    //    ImageView question_bg;
    QuestionListViewAdapter adapter;
    RelativeLayout question_container;
    //    FrameLayout title_layout;
    ValueAnimator animator;

    int optionsCount;
    int index;

    DisplayImageOptions displayImageOptions;
    private View questionTopLayoutBg;
    private FrameLayout questionTopLayout;
    private FrameLayout questionIconLayout;

    public void setDisplayImageOptions(DisplayImageOptions imageOptions) {
        displayImageOptions = imageOptions;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public QuestionPageLayout(Context context, AttributeSet attr) {
        super(context, attr);
    }

    String type;
    QuestionDetailInfo questionDetailInfo;
    public final static String ITEM_TYPE_A = "A";
    public final static String ITEM_TYPE_B = "B";
    public final static String ITEM_TYPE_C = "C";
    String coverUrl;


    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        adapter = new QuestionListViewAdapter(getContext());
        questionTopLayout = (FrameLayout) findViewById(R.id.questionTopLayout);
        questionTopLayoutBg = findViewById(R.id.questionTopLayoutBg);
        questionIconLayout = (FrameLayout) findViewById(R.id.question_icon_layout);
        listview = (GridView) findViewById(R.id.option);
        question_container = (RelativeLayout) findViewById(R.id.question_container);
        questionimage = (ScaleDraweeView) findViewById(R.id.question_image);
        question_icon = (ImageView) findViewById(R.id.question_icon);
        question_title = (TextView) findViewById(R.id.questionTitle);
//        question_bg = (ImageView) findViewById(R.id.title_bg);
//        title_layout = (FrameLayout) findViewById(R.id.title_layout);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new KaDaApplication.OnItemClickWithSound() {
            @Override
            public void OnItemClickWithSound(AdapterView<?> adapterView, View view, int i, long l) {
                if (listner != null && questionDetailInfo != null && !questionDetailInfo.getQuestions().get(index).getisAnswered()) {
                    listner.onOptionClick(view, i);
                }
            }
        });

        question_icon.setOnClickListener(new KaDaApplication.NoDoubleClickListener() {
            @Override
            public void onNoDoubleClick(View v) {
                if (iconListener != null) {
                    iconListener.onIconClick(v);
                }
            }
        });

        animator = ValueAnimator.ofFloat(0, -20, 0, 20, 0);
        animator.setTarget(question_icon);
        animator.setDuration(1500);
        animator.setInterpolator(new LinearInterpolator());
        animator.setRepeatCount(ValueAnimator.INFINITE);
//        animator.setRepeatMode(ValueAnimator.INFINITE);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                question_icon.setRotation((Float) valueAnimator.getAnimatedValue());
            }
        });
//        animator.start();

    }

    public void setQuestionDetailInfo(QuestionDetailInfo questionDetailInfo, int index) {
        this.index = index;
        LogHelper.d("bookType", "" + type);
        if (questionDetailInfo != null) {
            this.questionDetailInfo = questionDetailInfo;
            optionsCount = questionDetailInfo.getQuestions().get(index).getOptions().size();

//            questionimage.setImageUrl(questionDetailInfo.getQuestions().get(0).getQuestion(),imageLoader);
            question_title.setText(questionDetailInfo.getQuestions().get(index).getText());
            adapter.clear();
            adapter.setOptionsCount(optionsCount);
            adapter.addAll(questionDetailInfo.getQuestions().get(index).getOptions());
            adapter.notifyDataSetChanged();
        }
    }


    public void setLayoutwithConfiguration() {

        //各组件params
        RelativeLayout.LayoutParams listviewparams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        RelativeLayout.LayoutParams imageparams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        FrameLayout.LayoutParams titleparams = (FrameLayout.LayoutParams) question_title.getLayoutParams();
        FrameLayout.LayoutParams topLayoutBgParams = (FrameLayout.LayoutParams) questionTopLayoutBg.getLayoutParams();
        FrameLayout.LayoutParams questionIconLayoutLayoutParams = (LayoutParams) questionIconLayout.getLayoutParams();

        if (type == null && questionDetailInfo != null) {
            List<QuestionDetailInfo.QuestionInfo> questionInfos = questionDetailInfo.getQuestions();
            if (questionInfos != null && index >= 0 && index < questionInfos.size()) {
                type = questionInfos.get(index).getKind();
            }
        }

        if (type == null) {
            return;
        }

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) { // 横屏
            topLayoutBgParams.height = LocalDisplay.dp2px(70);
            questionIconLayoutLayoutParams.topMargin = 0;

            if (type.equals(ITEM_TYPE_A)) {
                questionimage.setVisibility(GONE);

                listview.setNumColumns(optionsCount);

                listviewparams.addRule(RelativeLayout.CENTER_IN_PARENT);
            } else if (type.equals(ITEM_TYPE_B)) {
                listview.setNumColumns(optionsCount);

                imageparams.width = ViewGroup.LayoutParams.MATCH_PARENT;
                imageparams.height = LocalDisplay.SCREEN_WIDTH_PIXELS * 2 / 5;
                imageparams.addRule(RelativeLayout.CENTER_HORIZONTAL);

                listviewparams.addRule(RelativeLayout.BELOW, R.id.question_image);
                listviewparams.addRule(RelativeLayout.CENTER_HORIZONTAL);
            } else if (type.equals(ITEM_TYPE_C)) {

                if (optionsCount >= 4) {
                    listview.setNumColumns(2);
                } else {
                    listview.setNumColumns(optionsCount);
                }

                imageparams.height = ViewGroup.LayoutParams.MATCH_PARENT;
                imageparams.width = LocalDisplay.SCREEN_WIDTH_PIXELS * 3 / 4;
                imageparams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);

                listviewparams.addRule(RelativeLayout.CENTER_HORIZONTAL);
                listviewparams.addRule(RelativeLayout.RIGHT_OF, R.id.question_image);
                listviewparams.addRule(RelativeLayout.CENTER_VERTICAL);
            }

            titleparams.topMargin = 0;
            titleparams.rightMargin = LocalDisplay.dp2px(100);
            question_title.setMaxLines(2);
            question_title.setPadding(LocalDisplay.dp2px(64), LocalDisplay.dp2px(12), LocalDisplay.dp2px(12), LocalDisplay.dp2px(12));
            question_title.setTextColor(Color.WHITE);

        } else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) { // 竖屏

            topLayoutBgParams.height = LocalDisplay.dp2px(70) + LocalDisplay.SCREEN_STATUS_HEIGHT;
            questionIconLayoutLayoutParams.topMargin = LocalDisplay.SCREEN_STATUS_HEIGHT;

            if (type.equals(ITEM_TYPE_A)) {
                questionimage.setVisibility(GONE);

                if (optionsCount >= 4) {
                    listview.setNumColumns(2);
                } else {
                    listview.setNumColumns(optionsCount);
                }

                listviewparams.addRule(RelativeLayout.CENTER_IN_PARENT);
            } else if (type.equals(ITEM_TYPE_B)) {

                if (optionsCount >= 4) {
                    listview.setNumColumns(2);
                } else {
                    listview.setNumColumns(optionsCount);
                }

                imageparams.width = ViewGroup.LayoutParams.MATCH_PARENT;
                imageparams.height = LocalDisplay.SCREEN_WIDTH_PIXELS * 2 / 3;
                imageparams.addRule(RelativeLayout.CENTER_HORIZONTAL);

                listviewparams.addRule(RelativeLayout.BELOW, R.id.question_image);
                listviewparams.addRule(RelativeLayout.CENTER_HORIZONTAL);
            } else if (type.equals(ITEM_TYPE_C)) {
                listview.setNumColumns(optionsCount);

                imageparams.width = ViewGroup.LayoutParams.MATCH_PARENT;
                imageparams.height = LocalDisplay.SCREEN_WIDTH_PIXELS * 3 / 4;

                imageparams.addRule(RelativeLayout.CENTER_HORIZONTAL);
                listviewparams.addRule(RelativeLayout.BELOW, R.id.question_image);
                listviewparams.addRule(RelativeLayout.CENTER_HORIZONTAL);
            }

            titleparams.topMargin = LocalDisplay.dp2px(70) + LocalDisplay.SCREEN_STATUS_HEIGHT;
            titleparams.rightMargin = 0;
            question_title.setMaxLines(3);
            question_title.setPadding(LocalDisplay.dp2px(12), LocalDisplay.dp2px(12), LocalDisplay.dp2px(12), LocalDisplay.dp2px(12));
            question_title.setTextColor(getResources().getColor(R.color.question_background));
        }

        questionimage.setLayoutParams(imageparams);
        listview.setLayoutParams(listviewparams);

        if (questionDetailInfo.getQuestions() != null
                && questionDetailInfo.getQuestions().size() > index
                && questionDetailInfo.getQuestions().get(index).getQuestion() != null
                && questionimage.getVisibility() == View.VISIBLE) {

            String url = CdnUtils.getImgCdnUrl(questionDetailInfo.getQuestions().get(index).getQuestion(), true);
            if (!TextUtils.equals(url, coverUrl)) {
                coverUrl = url;
                FrescoUtils.showImg(questionimage, url);
            }
        }
        questionimage.requestLayout();
        listview.requestLayout();
    }

    public void setListViewEnabled(boolean enabled) {
        if (listview != null) {
            listview.setEnabled(enabled);
        }
    }


    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (animator != null) {
            animator.cancel();
            animator.end();
        }
    }

    public void startAnim() {
        if (animator != null && !animator.isRunning() && !animator.isStarted()) {
            UserHabitService.getInstance().track(UserHabitService.newUserHabit("", "enterbookquestion_page", TimeUtil.currentTime()));
            question_icon.setPivotX(question_icon.getMeasuredWidth() * 0.5f);
            question_icon.setPivotY(question_icon.getMeasuredHeight() * 0.9f);
            animator.start();
        }
    }

    public int getMeasuredHeight(int height) {
//        float rate = ScreenUtil.getScreenSize(getContext()).y > ScreenUtil.getScreenSize(getContext()).x
//                ? (ScreenUtil.getScreenSize(getContext()).y) / 1136f : (ScreenUtil.getScreenSize(getContext()).y) / 640f;
//        return (int) (rate * height);

        return LocalDisplay.dp2px(height);
    }

    public int getMeasuredWidth(int width) {
//        float rate = ScreenUtil.getScreenSize(getContext()).y > ScreenUtil.getScreenSize(getContext()).x
//                ? (ScreenUtil.getScreenSize(getContext()).x) / 640f : (ScreenUtil.getScreenSize(getContext()).x) / 1136f;
//        return (int) (rate * width);

        return LocalDisplay.dp2px(width);
    }


    class QuestionListViewAdapter extends MyBaseAdapter<String> {


        int optionsCount;
        int mItemWidth;

        public QuestionListViewAdapter(Context context) {
            super(context);


        }

        public void setOptionsCount(int column) {
            this.optionsCount = column;

        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = View.inflate(mContext, R.layout.question_option_item_layout, null);
            }

            ScaleDraweeView cover = BaseViewHolder.getChildView(convertView, R.id.optionimage);
            FrameLayout layout = BaseViewHolder.getChildView(convertView, R.id.option);
            ImageView checkbox = BaseViewHolder.getChildView(convertView, R.id.check);
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) (layout.getLayoutParams());

            if (questionDetailInfo != null) {
                if (questionDetailInfo.getQuestions().get(index).getisAnswered() && checkbox != null) {
                    if (questionDetailInfo.getQuestions().get(index).getAnswer().contains(position + 1)) {
                        checkbox.setVisibility(VISIBLE);
                    } else {
                        checkbox.setVisibility(GONE);
                    }
                }
            }

            //横屏
            if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                if (type.equals(ITEM_TYPE_A)) {

                    int space = LocalDisplay.dp2px(12);
                    int maxItemHeight = LocalDisplay.SCREEN_WIDTH_PIXELS
                            - LocalDisplay.dp2px(70 + 24)
                            - space;
                    int listViewWidth = LocalDisplay.SCREEN_HEIGHT_PIXELS - LocalDisplay.dp2px(24) - space * listview.getNumColumns();

                    int itemWidth = listViewWidth / listview.getNumColumns();
                    mItemWidth = itemWidth < maxItemHeight ? itemWidth : maxItemHeight;

                    params.width = mItemWidth;
                    params.height = mItemWidth;

                } else if (type.equals(ITEM_TYPE_B)) {

                    int space = LocalDisplay.dp2px(12);
                    int maxItemHeight = LocalDisplay.SCREEN_WIDTH_PIXELS * 3 / 5 - LocalDisplay.dp2px(70 + 24) - space;
                    int listViewWidth = LocalDisplay.SCREEN_HEIGHT_PIXELS - LocalDisplay.dp2px(24) - space * listview.getNumColumns();

                    int itemWidth = listViewWidth / listview.getNumColumns();
                    mItemWidth = itemWidth < maxItemHeight ? itemWidth : maxItemHeight;

                    params.width = mItemWidth;
                    params.height = mItemWidth;

                } else if (type.equals(ITEM_TYPE_C)) {

                    int space = LocalDisplay.dp2px(12);
                    int vSpace = optionsCount >= 4 ? space * 2 : space;
                    int listViewHeight = LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(70 + 24) - vSpace;
                    int listViewWidth = LocalDisplay.SCREEN_HEIGHT_PIXELS
                            - LocalDisplay.SCREEN_WIDTH_PIXELS * 3 / 4
                            - LocalDisplay.dp2px(24)
                            - space * listview.getNumColumns();

                    int itemWidth = listViewWidth / listview.getNumColumns();
                    int itemHeight = listViewHeight;

                    if (optionsCount >= 4) {
                        itemHeight = listViewHeight / 2;
                    }

                    mItemWidth = itemWidth < itemHeight ? itemWidth : itemHeight;

                    params.width = mItemWidth;
                    params.height = mItemWidth;
                }
            }

            //竖屏
            else if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                if (type.equals(ITEM_TYPE_A)) {

                    int space = LocalDisplay.dp2px(12);
                    int vSpace = optionsCount >= 4 ? space * 2 : space;
                    int listViewHeight = LocalDisplay.SCREEN_HEIGHT_PIXELS
                            - LocalDisplay.dp2px(70 + 60 + 24)
                            - LocalDisplay.SCREEN_STATUS_HEIGHT
                            - vSpace;
                    int listViewWidth = LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(24) - space * listview.getNumColumns();

                    int itemWidth = listViewWidth / listview.getNumColumns();
                    int itemHeight = listViewHeight;

                    if (optionsCount >= 4) {
                        itemHeight = listViewHeight / 2;
                    }

                    mItemWidth = itemWidth < itemHeight ? itemWidth : itemHeight;

                    params.width = mItemWidth;
                    params.height = mItemWidth;

                } else if (type.equals(ITEM_TYPE_B)) {

                    int space = LocalDisplay.dp2px(12);
                    int vSpace = optionsCount >= 4 ? space * 2 : space;
                    int listViewHeight = LocalDisplay.SCREEN_HEIGHT_PIXELS
                            - LocalDisplay.SCREEN_WIDTH_PIXELS * 2 / 3
                            - LocalDisplay.dp2px(70 + 60 + 24)
                            - LocalDisplay.SCREEN_STATUS_HEIGHT
                            - vSpace;
                    int listViewWidth = LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(24) - space * listview.getNumColumns();

                    int itemWidth = listViewWidth / listview.getNumColumns();
                    int itemHeight = listViewHeight;

                    if (optionsCount >= 4) {
                        itemHeight = listViewHeight / 2;
                    }

                    mItemWidth = itemWidth < itemHeight ? itemWidth : itemHeight;

                    params.width = mItemWidth;
                    params.height = mItemWidth;

                } else if (type.equals(ITEM_TYPE_C)) {

                    int space = LocalDisplay.dp2px(12);
                    int listViewHeight = LocalDisplay.SCREEN_HEIGHT_PIXELS
                            - LocalDisplay.dp2px(70 + 60 + 24)
                            - LocalDisplay.SCREEN_STATUS_HEIGHT
                            - space;
                    int listViewWidth = LocalDisplay.SCREEN_WIDTH_PIXELS - LocalDisplay.dp2px(24) - space * listview.getNumColumns();

                    int itemWidth = listViewWidth / listview.getNumColumns();
                    mItemWidth = itemWidth < listViewHeight ? itemWidth : listViewHeight;

                    params.width = mItemWidth;
                    params.height = mItemWidth;
                }
            }

            String coverUrl = CdnUtils.getImgCdnUrl(getItemAt(position), true);
            FrescoUtils.showImg(cover, coverUrl);

            return convertView;
        }

    }

    public interface Listner {
        void onOptionClick(View view, int position);
    }

    public Listner getListner() {
        return listner;
    }

    public void setListner(Listner listner) {
        this.listner = listner;
    }

    public interface iconListener {
        void onIconClick(View view);
    }

    public void setIconListener(iconListener listener) {
        this.iconListener = listener;
    }

    iconListener iconListener;
    Listner listner;
}
