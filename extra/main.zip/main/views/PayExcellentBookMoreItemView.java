package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;

import com.hhdd.kada.R;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.ui.book.BookItemView;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/1
 * @describe : com.hhdd.kada.main.views
 */
public class PayExcellentBookMoreItemView extends BasePayExcellentMoreItemView<BookCollectionInfo> {

    @BindView(R.id.bookItemView)
    BookItemView bookItemView;

    public PayExcellentBookMoreItemView(Context context) {
        super(context);
    }

    public PayExcellentBookMoreItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_pay_excellent_more_book;
    }

    @Override
    public void update(BookCollectionInfo data) {
        super.update(data);
        if(data != null){
            bookItemView.update(data);
        }
    }
}
