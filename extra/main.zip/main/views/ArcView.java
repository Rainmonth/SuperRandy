package com.hhdd.kada.main.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

import com.hhdd.kada.android.library.utils.LocalDisplay;

/**
 * @autor lazys
 * @created 2018/6/6 11:27
 * @desc 圆弧效果
 */
public class ArcView extends View {

    private Paint mPaint;
    private Path path;

    public ArcView(Context context) {
        super(context);
        init();
    }

    public ArcView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }
    private void init() {
        path = new Path();
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        setLayerType(View.LAYER_TYPE_SOFTWARE, mPaint);
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setColor(Color.WHITE);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        path.moveTo(0, getHeight());

        int width = LocalDisplay.SCREEN_WIDTH_PIXELS;//使用getWidth()不精确
        int height = getHeight();

        path.lineTo(width, height);
        path.quadTo(width / 2, height * -1, 0, height);
        canvas.drawPath(path, mPaint);

        super.onDraw(canvas);
    }
}

