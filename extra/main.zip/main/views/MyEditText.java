package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.EditText;

import com.hhdd.kada.R;
import com.hhdd.kada.main.views.animator.MorphingAnimation;

/**
 * Created by lj on 16/2/22.
 */
public class MyEditText extends EditText{

    MorphingAnimation animation;
    public MyEditText(Context context) {
        super(context);

//        init();
    }

    public MyEditText(Context context, AttributeSet attrs) {
        super(context, attrs);

//        init();
    }
//
//    private StateListDrawable mIdleStateDrawable;
//    private StrokeGradientDrawable background;
//    void init(){
//
//        if (background == null) {
//            background = createDrawable();
//        }
//        mIdleStateDrawable = new StateListDrawable();
//
//        mIdleStateDrawable.addState(StateSet.WILD_CARD, background.getGradientDrawable());
//        setBackgroundCompat(mIdleStateDrawable);
//    }
//
//    /**
//     * Set the View's background. Masks the API changes made in Jelly Bean.
//     */
//    @SuppressWarnings("deprecation")
//    @SuppressLint("NewApi")
//    public void setBackgroundCompat(Drawable drawable) {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
//            setBackground(drawable);
//        } else {
//            setBackgroundDrawable(drawable);
//        }
//    }
//
//    private StrokeGradientDrawable createDrawable() {
//        GradientDrawable drawable = (GradientDrawable) getResources().getDrawable(R.drawable.round_get_verification_code_bg).mutate();
////        drawable.setColor(color);
//        drawable.setCornerRadius(getResources().getDimension(R.dimen.corners_radius));
//        StrokeGradientDrawable strokeGradientDrawable = new StrokeGradientDrawable(drawable);
////        strokeGradientDrawable.setStrokeColor(color);
////        strokeGradientDrawable.setStrokeWidth(mStrokeWidth);
//
//        return strokeGradientDrawable;
//    }

    private MorphingAnimation createMorphing(int width) {

//        GradientDrawable drawable = (GradientDrawable) getResources().getDrawable(R.drawable.round_get_verification_code_bg).mutate();
//        StrokeGradientDrawable strokeGradientDrawable = new StrokeGradientDrawable(drawable);
        MorphingAnimation animation = new MorphingAnimation(this);

        animation.setFromWidth(0);
        animation.setToWidth(width / 2 - getResources().getDimensionPixelOffset(R.dimen.view_margin));

//        animation.setFromColor(getResources().getColor(R.color.yellow));
//        animation.setToColor(getResources().getColor(R.color.yellow));
//
//        animation.setFromStrokeColor(getResources().getColor(R.color.yellow));
//        animation.setToStrokeColor(getResources().getColor(R.color.black));

//        animation.setDuration(MorphingAnimation.DURATION_NORMAL);

        return animation;
    }


    public void start(int width){
        if(animation == null){
            animation = createMorphing(width);
            animation.start2();
        }
    }
}
