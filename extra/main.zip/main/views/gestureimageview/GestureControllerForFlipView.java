package com.hhdd.kada.main.views.gestureimageview;

import android.annotation.TargetApi;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import com.alexvasilkov.gestures.GestureController;
import com.alexvasilkov.gestures.State;

import se.emilsjolander.flipview.FlipView;

/**
 * Created by simon on 7/12/16.
 */
public class GestureControllerForFlipView extends GestureController {

    private static final int[] locationTmp = new int[2];
    private static final Matrix matrixTmp = new Matrix();

    private final int touchSlop;

    private FlipView mFlipView;

    private boolean isScrollGestureDetected;

    private int viewPagerX;
    private boolean isViewPagerInterceptedScroll;
    private float lastViewPagerEventX;

    public GestureControllerForFlipView(@NonNull View view) {
        super(view);
        touchSlop = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
    }

    /**
     * Enables scroll inside {@link ViewPager}
     * (by enabling cross movement between ViewPager and it's child view)
     */
    public void enableScrollInFlipView(FlipView flipView) {
        mFlipView = flipView;

        // Disabling motion event splitting
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            flipView.setMotionEventSplittingEnabled(false);
        }
    }

    @Override
    public boolean onTouch(@NonNull View view, @NonNull MotionEvent event) {
        if (mFlipView == null) {
            return super.onTouch(view, event);
        } else {
            // Getting motiona event in pager coordinates
            MotionEvent pagerEvent = MotionEvent.obtain(event);
            transformToPagerEvent(pagerEvent, view, mFlipView);

            boolean result = super.onTouch(view, pagerEvent);
            pagerEvent.recycle();
            return result;
        }
    }

    @Override
    protected boolean onDown(@NonNull MotionEvent e) {
        if (mFlipView == null) {
            return super.onDown(e);
        }
        mFlipView.requestDisallowInterceptTouchEvent(true);

        isViewPagerInterceptedScroll = false;
        isScrollGestureDetected = false;

        viewPagerX = 0;
        lastViewPagerEventX = e.getX();

        passEventToViewPager(e);

        super.onDown(e);
        return true;
    }

    @Override
    protected void onUpOrCancel(@NonNull MotionEvent event) {
        passEventToViewPager(event);
        super.onUpOrCancel(event);
    }

    @Override
    protected boolean onScroll(@NonNull MotionEvent e1, @NonNull MotionEvent e2, float dX, float dY) {
        if (mFlipView == null) {
            return super.onScroll(e1, e2, dX, dY);
        } else {
            if (!isScrollGestureDetected) {
                isScrollGestureDetected = true;
                // First scroll event can stutter a bit, so we will ignore it for smoother scrolling
                return true;
            }

            // Splitting movement between pager and view
            float fixedDistanceX = -scrollBy(e2, -dX);

            return super.onScroll(e1, e2, fixedDistanceX, dY);
        }
    }

    /**
     * Scrolls ViewPager if view reached bounds. Returns distance at which view can be actually
     * scrolled. Here we will split given distance (dX) into movement of ViewPager and movement
     * of view itself.
     */
    private float scrollBy(@NonNull MotionEvent event, float dx) {

        final State stateOrig = getState();
        final State state = stateOrig.copy();
        final RectF movBounds = new RectF();
        getStateController().getEffectiveMovementArea(movBounds,stateOrig);

        float pagerDx = splitPagerScroll(dx, state, movBounds);
        float viewDx = dx - pagerDx;

        // Applying pager scroll
        boolean shouldFixViewX = isViewPagerInterceptedScroll;
        int actualX = performViewPagerScroll(event, pagerDx);
        viewPagerX += actualX;
        if (shouldFixViewX) { // Adding back scroll not handled by ViewPager
            viewDx += Math.round(pagerDx) - actualX;
        }

        // Returning altered scroll left for image
        return viewDx;
    }

    /**
     * Splits x scroll between viewpager and view.
     */
    private float splitPagerScroll(float dx, State state, RectF movBounds) {
        if (getSettings().isPanEnabled()) {
            final float dir = Math.signum(dx);
            final float movementX = Math.abs(dx); // always >= 0, no direction info

            final float viewX = state.getX();
            // available movement distances (always >= 0, no direction info)
            float availableViewX = dir < 0 ? viewX - movBounds.left : movBounds.right - viewX;
            float availablePagerX = 0;

            // Not available if already overscrolled in same direction
            if (availableViewX < 0) {
                availableViewX = 0;
            }

            float pagerMovementX;
            if (availablePagerX >= movementX) {
                // Only ViewPager is moved
                pagerMovementX = movementX;
            } else if (availableViewX + availablePagerX >= movementX) {
                // Moving pager for full available distance and moving view for remaining distance
                pagerMovementX = availablePagerX;
            } else {
                // Moving view for full available distance and moving pager for remaining distance
                pagerMovementX = movementX - availableViewX;
            }

            return pagerMovementX * dir; // Applying direction
        } else {
            return dx;
        }
    }

    /**
     * Manually scrolls ViewPager and returns actual distance at which pager was scrolled.
     */
    private int performViewPagerScroll(@NonNull MotionEvent event, float pagerDx) {
        int scrollBegin = mFlipView.getScrollX();
        lastViewPagerEventX += pagerDx;
        passEventToViewPager(event);
        return scrollBegin - mFlipView.getScrollX();
    }

    private void passEventToViewPager(@NonNull MotionEvent event) {
        if (mFlipView == null) {
            return;
        }

        MotionEvent fixedEvent = obtainOnePointerEvent(event);
        fixedEvent.setLocation(lastViewPagerEventX, 0f);

        if (isViewPagerInterceptedScroll) {
            mFlipView.onTouchEvent(fixedEvent);
        } else {
            isViewPagerInterceptedScroll = mFlipView.onInterceptTouchEvent(fixedEvent);
        }

        fixedEvent.recycle();
    }

    private static MotionEvent obtainOnePointerEvent(@NonNull MotionEvent event) {
        return MotionEvent.obtain(event.getDownTime(), event.getEventTime(), event.getAction(),
                event.getX(), event.getY(), event.getMetaState());
    }

    private static void transformToPagerEvent(MotionEvent event, View view, FlipView flipView) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            matrixTmp.reset();
            transformMatrixToPager(matrixTmp, view, flipView);
            event.transform(matrixTmp);
        } else {
            view.getLocationOnScreen(locationTmp);
            event.offsetLocation(locationTmp[0], locationTmp[1]);
            flipView.getLocationOnScreen(locationTmp);
            event.offsetLocation(-locationTmp[0], -locationTmp[1]);
        }
    }

    /**
     * Inspired by hidden method View#transformMatrixToGlobal().
     */
    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private static void transformMatrixToPager(Matrix matrix, View view, FlipView flipView) {
        View parent = (View) view.getParent();
        if (parent != null && parent != flipView) {
            transformMatrixToPager(matrix, parent, flipView);
        }
        if (parent != null) {
            matrix.preTranslate(-parent.getScrollX(), -parent.getScrollY());
        }

        matrix.preTranslate(view.getLeft(), view.getTop());
        matrix.preConcat(view.getMatrix());
    }

    public void resetStateByChange() {
        stopAllAnimations();
        getState().set(0f,0f,1.0f,0f);
        notifyStateReset();
    }
}
