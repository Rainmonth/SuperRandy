package com.hhdd.kada.main.views;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.drawee.generic.RoundingParams;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.FrescoUtils;

import static com.hhdd.kada.Constants.PAUSE_MODE;
import static com.hhdd.kada.Constants.PLAY_MODE;

/**
 * Created by lj on 2017/5/16.
 */

public class CustomStoryView extends FrameLayout {


    private FrameLayout container;
    private Context mContext;

    public CustomStoryView(@NonNull Context context) {
        this(context, null);
    }

    public CustomStoryView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CustomStoryView(@NonNull Context context, @Nullable AttributeSet attrs, @AttrRes int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        mContext = context;
        init(context);
    }

    ViewGroup mContainer;
    ScaleDraweeView cover;
    ImageView bg, collectionBg;                  // 两个Bg不共存
    ImageView bottomShadow;
    TextView storyTitle;
    ImageView gold_border;
    ImageView serialize;
    ImageView subscribeBorder;


    public void convertToHistoryCustomerView() {
        mContainer.removeAllViews();
        mContainer = (ViewGroup) LayoutInflater.from(mContext).inflate(R.layout.view_custom_story_item_history, this);
        cover = (ScaleDraweeView) mContainer.findViewById(R.id.cover);
        bg = (ImageView) mContainer.findViewById(R.id.bg);
        collectionBg = (ImageView) mContainer.findViewById(R.id.color_bg);
        bottomShadow = (ImageView) mContainer.findViewById(R.id.bottom_shadow);
        storyTitle = (TextView) mContainer.findViewById(R.id.story_title);
    }

    void init(Context mContext) {
        mContainer = (ViewGroup) LayoutInflater.from(mContext).inflate(R.layout.view_custom_story_item, this);
        cover = (ScaleDraweeView) mContainer.findViewById(R.id.cover);
        bg = (ImageView) mContainer.findViewById(R.id.bg);
        collectionBg = (ImageView) mContainer.findViewById(R.id.color_bg);
        bottomShadow = (ImageView) mContainer.findViewById(R.id.bottom_shadow);
        storyTitle = (TextView) mContainer.findViewById(R.id.story_title);
        gold_border = (ImageView) mContainer.findViewById(R.id.gold_border);
        serialize = (ImageView) mContainer.findViewById(R.id.csv_serialize_iv);
        subscribeBorder = (ImageView) mContainer.findViewById(R.id.subscribe_border);
    }

    public void showUrl(String url) {
        String imgUrl = CdnUtils.getImgCdnUrl(url, CdnUtils.getStoryCoverSize(), true);
        FrescoUtils.showImg(cover, imgUrl);
    }

    public void showUrl(String url, int width, int height) {
        String imgUrl = CdnUtils.getImgCdnUrl(url, CdnUtils.getStoryCoverSize(), true);
        FrescoUtils.showImg(cover, imgUrl, width, height);
    }

    public void showUrlWithCdn(String url, int width, int height) {
        FrescoUtils.showImg(cover, url, width, height);
    }

    public void cancelRound() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            RoundingParams roundingParams = cover.getHierarchy().getRoundingParams();
            roundingParams.setBorderWidth(0);
            cover.getHierarchy().setRoundingParams(roundingParams);
        }
    }

    public void cancelCoverHorizontalMargin() {
        FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) cover.getLayoutParams();
        params.setMargins(0, params.topMargin, 0, params.bottomMargin);
        cover.setLayoutParams(params);
        FrameLayout.LayoutParams colorBgParam = (FrameLayout.LayoutParams) collectionBg.getLayoutParams();
        colorBgParam.gravity = Gravity.TOP;
        colorBgParam.setMargins(0, colorBgParam.topMargin, 0, colorBgParam.bottomMargin);
        collectionBg.setLayoutParams(colorBgParam);
    }

    public void setRound() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            RoundingParams roundingParams = cover.getHierarchy().getRoundingParams();
            if (roundingParams != null) {
                roundingParams.setBorderWidth(getResources().getDimension(R.dimen.story_cover_border));
                roundingParams.setBorderColor(Color.WHITE);
            }
            cover.getHierarchy().setRoundingParams(roundingParams);
        }
    }

    public void showBg(int resId) {
//        bg.setImageBitmap(BitmapUtils.readBitMap(mContext,resId));
        bg.setImageResource(resId);
        bg.setVisibility(VISIBLE);
        collectionBg.setVisibility(GONE);
    }

    public void showCollectionBg(int resId) {
        bg.setVisibility(GONE);
        collectionBg.setVisibility(VISIBLE);
    }

    public void setBottomShadow(int drawableResId) {
        bottomShadow.setBackgroundResource(drawableResId);
    }

    public void showBottomShadow() {
        bottomShadow.setVisibility(VISIBLE);
    }

    public void hideBottomShadow() {
        bottomShadow.setVisibility(GONE);
    }

    public void showStoryTitle(String title) {
        if (storyTitle != null && !TextUtils.isEmpty(title)) {
            storyTitle.setVisibility(VISIBLE);
            storyTitle.setText(title);
        }
    }

    public void hideStoryTitle() {
        if (storyTitle != null) {
            storyTitle.setVisibility(GONE);
        }
    }

    public void setStoryTitleHeight(int height) {
        if (storyTitle != null) {
            storyTitle.getLayoutParams().height = height;
        }
    }

    public void setRoundBorderColor(int id) {
        RoundingParams roundingParams = cover.getHierarchy().getRoundingParams();
        roundingParams.setBorderColor(getResources().getColor(id));
        cover.getHierarchy().setRoundingParams(roundingParams);
    }

    public void showGoldBorder(boolean isShow) {
        if (gold_border != null) {
            gold_border.setVisibility(isShow ? VISIBLE : GONE);
        }
    }

    public void showSubscribeBorder(int visible) {
        subscribeBorder.setVisibility(visible);
    }

    public void showSerialize(boolean isShow) {
        if (serialize != null) {
            serialize.setVisibility(isShow ? VISIBLE : GONE);
        }
    }

    public void setPlaceHolder(int id) {
        cover.getHierarchy().setPlaceholderImage(id);
    }

    public void hideAllBg() {
        bg.setVisibility(GONE);
        collectionBg.setVisibility(GONE);
    }

    public void hideBg() {
        bg.setVisibility(GONE);
    }

    public void hideCollectionBg() {
        collectionBg.setVisibility(GONE);
    }

    public void hideBgNoMargin() {
        bg.setVisibility(GONE);
        LayoutParams params = (LayoutParams) cover.getLayoutParams();
        params.setMargins(0, 0, 0, 0);
        cover.setLayoutParams(params);
    }

    //因为一种情况会导致bug所以标志过期：界面初始化的过程中调用setMode()，方法内部使用getMeasuredWidth
    //会为0，导致VisualizerView永远展示不出来。
    @Deprecated
    public void setMode(int mode) {
        setMode(mode, -1, -1);
    }

    public void setMode(int mode, int width, int height) {
        VisualizerView mVisualView = null;
        Object o = cover.getTag(R.id.listen_visualview);
        if (o instanceof VisualizerView) {
            mVisualView = (VisualizerView) o;
        }
        if (mode == PLAY_MODE) {
            if (mVisualView == null) {
                mVisualView = new VisualizerView(getContext());
                if (width == -1) {
                    width = cover.getMeasuredWidth() / 2;
                }
                if (height == -1) {
                    height = cover.getMeasuredHeight() / 2;
                }

                FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(width, height);
                params.gravity = Gravity.CENTER;
                mVisualView.setBackgroundResource(R.drawable.round_corner_visual_view);
                mContainer.addView(mVisualView, params);
                cover.setTag(R.id.listen_visualview, mVisualView);
            }
            mVisualView.setVisibility(View.VISIBLE);
            mVisualView.setDrawing(true);
        } else if (mode == PAUSE_MODE) {
            if (mVisualView != null) {
                mVisualView.setDrawing(false);
            }
        } else {
            if (mVisualView != null) {
                mVisualView.setDrawing(false);
                mVisualView.setVisibility(View.GONE);
            }
        }
    }

}
