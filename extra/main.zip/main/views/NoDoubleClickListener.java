package com.hhdd.kada.main.views;

import android.view.View;

/**
 * Created by simon on 7/8/16.
 */
public abstract class NoDoubleClickListener implements View.OnClickListener {

    private static long lastClickTime = 0;
    public static final int MIN_CLICK_DELAY_TIME = 500;

    @Override
    public void onClick(View v) {
        long interval = System.currentTimeMillis() - lastClickTime;
        if (interval > 0 && interval < MIN_CLICK_DELAY_TIME) {
            return;
        }

        lastClickTime = System.currentTimeMillis();
        onNoDoubleClick(v);
    }

    public abstract void onNoDoubleClick(View v);
}
