package com.hhdd.kada.main.views.magicindicator;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;

import com.hhdd.kada.R;

import net.lucode.hackware.magicindicator.FragmentContainerHelper;
import net.lucode.hackware.magicindicator.buildins.UIUtil;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.model.PositionData;

import java.util.List;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/30
 * @describe : com.hhdd.kada.main.views.magicindicator
 */
public class MyPagerIndicator extends View implements IPagerIndicator {

    private Interpolator mStartInterpolator = new LinearInterpolator();
    private Interpolator mEndInterpolator = new LinearInterpolator();

    /**
     * 相对于底部的偏移量，如果你想让直线位于title上方，设置它即可
     */
    private float mYOffset;
    private float mDrawableHeight;
    private float mXOffset;
    private float mDrawableWidth;

    private Paint mPaint;
    private List<PositionData> mPositionDataList;
    private Drawable mLeftDrawable;
    private Drawable mRightDrawable;
    private Drawable mDrawable;
    private float lastValue;

    private Rect mDrawableRect = new Rect();

    public MyPagerIndicator(Context context) {
        super(context);
        init(context);
    }

    private void init(Context context) {
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mPaint.setStyle(Paint.Style.FILL);
        mDrawableHeight = UIUtil.dip2px(context, 13);
        mDrawableWidth = UIUtil.dip2px(context, 21);
        mLeftDrawable = getResources().getDrawable(R.drawable.icon_indicator_drawable_left);
        mRightDrawable = getResources().getDrawable(R.drawable.icon_indicator_drawable_right);
        mDrawable = mRightDrawable;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        mDrawable.draw(canvas);
    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        if (mPositionDataList == null || mPositionDataList.isEmpty()) {
            return;
        }

        if(positionOffset > 0) {
            if (lastValue > positionOffset) {
                // 递减，从右向左滑动  向左
                mDrawable = mLeftDrawable;
            } else if (lastValue < positionOffset) {
                // 递增，从左向右滑动  向右
                mDrawable = mRightDrawable;
            }
        }
        lastValue = positionOffset;

        // 计算锚点位置
        PositionData current = FragmentContainerHelper.getImitativePositionData(mPositionDataList, position);
        PositionData next = FragmentContainerHelper.getImitativePositionData(mPositionDataList, position + 1);

        float leftX = current.mLeft + (current.width() - mDrawableWidth) / 2;
        float nextLeftX = next.mLeft + (next.width() - mDrawableWidth) / 2;
        float rightX = current.mLeft + (current.width() + mDrawableWidth) / 2;
        float nextRightX = next.mLeft + (next.width() + mDrawableWidth) / 2;

        mDrawableRect.left = (int) (leftX + (nextLeftX - leftX) * mStartInterpolator.getInterpolation(positionOffset));
        mDrawableRect.right = (int) (rightX + (nextRightX - rightX) * mEndInterpolator.getInterpolation(positionOffset));
        mDrawableRect.top = (int) (getHeight() - mDrawableHeight - mYOffset);
        mDrawableRect.bottom = (int) (getHeight() - mYOffset);
        mDrawable.setBounds(mDrawableRect);

        invalidate();
    }

    @Override
    public void onPageSelected(int position) {
    }

    @Override
    public void onPageScrollStateChanged(int state) {
    }

    @Override
    public void onPositionDataProvide(List<PositionData> dataList) {
        mPositionDataList = dataList;
    }

    public float getYOffset() {
        return mYOffset;
    }

    public void setYOffset(float yOffset) {
        mYOffset = yOffset;
    }

    public float getXOffset() {
        return mXOffset;
    }

    public void setXOffset(float xOffset) {
        mXOffset = xOffset;
    }

    public Paint getPaint() {
        return mPaint;
    }

    public Interpolator getStartInterpolator() {
        return mStartInterpolator;
    }

    public void setStartInterpolator(Interpolator startInterpolator) {
        mStartInterpolator = startInterpolator;
        if (mStartInterpolator == null) {
            mStartInterpolator = new LinearInterpolator();
        }
    }

    public Interpolator getEndInterpolator() {
        return mEndInterpolator;
    }

    public void setEndInterpolator(Interpolator endInterpolator) {
        mEndInterpolator = endInterpolator;
        if (mEndInterpolator == null) {
            mEndInterpolator = new LinearInterpolator();
        }
    }
}
