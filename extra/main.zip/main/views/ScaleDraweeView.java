package com.hhdd.kada.main.views;

import android.content.Context;
import android.net.Uri;
import android.util.AttributeSet;

import com.facebook.drawee.generic.GenericDraweeHierarchy;
import com.facebook.drawee.view.SimpleDraweeView;

/**
 * Created by simon on 7/8/16.
 */
public class ScaleDraweeView extends SimpleDraweeView {

//    OnClickListener onClickListener;
//    OnClickListener impl = new OnClickListener() {
//        @Override
//        public void onClick(final View view) {
//            ViewHelper.setPivotX(view,0.5f);
//            ViewHelper.setPivotY(view,0.5f);
//            ScaleAnimator scaleAnimator = new ScaleAnimator(0.8f);
//            scaleAnimator.setTarget(view).setDuration(100).animate();
//            scaleAnimator.addAnimatorListener(new AnimatorListenerAdapter() {
//                @Override
//                public void onAnimationEnd(Animator animation) {
//                    super.onAnimationEnd(animation);
//                    if (onClickListener!=null) {
//                        onClickListener.onClick(view);
//                    }
//                }
//            });
//        }
//    };


    public ScaleDraweeView(Context context, GenericDraweeHierarchy hierarchy) {
        super(context, hierarchy);
    }

    public ScaleDraweeView(Context context) {
        super(context);
    }

    public ScaleDraweeView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ScaleDraweeView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public ScaleDraweeView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

//    @Override
//    public void setOnClickListener(OnClickListener l) {
//        onClickListener = l;
//        super.setOnClickListener(impl);
//    }



    @Override
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
    }

}
