package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/**
 * Created by simon on 7/12/16.
 */
public class PlaybackBookPageLayout extends FrameLayout {

    public PlaybackBookPageLayout(Context context) {
        super(context);
    }

    public PlaybackBookPageLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public PlaybackBookPageLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public PlaybackBookPageLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }
}
