package com.hhdd.kada.main.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

import com.hhdd.kada.main.views.animator.ScaleAnimator;

/**
 * Created by simon on 8/24/16.
 */
public class ScaleFrameLayout extends FrameLayout {

    OnClickListener onClickListener;
    OnClickListener impl = new OnClickListener() {
        @Override
        public void onClick(final View view) {
            ScaleAnimator scaleAnimator = new ScaleAnimator(0.8f);
            scaleAnimator.setTarget(view).setDuration(100).animate();
            scaleAnimator.addAnimatorListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    if (onClickListener!=null) {
                        onClickListener.onClick(view);
                    }
                }
            });
        }
    };

    public ScaleFrameLayout(Context context) {
        super(context);
    }

    public ScaleFrameLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ScaleFrameLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public ScaleFrameLayout(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @Override
    public void setOnClickListener(OnClickListener l) {
        onClickListener = l;
        super.setOnClickListener(impl);
    }
}
