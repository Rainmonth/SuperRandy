package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.StoryCollectionInfo;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/1
 * @describe : com.hhdd.kada.main.views
 */
public class PayExcellentStoryMoreItemView extends BasePayExcellentMoreItemView<StoryCollectionInfo> {

    @BindView(R.id.storyItemView)
    StoryItemView storyItemView;

    public PayExcellentStoryMoreItemView(Context context) {
        super(context);
    }

    public PayExcellentStoryMoreItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_pay_excellent_more_story;
    }

    @Override
    public void update(StoryCollectionInfo data) {
        super.update(data);
        if(data != null){
            storyItemView.update(data);
        }
    }
}
