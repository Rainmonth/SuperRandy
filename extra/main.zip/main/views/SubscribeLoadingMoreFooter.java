package com.hhdd.kada.main.views;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import com.hhdd.core.service.UserHabitService;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.android.library.views.loadmore.LoadMoreContainer;
import com.hhdd.kada.android.library.views.loadmore.LoadMoreDefaultFooterView;
import com.hhdd.kada.main.common.FragmentUtil;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.UpdateMainTabEvent;
import com.hhdd.kada.main.ui.dialog.ChildrenLockDialog;
import com.hhdd.kada.main.ui.fragment.MotherBookFragment;
import com.hhdd.kada.main.ui.story.MotherStoryFragment;
import com.hhdd.kada.main.utils.TimeUtil;
import com.hhdd.kada.record.callback.ChildrenDialogCallback;

/**
 * Created by sxh on 2017/8/2.
 */

public class SubscribeLoadingMoreFooter extends LoadMoreDefaultFooterView {

    private int type;
    public static final int TYPE_BOOK = 0;
    public static final int TYPE_STORY = 1;
    public static final String[] TRACK_ARR = {"child_book_home_bottom_click", "child_story_home_bottom_click"};
    public static final String[] TRACK_VIEW = {"child_book_home_back_bottom_view","child_story_home_back_bottom_view"};

    public SubscribeLoadingMoreFooter(Context context) {
        super(context);
    }

    public SubscribeLoadingMoreFooter(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SubscribeLoadingMoreFooter(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public void onLoadFinish(LoadMoreContainer container, boolean empty, boolean hasMore) {
        if (!hasMore) {
            setVisibility(VISIBLE);
            layout.setPadding(0, 0, 0, LocalDisplay.dp2px(30));
            mImageView.setVisibility(GONE);
            if (empty) {
                mTextView.setText(com.hhdd.kada.android.library.R.string.cube_views_load_more_loaded_empty);
            } else {
                mTextView.setText("想要更多内容，快请妈妈帮你订阅哦");
                mButton.setVisibility(VISIBLE);

                String track = type == TYPE_BOOK || type == TYPE_STORY ? TRACK_VIEW[type] : "";
                UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", track, TimeUtil.currentTime()));

//                addOnAttachStateChangeListener(new OnAttachStateChangeListener() {
//                    @Override
//                    public void onViewAttachedToWindow(View v) {
//
//                    }
//
//                    @Override
//                    public void onViewDetachedFromWindow(View v) {
//
//                    }
//                });
                setButtonClickListener(new OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(getContext() == null){
                            return;
                        }
                        if(getContext() instanceof Activity){
                            if(((Activity) getContext()).isFinishing()){
                                return;
                            }
                        }
                        String track = type == TYPE_BOOK || type == TYPE_STORY ? TRACK_ARR[type] : "";
                        UserHabitService.getInstance().trackHabit(UserHabitService.newUserHabit("", track, TimeUtil.currentTime()));
                        ChildrenLockDialog dialog = new ChildrenLockDialog(getContext());
                        dialog.setCallback(new ChildrenDialogCallback() {
                            @Override
                            public void onAnswerRight() {
                                if (type==TYPE_BOOK){
                                    FragmentUtil.pushFragment(MotherBookFragment.class, null, true);
                                }else if(type==TYPE_STORY){
                                    FragmentUtil.pushFragment(MotherStoryFragment.class, null, true);
                                }
                            }
                            @Override
                            public void onDirectDismiss() {

                            }
                        });
                        dialog.show();
                    }
                });
            }
        } else {
            setVisibility(INVISIBLE);
        }
    }

}
