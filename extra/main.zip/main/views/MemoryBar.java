package com.hhdd.kada.main.views;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;

import com.hhdd.kada.R;

/**
 * Created by zhengkaituo on 16/2/18.
 */
public class MemoryBar extends View {


    private Paint bottompaint;
    private Paint firstcolorpaint;
    private Paint secondcolorpaint;
    private TextPaint textPaint;
    private Paint bitmappaint;
    private RectF mBottomRect, mFirstRect, mSecondRect;
    private int defaultmarginleft ;
    private int defaultmargintop;
    private int defaultbitmapwidth ;
    float bookSize = 0;
    float listenSize = 0;
    float availableSize = 0;


    public MemoryBar(Context context) {
        super(context);
    }

    public MemoryBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public MemoryBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }


    void init() {
        textPaint = new TextPaint();
        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(getResources().getDimension(R.dimen.offline_memory_text_size));
        textPaint.setAntiAlias(true);

        bottompaint = new Paint();
//        bottompaint.setShadowLayer(10, 3, 3, Color.DKGRAY);
        bottompaint.setColor(Color.GREEN);
        bottompaint.setAntiAlias(true);

        firstcolorpaint = new Paint();
//        firstcolorpaint.setShadowLayer(10, 3, 3, Color.DKGRAY);
        firstcolorpaint.setColor(Color.GREEN);
        firstcolorpaint.setAntiAlias(true);

        secondcolorpaint = new Paint();
//        secondcolorpaint.setShadowLayer(10, 3, 3, Color.DKGRAY);
        secondcolorpaint.setColor(Color.YELLOW);
        secondcolorpaint.setAntiAlias(true);

        bitmappaint = new Paint();
        bitmappaint.setAntiAlias(true);
        bitmappaint.setFilterBitmap(true);

        defaultbitmapwidth = (int) getResources().getDimension(R.dimen.offline_memory_bitmap_size);
        defaultmarginleft = (int) getResources().getDimension(R.dimen.offline_memory_margin_left);
        defaultmargintop = (int) getResources().getDimension(R.dimen.offline_memory_margin_top);
    }


    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

    }


    public void setProgress(long booksM, long listenM, long availableSizeM) {
        bookSize = booksM;
        listenSize = listenM;
        availableSize = availableSizeM;
        postInvalidate();
    }

    int drawIcon(Canvas canvas, Bitmap bitmap, String typesize, int marginleft) {
        Rect mSrcRect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
        Rect mDecRect = new Rect(marginleft, getMeasuredHeight() / 4 + 20, marginleft + defaultbitmapwidth, getMeasuredHeight() / 4 + 20 + defaultbitmapwidth);
        canvas.drawBitmap(bitmap, mSrcRect, mDecRect, bitmappaint);
//        canvas.drawText(typesize, marginleft + 2 * defaultbitmapwidth, getMeasuredHeight() / 4 + 20, textcolorpaint);

        Paint pFont = new Paint();
        Rect rect = new Rect();
        textPaint.getTextBounds(typesize, 0, typesize.length(), rect);
        int width = (int)(1.3F*typesize.length()+0.5+rect.width());

        StaticLayout layout = new StaticLayout(typesize, textPaint, width,
                Layout.Alignment.ALIGN_NORMAL, 1.3F, 0.0F, true);
        canvas.save();
        canvas.translate(marginleft + defaultbitmapwidth + 20, getMeasuredHeight() / 4 + 20);
        layout.draw(canvas);
        canvas.restore();//别忘了restore
        return defaultbitmapwidth+20+width;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int sc = canvas.saveLayer(0, 0, getWidth(), getHeight(), null, Canvas.MATRIX_SAVE_FLAG | Canvas.CLIP_SAVE_FLAG
                | Canvas.HAS_ALPHA_LAYER_SAVE_FLAG
                | Canvas.FULL_COLOR_LAYER_SAVE_FLAG
                | Canvas.CLIP_TO_LAYER_SAVE_FLAG);

        mBottomRect = new RectF(defaultmarginleft, defaultmargintop, getMeasuredWidth() - defaultmarginleft, getMeasuredHeight() / 4);
        Bitmap totle = BitmapFactory.decodeResource(getResources(),
                R.drawable.disk_total);
        canvas.drawBitmap(totle, new Rect(0, 0, totle.getWidth(), totle.getHeight()), mBottomRect, bitmappaint);

        float totalSize = bookSize+listenSize+availableSize;


        if (listenSize>0&&totalSize>0) {
            int bookRight = 0;
            if(bookSize >0){
                bookRight = (int)(defaultmarginleft+(getMeasuredWidth()-2*defaultmarginleft) * (bookSize/totalSize));
                if (bookRight-defaultmarginleft < (getMeasuredWidth()-2*defaultmarginleft) /10.0f){
                    bookRight = (int) ((getMeasuredWidth()-2*defaultmarginleft) /10.0f);
                }
            }

            int right = (int)(defaultmarginleft+(getMeasuredWidth()-2*defaultmarginleft) * (listenSize/totalSize));
            if(bookRight != 0){
                right = right + bookRight;
            }
            if(right - defaultmarginleft < (getMeasuredWidth()-2*defaultmarginleft) /5.0f){
                right = (int) ((getMeasuredWidth()-2*defaultmarginleft) /5.0f);
            }
            mSecondRect = new RectF(defaultmarginleft, defaultmargintop, right, getMeasuredHeight() / 4);
            canvas.drawRoundRect(mSecondRect, 10, 10, secondcolorpaint);
        }

        mFirstRect=null;
        if (bookSize>0&&totalSize>0) {
            int right = (int)(defaultmarginleft+(getMeasuredWidth()-2*defaultmarginleft) * (bookSize/totalSize));
            if (right-defaultmarginleft < (getMeasuredWidth()-2*defaultmarginleft) /10.0f){
                right = (int) ((getMeasuredWidth()-2*defaultmarginleft) /10.0f);
            }
            mFirstRect = new RectF(defaultmarginleft, defaultmargintop, right, getMeasuredHeight() / 4);
//        canvas.drawRoundRect(mBottomRect, 10, 10, bottompaint);
            canvas.drawRoundRect(mFirstRect, 10, 10, firstcolorpaint);
        }


        int marginLeftTemp = defaultmarginleft;
        if (bookSize>0) {
            Bitmap mBookicon = BitmapFactory.decodeResource(getResources(), R.drawable.offline_book);
            String size ;
            if(bookSize >1024){
                size = ((int)(bookSize/1024*100))/100.0f +"G";
            }else{
                size = bookSize +"M";
            }
            int ret = drawIcon(canvas, mBookicon, "绘本 \n" + size, marginLeftTemp);
            marginLeftTemp+=ret;
        }

        if (listenSize>0) {
            marginLeftTemp += 25;
            Bitmap mListenicon = BitmapFactory.decodeResource(getResources(), R.drawable.offline_story);
//            drawIcon(canvas, mListenicon, "听书\n" + (int) listenSize + "M", (int) ((getMeasuredWidth() - defaultmarginleft) * (bookSize / totalSize)) - defaultbitmapwidth);
            String size ;
            if(listenSize >1024){
                size = ((int)(listenSize/1024*100))/100.0f +"G";
            }else{
                size = listenSize +"M";
            }
            int ret = drawIcon(canvas, mListenicon, "听书 \n" + size, marginLeftTemp);
            marginLeftTemp+=ret;
        }

        if (availableSize>0) {
            marginLeftTemp += 25;
            Bitmap mTotalicon = BitmapFactory.decodeResource(getResources(), R.drawable.disk_icon);
//            drawIcon(canvas, mTotalicon, "剩余" + (int) totalSize + "M", getMeasuredWidth() - defaultmarginleft - 220);
            String size ;
            if(availableSize >1024){
                size = ((int)(availableSize/1024*100))/100.0f +"G";
            }else{
                size = availableSize +"M";
            }
            int ret = drawIcon(canvas, mTotalicon, "剩余 \n" + size, marginLeftTemp);
            marginLeftTemp+=ret;
        }

//        canvas.drawBitmap();
        canvas.restoreToCount(sc);

    }

}
