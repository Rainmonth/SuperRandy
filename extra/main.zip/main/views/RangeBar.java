package com.hhdd.kada.main.views;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.utils.BitmapUtils;
import com.hhdd.logger.LogHelper;

public class RangeBar extends View {


    private static final float DEFAULT_TEXT_HEIGHT_DP = 24;
    private static final float DEFAULT_BAR_WEIGHT_PX = 4;
    private static final int DEFAULT_BAR_COLOR = Color.LTGRAY;
    private static final int DEFAULT_THUMB_IMAGE_NORMAL = R.drawable.clock;
    private static final int DEFAULT_BAR_IMAGE = R.drawable.dot;
    private static final float DEFAULT_BAR_TEXT_HEIGHT_SP = 12;


    private static final float DEFAULT_THUMB_RADIUS_DP = 30;

    private int mDefaultWidth = 500;
    private int mDefaultHeight = 100;

    private int mTickCount;
    private float mTextHeightDP = DEFAULT_TEXT_HEIGHT_DP;
    private float mBarWeight = DEFAULT_BAR_WEIGHT_PX;
    private int mBarColor = DEFAULT_BAR_COLOR;
    private int mThumbImageNormal = DEFAULT_THUMB_IMAGE_NORMAL;

    private float mThumbRadiusDP = DEFAULT_THUMB_RADIUS_DP;
    private float mBarTextSize = DEFAULT_BAR_TEXT_HEIGHT_SP;
    private int mBarImage = DEFAULT_BAR_IMAGE;

    private int mLeftIndex = 0;
    private int mRightIndex = 1;
    private float mLeftX;
    private float mRightX;

    private boolean isSelected = false;
    private float yPos;
    private float xPos;
    private float startX;

    private Thumb mThumb;
    private Bar mBar;
    private ConnectingLine mConnectingLine;
//    private int[] mColorConnectLine;
    private String[] mBarTextArray;
    private boolean mChecked = false;//无限制是否勾选
    private int mTime = 15;//阅读时长

    public RangeBar(Context context) {
        super(context);
    }

    public RangeBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        Init(context, attrs);
    }

    public RangeBar(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        Init(context, attrs);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width;
        int height;

        final int measureWidthMode = MeasureSpec.getMode(widthMeasureSpec);
        final int measureHeightMode = MeasureSpec.getMode(heightMeasureSpec);
        final int measureWidth = MeasureSpec.getSize(widthMeasureSpec);
        final int measureHeight = MeasureSpec.getSize(heightMeasureSpec);

        if (measureWidthMode == MeasureSpec.AT_MOST) {
            width = measureWidth;
        } else if (measureWidthMode == MeasureSpec.EXACTLY) {
            width = measureWidth;
        } else {
            width = mDefaultWidth;
        }
        float compare_height = Math.max(mTextHeightDP, mThumbRadiusDP);

        if (measureHeightMode == MeasureSpec.AT_MOST) {
            height = Math.min(mDefaultHeight, measureHeight)
                    + (int) (compare_height + mBarTextSize * 2f);
        } else if (measureHeightMode == MeasureSpec.EXACTLY) {
            height = measureHeight + (int) (compare_height + mBarTextSize * 2f);
        } else {
            height = mDefaultHeight + (int) (compare_height + mBarTextSize * 2f);
        }

        setMeasuredDimension(width, height);

    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        final Context ctx = getContext();

        yPos = h / 2f;


        mThumb = new Thumb(ctx, yPos, mThumbRadiusDP, mThumbImageNormal,mTextHeightDP,mBarTextSize);

        final float marginLeft = Math.max(mThumb.getHalfWidth(),3.0f*mBarTextSize);
        final float barLength = w - 2 * marginLeft;
        mLeftX = marginLeft;
        mRightX = mLeftX+barLength;

        mBar = new Bar(ctx, marginLeft, yPos, barLength, mTickCount,
                mTextHeightDP, mBarWeight, mBarColor, mBarImage, mBarTextSize,
                mBarTextArray);


        mConnectingLine = new ConnectingLine(ctx, yPos, mBarWeight);

        xPos = startX  = marginLeft + (mLeftIndex / (float) (mTickCount - 1))
                * barLength;
        if(mTime>15){
            xPos  = (float) ((mTime-15)/75.0 *barLength +mLeftX);
        }
        mThumb.setX(xPos);


    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mTime = Math.round((xPos - mLeftX) / (mRightX - mLeftX) * 75) + 15;
        mConnectingLine.setChecked(mChecked);
        mThumb.setUseColor(mChecked);
        mBar.setChecked(mChecked);
        mConnectingLine.draw(canvas, startX, mThumb);
        mBar.draw(canvas, xPos);
        mThumb.draw(canvas,mTime);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        if (!isEnabled()) {
            return false;
        }
//        if (mChecked){
//            return false;
//        }

        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                xPos = event.getX();
                // onActionDown(event.getX(), event.getY());
                if (mThumb.isInTargetZone(event.getX(), event.getY())) {

                    pressThumb(mThumb);

                } else {
                    isSelected = true;
                    moveThumb(mThumb, event.getX(), yPos);
//                    final int newLeftIndex = mLeftIndex;
//                    final int newRightIndex = mBar.getNearestTickIndex(mThumb);
//                    if (newLeftIndex != mLeftIndex || newRightIndex != mRightIndex) {
//
//                        mLeftIndex = newLeftIndex;
//                        mRightIndex = newRightIndex;
//
//                    }
                    this.getParent().requestDisallowInterceptTouchEvent(true);
                }
                return true;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                this.getParent().requestDisallowInterceptTouchEvent(false);
                releaseThumb(mThumb);
                return true;

            case MotionEvent.ACTION_MOVE:
                xPos = event.getX();
                moveThumb(mThumb, event.getX(), event.getY());

                final int newLeftIndex = mLeftIndex;
                final int newRightIndex = mBar.getNearestTickIndex(mThumb);

                if (newLeftIndex != mLeftIndex || newRightIndex != mRightIndex) {

                    mLeftIndex = newLeftIndex;
                    mRightIndex = newRightIndex;

                }
                this.getParent().requestDisallowInterceptTouchEvent(true);
                return true;

            default:
                return false;
        }
    }

    private void Init(Context context, AttributeSet attrs) {
        TypedArray a = context.obtainStyledAttributes(attrs,
                R.styleable.RangeBar, 0, 0);

        int tickCount = a.getInteger(R.styleable.RangeBar_tickCount, 0);

        if (isValidTickCount(tickCount)) {
            mTickCount = tickCount;
            mLeftIndex = 0;
            mRightIndex = mTickCount - 1;
        } else {
            LogHelper.e("RangeBar", "tickCount less than 2;");
        }

        mTextHeightDP = a.getDimension(R.styleable.RangeBar_textHeight,
                TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                        DEFAULT_BAR_TEXT_HEIGHT_SP, getResources()
                                .getDisplayMetrics()));
        mBarWeight = a.getDimension(R.styleable.RangeBar_barWeight,
                TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                        DEFAULT_BAR_WEIGHT_PX, getResources()
                                .getDisplayMetrics()));
        mBarColor = a
                .getColor(R.styleable.RangeBar_barColor, DEFAULT_BAR_COLOR);
        mBarTextArray = a.getResources().getStringArray(R.array.time);
        mBarTextSize = a.getDimension(R.styleable.RangeBar_textSize,
                TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP,
                        DEFAULT_BAR_TEXT_HEIGHT_SP, getResources()
                                .getDisplayMetrics()));
        mBarImage = a.getResourceId(R.styleable.RangeBar_barImage,
                DEFAULT_BAR_IMAGE);

//		mConnectingLineColor = a.getColor(
//				R.styleable.RangeBar_connectingLineColor,
//				DEFAULT_CONNECTING_LINE_COLOR);
        mThumbRadiusDP = a.getDimension(R.styleable.RangeBar_thumbRadius,
                TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                        DEFAULT_THUMB_RADIUS_DP, getResources()
                                .getDisplayMetrics()));
        mThumbImageNormal = a.getResourceId(R.styleable.RangeBar_thumbImage,
                DEFAULT_THUMB_IMAGE_NORMAL);

        a.recycle();
    }

    private boolean isValidTickCount(int tickCount) {
        return true;
    }

    private void pressThumb(Thumb thumb) {

        if (isSelected == false)
            isSelected = true;
//            invalidate();
    }

    private void releaseThumb(Thumb thumb) {
        if (isSelected == true) {
            isSelected = false;
        }
//		final float nearestTickX = mBar.getNearestTickCoordinate(thumb);
//		thumb.setX(nearestTickX);
        xPos = thumb.getX();
        invalidate();

    }

    private void moveThumb(Thumb thumb, float x, float y) {

        if (x < mBar.getLeftX() || x > mBar.getRightX()) {

        } else {
            if (isSelected == true) {
                thumb.setX(x);
                if(getChecked()){
                    setChecked(false);
                    if(callback != null){
                        callback.changeSeekBarStatus(false);
                    }
                }
                invalidate();
            }

        }
    }

    ViewCallback callback;

    public void setCallback(ViewCallback callback) {
        this.callback = callback;
    }

    public interface ViewCallback{
        void changeSeekBarStatus(boolean isSelected);
    }

    public void setChecked(boolean checked) {
        mChecked = checked;
    }

    public boolean getChecked(){return mChecked;}

    public int getTime(){
        if(mBar != null)
            return mBar.getmTime();
        else{
            return 15;
        }
    }

    public void setTime(int time){
        mTime = time;
    }

}

class Bar {

    private final Paint mPaint;
    private final Paint mTextPaint;
    private final float mLeftX;
    private final float mRightX;
    private final float mY;

    private int mNumSegments;
    private float mTickDistance;
    private final float mTextHeight;
    private final float mTickStartY;
    private final float mBarWeight;
    private Bitmap mBarImage;
    private String[] mtextArray;
    private boolean mChecked;
    private int mTime;//阅读时长

    Bar(Context ctx, float x, float y, float length, int tickCount,
        float textHeightDP,
        float barWeight,
        int barColor,
        int barImage,
        float textSize,
        String[] textArray
    ) {

        mLeftX = x;
        mRightX = x + length;
        mY = y;

        mNumSegments = tickCount - 1;
        mTickDistance = length / mNumSegments;
        mTextHeight = textHeightDP;
        mTickStartY = mY - mTextHeight;

        mBarWeight = barWeight;

        mPaint = new Paint();
        mPaint.setColor(barColor);
        mPaint.setStrokeWidth(mBarWeight);
        mPaint.setAntiAlias(true);
        mPaint.setAlpha(255);

        mTextPaint = new Paint();
        mTextPaint.setColor(Color.WHITE);
        mTextPaint.setAlpha(255);
        mTextPaint.setTextSize(textSize);
        mTextPaint.setAntiAlias(true);




        mBarImage = ((BitmapDrawable) ctx.getResources().getDrawable(barImage))
                .getBitmap();
        mtextArray = textArray;
    }

    void draw(Canvas canvas, float xPos) {
        ColorMatrix cm = new ColorMatrix();
        ColorMatrixColorFilter f;
        if (mChecked) {
            cm.setSaturation(0.2f);
            f = new ColorMatrixColorFilter(cm);
        } else {
            cm.setSaturation(1);
            f = new ColorMatrixColorFilter(cm);
        }
        mPaint.setColorFilter(f);
        canvas.drawLine(xPos, mY, mRightX, mY, mPaint);
        if(mNumSegments!=-1){

            mTime = Math.round((xPos - mLeftX) / (mRightX - mLeftX) * 75) + 15;


            for (int i = 0; i <= mNumSegments; i++) {
                final float x = i * mTickDistance + mLeftX;
//
                Rect rect = new Rect((int) x - 20, (int) mY - 20, (int) x + 20,
                        (int) mY + 20);
                if(mChecked){
                    canvas.drawBitmap(BitmapUtils.toGrayscale(mBarImage),null,rect,null);
                }else{
                    canvas.drawBitmap(mBarImage, null, rect, null);
                }


//			if(x==xPos){
//				float width = mSelectedTextPaint.getTextSize() * 3;
//				float height = mSelectedTextPaint.getTextSize();
//				canvas.drawText(mtextArray[i], x-width/2, mTickStartY-height/2,
//						mSelectedTextPaint);
//			}else {
                if(i==0&& mTime !=15){
                    float width = mTextPaint.getTextSize() * 3;
                    canvas.drawText(mtextArray[i], x - width / 2, mY +1.5f* mTextHeight,
                            mTextPaint);
                }else if(i==1&& mTime !=90){
                    float width = mTextPaint.getTextSize() *3;
                    canvas.drawText(mtextArray[i], x - width / 2, mY +1.5f* mTextHeight,
                            mTextPaint);
                }

            }
        }
    }

    void setChecked(boolean checked) {
        mChecked = checked;
    }

    float getLeftX() {
        return mLeftX;
    }

    float getRightX() {
        return mRightX;
    }

    float getNearestTickCoordinate(Thumb thumb) {

        final int nearestTickIndex = getNearestTickIndex(thumb);

        final float nearestTickCoordinate = mLeftX
                + (nearestTickIndex * mTickDistance);

        return nearestTickCoordinate;
    }

    int getNearestTickIndex(Thumb thumb) {

        final int nearestTickIndex = (int) ((thumb.getX() - mLeftX + mTickDistance / 2f) / mTickDistance);

        return nearestTickIndex;
    }

    void setTickCount(int tickCount) {

        final float barLength = mRightX - mLeftX;

        mNumSegments = tickCount - 1;
        mTickDistance = barLength / mNumSegments;
    }

    int getmTime(){
        return mTime;
    }
}

class ConnectingLine {


    private final Paint mPaint;

    private final float mConnectingLineWeight;
    private final float mY;
    private boolean mChecked;


    ConnectingLine(Context ctx,
                   float y, float connectingLineWeight) {

        final Resources res = ctx.getResources();

//        mConnectingLineWeight = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
//                                                          connectingLineWeight,
//                                                          res.getDisplayMetrics());
        mConnectingLineWeight = connectingLineWeight;
        // Initialize the paint, set values
        mPaint = new Paint();
        mPaint.setColor(Color.YELLOW);
        mPaint.setStrokeWidth(mConnectingLineWeight);
        mPaint.setAntiAlias(true);

        mY = y;
    }

    public void setConnectLineColor(int color) {
        mPaint.setColor(color);
    }

    public void setChecked(boolean checked) {
        mChecked = checked;
    }

    void draw(Canvas canvas, float startX, Thumb rightThumb) {

        ColorMatrix cm = new ColorMatrix();
        ColorMatrixColorFilter f;
        if (mChecked) {
            cm.setSaturation(0);
            f = new ColorMatrixColorFilter(cm);
        } else {
            cm.setSaturation(1);
            f = new ColorMatrixColorFilter(cm);
        }

        mPaint.setColorFilter(f);

//        int endIndex = 0;
//        for (int i = 0; mBarX[i] < rightThumb.getX(); i++) {
//            endIndex = i + 1;
//        }
//        for (int i = endIndex; i > 0; i--) {
//            mPaint.setColor(mColor[i - 1]);
//            if (i == endIndex) {
//                canvas.drawLine(startX, mY, rightThumb.getX(), mY, mPaint);
//            } else {
//                canvas.drawLine(startX, mY, mBarX[i], mY, mPaint);
//            }
//        }
        canvas.drawLine(startX,mY,rightThumb.getX(),mY,mPaint);
    }
}


class Thumb {


    private final Bitmap mImageNormal;

    private final float mHalfWidthNormal;
    private final float mHalfHeightNormal;

    private final float mY;

    private float mX;

    private Paint mPaintNormal,mSelectedTextPaint;

    private float mThumbRadiusPx;

    private boolean isColor;

    private float mTextHeight;

    Thumb(Context ctx, float y, float thumbRadiusDP, int thumbImageNormal,
          float textSize,float textHeight
    ) {

        final Resources res = ctx.getResources();
        mImageNormal = BitmapFactory.decodeResource(res, thumbImageNormal);
        mThumbRadiusPx = thumbRadiusDP;
//		mThumbRadiusPx = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
//				thumbRadiusDP, res.getDisplayMetrics());

        mPaintNormal = new Paint();
        mPaintNormal.setAntiAlias(true);
        mPaintNormal.setColor(Color.GRAY);

        mSelectedTextPaint = new Paint();
        mSelectedTextPaint.setColor(Color.WHITE);
        mSelectedTextPaint.setAlpha(255);
        mSelectedTextPaint.setTextSize(LocalDisplay.designedDP2px(16));
        mSelectedTextPaint.setAntiAlias(true);

        mHalfHeightNormal = mThumbRadiusPx;
        mHalfWidthNormal = mThumbRadiusPx;

        mTextHeight = textHeight;

        mX = mHalfWidthNormal;
        mY = y;
    }

    float getHalfWidth() {
        return mHalfWidthNormal;
    }

    float getHalfHeight() {
        return mHalfHeightNormal;
    }

    void setX(float x) {
        mX = x;
    }

    float getX() {
        return mX;
    }

    void setUseColor(boolean useColor) {
        isColor = useColor;
    }

    boolean isInTargetZone(float x, float y) {

        if (Math.abs(x - mX) <= mThumbRadiusPx
                && Math.abs(y - mY) <= mThumbRadiusPx) {
            return true;
        }
        return false;
    }

    void draw(Canvas canvas,int time) {

        final Bitmap bitmap = mImageNormal;

        Rect rect = new Rect((int) (mX - 1.1*mThumbRadiusPx),
                (int) (mY - mThumbRadiusPx), (int) (mX + 1.1*mThumbRadiusPx),
                (int) (mY + mThumbRadiusPx));
        if (isColor)
            canvas.drawBitmap(BitmapUtils.toGrayscale(bitmap), null, rect, null);
        else
            canvas.drawBitmap(bitmap, null, rect, null);


        String text =  time + "分钟";
        canvas.drawText(text, mX - (mSelectedTextPaint.getTextSize() * 3) / 2,
                mY - mSelectedTextPaint.getTextSize(), mSelectedTextPaint);
    }

}