package com.hhdd.kada.main.views;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.hhdd.core.service.UserService;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.kada.main.event.LogoutEvent;

import butterknife.BindView;
import butterknife.OnClick;
import de.greenrobot.event.EventBus;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.views
 */
public class MotherHeaderView extends BaseHeaderView {

    @BindView(R.id.headLayout)
    View headLayout;
    @BindView(R.id.orderLayout)
    View orderLayout;
    @BindView(R.id.settingLayout)
    View settingLayout;
    @BindView(R.id.search_text)
    TextView searchText;
    @BindView(R.id.searchLayout)
    View searchLayout;

    public MotherHeaderView(Context context) {
        super(context);
    }

    public MotherHeaderView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_mother_header;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        updateHeadLoginState();
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        EventBus.getDefault().register(this);
        headLayout.setOnClickListener(new OnItemAnimClickListener());
//        shopCartLayout.setOnClickListener(new OnItemAnimClickListener());
        orderLayout.setOnClickListener(new OnItemAnimClickListener());
        settingLayout.setOnClickListener(new OnItemAnimClickListener());
    }

    public void onEvent(UserService.AvatarFetchedEvent event) {
        updateHeadLoginState();
    }

    public void onEvent(UserService.AvatarChangedEvent event) {
        updateHeadLoginState();
    }

    public void onEvent(LoginEvent event) {
        updateHeadLoginState();
//        updateAddShopCartCount();
    }

    public void onEvent(LogoutEvent event) {
        updateHeadLoginState();
//        updateAddShopCartCount();
    }

//    public void onEvent(AddShopCartSuccessEvent event) {
//        updateAddShopCartCount();
//    }
//
//    public void onEvent(ShopCartChangeEvent event) {
//        updateAddShopCartCount();
//    }
//
//    public void onEvent(ShopCartRefreshEvent event) {
//        updateAddShopCartCount();
//    }

    /**
     * 更新购物车数量
     */
//    public void updateAddShopCartCount(){
//        if(UserService.getInstance().isLogining() && !TextUtils.isEmpty(UserService.getInstance().getCurrentUserId())) {
//            SharedPreferences sp = context.getSharedPreferences(UserService.getInstance().getCurrentUserId(),
//                    Context.MODE_PRIVATE);
//            int count = sp.getInt(StoreUtils.ADDSHOPCART_COUNT, 0);
//            unReadCountTextView.setText(String.valueOf(count));
//            unReadCountTextView.setVisibility(count > 0 ? VISIBLE : GONE);
//        }else {
//            unReadCountTextView.setVisibility(GONE);
//        }
//    }


    /**
     * 更新搜索热词
     */
    public void updateSearchText(String popularWord) {
        if (!TextUtils.isEmpty(popularWord)){
            searchText.setText(popularWord);
            searchLayout.setTag(R.id.data, popularWord);
        }

    }


    @OnClick(R.id.searchLayout)
    void onItemClick(View view) {
        onChildViewClick(view, 99);
    }

    class OnItemAnimClickListener extends KaDaApplication.OnClickWithAnimListener {
        @Override
        public void OnClickWithAnim(View v) {
            onChildViewClick(v, 99);
        }
    }

    public void onDestroyView() {
        EventBus.getDefault().unregister(this);
    }

}
