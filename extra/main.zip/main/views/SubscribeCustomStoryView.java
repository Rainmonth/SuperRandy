package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.hhdd.core.db.DatabaseManager;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.db.main.entities.CollectionCountInfo;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.RedirectInfo;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryListItem;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.LocalSubscribeUtil;
import com.hhdd.kada.main.utils.SafeHandler;
import com.hhdd.kada.main.views.base.BaseFrameLayout;
import com.plattysoft.leonids.ParticleSystem;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;

import static com.hhdd.kada.Constants.STOP_MODE;

public class SubscribeCustomStoryView extends BaseFrameLayout {

    @BindView(R.id.custom_story_view)
    CustomStoryView customStoryView;
    @BindView(R.id.subscribe_custom_story_view)
    FrameLayout subscribeCustomStoryView;

    private final int PARTICLE_SYSTEM_COUNT = 4;   //发射器数量
    private final int EMIT_ING_TIME = 1000 * 60 * 60;   //持续发射时间
    private final int PARTICLE_ALIVE_TIME = 800;   //粒子存货时间
    private final int PARTICLES_PER_SECOND = 5;   //每秒钟发射的粒子数量
    private final float SPEED_MIN = 0.01f;   //最小速度
    private final float SPEED_MAX = 0.04f;   //最大速度
    private final int ROTATION_SPEED = 90;   //粒子自身旋转速度

    @BindView(R.id.charge_flag)
    ImageView chargeFlag;
    @BindView(R.id.new_flag)
    ImageView newFlag;
    @BindView(R.id.free_flag)
    ImageView freeFlag;

    private SafeHandler handler;
    private List<ParticleSystem> particleSystemList;
    private ParticleSystemRunnable particleSystemRunnable;

    public SubscribeCustomStoryView(Context context) {
        super(context);
    }

    public SubscribeCustomStoryView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.subscribe_custem_story_view;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        handler = new SafeHandler();
    }

    public void updateView(RedirectInfo info, int width, int height) {
        customStoryView.showUrl(info.getImageUrl());
        //隐藏复用的图标
        chargeFlag.setVisibility(View.GONE);
        newFlag.setVisibility(View.GONE);
        customStoryView.setMode(STOP_MODE, width, height);
        customStoryView.hideCollectionBg();
        customStoryView.hideBottomShadow();
    }

    public void updateView(StoryListItem storyListItem, int width, int height) {
        BaseModel data = storyListItem.getData();
        if (data != null && data instanceof StoryCollectionInfo) {

            final StoryCollectionInfo info = (StoryCollectionInfo) data;

            customStoryView.setPlaceHolder(R.drawable.books_two_square);
            customStoryView.showCollectionBg(R.drawable.bg_story_collect);
            customStoryView.setBottomShadow(R.drawable.bg_shape_story_shelf_item_bottom_shadow);
            customStoryView.showBottomShadow();
            //收费标志和限免标志显示逻辑处理（限免与收费二者互斥）
            long extFlag = info.getExtFlag();
            if ((extFlag & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32) {
                chargeFlag.setVisibility(View.VISIBLE);
                freeFlag.setVisibility(GONE);
            } else if ((extFlag & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL ||         // 全用户限免
                    (extFlag & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW) {            // 新用户限免
                chargeFlag.setVisibility(GONE);
                freeFlag.setVisibility(VISIBLE);
            } else {
                chargeFlag.setVisibility(View.GONE);
                freeFlag.setVisibility(GONE);
            }
            //订阅星星动画
            if (LocalSubscribeUtil.containStorySubscribeId(info.getCollectId())) {
                startSubscribedAnim();
            } else {
                stopSubscribedAnim();
            }
            //我的订阅中 对比之前合集内单本数量 判断是否有更新
            Flowable.create(new QueryCollectionCountInfoFlowableOnSubscribe(info), BackpressureStrategy.BUFFER)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe(new Consumer<CollectionCountInfo>() {
                        @Override
                        public void accept(CollectionCountInfo collectionCountInfo) throws Exception {
                            if (collectionCountInfo != null && collectionCountInfo.getCount() < info.getCurrentCount()) {
                                //显示有更新标志
                                info.setShowNew(true);
                                newFlag.setVisibility(View.VISIBLE);
                            }
                        }
                    });
            String coverUrl = info.getCoverUrl();
            customStoryView.showUrl(coverUrl);
            customStoryView.setRound();
        }
        customStoryView.setMode(storyListItem.getPlayMode(), width, height);
    }

    private static class QueryCollectionCountInfoFlowableOnSubscribe implements FlowableOnSubscribe<CollectionCountInfo> {

        private StoryCollectionInfo mStoryCollectionInfo;

        public QueryCollectionCountInfoFlowableOnSubscribe(StoryCollectionInfo storyCollectionInfo) {
            mStoryCollectionInfo = storyCollectionInfo;
        }

        @Override
        public void subscribe(FlowableEmitter<CollectionCountInfo> e) throws Exception {
            CollectionCountInfo countInfo = DatabaseManager.getInstance().collectionDB().query(mStoryCollectionInfo.getCollectId());
            if (countInfo != null) {
                e.onNext(countInfo);
            } else {
                mStoryCollectionInfo.setShowNew(false);
            }
            e.onComplete();
        }
    }

    public CustomStoryView getCustomStoryView() {
        return customStoryView;
    }

    /**
     * 订阅合辑边缘的星星动画
     */
    public synchronized void startSubscribedAnim() {
        stopSubscribedAnim();
        customStoryView.showSubscribeBorder(View.VISIBLE);
        particleSystemList = new ArrayList<>();
        particleSystemRunnable = new ParticleSystemRunnable(3);
        for (int i = 0; i < PARTICLE_SYSTEM_COUNT; i++) {
            particleSystemRunnable = new ParticleSystemRunnable(i % 4 + 1);
            handler.postDelayed(particleSystemRunnable, i * 200 + 200);
        }

    }

    class ParticleSystemRunnable implements Runnable {

        private int mType;   // 1 往左边发射粒子   2 往上边发射粒子   3 往右边发射粒子  4  往下边发射粒子

        ParticleSystemRunnable(int type) {
            mType = type;
        }

        @Override
        public void run() {
            if (mType == 4) {
                ParticleSystem particleSystem = new ParticleSystem(subscribeCustomStoryView, 100, KaDaApplication.getInstance().getResources().getDrawable(R.drawable.subscribe_star), PARTICLE_ALIVE_TIME)
                        .setSpeedModuleAndAngleRange(SPEED_MIN, SPEED_MAX, 0, 180)
                        .setRotationSpeed(ROTATION_SPEED);
                particleSystem.emitWithGravity(customStoryView, Gravity.BOTTOM, PARTICLES_PER_SECOND, EMIT_ING_TIME);
                particleSystemList.add(particleSystem);
            } else if (mType == 3) {
                ParticleSystem particleSystem = new ParticleSystem(subscribeCustomStoryView, 100, KaDaApplication.getInstance().getResources().getDrawable(R.drawable.subscribe_star), PARTICLE_ALIVE_TIME)
                        .setSpeedModuleAndAngleRange(SPEED_MIN, SPEED_MAX, 270, 90)
                        .setRotationSpeed(ROTATION_SPEED);
                particleSystem.emitWithGravity(customStoryView, Gravity.RIGHT, PARTICLES_PER_SECOND, EMIT_ING_TIME);
                particleSystemList.add(particleSystem);
            } else if (mType == 2) {
                ParticleSystem particleSystem = new ParticleSystem(subscribeCustomStoryView, 100, KaDaApplication.getInstance().getResources().getDrawable(R.drawable.subscribe_star), PARTICLE_ALIVE_TIME)
                        .setSpeedModuleAndAngleRange(SPEED_MIN, SPEED_MAX, 180, 360)
                        .setRotationSpeed(ROTATION_SPEED);
                particleSystem.emitWithGravity(customStoryView, Gravity.TOP, PARTICLES_PER_SECOND, EMIT_ING_TIME);
                particleSystemList.add(particleSystem);
            } else if (mType == 1) {
                ParticleSystem particleSystem = new ParticleSystem(subscribeCustomStoryView, 100, KaDaApplication.getInstance().getResources().getDrawable(R.drawable.subscribe_star), PARTICLE_ALIVE_TIME)
                        .setSpeedModuleAndAngleRange(SPEED_MIN, SPEED_MAX, 90, 270)
                        .setRotationSpeed(ROTATION_SPEED);
                particleSystem.emitWithGravity(customStoryView, Gravity.LEFT, PARTICLES_PER_SECOND, EMIT_ING_TIME);
                particleSystemList.add(particleSystem);
            }
        }
    }

    public synchronized void stopSubscribedAnim() {
        customStoryView.showSubscribeBorder(View.GONE);
        if (handler != null) {
            handler.removeCallbacks(particleSystemRunnable);
        }
        if (particleSystemList == null || particleSystemList.isEmpty()) {
            return;
        }
        for (ParticleSystem particleSystem : particleSystemList) {
            particleSystem.cancel();
        }
    }

}
