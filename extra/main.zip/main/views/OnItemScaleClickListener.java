package com.hhdd.kada.main.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.AdapterView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.main.views.animator.ScaleAnimator;
import com.nineoldandroids.view.ViewHelper;

/**
 * Created by simon on 9/27/16.
 */

public abstract class OnItemScaleClickListener extends KaDaApplication.NoDoubleItemClickListener {

    @Override
    public void onNoDoubleClick(final AdapterView<?> parent, final View view, final int position, final long id) {
        ViewHelper.setPivotY(view, 0.5f);
        ViewHelper.setPivotX(view, 0.5f);
        ScaleAnimator animator = new ScaleAnimator(0.8f);
        animator.setInterpolator(new LinearInterpolator());
        animator.setDuration(100).setTarget(view).start();

        animator.addAnimatorListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                onItemClickScaled(parent, view, position, id);
            }
        });
    }

    public void onItemClickScaled(AdapterView<?> parent, View view, int position, long id) {

    }
}
