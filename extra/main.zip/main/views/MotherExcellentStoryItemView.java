package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.views.base.BaseDataLinearLayout;
import com.hhdd.kada.store.utils.PriceUtil;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.views
 */
public class MotherExcellentStoryItemView extends BaseDataLinearLayout<StoryCollectionInfo> {

    @BindView(R.id.storyItemView)
    StoryItemView storyItemView;
    @BindView(R.id.titleTextView)
    TextView titleTextView;
    @BindView(R.id.descriptionTextView)
    TextView descriptionTextView;
    @BindView(R.id.subscribeCountTextView)
    TextView subscribeCountTextView;
    @BindView(R.id.priceTextView)
    TextView priceTextView;
    int i = 0;

    private StoryCollectionInfo storyCollectionInfo;

    public MotherExcellentStoryItemView(Context context) {
        super(context);
    }

    public MotherExcellentStoryItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_mother_excellent_story;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        setOrientation(VERTICAL);
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        storyItemView.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                if(storyCollectionInfo != null) {
                    onChildViewClick(v, 99, storyCollectionInfo);
                }
            }
        });
    }

    @Override
    public void update(StoryCollectionInfo data) {
        if(data != null){
            this.storyCollectionInfo = data;
            storyItemView.update(data);

            descriptionTextView.setText(data.getRecommend());

//            <!--精简《精选页》1x3 不显示价格和订阅量 by lazy for v3.7 at 2018/5/24 -->
//            titleTextView.setText(data.getName());
//            subscribeCountTextView.setText(data.getSubscribeCount() + "人订阅");
//
//            String priceStr;
//            double price = data.getPrice();
//            if (price <= 0.0) {
//                priceStr = "免费";
//            } else {
//                priceStr = "¥" + PriceUtil.formatPrice(String.valueOf(price));
//            }
//            priceTextView.setText(priceStr);
        }
    }
}
