package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseCollectionInfo;
import com.hhdd.kada.main.views.base.BaseDataLinearLayout;
import com.hhdd.kada.store.utils.PriceUtil;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/1
 * @describe : com.hhdd.kada.main.views
 */
public abstract class BasePayExcellentMoreItemView<T extends BaseCollectionInfo> extends BaseDataLinearLayout<T> {

    @BindView(R.id.titleTextView)
    TextView titleTextView;
    @BindView(R.id.descriptionTextView)
    TextView descriptionTextView;
    @BindView(R.id.countTextView)
    TextView countTextView;
    @BindView(R.id.subscribeCountTextView)
    TextView subscribeCountTextView;
    @BindView(R.id.priceTextView)
    TextView priceTextView;
    @BindView(R.id.subscribeView)
    View subscribeView;

    public BasePayExcellentMoreItemView(Context context) {
        super(context);
    }

    public BasePayExcellentMoreItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public void doInitView() {
        super.doInitView();
        int padding = LocalDisplay.dp2px(10);
        setPadding(padding, padding, padding, padding);
        setOrientation(HORIZONTAL);
    }

    @Override
    public void update(T data) {
        if(data != null){
            String name = data.getName();
            titleTextView.setText(name);
            descriptionTextView.setText(data.getRecommend());
            countTextView.setText("共" + data.getCount() + "本");
            subscribeCountTextView.setText(data.getSubscribeCount() + "人订阅");

            String priceStr;
            double price = data.getPrice();
            if (price <= 0.0) {
                priceStr = "免费";
            } else {
                priceStr = "¥" + PriceUtil.formatPrice(String.valueOf(price));
            }
            priceTextView.setText(priceStr);
            subscribeView.setVisibility(data.getSubscribe() == 1 ? VISIBLE : GONE);
        }
    }
}
