package com.hhdd.kada.main.views;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;
import android.support.annotation.ColorRes;
import android.support.annotation.DrawableRes;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.facebook.drawee.view.SimpleDraweeView;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.model.RedirectPositionSubjectInfo;
import com.hhdd.kada.main.ui.activity.RedirectActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.kada.main.views.base.BaseDataRelativeLayout;

import butterknife.BindView;

/**
 * @autor lazys
 * @created 2018/5/25 10:40
 * @desc 固定标题样式 - 可配置位置
 */
public class ConfigPositionTitleView extends BaseDataRelativeLayout<RedirectPositionSubjectInfo> {

    @BindView(R.id.container)
    RelativeLayout contaienr;

    @BindView(R.id.mid_title_container)
    RelativeLayout midTitleContainer;

    @BindView(R.id.position_iconImageView)
    SimpleDraweeView midTitleIcon;

    @BindView(R.id.position_subject_title)
    TextView midTitle;

    @BindView(R.id.position_subject_sub_title)
    TextView midSubTitle;

    @BindView(R.id.left_title_container)//位置控制部分
            LinearLayout leftTitleContainer;

    @BindView(R.id.position_iconImageView2)
    SimpleDraweeView leftTitleIcon;

    @BindView(R.id.position_subject_title2)
    TextView leftTitle;

    @BindView(R.id.position_subject_sub_title2)
    TextView leftSubTitle;

    @BindView(R.id.more_container)
    LinearLayout moreContainer;

    @BindView(R.id.position_subject_more)
    TextView moreTextView;

    @BindView(R.id.more_icon)
    ImageView moreIcon;

    private RedirectPositionSubjectInfo positionSubjectInfo;
    private boolean isCenter;//默认居左

    public void setCenter(boolean center) {
        isCenter = center;
    }

    public boolean isCenter() {
        return isCenter;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    public ConfigPositionTitleView(Context context) {
        super(context);
    }

    public ConfigPositionTitleView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public void setTitleBackgroundColor(int colorResId) {
        contaienr.setBackgroundColor(KaDaApplication.getInstance().getResources().getColor(colorResId));
    }

    public void isShowLeftTitleIcon(boolean isShowLeftTitleIcon) {
        if (isShowLeftTitleIcon) {
            leftTitleIcon.setVisibility(VISIBLE);
        } else {
            leftTitleIcon.setVisibility(GONE);
        }
    }

    public void isShowMidTitleIcon(boolean isShowMidTitleIcon) {
        if (isShowMidTitleIcon) {
            midTitleIcon.setVisibility(VISIBLE);
        } else {
            midTitleIcon.setVisibility(GONE);
        }
    }

    public void setMidTitleTextColor(@ColorRes int colorResId) {
        midTitle.setTextColor(KaDaApplication.getInstance().getResources().getColor(colorResId));
    }

    public void setMidSubTitleTextColor(@ColorRes int colorResId) {
        midSubTitle.setTextColor(KaDaApplication.getInstance().getResources().getColor(colorResId));
    }

    public void setLeftTitleTextColor(@ColorRes int colorResId) {
        leftTitle.setTextColor(KaDaApplication.getInstance().getResources().getColor(colorResId));
    }

    public void setLeftSubTitleTextColor(@ColorRes int colorResId) {
        leftSubTitle.setTextColor(KaDaApplication.getInstance().getResources().getColor(colorResId));
    }

    public void setMoreTextColor(@ColorRes int colorResId) {
        moreTextView.setTextColor(KaDaApplication.getInstance().getResources().getColor(colorResId));
    }

    public void setMoreContainerBg(@DrawableRes int drawableResId) {
        moreContainer.setBackgroundResource(drawableResId);
    }

    public void setMoreIconImageResource(@DrawableRes int drawableResId) {
        moreIcon.setImageResource(drawableResId);
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    public void update(RedirectPositionSubjectInfo data) {
        if (null == data)
            return;

        positionSubjectInfo = data;

        //采用以下注释的方式刷新时UI会异常
//        RelativeLayout.LayoutParams layoutParams = (RelativeLayout.LayoutParams) midTitleContainer.getLayoutParams();
//        layoutParams.addRule(isCenter ? RelativeLayout.CENTER_IN_PARENT : RelativeLayout.ALIGN_PARENT_LEFT, TRUE);
//                titleContentLinearLayout.setGravity(isCenter ? Gravity.CENTER : Gravity.LEFT);
//                midTitleContainer.getParent().requestLayout();

//

        if (isCenter) {
            midTitleContainer.setVisibility(View.VISIBLE);
            leftTitleContainer.setVisibility(View.GONE);

            midTitle.setText(data.getTitle());
            midSubTitle.setText(data.getSubTitle());

            String imgUrl = CdnUtils.getImgCdnUrl(data.getImageUrl());
            FrescoUtils.showImg(midTitleIcon, imgUrl);
        } else {
            midTitleContainer.setVisibility(View.GONE);
            leftTitleContainer.setVisibility(View.VISIBLE);

            leftTitle.setText(data.getTitle());
            leftSubTitle.setText(data.getSubTitle());

            String imgUrl = CdnUtils.getImgCdnUrl(data.getImageUrl());
            FrescoUtils.showImg(leftTitleIcon, imgUrl);
        }


        boolean isKADAProtocol = !TextUtils.isEmpty(data.getRedirectUri())
                && data.getRedirectUri().startsWith("kada://")
                ? true : false;
        moreContainer.setVisibility(isKADAProtocol ? View.VISIBLE : View.GONE);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_config_position_title_view;
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        moreContainer.setOnClickListener(new KaDaApplication.OnClickWithAnimListener() {
            @Override
            public void OnClickWithAnim(View v) {
                RedirectActivity.startActivity(context, positionSubjectInfo);
            }
        });
    }
}
