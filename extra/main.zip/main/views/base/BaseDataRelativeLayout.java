package com.hhdd.kada.main.views.base;

import android.content.Context;
import android.util.AttributeSet;

public abstract class BaseDataRelativeLayout<T> extends BaseRelativeLayout {
    public BaseDataRelativeLayout(Context context) {
        super(context);
    }

    public BaseDataRelativeLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public abstract void update(T data);
}
