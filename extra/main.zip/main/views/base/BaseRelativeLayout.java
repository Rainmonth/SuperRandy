package com.hhdd.kada.main.views.base;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;

import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.listener.OnInitListener;

import butterknife.ButterKnife;

public abstract class BaseRelativeLayout extends RelativeLayout implements OnInitListener {
    protected OnChildViewClickListener onChildViewClickListener;
    protected Context context;


    public void setOnChildViewClickListener(OnChildViewClickListener onChildViewClickListener) {
        this.onChildViewClickListener = onChildViewClickListener;
    }

    protected void onChildViewClick(View childView, int action, Object obj) {
        if (onChildViewClickListener != null) {
            onChildViewClickListener.onChildViewClick(childView, action, obj);
        }
    }

    protected void onChildViewClick(View childView, int action) {
        onChildViewClick(childView, action, null);
    }


    public BaseRelativeLayout(Context context) {
        super(context);
        init(context, null);
    }

    public BaseRelativeLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }
    protected View rootView;
    protected void init(Context context, AttributeSet attrs) {
        this.context = context;
        if (getLayoutId() != 0) {
            rootView= LayoutInflater.from(context).inflate(getLayoutId(), this, true);
            //LayoutParams layoutParams = new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
            //addView(view,layoutParams);
            if (rootView != null) {
                ButterKnife.bind(this, rootView);
            }
            if (attrs != null) {
                initAttributeSet(attrs);
            }
        }
        doInitView();
        doInitListener();
        doInitData();
    }

    protected void initAttributeSet(AttributeSet attrs) {

    }

    @Override
    public void doInitView() {

    }

    @Override
    public void doInitListener() {

    }

    @Override
    public void doInitData() {

    }
}
