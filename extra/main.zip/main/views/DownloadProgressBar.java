package com.hhdd.kada.main.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import com.hhdd.kada.R;
import com.hhdd.logger.LogHelper;


/**
 * Created by zhengkaituo on 16/2/23.
 */
public class DownloadProgressBar extends View {

    public DownloadProgressBar(Context context) {
        super(context);
    }

    public DownloadProgressBar(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public DownloadProgressBar(Context context, AttributeSet attr, int defStyle) {
        super(context, attr, defStyle);
        init();
    }

    Paint finishPaint;
    Paint startPaint;
    Paint processPaint;
    Paint textPaint;
//    Bitmap bitmap;
    boolean isDownload;
    int downloadState;
    float process = 0;
    int leftpadding = 0;
    int toppadding = 15;
    int round;
    private android.os.Handler mHandler;
    private PorterDuffXfermode mPorterDuffXfermode;
    static int NO_DOWNLOADING = 1;
    static int START_LOADINGDATA = 2;
    static int START_DOWNLOADING = 3;
    static int FINISH_DOWNLOADING = 4;
    static int UNCOMPLETE_DOWNLOADING = 5;
    ProgressFinishedListener listener;
    private Rect mMaskSrcRect, mMaskDestRect;
    private String state_text;

    int uncompleteDownloadCount = 0;


    void init() {
        finishPaint = new Paint();
        finishPaint.setAntiAlias(true);
//        finishPaint.setColor(Color.argb(255, 255, 215, 0));
        finishPaint.setColor(Color.parseColor("#37e6fe"));

        startPaint = new Paint();
        startPaint.setAntiAlias(true);
        startPaint.setColor(Color.DKGRAY);
        startPaint.setAlpha(100);

        processPaint = new Paint();
        processPaint.setAntiAlias(true);
        processPaint.setColor(Color.GREEN);
        processPaint.setFilterBitmap(true);

        textPaint = new Paint();
        textPaint.setColor(Color.WHITE);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setStrokeWidth(3);
        textPaint.setTextSize(getResources().getDimension(R.dimen.offline_text_size));
        textPaint.setAntiAlias(true);
        isDownload = false;
        mPorterDuffXfermode = new PorterDuffXfermode(PorterDuff.Mode.SRC_IN);

        mHandler = new Handler() {
            @Override
            public void handleMessage(android.os.Message msg) {
                if (msg.what == 0) {
                    process++;
                    LogHelper.d("curprocess", process + "");
                    if (process < 101) {
                        invalidate();
                    } else {
                        downloadState = FINISH_DOWNLOADING;
                    }
                    if (downloadState == START_DOWNLOADING) {
                        // 不断发消息给自己，使自己不断被重绘
                        mHandler.sendEmptyMessageDelayed(0, 60L);
                    } else {
                        getHandler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                invalidate();
                            }
                        }, 500);
                        mHandler.removeMessages(0);
                        process = 0;
                        if (listener != null)
                            listener.onFinished();
                    }
                }
            }
        };

        round = (int) getResources().getDimension(R.dimen.offline_round);
    }

    public void setNoDownloading() {
        downloadState = NO_DOWNLOADING;
        postInvalidate();
    }

    public void setStartLoadingData() {
        this.process = 0;
        downloadState = START_LOADINGDATA;
        postInvalidate();
    }

    public void setStartDownloading() {
        downloadState = START_DOWNLOADING;
        postInvalidate();
    }

    public void setFinishDownloading() {
        this.process = 100;
        downloadState = FINISH_DOWNLOADING;
        postInvalidate();
    }

    public void setProcess(long process) {
        this.process = process;
        downloadState = START_DOWNLOADING;
        postInvalidate();
    }

    public void setUncompleteDownloading(int uncompleteDownloadCount) {
        this.uncompleteDownloadCount = uncompleteDownloadCount;
        downloadState = UNCOMPLETE_DOWNLOADING;
        postInvalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int sc = canvas.saveLayer(0, 0, getWidth(), getHeight(), null, Canvas.MATRIX_SAVE_FLAG | Canvas.CLIP_SAVE_FLAG
                | Canvas.HAS_ALPHA_LAYER_SAVE_FLAG
                | Canvas.FULL_COLOR_LAYER_SAVE_FLAG
                | Canvas.CLIP_TO_LAYER_SAVE_FLAG);
        RectF bgRect = new RectF(leftpadding, toppadding, getMeasuredWidth() - leftpadding, getMeasuredHeight() - toppadding);

        RectF processRect = new RectF(leftpadding, toppadding, leftpadding + (getMeasuredWidth() - 2 * leftpadding) * (process / 100), getMeasuredHeight() - toppadding);
        canvas.drawRoundRect(bgRect, round, round, finishPaint);
        Paint.FontMetricsInt fontMetrics = textPaint.getFontMetricsInt();
        float baseline = (bgRect.bottom + bgRect.top - fontMetrics.bottom - fontMetrics.top) / 2;
        canvas.drawRoundRect(bgRect, round, round, finishPaint);

        if (downloadState == START_DOWNLOADING||downloadState==START_LOADINGDATA) {
            canvas.drawRoundRect(bgRect, round, round, startPaint);
            processPaint.setXfermode(mPorterDuffXfermode);

            //设置进度条的颜色
            canvas.drawRect(processRect, processPaint);
//            canvas.drawBitmap(bitmap,mMaskSrcRect,processRect,processPaint);
            processPaint.setXfermode(null);
            if (downloadState == START_LOADINGDATA) {
                canvas.drawText("正在获取数据...", bgRect.centerX(), baseline, textPaint);
            } else {
                long tempProcess = (long)process;
                canvas.drawText("正在下载("+tempProcess+"%)", bgRect.centerX(), baseline, textPaint);
            }
        } else if (downloadState==UNCOMPLETE_DOWNLOADING) {
            canvas.drawText("继续未完成下载("+uncompleteDownloadCount+")", bgRect.centerX(), baseline, textPaint);
        } else {
            canvas.drawText("开始下载", bgRect.centerX(), baseline, textPaint);
        }

        canvas.restoreToCount(sc);


    }

    public void startDownload() {
        if (downloadState == START_DOWNLOADING) {
//            downloadState = NO_DOWNLOADING;
//            process = 0;
//            this.mHandler.removeMessages(0);
//            postInvalidate();
        } else {
            downloadState = START_DOWNLOADING;
            this.mHandler.sendEmptyMessage(0);
        }

    }


    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        // 关闭硬件加速，防止异常unsupported operation exception
        this.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.mHandler.removeMessages(0);
    }


    public void setProgressFinishedListener(ProgressFinishedListener listener) {
        this.listener = listener;
    }

    public interface ProgressFinishedListener {
        void onFinished();
    }


}

