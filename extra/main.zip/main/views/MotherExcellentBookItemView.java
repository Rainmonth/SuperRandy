package com.hhdd.kada.main.views;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.main.listener.OnChildViewClickListener;
import com.hhdd.kada.main.model.BookCollectionInfo;
import com.hhdd.kada.main.views.base.BaseDataLinearLayout;
import com.hhdd.kada.store.utils.PriceUtil;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/31
 * @describe : com.hhdd.kada.main.views
 */
public class MotherExcellentBookItemView extends BaseDataLinearLayout<BookCollectionInfo> {

    @BindView(R.id.bookInfoView)
    BookCollectionInfoView bookCollectionInfoView;
    @BindView(R.id.subscribeCountTextView)
    TextView subscribeCountTextView;
    @BindView(R.id.priceTextView)
    TextView priceTextView;

    public MotherExcellentBookItemView(Context context) {
        super(context);
    }

    public MotherExcellentBookItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_mother_excellent_book;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        setOrientation(VERTICAL);
    }

    @Override
    public void doInitListener() {
        super.doInitListener();
        bookCollectionInfoView.setOnChildViewClickListener(new OnChildViewClickListener() {
            @Override
            public void onChildViewClick(View childView, int action, Object obj) {
                MotherExcellentBookItemView.super.onChildViewClick(childView, action, obj);
            }
        });
    }

    @Override
    public void update(BookCollectionInfo data) {
        if(data != null){
            bookCollectionInfoView.update(data);

//            <!--精简《精选页》1x3 不显示价格和订阅量 by lazy at 2018/5/24 for v3.7-->
//            subscribeCountTextView.setText(data.getSubscribeCount() + "人订阅");
//
//            String priceStr;
//            double price = data.getPrice();
//            if (price <= 0.0) {
//                priceStr = "免费";
//            } else {
//                priceStr = "¥" + PriceUtil.formatPrice(String.valueOf(price));
//            }
//            priceTextView.setText(priceStr);
        }
    }
}
