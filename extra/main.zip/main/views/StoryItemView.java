package com.hhdd.kada.main.views;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.android.library.utils.LocalDisplay;
import com.hhdd.kada.main.model.BaseModel;
import com.hhdd.kada.main.model.StoryCollectionInfo;
import com.hhdd.kada.main.model.StoryInfo;
import com.hhdd.kada.main.utils.AppUtils;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.views.base.BaseDataFrameLayout;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/1
 * @describe : com.hhdd.kada.main.views
 */
public class StoryItemView extends BaseDataFrameLayout<BaseModel> {

    @BindView(R.id.customStoryView)
    CustomStoryView customStoryView;
    @BindView(R.id.hotFlagView)
    ImageView hotFlagView;
    @BindView(R.id.newFlagView)
    ImageView newFlagView;
    @BindView(R.id.chargeFlagView)
    View chargeFlagView;
    @BindView(R.id.free_flag)
    View freeFlag;

    public StoryItemView(Context context) {
        super(context);
    }

    public StoryItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_story_item;
    }

    @Override
    public void doInitView() {
        super.doInitView();
        post(new Runnable() {
            @Override
            public void run() {
                FrameLayout.LayoutParams coverParams = (FrameLayout.LayoutParams) customStoryView.getLayoutParams();
                coverParams.width = getWidth();
                coverParams.height = getWidth();
                customStoryView.setLayoutParams(coverParams);
                customStoryView.setPlaceHolder(R.drawable.books_two_square);
            }
        });
    }

    @Override
    public void update(BaseModel data) {
        if (data != null) {
            if (data instanceof StoryInfo) {
                StoryInfo info = (StoryInfo) data;
                customStoryView.hideCollectionBg();
                updateFlagView(info.getExtFlag());
                if (info.getStoryId() == 0) {
                    customStoryView.cancelRound();
                    String coverUrl = "res://" + KaDaApplication.getInstance().getPackageName() + "/" + R.drawable.icon_story_add;
                    customStoryView.showUrl(coverUrl);
                    customStoryView.setTag(R.id.book_list_item_image_url, coverUrl);
                } else {
                    showNetCoverUrl(info.getCoverUrl());
                }
            } else if (data instanceof StoryCollectionInfo) {
                StoryCollectionInfo info = (StoryCollectionInfo) data;
                customStoryView.showCollectionBg(R.drawable.bg_story_collect);
                customStoryView.showBottomShadow();
                updateFlagView(info.getExtFlag());
                //收费标志
                boolean isCharge = (info.getExtFlag() & Extflag.STORY_EXT_FLAG_32) == Extflag.STORY_EXT_FLAG_32;
                boolean isFree = ((info.getExtFlag() & Extflag.STORY_FLAG_FREE_NEW) == Extflag.STORY_FLAG_FREE_NEW) ||
                        ((info.getExtFlag() & Extflag.STORY_FLAG_FREE_ALL) == Extflag.STORY_FLAG_FREE_ALL);
                if (isFree) {
                    freeFlag.setVisibility(View.VISIBLE);
                    chargeFlagView.setVisibility(View.GONE);
                } else {
                    if (isCharge) {
                        chargeFlagView.setVisibility(View.VISIBLE);
                    } else {
                        chargeFlagView.setVisibility(View.GONE);
                    }
                }
//                customStoryView.showGoldBorder(isCharge);
                showNetCoverUrl(info.getCoverUrl());
            }
        }
    }

    private void showNetCoverUrl(String coverUrl) {
        customStoryView.setRound();
        boolean needResetImageUrl = true;
        if (customStoryView.getTag(R.id.book_list_item_image_url) != null) {
            String url = (String) customStoryView.getTag(R.id.book_list_item_image_url);
            if (TextUtils.equals(url, coverUrl)) {
                needResetImageUrl = false;
            }
        }
        if (needResetImageUrl) {
            customStoryView.setTag(R.id.book_list_item_image_url, coverUrl);
            customStoryView.showUrl(coverUrl);
        }
    }

    private void updateFlagView(int extFlag) {
//        if ((extFlag & Extflag.STORY_EXT_FLAG_8) == Extflag.STORY_EXT_FLAG_8) {
//            hotFlagView.setVisibility(View.VISIBLE);
//        } else {
        if ((extFlag & Extflag.STORY_EXT_FLAG_4) == Extflag.STORY_EXT_FLAG_4) {
            newFlagView.setVisibility(View.VISIBLE);
            LayoutParams params = (LayoutParams) newFlagView.getLayoutParams();
            params.setMargins(0, LocalDisplay.dp2px(10), LocalDisplay.dp2px(4), 0);
            newFlagView.setLayoutParams(params);
        } else {
            newFlagView.setVisibility(View.GONE);
        }
//            hotFlagView.setVisibility(View.GONE);
//        }
    }
}
