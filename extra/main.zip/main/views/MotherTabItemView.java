package com.hhdd.kada.main.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;
import android.widget.TextView;

import com.hhdd.kada.R;
import com.hhdd.kada.main.views.base.BaseRelativeLayout;

import butterknife.BindView;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/24
 * @describe : com.hhdd.kada.main.views
 */
public class MotherTabItemView extends BaseRelativeLayout {

    @BindView(R.id.tabItemText)
    TextView tabItemText;
    @BindView(R.id.flagView)
    View flagView;

    public MotherTabItemView(Context context) {
        super(context);
    }

    public MotherTabItemView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public int getLayoutId() {
        return R.layout.layout_mother_tab_item;
    }

    @Override
    protected void initAttributeSet(AttributeSet attrs) {
        super.initAttributeSet(attrs);
        if (attrs != null) {
            TypedArray typedArray = null;
            try {
                typedArray = context.obtainStyledAttributes(attrs,
                        R.styleable.MotherTabItemView);
                if(typedArray.hasValue(R.styleable.MotherTabItemView_motherItemText)){
                    tabItemText.setText(typedArray.getString(R.styleable.MotherTabItemView_motherItemText));
                }
            } finally {
                if (typedArray != null) {
                    typedArray.recycle();
                    typedArray = null;
                }
            }
        }
    }

    public View getBottomView(){
        return flagView;
    }

    public void setTextBold(boolean isBold){
        TextPaint tp = tabItemText.getPaint();
        tp.setFakeBoldText(isBold);
    }
}
