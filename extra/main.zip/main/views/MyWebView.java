package com.hhdd.kada.main.views;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebView;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.core.service.AuthService;
import com.hhdd.kada.api.CookieUtil;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.jsbridge.JsBridgeController;
import com.hhdd.kada.main.event.LoginEvent;
import com.hhdd.logger.LogHelper;

import de.greenrobot.event.EventBus;


/**
 * Created by simon on 16/6/15.
 */
public class MyWebView extends WebView {

    Context mContext;

    public MyWebView(Context context) {
        super(context);
        mContext = context;
        init();
    }

    public MyWebView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mContext = context;
        init();
    }

    public MyWebView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mContext = context;
        init();
    }

    public static int getAndroidSDKVersion() {
        int version = 0;
        try {
            version = Integer.valueOf(android.os.Build.VERSION.SDK);
        } catch (NumberFormatException e) {
        }
        return version;
    }

    protected String mUrl;

    @Override
    public void loadUrl(String url) {
        synCookies(mContext, url);
        if (url.startsWith("http") || url.startsWith("file")) {
            mUrl = url;
            EventBus.getDefault().post(new JsBridgeController.WebviewLoadUrlEvent(mUrl));
        }
        super.loadUrl(url);
    }

    public void onEvent(AuthService.AuthorizedSuccessEvent event) {
        synCookies(mContext, mUrl);
    }

    public void onEvent(LoginEvent event) {
        synCookies(mContext, mUrl);
    }

    public void synCookies(Context context, String url) {

        if (url != null && url.startsWith("http")) {
            String cookie = ((CookieUtil) ServiceProxyFactory.getProxy().getService(ServiceProxyName.COOKIE_UTIL)).getUserCookie();
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
                CookieSyncManager.createInstance(context);
            }
            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.setAcceptCookie(true);
//            cookieManager.removeSessionCookie();//移除
            cookieManager.setCookie(url, cookie);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                cookieManager.flush();
            } else {
                CookieSyncManager.getInstance().sync();
            }
        }
    }

    private void init() {
        //在4.0.X版本上，暂时关闭webview的硬件加速，防止ANR
        if (getAndroidSDKVersion() == Build.VERSION_CODES.ICE_CREAM_SANDWICH
                || getAndroidSDKVersion() == Build.VERSION_CODES.ICE_CREAM_SANDWICH_MR1) {
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }

        //Webview初始化的时候，resume以下，保证WebCoreThread起来，因为其他地方可能考虑到性能问题，会让WebCoreThread pause
        onResume();
        EventBus.getDefault().register(this);
    }

    /**
     * 某些情况下会有莫名的null pointer，所以做了这么一个workaround
     */
    @Override
    public void onWindowFocusChanged(boolean bHasWindowFocus) {

        try {
            super.onWindowFocusChanged(bHasWindowFocus);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        try {
            return super.onTouchEvent(event);
        } catch (Exception e) {
            LogHelper.printStackTrace(e);
            return true;
        }
    }

    //释放资源的时候保证不存在控件之类的泄露，从而保证内存资源的释放
    public void releaseWebViewResouce(Handler handler) {
        EventBus.getDefault().unregister(this);
        try {
            this.setVisibility(View.GONE);
            this.removeAllViews();
            MyWebView.this.destroy();
        } catch (Exception e) {
            delayDestroy(handler);
        } catch (Throwable tr) {
            delayDestroy(handler);
        }
    }

    private void delayDestroy(Handler handler) {
        //延后回收的原因在于：避免放大缩小按钮导致的activity leak从而导致潜在的内存泄露
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    MyWebView.this.destroy();     //出异常后再延迟销毁
                } catch (Exception e) {   //如果这样还报异常，，，那就没办法了

                } catch (Throwable t) {

                }
            }
        }, 3000);
    }
}

//http://blog.csdn.net/u010041075/article/details/52764144