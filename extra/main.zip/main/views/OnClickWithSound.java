package com.hhdd.kada.main.views;

import android.view.View;

/**
 * Created by simon on 7/8/16.
 */
public abstract class OnClickWithSound extends NoDoubleClickListener {

    @Override
    public void onNoDoubleClick(View v) {
//            if (sp != null)
//                sp.play(music, 1, 1, 0, 0, 1);
        onClickWithSound(v);
    }

    public abstract void onClickWithSound(View v);
}