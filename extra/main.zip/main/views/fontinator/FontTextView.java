package com.hhdd.kada.main.views.fontinator;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Pair;
import android.widget.TextView;

import com.hhdd.kada.main.views.fontinator.utilities.TypefaceLoader;
import com.hhdd.kada.main.views.fontinator.utilities.Typefaceable;

/**
 * Created by simon on 18/6/15.
 */
public class FontTextView extends TextView implements Typefaceable {

    private TypefaceLoader typefaceLoader;
    public FontTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        typefaceLoader = TypefaceLoader.get(this, context, attrs);
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        Pair<CharSequence, BufferType> pair = TypefaceLoader.inject(typefaceLoader, text, type);
        super.setText(pair.first, pair.second);
    }
}
