package com.hhdd.kada.main.views.fontinator.utilities;

/**
 * Created by simon on 18/6/15.
 */
public interface Typefaceable {
}
