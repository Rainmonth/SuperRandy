package com.hhdd.kada.main.views.fontinator;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Pair;
import android.widget.Button;

import com.hhdd.kada.main.views.fontinator.utilities.TypefaceLoader;
import com.hhdd.kada.main.views.fontinator.utilities.Typefaceable;


public class FontButton extends Button implements Typefaceable{
    private TypefaceLoader typefaceLoader;
    public FontButton(Context context, AttributeSet attrs) {
        super(context, attrs);
        typefaceLoader = TypefaceLoader.get(this, context, attrs);
    }

    @Override
    public void setText(CharSequence text, BufferType type) {
        Pair<CharSequence, BufferType> pair = TypefaceLoader.inject(typefaceLoader, text, type);
        super.setText(pair.first, pair.second);
    }
}
