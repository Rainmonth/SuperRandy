package com.hhdd.kada.main.views.particleanim;

/**
 * Created by lj on 16/4/11.
 */

import android.content.Context;
import android.graphics.Color;

import com.hhdd.kada.R;

import java.util.ArrayList;
import java.util.Random;

public class ParticleSet {
    ArrayList<Particle> ParticleSet;
    Context mContext;
    Random random;
    int distance;
    public ParticleSet(Context context)
    {
        mContext = context;
        ParticleSet = new ArrayList<Particle>();
        random = new Random();
        distance = (int)mContext.getResources().getDimension(R.dimen.star_move_distance);
    }
    public void add(int startX,int startY,int count,double startTime)
    {
        for(int i=0; i<count;i++)    //创建count个数的粒子对象
        {
//    		int tempColor = this.getColor(i);
            float tempR = mContext.getResources().getDimension(R.dimen.star_small_R);
            double tempv_v=distance - random.nextInt(2* distance);    //随机产生粒子垂直方向上的速度
            double tempv_h=distance - random.nextInt(2* distance);     //随机产生粒子水平方向上的速度
            int tempX = startX;
            int tempY= startY;

            Particle particle = new Particle(tempR,tempv_v,tempv_h,tempX,tempY,startTime);

            ParticleSet.add(particle);
        }
    }
    public int getColor(int i)
    {
        int color = Color.RED;
        switch(i%4)
        {
            case 0:
                color = Color.RED;
                break;
            case 1:
                color = Color.GREEN;
                break;
            case 2:
                color = Color.YELLOW;
                break;
            case 3:
                color = Color.GRAY;
                break;
        }
        return color;
    }

}
