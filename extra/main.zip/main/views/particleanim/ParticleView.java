package com.hhdd.kada.main.views.particleanim;

/**
 * Created by lj on 16/4/11.
 */

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.hhdd.kada.R;
import com.hhdd.kada.main.utils.ScreenUtil;

import java.util.ArrayList;

public class ParticleView extends SurfaceView implements SurfaceHolder.Callback {
    public static final int DIE_OUT_LINE = 30;   //粒子的Y坐标超过该值就会被从粒子集合移出
    DrawThread dt;                             //后台刷新屏幕线程
    ParticleSet ps;
    ParticleThread pt;
    String fps = "FPS:N/A";
    Bitmap smallStar1;
    Bitmap smallStar2;
    Bitmap src;

    int lastX = 0;
    int lastY = 0;

    int screenWidth;
    int screenHeight;
    int starWidth;
    int starHeight;
    int starNowX;
    int starNowY;
    boolean isMove;

    public ParticleView(Context context) {
        this(context, null);
    }

    public ParticleView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ParticleView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        screenHeight = ScreenUtil.getScreenHeight(context);
        screenWidth = ScreenUtil.getScreenWidth(context);
        starWidth = getResources().getDimensionPixelOffset(R.dimen.star_width);
        starHeight = getResources().getDimensionPixelOffset(R.dimen.star_height);
        init(context);
    }

    void init(Context context) {
        this.getHolder().addCallback(this);
        dt = new DrawThread(this, getHolder());
        ps = new ParticleSet(context);
        pt = new ParticleThread(this);
    }


    @Override
    public void surfaceChanged(SurfaceHolder arg0, int arg1, int arg2, int arg3) {
        // TODO Auto-generated method stub
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // TODO Auto-generated method stub
        if(dt == null){
            dt = new DrawThread(this, getHolder());
        }
        if(pt == null){
            pt = new ParticleThread(this);
        }
        getHandler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (dt != null && !dt.isAlive()) {
                    dt.start();
                }
                if (pt != null && !pt.isAlive()) {
                    pt.start();
                }
            }
        },100);
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // TODO Auto-generated method stub
        dt.flag = false;
        dt = null;
        pt.flag = false;
        pt = null;
    }

    public void setLocation(int x, int y) {
        starNowX = x;
        starNowY = y;
    }
    public void setIsMove(boolean isMove){
        this.isMove = isMove;
    }

    public void start(int startX, int startY, int endX, int endY) {
        if(pt != null){
            pt.setLocation(startX, startY, endX, endY);
        }

        if (dt != null && !dt.isAlive()) {
            dt.start();
        }
        if (pt != null && !pt.isAlive()) {
            pt.start();
        }
    }

    public void onPause(){
        if(dt != null){
            dt.flag = false;
            dt = null;
        }
        if(pt != null){
            pt.flag = false;
            pt = null;
        }
    }
    public void onResume(){
        dt = new DrawThread(this, getHolder());
        pt = new ParticleThread(this);
    }

    public void doDraw(Canvas canvas) {
        canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
//        int sc = canvas.saveLayer(0, 0, getWidth(), getHeight(), null, Canvas.MATRIX_SAVE_FLAG | Canvas.CLIP_SAVE_FLAG
//                | Canvas.HAS_ALPHA_LAYER_SAVE_FLAG
//                | Canvas.FULL_COLOR_LAYER_SAVE_FLAG
//                | Canvas.CLIP_TO_LAYER_SAVE_FLAG);

        ArrayList<Particle> particleSet = ps.ParticleSet;
//        if (particleSet == null || particleSet.size() == 0) {
//            return;
//        }
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.YELLOW);
        for (int i = 0; i < particleSet.size(); i++) {
            Particle p = particleSet.get(i);
            if(p != null){
                int tempX = p.x;
                int tempY = p.y;
                float tempRadius = p.r;

                if (smallStar1 == null || smallStar1.isRecycled()) {
                    smallStar1 = BitmapFactory.decodeResource(getResources(), R.drawable.star_small);
                }
                if (smallStar2 == null || smallStar2.isRecycled()){
                    smallStar2 = BitmapFactory.decodeResource(getResources(),R.drawable.star_small2);
                }

                int alpha = (int) (255 - 255 * (System.currentTimeMillis() - p.startTime) / 1000.0f);
                paint.setAlpha(alpha);
//                Matrix matrix = new Matrix();
//                matrix.postRotate(30,tempX- tempRadius,tempY- tempRadius);
//                Bitmap tempBitmap = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
                if(i % 2 == 0){
                    Rect mSrcRect = new Rect(0, 0, smallStar1.getWidth(), smallStar1.getHeight());
                    RectF oval = new RectF(tempX - tempRadius, tempY - tempRadius, tempX + tempRadius, tempY + tempRadius);
                    canvas.drawBitmap(smallStar1, mSrcRect, oval, paint);
                }else{
                    Rect mSrcRect = new Rect(0, 0, smallStar2.getWidth(), smallStar2.getHeight());
                    RectF oval = new RectF(tempX - tempRadius, tempY - tempRadius, tempX + tempRadius, tempY + tempRadius);
                    canvas.drawBitmap(smallStar2, mSrcRect, oval, paint);
                }
            }
//			RectF oval = new RectF(tempX,tempY,tempX+2*tempRadius,tempY+2*tempRadius);
//			canvas.drawOval(oval, paint);
        }
//        canvas.restoreToCount(sc);
//        canvas.restore();
        paint.setAlpha(255);
        if (src == null || src.isRecycled()) {
            src = BitmapFactory.decodeResource(getResources(), R.drawable.star_normal);
        }
        if (isMove) {
            Rect mSrcRect = new Rect(0, 0, src.getWidth(), src.getHeight());
            RectF oval = new RectF(starNowX - starWidth / 2.0f, starNowY - starHeight / 2.0f,
                    starNowX + starWidth / 2.0f, starNowY + starHeight / 2.0f);
            canvas.drawBitmap(src, mSrcRect, oval, paint);
        } else {
            Rect mSrcRect = new Rect(0, 0, src.getWidth(), src.getHeight());
            RectF oval = new RectF(screenWidth / 2.0f - starWidth / 2.0f, screenHeight / 2.0f - starHeight,
                    screenWidth / 2.0f + starWidth / 2.0f, screenHeight / 2.0f);
            canvas.drawBitmap(src, mSrcRect, oval, paint);
        }

    }



}
