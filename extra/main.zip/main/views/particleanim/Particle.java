package com.hhdd.kada.main.views.particleanim;

/**
 * Created by lj on 16/4/11.
 */
/*
 * 构建一个粒子对象
 */
public class Particle {
    float r;                                    //粒子半径
    double vertical_v;                         //垂直方向上的速度
    double horizontal_v;                       //水平方向上的速度的
    int startX;                                //X 方向上的初始坐标
    int startY;
    int x;                                       //实时X坐标
    int y;                                       //实时Y坐标；
    double startTime;                            //起始时间
    public Particle(float r, double vertical_v, double horizontal_v,int x,int y, double startTime)
    {
        this.r=r;
        this.vertical_v=vertical_v;
        this.horizontal_v=horizontal_v;
        this.x=x;
        this.y=y;
        this.startTime=startTime;
        this.startX=x;
        this.startY=y;
    }
}
