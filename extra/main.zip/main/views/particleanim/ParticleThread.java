package com.hhdd.kada.main.views.particleanim;

/**
 * Created by lj on 16/4/11.
 */
import com.hhdd.logger.LogHelper;

import java.util.ArrayList;
import java.util.Random;

public class ParticleThread extends Thread {
    ParticleView father;
    int sleepSpan = 80;
    double span = 0.15;
    int startX;
    int startY;
    int endX;
    int endY;
    boolean flag;
    Random random;

    public ParticleThread(ParticleView father) {
        this.father = father;
        this.flag = true;	//设置线程执行标志位为true
        random = new Random();
    }

    public void setLocation(int startX, int startY, int endX, int endY) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;

        int tempX = (int)(random.nextDouble() *(endX - startX) + startX);
        int tempY = (int)(random.nextDouble() *(endY - startY) + startY);
        father.ps.add(tempX, tempY, 1, System.currentTimeMillis());
    }

    public void run() {

        while(flag){
            ArrayList<Particle> tempSet = father.ps.ParticleSet;
            int count = tempSet.size();
            for (int i = 0; i < count; i++) {
                Particle particle = tempSet.get(i);
                if(particle != null){
                    double timeSpan = System.currentTimeMillis() - particle.startTime;   //�������X���

                    particle.r = (float) (particle.r - (timeSpan / 2000) * particle.r);
                    int tempx = (int) (particle.startX + particle.horizontal_v * (timeSpan / 1000.0f) );
                    int tempy = (int) (particle.startY + particle.vertical_v * (timeSpan / 1000.0f));
                    particle.x = tempx;
                    particle.y = tempy;

                    // 根据时间控制星星remove
                    if (timeSpan > 1000) {
                        tempSet.remove(particle);
                        count = tempSet.size();
                    }
                }
            }
            try {
                Thread.sleep(sleepSpan);

            } catch (Exception e) {
                LogHelper.printStackTrace(e);
            }
        }
    }
}
