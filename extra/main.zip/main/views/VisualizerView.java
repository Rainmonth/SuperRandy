package com.hhdd.kada.main.views;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import com.hhdd.kada.main.utils.SafeHandler;
import com.hhdd.logger.LogHelper;

import java.util.Random;

/**
 * Created by lj on 15/10/15.
 */
public class VisualizerView extends RoundedImageView {

    SafeHandler mHandler = new SafeHandler();
    private float[] mBytes;
    private float[] mPoints;
    private Rect mRect = new Rect();
    private boolean drawing = false;

    private Paint mForePaint = new Paint();
    private int mSpectrumNum = 5;

    public VisualizerView(Context context) {
        super(context);
        init();
    }

    private void init() {
        mBytes = null;
        mForePaint.setStrokeWidth(9f);
        mForePaint.setAntiAlias(true);
        mForePaint.setColor(Color.rgb(0, 255, 216));
    }

    public void setDrawing(boolean drawing) {
        this.drawing = drawing;
        if (drawing) {
            if (mThread==null) {
                mThread = new VisualizerThread(mHandler);
                mThread.start();
            }
        } else {
            if (mThread!=null) {
                mThread.quit();
                mThread = null;
            }
        }
    }

    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (drawing) {
                float[] model = new float[mSpectrumNum];
                Random random = new Random();
                for (int i = 0; i < model.length; i++) {
                    model[i] = random.nextFloat() * getHeight() / 3.0f;
                }
                mBytes = model;
                postInvalidate();
            }
        }
    };

    class VisualizerThread extends Thread {
        VisualizerThread(SafeHandler handler) {
            this.handler = handler;
        }
        boolean mQuit = false;
        SafeHandler handler;
        @Override
        public void run() {
            super.run();
            while (!mQuit) {
                try {
                    if (this.handler!=null) {
                        this.handler.post(runnable);
                    }
                    Thread.sleep(220);
                } catch (InterruptedException e) {
                    LogHelper.printStackTrace(e);
                }
            }
        }

        void quit() {
            mQuit = true;
            handler.removeCallbacks(null);
            handler = null;
        }
    }

    VisualizerThread mThread;

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mBytes == null) {
            return;
        }
        if (mPoints == null || mPoints.length < mBytes.length * 4) {
            //mPoints用来存储画直线的2个坐标（x,y）
            mPoints = new float[mBytes.length * 4];
        }
        mRect.set(0, 0, (int) (getWidth() / 3.0f), (int) (getHeight() / 3.0f));
        //baseX是每个刻度长度
        final int baseX = mRect.width() / mSpectrumNum;
        final int height = mRect.height();
        for (int i = 0; i < mSpectrumNum; i++) {
            if (mBytes[i] < 0) {
                mBytes[i] = 127;
            }
            final int xi = baseX * i + baseX / 2;
            mPoints[i * 4] = xi + (int) (getWidth() / 3.0f);
            mPoints[i * 4 + 1] = height + (int) (getHeight() / 3.0f);
            mPoints[i * 4 + 2] = xi + (int) (getWidth() / 3.0f);
            mPoints[i * 4 + 3] = height - mBytes[i] + (int) (getHeight() / 3.0f);
        }
        canvas.drawLines(mPoints, mForePaint);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        setDrawing(false);
    }
}