package com.hhdd.kada.main.event;

import android.os.Looper;

import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.android.library.app.lifecycle.LifeCycleComponentManager;
import com.hhdd.kada.base.IFragmentBase;

import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;


/**
 * Created by simon on 4/6/16.
 */
public class EventCenter {

    private static class SingletonHolder {
        private static final EventBus instance = EventBus.getDefault();
    }

    private EventCenter() {

    }

    public static SimpleEventHandler bindContainerAndHandler(Object container, SimpleEventHandler handler) {
        LifeCycleComponentManager.tryAddComponentToContainer(handler, container);
        handler.tryToRegisterIfNot();
        return handler;
    }

    static final synchronized EventBus getInstance() {
        return SingletonHolder.instance;
    }

    public static void register(final Object subscriber) {
        synchronized (EventCenter.getInstance()) {
            if (!EventCenter.getInstance().isRegistered(subscriber)){
                EventCenter.getInstance().register(subscriber);
            }
        }
    }

    public static void unregister(final Object subscriber) {
        synchronized (EventCenter.getInstance()) {
            if (EventCenter.getInstance().isRegistered(subscriber)){
                EventCenter.getInstance().unregister(subscriber);
            }

        }
    }

    public static void fireEvent(final Object object) {
        if (Thread.currentThread().getId() == Looper.getMainLooper().getThread().getId()) {
            EventCenter.getInstance().post(object);
        } else {
            KaDaApplication.mainLooperHandler().post(new Runnable() {
                @Override
                public void run() {
                    EventCenter.getInstance().post(object);
                }
            });
        }
    }
}
