package com.hhdd.kada.main.event;

/**
 * Created by lj on 2017/5/24.
 * 订阅成功
 */

public class SubscribeSuccessEvent {

    public SubscribeSuccessEvent(int collectId) {
        this.collectId = collectId;
    }

    public int collectId;
}
