package com.hhdd.kada.main.event;


/**
 * Created by sxh on 2017/8/4.
 */

public class BookSubscribeStatusEvent {

    private int status;   //  0  未订阅    1 订阅   2 假订阅  3  取消订阅
    private String from; //订阅操作页面来源 用来区分打点
    private int collectId;   //合辑id


    public BookSubscribeStatusEvent(){}

    public BookSubscribeStatusEvent(int collectId,int status) {
        this.collectId = collectId;
        this.status = status;
    }

    public BookSubscribeStatusEvent(int collectId,int status, String from) {
        this.collectId = collectId;
        this.status = status;
        this.from = from;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }
}
