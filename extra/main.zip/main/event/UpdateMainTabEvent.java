package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/8/10
 * @describe : com.hhdd.kada.main.event
 */
public class UpdateMainTabEvent {

    private int index;
    private boolean isShowLockDialog;
    private int childIndex;

    public UpdateMainTabEvent(boolean isShowLockDialog, int childIndex) {
        this.index = 0;
        this.isShowLockDialog = isShowLockDialog;
        this.childIndex = childIndex;
    }

    public UpdateMainTabEvent(int index, boolean isShowLockDialog, int childIndex) {
        this.index = index;
        this.isShowLockDialog = isShowLockDialog;
        this.childIndex = childIndex;
    }

    public int getIndex() {
        return index;
    }

    public boolean isShowLockDialog() {
        return isShowLockDialog;
    }

    public int getChildIndex() {
        return childIndex;
    }
}
