package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/6
 * @describe : com.hhdd.kada.main.event
 */
public class UpdateAppStartTimeEvent {
}
