package com.hhdd.kada.main.event;

/**
 * Created by sxh on 2018/1/24.
 * 听书单本下载成功
 */

public class StoryFinishDownloadEvent {
}
