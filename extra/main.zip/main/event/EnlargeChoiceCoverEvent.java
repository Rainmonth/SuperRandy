package com.hhdd.kada.main.event;

public class EnlargeChoiceCoverEvent {

    public int nextPosition;
    public int questionId;

    public EnlargeChoiceCoverEvent(int nextPosition,int questionId) {
        this.nextPosition = nextPosition;
        this.questionId = questionId;
    }
}
