package com.hhdd.kada.main.event;

/**
 * Created by bjx on 2017/10/31.
 */

public class RequestStoryHistoryListEvent {
}
