package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/1/5
 * @describe : com.hhdd.kada.main.event
 */
public class GetTryReadBookIdEvent {

    private int bookId;
    private int version;
    private int issueId;

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public void setIssueId(int issueId) {
        this.issueId = issueId;
    }

    public int getIssueId() {
        return issueId;
    }
}
