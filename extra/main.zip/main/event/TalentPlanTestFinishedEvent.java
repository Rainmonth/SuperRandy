package com.hhdd.kada.main.event;

/**
 * Created by sxh on 2018/1/20.
 * 优才计划答完题，答案提交成功后发出该事件，通知相关地方更新答题星星数量
 */

public class TalentPlanTestFinishedEvent {
    public int bookId;
    public int starCount;

    public TalentPlanTestFinishedEvent(int bookId, int starCount) {
        this.bookId = bookId;
        this.starCount = starCount;
    }
}
