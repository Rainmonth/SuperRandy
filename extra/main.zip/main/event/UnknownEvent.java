package com.hhdd.kada.main.event;

/**
 * Created by simon on 4/6/16.
 */
public class UnknownEvent {
}
