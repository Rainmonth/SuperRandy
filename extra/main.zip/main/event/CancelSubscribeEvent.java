package com.hhdd.kada.main.event;

/**
 * Created by lj on 2017/5/24.
 * 取消订阅
 */

public class CancelSubscribeEvent {
    private String from;
    private int collectId;

    public CancelSubscribeEvent(int collectId,String from) {
        this.collectId = collectId;
        this.from = from;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public int getCollectId() {
        return collectId;
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }
}
