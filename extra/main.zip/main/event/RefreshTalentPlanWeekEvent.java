package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/16
 * @describe : com.hhdd.kada.main.event
 */
public class RefreshTalentPlanWeekEvent {
    private int weekId;

    public RefreshTalentPlanWeekEvent(int weekId) {
        this.weekId = weekId;
    }

    public int getWeekId() {
        return weekId;
    }

    public void setWeekId(int weekId) {
        this.weekId = weekId;
    }
}
