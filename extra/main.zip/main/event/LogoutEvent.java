package com.hhdd.kada.main.event;

/**
 * Created by simon on 6/27/16.
 */
public class LogoutEvent {
    private boolean isCookieExpired;   //是否是登录过期发出的event

    public LogoutEvent() {
    }

    public LogoutEvent(boolean isCookieExpired) {
        this.isCookieExpired = isCookieExpired;
    }

    public void setCookieExpired(boolean cookieExpired) {
        isCookieExpired = cookieExpired;
    }

    public boolean isCookieExpired() {
        return isCookieExpired;
    }
}
