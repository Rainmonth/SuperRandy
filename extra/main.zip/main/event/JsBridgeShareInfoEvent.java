package com.hhdd.kada.main.event;

import com.hhdd.kada.share.ShareProvider;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/26
 * @describe : com.hhdd.kada.main.event
 */
public class JsBridgeShareInfoEvent {

    private ShareProvider.JsBridgeShareVO shareVO;

    public ShareProvider.JsBridgeShareVO getShareVO() {
        return shareVO;
    }

    public void setShareVO(ShareProvider.JsBridgeShareVO shareVO) {
        this.shareVO = shareVO;
    }
}
