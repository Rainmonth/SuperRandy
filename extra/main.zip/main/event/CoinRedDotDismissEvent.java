package com.hhdd.kada.main.event;

/**
 * Created by sxh on 2017/9/25.
 * 咔哒币红点消失event
 */

public class CoinRedDotDismissEvent {

}
