package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/5
 * @describe : com.hhdd.kada.main.event
 */
public class UnLockEvent {
    /**
     * 对自动解锁或用户解锁做区分是为了控制名师解读暂停和继续播放逻辑
     */
    private int type;

    public static final int TYPE_REST_USER = 1; //休息页面用户解锁
    public static final int TYPE_REST_AUTO = TYPE_REST_USER + 1; //休息页面自动解锁
    public static final int TYPE_SLEEP_USER = TYPE_REST_AUTO + 1; //睡眠页面用户解锁
    public static final int TYPE_SLEEP_AUTO = TYPE_SLEEP_USER + 1; //睡眠页面自动解锁

    /**
     * 睡眠页面推送解锁(推送本来应该算自动解锁，但在推送解锁需求为本次解锁，若按照自动解锁逻辑，
     * 在睡眠时间内通过推送解锁，一分钟后会继续出锁，不符合需求，应与用户解锁逻辑一致，故单独列出。
     */
    public static final int TYPE_SLEEP_PUSH = TYPE_SLEEP_AUTO + 1;

    public UnLockEvent() {
    }

    public UnLockEvent(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
