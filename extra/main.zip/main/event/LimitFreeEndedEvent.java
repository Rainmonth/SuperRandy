package com.hhdd.kada.main.event;

/**
 * @author: Randy Zhang
 * @description: 限免结束时间
 * @created: 2018/9/25
 **/
public class LimitFreeEndedEvent {
    public LimitFreeEndedEvent() {
    }
}
