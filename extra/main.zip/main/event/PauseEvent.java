package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/5
 * @describe : com.hhdd.kada.main.event
 */
public class PauseEvent {

    public boolean isLockPause; // 是否休息睡眠锁触发的暂停；

    public PauseEvent() {
    }

    public PauseEvent(boolean isLockPause) {
        this.isLockPause = isLockPause;
    }
}
