package com.hhdd.kada.main.event;

/**
 * Created by sxh on 2017/12/25.
 * 优才计划获取奖励咔哒币
 */

public class TalentPlanFetchCoinEvent {
}
