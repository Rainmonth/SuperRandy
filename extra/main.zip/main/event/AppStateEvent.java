package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/12/16
 * @describe : com.hhdd.kada.main.event
 */
public class AppStateEvent {

    private boolean isBackground;

    public AppStateEvent(boolean isBackground) {
        this.isBackground = isBackground;
    }

    public boolean isBackground() {
        return isBackground;
    }

    public void setBackground(boolean background) {
        isBackground = background;
    }
}
