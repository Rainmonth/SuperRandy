package com.hhdd.kada.main.event;

/**
 * Created by sxh on 2018/1/24.
 * 绘本单本下载成功
 */

public class BookFinishDownloadEvent {
}
