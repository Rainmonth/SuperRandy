package com.hhdd.kada.main.event;

/**
 * 登录状态事件
 *
 */
public class LoginStatusForJsBridgeEvent {

    public LoginStatusForJsBridgeEvent(int loginStatus) {
        this.loginStatus = loginStatus;
    }

    public int loginStatus;   // -1：取消登录   0：登录失败   1：登录成功
}
