package com.hhdd.kada.main.event;

import com.hhdd.kada.android.library.app.lifecycle.LifeCycleComponent;

/**
 * Created by simon on 4/6/16.
 */
public class SimpleEventHandler implements LifeCycleComponent {

    private boolean mRegistered = false;

    public SimpleEventHandler register() {
        if (!mRegistered) {
            mRegistered = true;
            EventCenter.register(this);
        }
        return this;
    }

    public synchronized SimpleEventHandler tryToUnregister() {
        if (mRegistered) {
            mRegistered = false;
            EventCenter.unregister(this);
        }
        return this;
    }

    public synchronized SimpleEventHandler tryToRegisterIfNot() {
        register();
        return this;
    }

    @Override
    public void onBecomesVisibleFromTotallyInvisible() {

    }

    @Override
    public void onBecomesPartiallyInvisible() {

    }

    @Override
    public void onBecomesVisible() {
        register();
    }

    @Override
    public void onBecomesTotallyInvisible() {

    }

    @Override
    public void onDestroy() {
        tryToUnregister();
    }

    /**
     * 与发布者在同一个线程
     * @param event 事件1
     */
    public void onEvent(UnknownEvent event){

    }

    /**
     * 执行在主线程。
     * 非常实用，可以在这里将子线程加载到的数据直接设置到界面中。
     * @param event 事件1
     */
    public void onEventMainThread(UnknownEvent event){

    }

    /**
     * 执行在子线程，如果发布者是子线程则直接执行，如果发布者不是子线程，则创建一个再执行
     * 此处可能会有线程阻塞问题。
     * @param event 事件1
     */
    public void onEventBackgroundThread(UnknownEvent event){

    }

    /**
     * 执行在在一个新的子线程
     * 适用于多个线程任务处理， 内部有线程池管理。
     * @param event 事件1
     */
    public void onEventAsync(UnknownEvent event){

    }
}
