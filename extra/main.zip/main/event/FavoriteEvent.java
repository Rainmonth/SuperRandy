package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2017/7/27
 * @describe : com.hhdd.kada.main.event
 */
public class FavoriteEvent {

    private int type;

    public static final int TYPE_BOOK = 1;
    public static final int TYPE_STORY = 2;

    public FavoriteEvent(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }
}
