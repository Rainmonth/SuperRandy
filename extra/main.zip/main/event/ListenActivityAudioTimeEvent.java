package com.hhdd.kada.main.event;

public class ListenActivityAudioTimeEvent {

    private long allTime;

    public ListenActivityAudioTimeEvent(long allTime) {
        this.allTime = allTime;
    }

    public long getAllTime() {
        return allTime;
    }

    public void setAllTime(long allTime) {
        this.allTime = allTime;
    }
}
