package com.hhdd.kada.main.event;

/**
 * Created by lj on 17/5/4.
 */

public class StoryHistoryUpdateEvent {
}
