package com.hhdd.kada.main.event;

/**
 * Created by simon on 6/28/16.
 */
public class ConnectivityChangedEvent {

    public final boolean isConnected;
    public final boolean isConnectedWifi;

    public ConnectivityChangedEvent(boolean isConnected, boolean isConnectedWifi) {
        this.isConnected = isConnected;
        this.isConnectedWifi = isConnectedWifi;
    }

    public static void fireEvent(boolean isConnected, boolean isConnectedWifi) {
        EventCenter.fireEvent(new ConnectivityChangedEvent(isConnected,isConnectedWifi));
    }
}
