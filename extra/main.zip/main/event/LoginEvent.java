package com.hhdd.kada.main.event;

/**
 * Created by simon on 6/27/16.
 */
public class LoginEvent {

    private String type;

    public LoginEvent() {
    }

    public LoginEvent(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
