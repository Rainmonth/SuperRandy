package com.hhdd.kada.main.event;

import com.tencent.mm.opensdk.modelmsg.SendAuth;

/**
 * Created by lj on 16/11/11.
 */

public class WeiXinLoginEvent {

    private boolean isSuccess;
    SendAuth.Resp resp;
    String tag;

    public boolean isSuccess() {
        return isSuccess;
    }

    public void setSuccess(boolean success) {
        isSuccess = success;
    }

    public void setResp(SendAuth.Resp resp) {
        this.resp = resp;
    }

    public SendAuth.Resp getResp() {
        return resp;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getTag() {
        return tag;
    }
}
