package com.hhdd.kada.main.event;

/**
 * Created by sxh on 2017/7/31.
 */

public class TabRefreshEvent {
    private int type;

    public TabRefreshEvent(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
