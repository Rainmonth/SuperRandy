package com.hhdd.kada.main.event;

/**
 * Created by simon on 6/27/16.
 */
public class TokenExpiredEvent {
}
