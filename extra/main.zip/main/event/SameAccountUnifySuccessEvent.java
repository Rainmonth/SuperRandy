package com.hhdd.kada.main.event;

/**
 * @author : Created by xiepeng
 * @email : xiepeng2015929@gmail.com
 * @created time : 2018/6/14
 * @describe : com.hhdd.kada.main.event
 * 选择当前登录帐号合并成功
 */
public class SameAccountUnifySuccessEvent {
}
