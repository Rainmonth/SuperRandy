package com.hhdd.kada.main.event;

/**
 * Created by mcx on 2017/12/13.
 */

public class TalentAnimStopEvent {
}
