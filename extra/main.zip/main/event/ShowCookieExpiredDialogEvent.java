package com.hhdd.kada.main.event;

/**
 * Created by bjx on 2018/8/18.
 */

public class ShowCookieExpiredDialogEvent {
}
