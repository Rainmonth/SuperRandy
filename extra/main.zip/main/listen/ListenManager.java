package com.hhdd.kada.main.listen;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.PowerManager;
import android.text.TextUtils;

import com.hhdd.android.common.ServiceProxyFactory;
import com.hhdd.android.thread.IThread;
import com.hhdd.core.model.StoryInfo;
import com.hhdd.core.service.DefaultCallback;
import com.hhdd.core.service.PlayActionService;
import com.hhdd.core.service.StoryService;
import com.hhdd.cryptokada.CryptoKadaLib;
import com.hhdd.kada.Dirs;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.app.serviceproxy.ServiceProxyName;
import com.hhdd.kada.main.controller.MainActivityController;
import com.hhdd.kada.main.event.EventCenter;
import com.hhdd.kada.main.event.ListenActivityAudioTimeEvent;
import com.hhdd.kada.main.mediaserver.MediaServer2;
import com.hhdd.kada.main.model.StoryCollectionDetail;
import com.hhdd.kada.main.playback.ReleaseMediaPlayerRunnable;
import com.hhdd.kada.main.utils.Extflag;
import com.hhdd.kada.main.utils.NetworkUtils;
import com.hhdd.kada.main.utils.ToastUtils;
import com.hhdd.kada.module.audio.AudioName;
import com.hhdd.kada.module.player.AudioInfo;
import com.hhdd.kada.module.player.IMediaPlayer;
import com.hhdd.kada.module.player.KdMediaPlayer;
import com.hhdd.kada.module.player.OnKdAudioFocusChangeListener;
import com.hhdd.kada.module.player.OnPlayListener;
import com.hhdd.kada.module.player.PlayMode;
import com.hhdd.logger.LogHelper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import de.greenrobot.event.EventBus;
import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Consumer;
import io.reactivex.schedulers.Schedulers;


/**
 * Created by lj on 16/5/18.
 * 听书播放控制器
 */
public class ListenManager implements
        MediaPlayer.OnPreparedListener,
        MediaPlayer.OnErrorListener,
        MediaPlayer.OnBufferingUpdateListener,
        MediaPlayer.OnCompletionListener,
        MediaPlayer.OnSeekCompleteListener,
        MediaPlayer.OnInfoListener {

    private IMediaPlayer mShortMediaPlayer = (IMediaPlayer) ServiceProxyFactory.getProxy().getService(ServiceProxyName.KD_MEDIA_PLAYER);

    private boolean isShortAudioOnStoppedContinueListen = true;
    private boolean isPlayNext = false;
    private boolean isBeginAudioPlaying = false;
    private boolean isEndAudioPlaying = false;

    List<Listener> mPlayEventCallbacks = new ArrayList<>(2);

    public void addCallback(Listener callback) {
        if (callback != null && !mPlayEventCallbacks.contains(callback)) {
            mPlayEventCallbacks.add(callback);
        }
    }

    public void clearCallback() {
        mPlayEventCallbacks.clear();
    }

    public void removeCallback(Listener callback) {
        if (callback != null && mPlayEventCallbacks.contains(callback)) {
            mPlayEventCallbacks.remove(callback);
        }
    }

    boolean isLost = false;

    private OnKdAudioFocusChangeListener mAudioFocusChangeListener = new OnKdAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            if (focusChange == AudioManager.AUDIOFOCUS_LOSS || focusChange == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
                if (isPlaying()) {
                    isLost = true;
                    pause(false);

                    if (currentIndex >= 0 && currentIndex < storyList.size()) {
                        EventBus.getDefault().post(new StoryService.PauseReadingEvent(storyList.get(currentIndex), startListenPosition, sessionId));
                    }
                    
                    setPause(true);
                    EventBus.getDefault().post(new MainActivityController.OnHideFloatingWindowEvent());
                }

            } else if (focusChange == AudioManager.AUDIOFOCUS_GAIN) {
                //获得焦点之后的操作
                if (isLost) {
                    isLost = false;
                    setPause(false);
                    play();

                    if (currentIndex >= 0 && currentIndex < storyList.size()) {
                        EventBus.getDefault().post(new StoryService.StartReadingEvent(storyList.get(currentIndex), startListenPosition, sessionId));
                    }

                    EventBus.getDefault().post(new MainActivityController.OnShowFloatingWindowEvent());
                }
            }
        }
    };

    //锁屏界面是否允许中
    public boolean isLockActivityRunning = false;
    //播放列表 viewpager列表 会因为合集加载展开而变化
    List<StoryInfo> storyList = new ArrayList<StoryInfo>();
    //底部listview列表 不变
    List<StoryInfo> storys = new ArrayList<StoryInfo>();
    //当前播放位置
    int currentIndex = -1;
    //是否暂停
    boolean isPause;
    boolean isPausedByShortAudio = false;
    //是否单曲循环
    boolean isSingleCycle;
    //是否prepare完成
    public boolean isReady;
    //试听
    boolean isFreeListen = false;
    //当前选中的音频
    private int nowMediaIsSelected;
    //当前音频url
    private String mCurrentSoundUrl;
    private String mDataSouce;
    private int collectId; //当前播放的合集id 用于续播判断
    private int collectionExtFlag;  //当前播放合辑的extflag

    private String sessionId;  //用于播放行为提交服务器的唯一标识

    public String getSessionId() {
        return sessionId;
    }

    private boolean needPostEvent = false;

    public void setNeedPostEvent(boolean needPostEvent) {
        this.needPostEvent = needPostEvent;
    }

    //    private Timer timer = null;
//    long mTime;
//    long nowTime;

    //开始播放点
    private long startListenPosition;
    //是否播放开始音 需求为只播放第一次
    boolean doPlayBegin = true;
    //开始音
    public static final int BEGIN_MEDIA = 0;
    //故事音
    public static final int STORY_MEDIA = 1;
    //结束音
    public static final int END_MEDIA = 2;

    //故事合集 从最后一本开始或第一本开始
    int collectionMode;
    final static int BEGIN_START = 0;
    final static int END_START = 1;

    private MediaPlayer mMediaPlayer;

    int mState = STATE_IDLE;
    int lastReportedPlaybackState;
    // Constants pulled into this class for convenience.
    public static final int STATE_IDLE = 1;//ExoPlayer.STATE_IDLE;
    public static final int STATE_PREPARING = 2;//ExoPlayer.STATE_PREPARING;
    public static final int STATE_BUFFERING = 3;//ExoPlayer.STATE_BUFFERING;
    public static final int STATE_READY = 4;//ExoPlayer.STATE_READY;
    public static final int STATE_ENDED = 5;//ExoPlayer.STATE_ENDED;
    public static final int STATE_PLAYING = 200;
    public static final int STATE_PAUSED = 300;

    private Context mContext;
    private static ListenManager mListenManager;
    private StoryInfo mStoryInfo;   //当前播放的听书info

    private ListenManager() {
        mContext = KaDaApplication.getInstance();
        mListenManager = this;
    }


    public static ListenManager getInstance() {
        if (mListenManager == null) {
            mListenManager = new ListenManager();
        }
        return mListenManager;
    }

    public void prepare(final int index) {
        if (storyList == null || storyList.size() <= index) {
            return;
        }

        isReady = false;

        mShortMediaPlayer.addOnPlayListener(mOnPlayListener);
        mShortMediaPlayer.addOnKdAudioFocusChangeListener(mAudioFocusChangeListener);

        for (Listener callback : mPlayEventCallbacks) {
            callback.handleLoadding();
        }

        if (this.storyList.get(index).getType() == StoryInfo.TYPE_COLLECTION) {
//            if (this.currentIndex == index + 1) {
//                collectionMode = END_START;
//            } else{
//                collectionMode = BEGIN_START;
//            }
//                final int fcollectionMode = collectionMode;

            StoryService.loadCollection((int) this.storyList.get(index).getCollectionId(), this.getStoryList().get(index).getCollectType(), new DefaultCallback<StoryCollectionDetail>() {
                @Override
                public void onDataReceived(StoryCollectionDetail data) {
                    if (data != null) {
                        if (data.getItems() == null || data.getItems().size() == 0) {
                            StoryInfo storyInfo = storyList.remove(index);
                            if (storys.contains(storyInfo)) {
                                storys.remove(storyInfo);
                            } else {
                                long id = storyInfo.getId();
                                int size = storys.size();
                                for (int i = 0; i < size; i++) {
                                    if (id == storys.get(i).getId()) {
                                        storys.remove(i);
                                        break;
                                    }
                                }
                            }

                            int size = storyList.size();
                            currentIndex = index < size ? index : size - 1;
                            EventBus.getDefault().post(new ListenActivity.OnRefreshViewEvent(storyList, storys, currentIndex));
                            if (currentIndex == size - 1) {
                                EventBus.getDefault().post(new ListenActivity.StopEvent());
                            } else {
                                prepare(currentIndex);
                            }
                        } else {
                            List<StoryInfo> allList = new ArrayList<>();
                            allList.addAll(storyList);
                            allList.remove(index);
                            List<StoryInfo> list = new ArrayList<StoryInfo>();
                            for (int i = 0; i < data.getItems().size(); i++) {
                                com.hhdd.kada.main.model.StoryInfo storyInfo = data.getItems().get(i);
                                if (data.getSubscribe() == 1) {
                                    StoryInfo info = StoryInfo.createInfoByStoryInfo(storyInfo, data);
                                    list.add(info);
                                } else if ((storyInfo.getExtFlag() & Extflag.STORY_EXT_FLAG_256) == Extflag.STORY_EXT_FLAG_256) {
                                    StoryInfo info = StoryInfo.createInfoByStoryInfo(storyInfo, data);
                                    list.add(info);
                                }
                            }
                            allList.addAll(index, list);
//                                int i;
//                                if (fcollectionMode == END_START)
//                                    i = index + list.size() - 1;
//                                else
//                                    i = index;
//                                currentIndex = i;
                            setStoryList(allList);
                            EventBus.getDefault().post(new ListenActivity.OnRefreshViewEvent(allList, storys, index));
                            prepare(index);
                        }
                    } else {
                        StoryInfo storyInfo = storyList.remove(index);
                        if (storys.contains(storyInfo)) {
                            storys.remove(storyInfo);
                        } else {
                            long id = storyInfo.getId();
                            int size = storys.size();
                            for (int i = 0; i < size; i++) {
                                if (id == storys.get(i).getId()) {
                                    storys.remove(i);
                                    break;
                                }
                            }
                        }

                        int size = storyList.size();
                        currentIndex = index < size ? index : size - 1;
                        EventBus.getDefault().post(new ListenActivity.OnRefreshViewEvent(storyList, storys, currentIndex));
                        if (currentIndex == size - 1) {
                            EventBus.getDefault().post(new ListenActivity.StopEvent());
                        } else {
                            prepare(currentIndex);
                        }
                    }
                }

                @Override
                public void onException(String reason) {
                    ToastUtils.showToast(reason);
                }
            });
        } else {
            sessionId = PlayActionService.getSessionId();
            currentIndex = index;
            if (!isPause) {
                EventBus.getDefault().post(new StoryService.StartReadingEvent(this.storyList.get(currentIndex), startListenPosition, sessionId));
            } else {
                EventBus.getDefault().post(new StoryService.PauseReadingEvent(this.storyList.get(currentIndex), startListenPosition, sessionId));
            }

            mStoryInfo = storyList.get(currentIndex);
            final String soundFile = this.storyList.get(currentIndex).getSoundUrl();
            final int storyId = (int) this.storyList.get(currentIndex).getId();
            final int version = this.storyList.get(currentIndex).getVersion();
            final int collectId = (int) this.storyList.get(currentIndex).getCollectionId();


            if (mCurrentSoundUrl != null && TextUtils.equals(soundFile, mCurrentSoundUrl)) {
                if (mState == STATE_READY) {
                    LogHelper.d("MediaServer-playback", "prepare-Ready");
                } else {
                    if (mState == STATE_PLAYING) {
                        LogHelper.d("MediaServer-Playback", "mMediaPlayer.start");
                        maybeReportPlayerState(true);
                    } else if (mState == STATE_PAUSED) {
                        isReady = true;
                        nowMediaIsSelected = STORY_MEDIA;
                        play();
                    }
                }
            } else if (mCurrentSoundUrl == null
                    || !TextUtils.equals(soundFile, mCurrentSoundUrl)
                    || (TextUtils.equals(soundFile, mCurrentSoundUrl) && mState != STATE_PREPARING)) {

                LogHelper.d("MediaServer-playback", "prepare-start");
//                mState = STATE_IDLE;
//                lastReportedPlaybackState = STATE_IDLE;

                mCurrentSoundUrl = soundFile;

                if (!TextUtils.isEmpty(soundFile) && soundFile.contains("http://")) {
                    if (version > 0) {
                        Flowable.create(new GetStoryAsstFlowableOnSubscribe(storyId, version, collectId), BackpressureStrategy.BUFFER)
                                .subscribeOn(Schedulers.io())
                                .observeOn(AndroidSchedulers.mainThread())
                                .subscribe(new Consumer<String>() {
                                    @Override
                                    public void accept(String AESST) throws Exception {

                                        if (TextUtils.isEmpty(AESST)) {
                                            if (!NetworkUtils.isReachable()) {
                                                processNetworkError();
                                            } else {
                                                processError();
                                            }
                                        } else {
                                            String playUrl = MediaServer2.prepareStory(soundFile, storyId, version, collectId, Dirs.getListenCachePath(), AESST);
                                            prepare(playUrl);
                                        }
                                    }
                                });

                    } else {
                        prepare(soundFile);
                    }
                }
            }
        }

    }

    private static class GetStoryAsstFlowableOnSubscribe implements FlowableOnSubscribe<String> {
        private int mStoryId;
        private int mVersion;
        private int mCollectId;

        public GetStoryAsstFlowableOnSubscribe(int storyId, int version, int collectId) {
            mStoryId = storyId;
            mVersion = version;
            mCollectId = collectId;
        }

        @Override
        public void subscribe(FlowableEmitter<String> e) throws Exception {
            String AESST = CryptoKadaLib.getInstance().getStoryASST(mStoryId, mVersion, mCollectId, "");
            if (AESST == null) {
                AESST = "";
            }
            e.onNext(AESST);
            e.onComplete();
        }
    }


    void prepare(String url) {

        releaseMediaPlayer();
        MediaServer2.getInstance().removeSession(url);

        mDataSouce = url;
        mMediaPlayer = KdMediaPlayer.createMediaPlayer(mContext); // initialize it here
        mMediaPlayer.setLooping(false);
        mMediaPlayer.setWakeMode(mContext, PowerManager.PARTIAL_WAKE_LOCK);

        mMediaPlayer.setOnInfoListener(this);
        mMediaPlayer.setOnPreparedListener(this);
        mMediaPlayer.setOnErrorListener(this);
        mMediaPlayer.setOnBufferingUpdateListener(this);
        mMediaPlayer.setOnSeekCompleteListener(this);
        mMediaPlayer.setOnCompletionListener(this);

        try {
            mMediaPlayer.reset();
            if (url.contains("http://")) {
                mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mMediaPlayer.setDataSource(url);
                mMediaPlayer.prepareAsync();
            } else if (url.length() > 0) {
                mMediaPlayer.setDataSource(url);
                mMediaPlayer.prepare();
            } else {
                releaseMediaPlayer();
            }
        } catch (IllegalArgumentException e) {
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(MediaServer2.packageString("IllegalArgumentException in ListenManager#prepare : " + e.toString()),
//                            MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
            LogHelper.printStackTrace(e);
        } catch (IllegalStateException e) {
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(MediaServer2.packageString("IllegalStateException in ListenManager#prepare : " + e.toString()),
//                            MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
            LogHelper.printStackTrace(e);
        } catch (IOException e) {
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(MediaServer2.packageString("IOException in ListenManager#prepare : " + e.toString()),
//                            MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
            LogHelper.printStackTrace(e);
        }
        mState = STATE_PREPARING;

        maybeReportPlayerState();
    }


    public long getNowTime() {
//        return nowTime;
        long currentPosition = getCurrentPosition();
        LogHelper.d("timeChanged", "nowTime = " + currentPosition);

        StoryInfo storyInfo = getCurrentStoryInfo();
        if (storyInfo != null) {
            long totalTime = storyInfo.getTime();
            if (currentPosition > totalTime && totalTime > 0) {
                currentPosition = totalTime;
                //todo 也许这里手动触发一下onComplete()可以修复一个bug：长时间听书时，停在最后，不自动跳转下一本。bug复现的时候发现onComplete()没有调用。
                //todo 但是手动触发的话，可能会导致新问题
            }
        }

        return currentPosition;
    }

    public void play() {

        if (isCanPlay() && !isPlaying()) {

            isPausedByShortAudio = false;

            if (nowMediaIsSelected == BEGIN_MEDIA) {
                playBegin();
            } else if (nowMediaIsSelected == STORY_MEDIA) {
                playMedia();
            } else {
                playEnd();
            }
        }
    }

    void playBegin() {

        doPlayBegin = false;
        mState = STATE_PLAYING;
        maybeReportPlayerState();

        boolean hasBeginMediaPlayed = false;
        List<AudioInfo> mCurrentPlayAudios = mShortMediaPlayer.getCurrentPlayAudio();
        if (mCurrentPlayAudios != null && !mCurrentPlayAudios.isEmpty()) {
            for (AudioInfo audioInfo : mCurrentPlayAudios) {
                if (AudioName.STORY_BEGIN_AUDIO.equals(audioInfo.mAudioTag)) {
                    hasBeginMediaPlayed = true;
                    break;
                }
            }
        }

        if (hasBeginMediaPlayed) {
            mShortMediaPlayer.resume();
        } else {
            mShortMediaPlayer.addPlayQueue(R.raw.begin, PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_BEGIN_AUDIO);
        }
    }

    private void playMedia() {
        if (mMediaPlayer != null && !isPause) {
            LogHelper.d("MediaServer-Playback", "mMediaPlayer.start");
//            startTimer();
            mState = STATE_PLAYING;
            maybeReportPlayerState();

            try {
                mMediaPlayer.start();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    void playEnd() {
        mState = STATE_PLAYING;
        maybeReportPlayerState();

        boolean hasEndMediaPlayed = false;
        List<AudioInfo> mCurrentPlayAudios = mShortMediaPlayer.getCurrentPlayAudio();
        if (mCurrentPlayAudios != null && !mCurrentPlayAudios.isEmpty()) {
            for (AudioInfo audioInfo : mCurrentPlayAudios) {
                if (AudioName.STORY_END_AUDIO.equals(audioInfo.mAudioTag) || AudioName.STORY_END_FREE_AUDIO.equals(audioInfo.mAudioTag)) {
                    hasEndMediaPlayed = true;
                    break;
                }
            }
        }

        if (hasEndMediaPlayed) {
            mShortMediaPlayer.resume();
        } else {
            if (isFreeListen) {
                mShortMediaPlayer.addPlayQueue(R.raw.free_listen_end, PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_END_FREE_AUDIO);
            } else {
                mShortMediaPlayer.addPlayQueue(R.raw.end, PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_END_AUDIO);
            }
        }
    }

    public void pause(boolean isCommit) {
        LogHelper.d("MediaServer-playback", "pause");
        isPause = true;

//        pauseTimer();

        mShortMediaPlayer.pause();

        mState = STATE_PAUSED;
        maybeReportPlayerState();

        if (mMediaPlayer != null && isPlaying()) {
            LogHelper.d("MediaServer-Playback", "pause1");
            if (isCommit) {
                startListenPosition = getCurrentPosition();
                if (currentIndex >= 0 && storyList.size() > currentIndex) {
                    EventBus.getDefault().post(new StoryService.StopReadingEvent(mStoryInfo, false, true, startListenPosition, getCurrentPosition(), sessionId));
                }
            }

            try {
                mMediaPlayer.pause();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }
        }
    }

    public void stop() {
        LogHelper.d("MediaServer-playback", "stop");

        mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_BEGIN_AUDIO);
        mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_END_AUDIO);
        mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_END_FREE_AUDIO);

        if (mCurrentSoundUrl != null && mCurrentSoundUrl.length() > 0) {
            MediaServer2.getInstance().removeSession(mCurrentSoundUrl);
        }
//        if (mBeginMediaPlayer != null && mBeginMediaPlayer.isPlaying()) {
//            mBeginMediaPlayer.stop();
//        } else if (mEndMediaPlayer != null && mEndMediaPlayer.isPlaying()) {
//            mEndMediaPlayer.stop();
//        }
        startListenPosition = getCurrentPosition();

        if (storyList != null && currentIndex < storyList.size() && currentIndex >= 0) {
            EventBus.getDefault().post(new StoryService.StopReadingEvent(storyList.get(currentIndex), false, true, startListenPosition, getCurrentPosition(), sessionId));

            storyList.clear();
            currentIndex = -1;
        }

        releaseMediaPlayer();
        mCurrentSoundUrl = null;
        mDataSouce = null;
        isReady = false;
//        mPlayEventCallbacks.clear();

//        pauseTimer();

        mShortMediaPlayer.removeOnPlayListener(mOnPlayListener);
        mShortMediaPlayer.removeOnKdAudioFocusChangeListener(mAudioFocusChangeListener);
    }

    public void seek(int position) {
        LogHelper.d("MediaServer-playback", "seek");
//        nowTime = position;
        startListenPosition = position;


        // seek的时候 如果有正在播放的（包括暂停状态）开始/结束短音频，先将这个短音频停止掉；
        boolean hasBeginMediaPlayed = false;
        boolean hasEndMediaPlayed = false;
        boolean hasEndFreeListenMediaPlayed = false;
        List<AudioInfo> mCurrentPlayAudios = mShortMediaPlayer.getCurrentPlayAudio();
        if (mCurrentPlayAudios != null && !mCurrentPlayAudios.isEmpty()) {
            for (AudioInfo audioInfo : mCurrentPlayAudios) {
                if (AudioName.STORY_BEGIN_AUDIO.equals(audioInfo.mAudioTag)) {
                    hasBeginMediaPlayed = true;
                    break;
                } else if (AudioName.STORY_END_AUDIO.equals(audioInfo.mAudioTag)) {
                    hasEndMediaPlayed = true;
                    break;
                } else if (AudioName.STORY_END_FREE_AUDIO.equals(audioInfo.mAudioTag)) {
                    hasEndFreeListenMediaPlayed = true;
                    break;
                }
            }
        }

        // stop成功后 会有onStop回调
        if (hasBeginMediaPlayed) {
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_BEGIN_AUDIO);
            return;
        } else if (hasEndMediaPlayed) {
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_END_AUDIO);
            return;
        } else if (hasEndFreeListenMediaPlayed) {
            mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_END_FREE_AUDIO);
            return;
        }


        if (mMediaPlayer != null) {
            if (isPlaying()) {
                mState = STATE_BUFFERING;
                LogHelper.d("MediaServer-Playback", "seek STATE_BUFFERING");
            }

            try {
                mMediaPlayer.seekTo(position);
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            maybeReportPlayerState();
        }
    }


    void switchNextStory() {
//        pauseTimer();

//        if (currentIndex >= 0 && currentIndex < storyList.size()) {
//            EventBus.getDefault().post(new StoryService.StopReadingEvent(storyList.get(currentIndex), true, true, 0));
//        }
        if (!isPause) {
            if (isSingleCycle) {
                nowMediaIsSelected = STORY_MEDIA;
                seek(0);
            } else {
                mState = STATE_ENDED;
                maybeReportPlayerState();
                if (storyList != null && currentIndex + 1 < storyList.size()) {
                    StoryInfo info = storyList.get(currentIndex + 1);

                    //下一本为收费 则停止播放
                    if (info.getType() == StoryInfo.TYPE_STORY && info.getCollectionId() != 0 && info.getSubscribe() != 1 && (info.getExtFlag() & Extflag.STORY_EXT_FLAG_256) != Extflag.STORY_EXT_FLAG_256) {
                        currentIndex++;
                        switchNextStory();
                    } else {
                        startListenPosition = 0;
                        prepare(currentIndex + 1);
                    }
                } else {
                    mState = STATE_PAUSED;
                    nowMediaIsSelected = STORY_MEDIA;
                    isPause = true;
//                    nowTime = 0;

                    stop();
                    EventBus.getDefault().post(new MainActivityController.OnHideFloatingWindowEvent());
                }
            }
        }

    }

    @Override
    public void onBufferingUpdate(MediaPlayer mp, int percent) {

    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        LogHelper.d("MediaServer-playback", "onCompletion");
        int duration = mp.getDuration();
        int currentPosition = mp.getCurrentPosition();
        if (duration != currentPosition) {
            LogHelper.e("MediaServer-playback", "未播放完，就算作结束了。duration=" + duration + ",current=" + currentPosition);
            //上报打点
//            UserHabitService.getInstance().trackHabit2Umeng(
//                    UserHabitService.newUserHabit(MediaServer2.packageString("未播放完，就算作结束了。duration=" + duration + ",current=" + currentPosition),
//                            MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
        }

        if (currentIndex >= 0 && currentIndex < storyList.size()) {
            EventBus.getDefault().post(new StoryService.StopReadingEvent(storyList.get(currentIndex), true, true, 0, getCurrentPosition(), sessionId));
        }

        if (isPlayNext) {
            isPlayNext = false;

            switchNextStory();
        } else {
            playEnd();
        }

//        pauseTimer();
    }

    @Override
    public boolean onError(MediaPlayer mp, int what, int extra) {
        //故意播放经过修改的文件时，会触发：error (1, -2147483648)
        LogHelper.d("MediaServer-playback", "error:" + what);
        //上报收集
//        UserHabitService.getInstance().trackHabit2Umeng(
//                UserHabitService.newUserHabit(MediaServer3.packageString("ListenManager. Media player error: what=" + what + ", extra=" + extra),
//                        MediaServer3.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
//        for (Listener mCallback : mPlayEventCallbacks) {
//            mCallback.handleErrorOccured();
        ToastUtils.showToast("加载音频失败");
//        }
//        pauseTimer();

        if (!NetworkUtils.isReachable()) {
            processNetworkError();
        } else {
            processError();
        }

        return true; // true indicates we handled the error
    }

    public static final int MEDIA_INFO_BUFFERING_START = 701;
    public static final int MEDIA_INFO_BUFFERING_END = 702;
    public static final int MEDIA_INFO_NOT_SEEKABLE = 801;
    public static final int MEDIA_INFO_TIMED_TEXT_ERROR = 972;

    @Override
    public boolean onInfo(MediaPlayer mediaPlayer, int i, int i1) {
        //http://blog.csdn.net/wufen1103/article/details/8085541
        if (i == MEDIA_INFO_BUFFERING_START) {
            LogHelper.d("MediaServer-playback", "info-i STATE_BUFFERING:");
            mState = STATE_BUFFERING;
            maybeReportPlayerState();
//            pauseTimer();
        } else if (i == MEDIA_INFO_BUFFERING_END) {
            if (!isPause) {
//                startTimer();
                mState = STATE_READY;
                maybeReportPlayerState();
                LogHelper.d("MediaServer-playback", "info-i READY:");
            }
        } else if (i == MEDIA_INFO_TIMED_TEXT_ERROR) {
            LogHelper.d("MediaServer-playback", "info-i: MEDIA_INFO_TIMED_TEXT_ERROR");
            reset();
//            pauseTimer();
        } else {
            LogHelper.d("MediaServer-playback", "info-i:" + i);
//            pauseTimer();
        }
        return false;
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        LogHelper.d("MediaServer-playback", "prepare-done");

        if (mMediaPlayer != null) {
            int duration = 0;

            try {
                duration = mMediaPlayer.getDuration();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            EventCenter.fireEvent(new ListenActivityAudioTimeEvent(duration));
        }
//        pauseTimer();
//        mTime = getDuration();
//        nowTime = 0;
        isReady = true;
        if (!isPlaying() && !isPause) {
            mState = STATE_READY;
            maybeReportPlayerState();

            if (doPlayBegin) {
                doPlayBegin = false;
                nowMediaIsSelected = BEGIN_MEDIA;
                play();
            } else {
                nowMediaIsSelected = STORY_MEDIA;
                if (startListenPosition == getCurrentPosition()) {
                    play();
                } else {
                    seek((int) startListenPosition);
                }
            }
        }
    }

    @Override
    public void onSeekComplete(MediaPlayer mp) {
        LogHelper.d("MediaServer-playback", "onSeekComplete from MediaPlayer:");
        if (!isPause && !isPlaying()) {
//            startTimer();
            if (storyList.size() > currentIndex && currentIndex >= 0) {
                if (!needPostEvent) {
                    EventBus.getDefault().post(new StoryService.StartReadingEvent(this.storyList.get(currentIndex), startListenPosition, sessionId));
                }
            }
            LogHelper.d("MediaServer-playback", "onSeekComplete from MediaPlayer: start");

            try {
                mMediaPlayer.start();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            mState = STATE_PLAYING;
            maybeReportPlayerState(true);
        }
    }

    public void reset() {
        if (mMediaPlayer != null && mDataSouce != null) {
            try {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.pause();
                }
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            try {
                mMediaPlayer.reset();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            try {
                mMediaPlayer.setDataSource(mDataSouce);
                mMediaPlayer.prepareAsync();
            } catch (IOException e) {
//                UserHabitService.getInstance().trackHabit2Umeng(
//                        UserHabitService.newUserHabit(MediaServer2.packageString("IOException in ListenManager#reset : " + e.toString()),
//                                MediaServer2.UMENG_TAG_AUDIODECRYPTPLAY, TimeUtil.currentTime()));
                LogHelper.printStackTrace(e);
            }

            mState = STATE_PREPARING;
            maybeReportPlayerState();
        }
    }

    public int getDuration() {
        LogHelper.d("MediaServer-playback", "getDuration");

        int duration = 0;

        try {
            if (mMediaPlayer != null) {
                duration = mMediaPlayer.getDuration();
            }
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return duration;
    }

    public void setFreeListen(boolean freeListen) {
        isFreeListen = freeListen;
    }

    public boolean isCanPlay() {
        LogHelper.d("MediaServer-playback", "isCanPlay");
        //mState == STATE_READY || mState == STATE_PAUSED || mState == STATE_PLAYING

        return !isPause && isReady;
    }

    public boolean isPlaying() {
        LogHelper.d("MediaServer-playback", "isPlaying");

        boolean isPlaying = false;
        try {
            if (mMediaPlayer != null) {
                isPlaying = mMediaPlayer.isPlaying();
            }
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return isPlaying;
    }

    /**
     * @return 如果听书或者开始、结束音有在播放 返回true，如果都没有播放 返回false
     */
    public boolean isPlayingOrPromptAudioPlaying() {
        return isPlaying() || isBeginAudioPlaying() || isEndAudioPlaying();
    }

    public boolean isBeginAudioPlaying() {
        return isBeginAudioPlaying;
    }

    public boolean isEndAudioPlaying() {
        return isEndAudioPlaying;
    }

    public long getCurrentPosition() {
        LogHelper.d("MediaServer-playback", "getCurrentPosition");

        int currentPosition = 0;

        try {
            if (mMediaPlayer != null) {
                currentPosition = mMediaPlayer.getCurrentPosition();
            }
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        return currentPosition;
    }

    public StoryInfo getCurrentStoryInfo() {
        if (storyList != null && storyList.size() > currentIndex && currentIndex >= 0) {
            return storyList.get(currentIndex);
        }
        return null;
    }


    void maybeReportPlayerState() {
        maybeReportPlayerState(false);
    }

    void maybeReportPlayerState(boolean byForce) {
        if (lastReportedPlaybackState != mState || byForce) {
//            for (PlayEventCallback callbackTmp : mPlayEventCallbacks) {
//                callbackTmp.handleStateChanged(mState);
//            }
            if (mState == STATE_PREPARING) {
                LogHelper.d("MediaServer-PlaybackActivity-Callback", "STATE_PREPARING");
                for (Listener callback : mPlayEventCallbacks) {
                    callback.handleLoadding();
                }
            } else if (mState == STATE_BUFFERING) {
                LogHelper.d("MediaServer-PlaybackActivity-Callback", "STATE_BUFFERING");
                for (Listener callback : mPlayEventCallbacks) {
                    callback.handlePaused();
                }
            } else if (mState == STATE_READY) {
                LogHelper.d("timeChanged", "STATE_READY");
                for (Listener callback : mPlayEventCallbacks) {
                    callback.handleStartPlaying();
                }
            } else if (mState == STATE_ENDED) {
                LogHelper.d("MediaServer-PlaybackActivity-Callback", "STATE_ENDED");
                //判断,开始播放
                for (Listener callback : mPlayEventCallbacks) {
                    callback.handleCompletion();
                }
            } else if (mState == STATE_PLAYING) {
                LogHelper.d("timeChanged", "STATE_PLAYING");
                LogHelper.d("MediaServer-PlaybackActivity-Callback", "STATE_PLAYING");
                for (Listener callback : mPlayEventCallbacks) {
                    callback.handleStartPlaying();
                }
            } else if (mState == STATE_PAUSED) {
                LogHelper.d("MediaServer-PlaybackActivity-Callback", "STATE_PAUSED");
                for (Listener callback : mPlayEventCallbacks) {
                    callback.handlePaused();
                }
            }
            lastReportedPlaybackState = mState;
        }
    }

    private void releaseMediaPlayer() {
        if (mMediaPlayer != null) {

            try {
                mMediaPlayer.stop();
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }

            ReleaseMediaPlayerRunnable runnable = new ReleaseMediaPlayerRunnable(mMediaPlayer);
            ((IThread) ServiceProxyFactory.getProxy().getService(ServiceProxyName.THREAD_SERVICE)).postDaemonTask(runnable, "StoryReleaseMediaPlayerJob");

            mMediaPlayer = null;
        }
    }

//    public void pauseTimer(){
//        Log.d("timeChanged", "pauseTimer");
//        if (timer != null) {
//            timer.cancel();
//            timer = null;
//        }
//    }
//
//    public void startTimer(){
//        Log.d("timeChanged", "startTimer");
//        if (timer == null) {
//            Log.d("timeChanged", "startTimer1");
//            timer = new Timer();
//            timer.schedule(new TimerTask() {
//                @Override
//                public void run() {
//                    //发送广播
//                    timeChanged();
//                }
//            }, 1000, 1000);
//        }
//    }

    public int getNowSelectId() {
        if (storyList.size() > currentIndex && currentIndex >= 0) {
            return (int) storyList.get(currentIndex).getId();
        }
        return 0;
    }

    public StoryInfo getNowStory() {
        if (storyList.size() > currentIndex && currentIndex >= 0) {
            return storyList.get(currentIndex);
        }
        return null;
    }

    public void setStoryList(List<StoryInfo> storyList) {
        this.storyList.clear();
        this.storyList.addAll(storyList);
    }

    public List<StoryInfo> getStoryList() {
        return storyList;
    }

    public List<StoryInfo> getStorys() {
        return storys;
    }

    public void setStorys(List<StoryInfo> storys) {
        this.storys.clear();
        this.storys.addAll(storys);
    }

    public void setCollectId(int collectId) {
        this.collectId = collectId;
    }

    public int getCollectId() {
        return collectId;
    }

    public int getCollectionExtFlag() {
        return collectionExtFlag;
    }

    public void setCollectionExtFlag(int collectionExtFlag) {
        this.collectionExtFlag = collectionExtFlag;
    }

    public void setPause(boolean pause) {
        isPause = pause;
    }

    public boolean isPause() {
        return isPause;
    }

    public void setPausedByShortAudio(boolean pausedByShortAudio) {
        isPausedByShortAudio = pausedByShortAudio;
    }

    public boolean isPausedByShortAudio() {
        return isPausedByShortAudio;
    }

    public int getCurrentIndex() {
        return currentIndex;
    }

    public void setStartListenPosition(long startListenPosition) {
        this.startListenPosition = startListenPosition;
    }

    public void setIsSingleCycle(boolean isSingleCycle) {
        this.isSingleCycle = isSingleCycle;
    }

    public boolean isSingleCycle() {
        return isSingleCycle;
    }

    public void setShortAudioOnStoppedContinueListen(boolean shortAudioOnStoppedContinueListen) {
        isShortAudioOnStoppedContinueListen = shortAudioOnStoppedContinueListen;
    }

    public void onDestory() {

        if (mShortMediaPlayer != null) {
            mShortMediaPlayer.removeOnKdAudioFocusChangeListener(mAudioFocusChangeListener);
            mShortMediaPlayer.removeOnPlayListener(mOnPlayListener);
        }

        try {
            if (mMediaPlayer != null) {
                mMediaPlayer.release();
            }
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        mListenManager = null;

    }

    private OnPlayListener mOnPlayListener = new OnPlayListener() {
        @Override
        public void onPrepared(String audioTag, int playMode) {
            if (AudioName.STORY_BEGIN_AUDIO.equals(audioTag)) {
                isBeginAudioPlaying = true;
            } else if (AudioName.STORY_END_AUDIO.equals(audioTag) || AudioName.STORY_END_FREE_AUDIO.equals(audioTag)) {
                isEndAudioPlaying = true;
            }
        }

        @Override
        public void onCompletion(String audioTag, int playMode) {
            if (AudioName.STORY_BEGIN_AUDIO.equals(audioTag)) {
                isBeginAudioPlaying = false;

                nowMediaIsSelected = STORY_MEDIA;
                playMedia();
            } else if (AudioName.STORY_END_AUDIO.equals(audioTag) || AudioName.STORY_END_FREE_AUDIO.equals(audioTag)) {
                isEndAudioPlaying = false;

                switchNextStory();
            }
        }

        @Override
        public void onError(String audioTag, int playMode) {
            if (AudioName.STORY_BEGIN_AUDIO.equals(audioTag)) {
                isBeginAudioPlaying = false;

                nowMediaIsSelected = STORY_MEDIA;
                playMedia();
            } else if (AudioName.STORY_END_AUDIO.equals(audioTag) || AudioName.STORY_END_FREE_AUDIO.equals(audioTag)) {
                isEndAudioPlaying = false;

                switchNextStory();
            }
        }

        @Override
        public void onStop(String audioTag, int playMode) {
            if (AudioName.STORY_BEGIN_AUDIO.equals(audioTag)) {
                isBeginAudioPlaying = true;
                isPlayNext = false;
            } else if (AudioName.STORY_END_AUDIO.equals(audioTag) || AudioName.STORY_END_FREE_AUDIO.equals(audioTag)) {
                isEndAudioPlaying = true;
                isPlayNext = true;
            }

            if (!isShortAudioOnStoppedContinueListen) {
                return;
            }

            if (AudioName.STORY_BEGIN_AUDIO.equals(audioTag)) {
                nowMediaIsSelected = STORY_MEDIA;
                if (startListenPosition == getCurrentPosition()) {
                    playMedia();
                } else {
                    seek((int) startListenPosition);
                }
            } else if (AudioName.STORY_END_AUDIO.equals(audioTag) || AudioName.STORY_END_FREE_AUDIO.equals(audioTag)) {
                if (startListenPosition == getCurrentPosition()) {
                    switchNextStory();
                } else {
                    seek((int) startListenPosition);
                }
            }
        }
    };

    private void processError() {
        for (Listener callback : mPlayEventCallbacks) {
            callback.handleError();
        }

        release();
    }

    private void processNetworkError() {
        for (Listener callback : mPlayEventCallbacks) {
            callback.handleNetworkError();
        }

        release();
    }

    private void release() {
        mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_BEGIN_AUDIO);
        mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_END_AUDIO);
        mShortMediaPlayer.stop(PlayMode.IMMEDIATELY_PLAY_MODE, AudioName.STORY_END_FREE_AUDIO);

        if (mCurrentSoundUrl != null && mCurrentSoundUrl.length() > 0) {
            MediaServer2.getInstance().removeSession(mCurrentSoundUrl);
        }

        startListenPosition = getCurrentPosition();

        if (storyList != null && currentIndex < storyList.size() && currentIndex >= 0) {
            EventBus.getDefault().post(new StoryService.StopReadingEvent(storyList.get(currentIndex), false, true, startListenPosition, getCurrentPosition(), sessionId));
        }

        try {
            if (mMediaPlayer != null) {
                mMediaPlayer.stop();
            }
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        try {
            if (mMediaPlayer != null) {
                mMediaPlayer.release();
            }
        } catch (Throwable e) {
            LogHelper.printStackTrace(e);
        }

        isPause = true;
        mCurrentSoundUrl = null;
        mDataSouce = null;
        mState = STATE_IDLE;
        isReady = false;

        EventBus.getDefault().post(new MainActivityController.OnHideFloatingWindowEvent());
    }

    public interface Listener {
        void handleLoadding();//加载中

        void handleStartPlaying(); //开始播放

        void handlePaused(); //播放暂停一般是由手动触发

        void handleCompletion(); //这一段播放完成了

        void handleNetworkError();

        void handleError();
    }
}
