package com.hhdd.kada.main.listen;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.IBinder;
import android.widget.RemoteViews;

import com.hhdd.core.model.StoryInfo;
import com.hhdd.kada.CdnUtils;
import com.hhdd.kada.KaDaApplication;
import com.hhdd.kada.R;
import com.hhdd.kada.main.ui.activity.MainActivity;
import com.hhdd.kada.main.utils.FrescoUtils;
import com.hhdd.logger.LogHelper;

/**
 * Created by lj on 17/1/5.
 */

public class ListenService2 extends Service {

    public static final String INTENT_ACTION = "com.hhdd.kada.listen.services";
    public static final String INTENT_PARAM_TYPE = "type";
    public static final String INTENT_PARAM_INDEX = "index";
    public static final String INTENT_PARAM_START_POSITION = "listenPosition";
    public static final String INTENT_PARAM_RESET = "isReset";
    public static final String INTENT_PARAM_NEED_COMMIT = "needcommit";
    public static final String INTENT_PARAM_NOTIFICATION_INFO = "notificationInfo";
    public static final String INTENT_PARAM_IS_PLAYING = "isPlaying";
    public static final String INTENT_PARAM_REMOVE_NOTIFICATION = "removeNotification";

    private static final int NOTIFY_ID = 200;

    private RemoteViews mRemoteViews;
    private Notification notify;

    private boolean isMusicPlayStopped = false;

    public static class Types {
        public static final int START = 1;
        public static final int PAUSE = 2;
        public static final int STOP = 3;
        public static final int SEEK = 4;
    }

    private static ListenService2 sInstance;
    private static ListenManager listenManager;

    public static void stopService() {
        if (sInstance != null) {
            sInstance.stopSelf();
            sInstance = null;
        }
    }


    @Override
    public IBinder onBind(Intent i) {
        throw new UnsupportedOperationException("Cannot bind to Download Manager Service");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        listenManager = ListenManager.getInstance();
    }

    @Override
    public void onDestroy() {

        stopForeground(true);

        if (!isMusicPlayStopped) {
            Intent intent = new Intent("com.hhdd.listen.destroy");
            KaDaApplication.applicationContext().sendBroadcast(intent);
        }

        super.onDestroy();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        int ret = super.onStartCommand(intent, flags, startId);
        if (intent == null || intent.getAction() == null) {
            return ret;
        }

        if (!intent.getAction().equals(INTENT_ACTION)) {
            return ret;
        }

        int type = intent.getIntExtra(INTENT_PARAM_TYPE, -1);
        if (type == -1) {
            return ret;
        }

        isMusicPlayStopped = false;

        if (type == Types.START) {
            /**
             * 开始播放 以{@link #startForeground(int, Notification)}方式显示通知栏
             */

            StoryInfo storyInfo = null;
            Object obj = intent.getSerializableExtra(INTENT_PARAM_NOTIFICATION_INFO);
            if (obj instanceof StoryInfo) {
                storyInfo = (StoryInfo) obj;
            }

            try {
                Intent openIntent = new Intent(this, MainActivity.class);
                PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, openIntent, 0);

                mRemoteViews = new RemoteViews(getPackageName(), R.layout.layout_notification);

                Notification.Builder mBuilder = new Notification.Builder(this);

                if (Build.VERSION.SDK_INT >= 26) {

                    mBuilder.setContent(mRemoteViews)
                            .setContentIntent(pendingIntent)
                            .setWhen(System.currentTimeMillis() + 500) // 通知产生的时间，会在通知信息里显示
                            .setPriority(Notification.PRIORITY_DEFAULT) // 设置该通知优先级
                            .setOngoing(true)
                            .setSmallIcon(R.drawable.app_icon_alpha)  //这个属性必须设置，否则notification不能显示
                            .setAutoCancel(true);
                    notify = mBuilder.build();
                    notify.flags = Notification.FLAG_AUTO_CANCEL;

                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    mBuilder.setContent(mRemoteViews)
                            .setContentIntent(pendingIntent)
                            .setWhen(System.currentTimeMillis() + 500) // 通知产生的时间，会在通知信息里显示
                            .setPriority(Notification.PRIORITY_DEFAULT) // 设置该通知优先级
                            .setOngoing(true)
                            .setSmallIcon(R.drawable.app_icon_48)  //这个属性必须设置，否则notification不能显示
                            .setAutoCancel(true);
                    notify = mBuilder.build();
                    notify.flags = Notification.FLAG_AUTO_CANCEL;

                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                    mBuilder.setContent(mRemoteViews)
                            .setContentIntent(pendingIntent)
                            .setWhen(System.currentTimeMillis() + 500) // 通知产生的时间，会在通知信息里显示
                            .setOngoing(true)
                            .setSmallIcon(R.drawable.app_icon_48)  //这个属性必须设置，否则notification不能显示
                            .setAutoCancel(true);
                    notify = mBuilder.getNotification();
                    notify.priority = Notification.PRIORITY_DEFAULT;
                    notify.flags = Notification.FLAG_AUTO_CANCEL;
                }
            } catch (Throwable e) {
                LogHelper.printStackTrace(e);
            }


            if (storyInfo != null && mRemoteViews != null) {
                mRemoteViews.setTextViewText(R.id.tv_notification_des, storyInfo.getName());

                String coverUrl = CdnUtils.getImgCdnUrl(storyInfo.getCoverUrl(), true);

                FrescoUtils.fetchDecodedImage(coverUrl, this, new FrescoUtils.FetchImageCallback() {
                    @Override
                    public void handleResult(Bitmap bitmap) {
                        if (bitmap != null && !bitmap.isRecycled()) {

                            mRemoteViews.setImageViewBitmap(R.id.iv_notification_content, bitmap);
                            startForeground(NOTIFY_ID, notify);
                        } else {

                            mRemoteViews.setImageViewResource(R.id.iv_notification_content, R.drawable.app_icon);
                            startForeground(NOTIFY_ID, notify);
                        }
                    }
                });

            }
        } else if (type == Types.PAUSE || type == Types.STOP) {
            /**
             * 停止播放 并remove通知栏
             */

            boolean removeNotification = intent.getBooleanExtra(INTENT_PARAM_REMOVE_NOTIFICATION, false);
            if (removeNotification) {
                stopForeground(true);
            }

            isMusicPlayStopped = true;
        }


        switch (type) {
            case Types.START: {
                int index = intent.getIntExtra(INTENT_PARAM_INDEX, 0);
                long startPosition = intent.getLongExtra(INTENT_PARAM_START_POSITION, 0);
                boolean reset = intent.getBooleanExtra(INTENT_PARAM_RESET, false);

                listenManager.setPause(false);

                if (!reset && index == listenManager.getCurrentIndex()) {

                    if (listenManager.isCanPlay() && listenManager.getCurrentPosition() == startPosition) {
                        listenManager.play();
                    } else if (listenManager.isCanPlay() && listenManager.getCurrentPosition() != startPosition) {
                        listenManager.setNeedPostEvent(false);
                        listenManager.seek((int) startPosition);
                    } else {
                        listenManager.setStartListenPosition(startPosition);
                        listenManager.prepare(index);
                    }
                } else {
                    listenManager.setStartListenPosition(startPosition);
                    listenManager.prepare(index);
                }
            }
            break;

            case Types.PAUSE: {
                boolean needcommit = intent.getBooleanExtra(INTENT_PARAM_NEED_COMMIT, false);
                listenManager.setPause(true);
                listenManager.pause(needcommit);
            }
            break;

            case Types.STOP: {
                listenManager.setPause(true);
                listenManager.stop();
            }
            break;

            case Types.SEEK: {
//                    int index = intent.getIntExtra(INTENT_PARAM_INDEX,0);
                long startPosition = intent.getLongExtra(INTENT_PARAM_START_POSITION, 0);
                boolean isPlaying = intent.getBooleanExtra(INTENT_PARAM_IS_PLAYING, false);

                listenManager.setPause(false);
                listenManager.setNeedPostEvent(isPlaying);
                listenManager.seek((int) startPosition);
            }
            break;

            default:
                break;
        }

        return START_STICKY;
    }

}
